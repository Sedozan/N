# v6 (2026-10-14 to 2026-10-16): does each source reach the master rule table, accurately?

SB's question: does the pipeline really take the NCCI files, the FFS manual PDFs and the AHCCCS tables and put every
rule they state into the master rule table, accurately, without needless complexity? Four agents each audited one area
against the primary sources (CMS, AHCCCS), fixed what they could prove, and then reviewed another agent's changes
without having seen them. Four more agents read the 36 live PDFs and recorded every rule the manual states (852,
verbatim, with page and section: `manual_rule_inventory_2026-10-15.xlsx`, delivered next to this package) so the
extractor's recall could be measured against something independent.

## 1. Federal: CMS Medicaid NCCI to the master table

**What was right.** Every row of every file is parsed or the file is refused; '*' or blank deletion date = open-ended;
indicator 9 and effective = deletion rows are skipped (TGM App. B); the deletion date is inclusive; each edit keeps its
window and its edit file. PTP files are cumulative, so the newest file per edit file holds every edit with its dates
(TGM 2026 s7.1.1: the public current-quarter files contain all PTP edits of the RISSNET files, which hold "every past and
present Medicaid NCCI edit"). MUE files are NOT cumulative ("do not contain the MUEs that are no longer in effect"), so
every MUE quarter since the claims start is needed.

**Defects fixed.**
- **A live PTP edit could lose every claim before the newest quarter.** The modifier-indicator comparison across
  quarters counted rows that never take effect (indicator 9 / effective = deletion) and keyed on (pair, effective date):
  a retro-deleted 9-row next to a live 1-row read as a change, the most permissive value ('9' = no edit) was applied
  before the newest quarter, and the edit vanished for 2024-10-01 to 2026-03-31. Now only live rows, keyed on (pair,
  effective, deletion), as 01 check C. (Found by the cross-review.)
- **Two edit files could merge.** A legacy rule row carrying `ncci_edition` gave that file to every rebuilt member, and
  the collapse merged a practitioner indicator 0 with an outpatient indicator 1 into one '1' rule. Such a rule is now
  refused and counted.
- **MUE gaps.** With gaps allowed, a value used to be carried across a missing quarter (flagged, still compiled). Now the
  MUE run closes at the missing quarter: no claim is ever judged by an inferred value. Because a gap now only loses
  recall, `NCCI_ALLOW_MUE_GAPS` defaults to True and the gap is listed in 01, the 07 build log, v03 and d08.
- **Freshness was measured from the first loaded quarter**, so "MUE starts 2026-04-01, claims start 2024-10-01" passed
  as GO. It is now measured from the claims start (`acquire_ncci.ncci_freshness`), with the lines and dollars before each
  file's first quarter.

**New.**
- `policy_ncci_edits_master` (07): every row of the newest PTP file per edit file and of every loaded MUE quarter, not
  scoped to the claims, with its window and status (`in_force`, `deleted_retroactive`, `effective_equals_deletion`,
  refused reasons). Built in Spark (3.97M rows in 29 s on 2 cores; the same as Python rule objects would take about 6
  minutes and 7 GB). A test pins that its in-force rows on paid codes equal the rules ingest builds. Detection stays
  scoped to paid codes.
- 00 `ARCHIVE = True` loads CMS's Medicaid MUE archive from the claims' first date of service (`HISTORY_FROM` to start
  elsewhere). CMS's archive lacks DME 2025Q2 (its link points to the practitioner zip): that quarter gets no DME MUE
  check. 2025Q1 exists only as revision r1 ("Effective Jan. 29, 2025") and is applied from Jan 1, with a warning.

**Routing (which edit file a line takes).**
- **D2:** a group billing type (`01`) routes on the line's rendering (servicing) type; a group line with no usable
  servicing type takes no file. Before, `01` had its own `practitioner` row, so school attendant care (93, 1.70M lines),
  school bus (92, 1.51M), FQHC (C2), integrated clinics (IC) and BH clinics (77) billed through a group took the
  practitioner file. AHCCCS FFS Ch3 p3: the servicing provider "cannot be ... type '01', a Group Billing Entity".
- **D1:** a line takes a file only through a SIGNED routing row; the 08 gate that skipped NCCI for everyone when any
  type was unsigned is gone. With nothing signed, NCCI runs and checks 0%; 01 shows the share it will check once rows
  are signed (98.9% of form A/O dollars on the test fixture), and 08 lists the unsigned types and the group lines no
  row routes, with lines and dollars. `NCCI_REQUIRE_SIGNED_ROUTING = False` previews on the proposed rows.
- The exploratory switches `NCCI_ROUTE_BY` ("form" / "provider_type") and `NCCI_UNMAPPED_PROVIDER_TYPE` ("form") are
  removed: one routing rule, no guessed edit file.
- `reference/ncci_provider_type_routing.csv`: 12 categories corrected with a citation in `note`, all still `proposed`:
  `01` to not_applicable (AHCCCS Group Biller one-pager; FFS Ch3 p3); `D1`, `D2`, `D3` to practitioner (TGM Table 2
  footnote 14: dentists are physician practitioners, like `07`); `93`, `40`, `37`, `A8`, `HC`, `27`, `38`, `G2` to
  other_outpatient (TGM footnote 22: outpatient services in homes and schools by non-practitioners; s5.2). They change
  no finding while CMS's optional rows stay off. Row `43` (ASC) keeps `asc` with the source conflict recorded: CMS sends
  ASCs to the practitioner file, AHCCCS Ch16 says ASCs follow the facility outpatient fee schedule's CCI.

**01 preflight.** Check C keys on (pair, effective, deletion) and ignores rows that never take effect (the 9->1 / 1->9
pairs were one key over two rows); check 4 is information only (07 never collapses across edit files); check T no longer
crashes on Decimal dollars; new check I lists lines, dollars and the share with a procedure code per claim form; the
verdict is split into "SAFE TO BUILD" and "NCCI WILL CHECK N% of form A/O paid dollars".

## 2. State manual: PDF to drafts

**Recall.**
- **D4 hub lists.** "X shall / may / cannot / must not be billed with A, B, C" pairs X (the finding line) with each
  listed code, never two listed codes, never X with itself. The six Ch19 day-program sentences give exactly their 95
  pairs; "S109" becomes a lead for the reviewer, never rewritten; "... or any other per diem code" adds a category lead;
  "H2025, H2026, and H2027 cannot be billed on the same day" gives every pair. A list that carries a condition, a
  partner that is not a code (a modifier, a place of service), a second clause ("but shall not ...") or words after the
  list ("on the same claim") gives a lead, never a pair (found by the cross-review).
- The PDF reader lost list items after a wrapped "S109," or ", or" and glued a run-in heading onto a list; fixed.
- Grounding dropped a correct quote made of a lead-in plus a later bullet ("Do not bill for CPT codes:" ... "11977":
  the Norplant rule); it now accepts it, and stops at the next lead-in so an item of another list never grounds.
- Unit caps read thousands commas ("2,400 units per benefit year"); limits stated in hours ("600 hours per benefit
  year", "5 hours or less") and "may only be billed for members who ... Medicare" become leads (derived units noted).
- The prompt states these shapes with examples from the manual. Because the prompt and the pattern layer changed, the
  engine is now labelled **v3** (`extract_rules.PROMPT_VERSION`; the prompt's sha256 is in the cache key) and
  `KB_PROMPT_VERSIONS` defaults to ("v2", "v3"): rules decided on v2 drafts keep compiling, v3 runs add to them.
- Measured on the 852-rule inventory (each quote through patterns, grounding and post-checks): the pattern layer alone
  produced 6 rules correctly before and 30 after (11 executable, 19 leads), 0 wrong before and after; Ch19 pairs from
  the hub sentences 37 before, 132 after. Most of the manual (provider-type lists, claim forms, PA, member programs) is
  for the model and the reviewer: deterministic patterns there would flag lawful claims.

**Governance.**
- **Lost decisions.** A reviewer's decision on a draft that a later run of the same document version superseded was
  "ignored: row is superseded": that is how the 21 Ch19 decisions were lost. It now applies.
- An approved rule a run on a NEW document version did not reproduce now goes to `needs_review` with a note saying
  whether its quote is still in the new version; 06 parks a plain Approve when it is not (a Fix with the new sentence is
  needed). Before, it stayed approved, was silently excluded by 07, and nobody saw it.
- The review export marks a pending draft on the same sentence as an already decided rule.
- Each PDF's revision-history table is parsed (dates as printed; an undated row stays undated) and every draft's note
  lists the entries that name its section or codes: a hint for the reviewer, never a start date.
- The extraction log's model calls and failures are per chapter (they were running totals: 6, 15, 39 ... 198).

## 3. AHCCCS tables, build and run

- **Audit.** Every cell and row of a version is read or the file refused; rules derive as QUERY_SEMANTICS 2b says. What
  was not compiled was only counted; it is now listed with its cell or row in `policy_ahcccs_conflicts` (daily-limit
  period limits, Same Day diagonal cells, B2 codes outside H0xxx / H2xxx), never counted as a contradiction.
- **D3.** A chapter pair that a loaded Same Day version marks A (allowed) stays executable up to the day before that
  version (and again from a later version that no longer allows it); the allowed period becomes a lead. Note: the 13
  Ch19 pairs were made leads by the 2026-10-06 REVIEW, not by 07; to date them, the reviewer re-signs each with its
  original pair predicate and 07 does the rest.
- **One contradiction register** (definition of done, pillar 6): `policy_ahcccs_conflicts` now holds every conflict
  kind computed (table vs chapter, table vs itself, state not covered vs federal edit, review `cross_source_conflict`
  leads) with both sources quoted, the window, the nature and a suggested resolution path. The build log's
  `contradiction_candidates` counts it; v03 shows that count by relationship (it used to add three overlapping lists).
- **D6 coverage.** Coverage counts a rule only when its statement ran: 08 writes `pct_paid_ran_any / _state / _federal`
  and the same over procedure-coded lines into the `RUN:snapshot` row; v03 and d04 read that. 07 no longer reports a
  "covered" share (it counted rules that never ran: the 45.76% of build B20261008T231304).
- The ambiguity register gains `in_build` (lead / compiled_flagged / compiled_and_lead / pending_review / excluded:...):
  it explains 433 entries against 235 leads (the register holds every non-rejected state row, drafts included).
- 08 reports a code pair flagged by both a state rule and a Same Day table rule (dollars counted twice).
- v06's NCCI scenarios follow the routing in force (they would have FAILed under D1 with unsigned rows); 00b no longer
  crashes on an empty drop zone; d01 prints the edit file and what each AHCCCS table says about the code.
- **Earlier table versions.** AHCCCS overwrites each file at the same address. Versions referenced elsewhere: Same Day
  04/03/2025 and 11/12/2025 (ClaimsClues May 2025, January 2026), 2/11/2026 (an MCO notice), 10/01/2026 (current); B2
  04/17/2025, 12/01/2025, 10/01/2026. Nothing found for 2024-10-01 to 2025-04-02. Request them with AHCCCS's RTRU form or
  from an MCO.

## 4. Measurement and simplification

- One corpus id: v03 printed documents + AHCCCS table hashes (`corpus-38bd...`) while v01 stamps documents only
  (`corpus-7134...`); v03 now shows the id v01 stamps.
- The 0.95 precision pass mark applies to the rules that compile (every compiled state rule scored: an exact rate);
  raw-draft precision is shown without a pass mark (it needed n >= 73 at zero errors and could never pass).
- Reviewers are counted case-insensitively ("2 reviewers" for a review signed "ss").
- Removed: the DBFM backend, `COMPILE_LEGACY_SEEDS`, about 20 names nothing read, 02's PoC-module path, test-only
  helpers, notebook source-text tests that behaviour tests cover, history-only docs. Net: 69 files changed, +4,523 /
  -2,529 lines, with the new behaviour.

## 5. Verification (local, Spark 4.0.1, pandas 2.2.3)

- Offline suite: 753 passed, 10 skipped (baseline 706 / 10).
- `tests/test_sql_spark.py` + both independent oracles (written from QUERY_SEMANTICS v2.8, not from the SQL): 211
  passed (232 before the exploratory routing modes and their oracle variants were removed).
- `tests/e2e_local_spark.py --demos` (every notebook in order, planted violations and traps): all checks passed on
  the merged fixes.
- Not verifiable here: the real claims, the real PDFs, NCCI zips and AHCCCS workbooks (the workspace could not
  download from azahcccs.gov / cms.gov; the PDFs were read through a web reader instead).

## 6. Queries for SB on Databricks

45 compiled state queries where the review expected 42 (most likely the 10-05 Ch19 decisions that the 10-06 run did not
reproduce, still approved on the same document version, plus near-duplicates):
```sql
WITH b AS (SELECT build_id FROM main.policy_kb.policy_build_log WHERE status='complete' ORDER BY built_at DESC LIMIT 1),
q AS (SELECT d.rule_id, d.extraction_key, d.predicate_type, r.codes, r.effective_date, r.end_date
      FROM main.policy_kb.policy_detectors d JOIN b ON d.build_id=b.build_id
      JOIN main.policy_kb.policy_rules r ON r.rule_id=d.rule_id AND r.build_id=b.build_id
      WHERE d.compiled AND d.sql IS NOT NULL AND COALESCE(d.origin,'') NOT IN ('ncci','ahcccs_table'))
SELECT s.chapter, SUBSTR(s.reviewed_at,1,10) AS reviewed_on, s.reviewer, s.extraction_run_id, q.*
FROM q LEFT JOIN main.sedo.state_rules s ON s.extraction_key=q.extraction_key
ORDER BY s.chapter, reviewed_on, q.codes;
```

---

## 7. PIE v6.1: adjudication of the two external reviews of v6 (ChatGPT, Gemini), 2026-10-17

Every point was reproduced on the code before anything changed. Each fix was written by the agent that owns the
area and reviewed blind by another agent; the blind reviews found nine further defects in the fixes (fixed). A fresh
critic with no involvement then reviewed the whole change: it found two blockers introduced by fixes of fixes (the
same-sentence rule dropped correct rules; some narrowing conditions vanished) and smaller holes; all were fixed and it
re-checked twice until only design choices remained.

### ChatGPT

| point | verdict | what changed |
|---|---|---|
| B1 a wrong period, provider type or role passes grounding with score 1.0 | **Confirmed, and worse**: "4 units per month" proposed as a DAILY cap of 4 also passed. The period check only asked whether the text names *a* period | Field checks in `post_checks`: each threshold is bound to the basis written next to it, per code clause ("4 units per day; ... 4 units per month"); a list-closing basis covers every number in the list ("nine days, and ... 12 days, per contract year"); provider types must be in the text and the list may not be narrower than the text's (routing-table vocabulary; the list ends at modifiers / POS); the role must fit the verb ("billed by" = billing or billing_or_rendering); scope words; a modifier_required modifier in the text; "may" for discretionary. A contradiction makes a lead; a field the text does not state is flagged. 48+ adversarial cases |
| B2 hybrid merge treats disagreement as corroboration | **Confirmed** (the key omitted provider types, role, age, exception, dates) | The key is the fields the compiler reads for that rule type, plus population, age, exception and window: two drafts that compile to the same SQL merge; any real difference stays two drafts noted "pattern and model disagree on ..." with no confidence bump |
| B3 end-to-end recall unproven | **Agreed; cannot be closed here** (needs the GPU run on the real PDFs) | v05 can now also score a run against the 852-rule inventory per rule type (`INVENTORY_PATH`), labelled "unreviewed inventory", never a gate |
| 45 compiled vs 42 expected | **Agreed** | v03 explains every compiled state rule (in the latest review / decided earlier and not reproduced / unexplained) and is NOT YET with any unexplained rule, any near-duplicate pair (same lines, overlapping dates) or any two decided readings of one sentence (see Gemini 4); exact duplicates (same compiled identity) compile once |
| precision bar 0.95 on a census | **Agreed** | 1.0 during the pilot; every unscored or wrong compiled rule is named |
| D3 lets an unsigned table reading change a signed rule | **Agreed** | D3 acts only when the Same Day readings are signed (tested on the signatures, whatever the switch); otherwise the overlap is listed `table_allows_unsigned_reading` |
| latest MUE value open-ended | **Agreed, also for PTP** | Every NCCI window ends at the newest loaded quarter of its edit file; claims after it get no check from that file, reported with lines and dollars |
| "AHCCCS-authoritative" NCCI wording | **Agreed** | "CMS Medicaid NCCI reference finding" in finding text, d02, d03, d08, README, QUERY_SEMANTICS |

### Gemini

| finding | verdict | what changed |
|---|---|---|
| 1 same-day pair sentences skip the condition / partner / trailing-word guards | **Confirmed** for 3 of 4 sentences through the full path: "with the HQ modifier" paired two codes; "on the same claim" kept a wider scope; "when rendered in an inpatient setting" was stored as an exception, so the rule flagged every setting. "unless prior authorization" was already handled as designed (exception, findings labelled) | The guards apply to same-day sentences; a clause that NARROWS when a rule applies makes a lead; only an EXEMPTING clause (unless / except) is an exception |
| 2 CCMI comparison keyed on the deletion date misses an indicator change that comes with a new deletion date (retroactive hard denial) | **Confirmed** (introduced by the v6 fix of the retro-deleted row) | Ingest and 01 check C key on (pair, effective date) over rows that can take effect |
| 3 D3 reads one cell of a pair | **Confirmed** | A version allows a pair only when neither direction is D / A*; a table that denies the other line is listed `finding_line_differs` |
| 4 two decisions on one sentence can both compile | **Confirmed** | First fix (07 keeps the latest decision) was wrong: the fresh critic showed it dropped correct signed rules (both directions of a pair, an age split, a quarterly and a yearly limit from one sentence). Final design: 07 never drops a signed rule for this; exact duplicates compile once; two DIFFERENT approved readings of one sentence from different extraction runs are listed in the build log and keep v03 at NOT YET until the later decision's note starts with "keep both" or one is rejected; readings of one run note each other in the review workbook |
| 5 a multi-sentence bullet breaks a lead-in list; a bullet's condition hidden from the truncation check | **Confirmed** | Fixed in the pattern layer and grounding |
| 6 the 2025Q1 r1 MUE file ("Effective Jan. 29, 2025") applied from Jan 1 | **Confirmed** | A revision applies from its stated date; Jan 1-28, 2025 is a reported gap (CMS publishes no other file for it) |
| 7 hub direction: the hub's line is the finding | **Agreed it is an assumption**, not a defect: the manual does not say which line AHCCCS denies | Every hub-pair draft says so in the reviewer's note; the register lists any pair where the Same Day table denies the other line |
| 8 master table vs MUE history on duplicate rows | **Confirmed (minor)** | Same statuses (`duplicate`, `value_conflict`, `value_not_max`); parity test extended |
| Part 3 next-phase architecture | **Not adopted now** | See below |

**Part 3, why not now.** SB asked for no complexity without a reason, and each item needs evidence first:
- *Docling parser*: a heavy dependency that would change every section text (re-extraction and re-review) for a benefit
  not yet measured. Run v07 page fidelity on the real PDFs first; trial Docling only on pages the current reader fails.
- *Composable condition schema*: conditions are where false findings come from; each new condition kind needs contract,
  SQL and oracle work. Add the frequent checkable ones (place of service, claim form) one at a time once the real run's
  leads show which matter.
- *Fee-schedule resolver*: it sends policy text to an outside API (GPT-4o), lets a model choose codes for category rules
  without grounding, and builds SQL by string formatting. A category rule stays a lead until a reviewer lists the codes
  or AHCCCS publishes the category as data.
- *DeBERTa NLI verifier*: a general-text model judging billing grammar with unvalidated thresholds; the failures the
  reviews found are now caught deterministically with a stated reason. Could be tried later as a review-priority signal
  measured against v01 scores, never as a gate.
- *Array-based PTP SQL*: no performance problem observed; the batch statements are proven equal to the per-rule SQL by
  the oracles, and a rewrite would have to be proven again.

### Verification of v6.1 (local, Spark 4.0.1, pandas 2.2.3)

Offline suite 863 passed / 10 skipped; `tests/test_sql_spark.py` + both independent oracles 211 passed;
`tests/e2e_local_spark.py --demos`: all checks passed. Every confirmed review point is pinned by a test that fails on
the v6 code. Still not verifiable here: the real claims, PDFs, NCCI zips and AHCCCS workbooks.

**Upgrade effects (one time):** NCCI rule ids no longer include the end date (rules that had one get new ids; old
findings still trace through `policy_rules_history` on (build_id, rule_id)); every NCCI window ends at the newest
loaded quarter; the per-rule NCCI SQL text changed (finding wording), so validator signatures on per-rule NCCI SQL
must be renewed in v06; the next 04 run re-asks the model (prompt text changed).

### Still open (unchanged by these reviews)

The real-data run (03, 04, 05 on the real PDFs, then v01 / v05 / v07 scored by a person), the routing and table-reading
signatures, AHCCCS's earlier table versions, RISSNET files, and which line AHCCCS denies in a hub or both-ways pair.

---

## 8. PIE v6.2: the prompt reviews (ChatGPT on the gpt-oss prompt, Gemini on v6.1), 2026-10-18

Mostly prompt and measurement. Two post-checks also change what can become executable (both narrower: see the critic
part below); nothing changes in how a query runs or how a rule is decided. A fresh critic reviewed the change; its
findings are below and all were fixed except the one left to SB.

| point | verdict | what changed |
|---|---|---|
| ChatGPT: add a completeness instruction | **Agreed** (the prompt had none, and it leans on "never invent") | "Return EVERY distinct billing obligation the TEXT states. One the grammar cannot express is still returned, as not_checkable with its reason" |
| ChatGPT: every field from the TEXT, never from an example | **Agreed** | Stated in the prompt (grounding and post_checks already refuse a code, number or provider type the text lacks) |
| ChatGPT: an internal completeness pass | **Partly**: one line (rule 14). At reasoning "low" it may do little; the A/B below measures it | rule 14 |
| ChatGPT: examples drawn from the manual inflate measured recall; build a holdout | **Agreed on the risk**; no separate holdout set | The 19 inventory rules the examples come from are named (`regress.PROMPT_EXAMPLE_SOURCES`); v05 reports recall with and without them |
| ChatGPT: low vs medium reasoning as an experiment | **Agreed**; 04 (`REASONING`) and v05 (`RUN_DIR_B`) already did it | v05 now scores BOTH runs against the inventory; the manifest records the prompt text's sha; v05 warns when the runs differ in more than one of prompt text, backend, reasoning |
| ChatGPT: the model's confidence is not a probability | **Agreed**; the workbook still sorted by it (lowest first, so leads came before rules that compile) | The workbook is ordered by the checks: rules that compile once signed first, those with an open question first among them; confidence only breaks ties |
| ChatGPT: stop growing the prompt; prompt for reading principles, code for checkable invariants, reader for layout | **Agreed** | The prompt is frozen for the first real run (a test pins its sha); v05 says where each missed rule was lost, which says which of the three to change |
| Gemini: the 8 v6 findings are fixed | **Agreed** (it re-read the code and the tests) | none |
| Gemini: "ready to run, next steps operational" | **Agreed for the code, with two corrections**: the steps also need the routing and table-reading signatures and v06 renewal (section 7), and v05 against the inventory is one unreviewed reading; the recall to report is v01's human-scored sample | README run order |

**Found while checking the prompt against these points (not in either review):**
- *Rule 3 contradicted post_checks.* It told the model to put any "unless / except / **when / only if**" clause in
  `exception`; since v6.1 post_checks reads a narrowing clause ("when provided in a residential setting") as a lead,
  because as an exception the rule would flag every other setting. The outcome was safe (the check downgrades it) but
  the prompt taught the wrong reading. Rule 3 and the `exception` field now say what the code does; a test checks the
  prompt's clause words against `post_checks._EXEMPT_RE`.
- *Grammar examples showed a wrong reading of the manual sentence they come from:* 98960 alone for the cap the
  manual calls "inclusive of all 3 billable codes" (the very C3-04 error the post-checks were written for); T2029's
  "$5,000 per member through the lifetime of the demonstration" as per benefit year; H0035 with two of its four
  provider types (the incomplete list the field checks reject); and (critic) RR on every E0618 / E0619 line, where
  Ch13 continues "The RR modifier is to be used when DME is rented" and Ch8 says "The NU, LL, and RR modifiers are
  all permitted". Corrected; the dollar and modifier examples use placeholder codes (X0000, XX), which grounding
  refuses if copied.
- *The pre-filter is a recall gate no prompt can fix:* a section without a rule signal never reaches the model. v05's
  `inventory_missed` now names, per missed rule, where it was lost: `dropped` (refused by grounding or a post-check,
  with the reason), `prefilter`, `failed` (a model call failed: rerun), `extractor` (the prompt or the pattern layer),
  `not_located` (no section text holds the quote: the reader, or the inventory's transcription).

**Fresh critic on the v6.2 change (fixed):**
- *A number copied from an example survived:* a draft with a threshold its text never writes (1000 per benefit year
  on the T2029 sentence) was only flagged by grounding ("treat as derived") and stayed executable. post_checks now
  makes it a lead (`threshold_not_in_text`), after the basis checks so their messages still name the text's own
  number. Narrower than before: it can only turn an executable draft into a lead.
- *The pair trigger the prompt names read as narrowing:* "... if both codes are billed on the same day" downgraded a
  pair. A pair's clause that names its codes by reference ("both", "these codes") is its own trigger, unless it also
  names a third code or "another" one ("if both are billed with H0001" still narrows: the critic's re-check caught
  the first version of this fix keeping such a pair executable).
  The re-check ran the cases that could lose a real rule ("four (4)", "once", "twice", "$1,000.00", "8 units/day",
  a lead-in with its list item, merged combined caps, pattern-layer quotes): all stay executable; "annually" counts
  as writing 1.
- *Rule 14 contradicted rules 1 and 3* ("add" a condition as an obligation): it now says to add a missing condition
  or exception to the rule it belongs to.
- *Inventory recall undercounted and cross-credited.* The inventory names a hub list's hub in `parameters.hub`, not in
  `codes`, so a correct pair never matched its own row (9 of 10 hub rows, two of them prompt examples); and one
  draft could credit a sibling row: the 14 pairs of the H2012 list "found" three other hub lists, and the CHW
  sentence's pairs "found" its two caps (50 rows have a sibling with a matching quote). The inventory matcher now adds
  the hub code, refuses a draft that compiles as another type than the row's kind, and gives each draft only its
  best row (a per-provider daily cap, which post_checks rescopes to `max_units_per_dos`, still finds its daily-cap
  row: re-check). A `duplicate` drop is no longer called `dropped`; a rule printed on two pages is located on its own page;
  a section with no outcome is `unknown`, not `extractor`. The tags now cover the kinds the examples show (19 rows:
  +99201-99499, +type 01; -the CHW pair reading, -the RR row).
- *v05:* the A/B scores both runs over the compared chapters; no `display(None)`; a missing inventory file warns
  instead of failing; prompt identity falls back to the prompt version when a manifest has no sha; the match runs
  once per run (about a minute on a full run).

**Left to SB (not urgent):** whether E0618 / E0619 need RR on every line. The first run's review approved that
reading of the Ch13 sentence (tests mark it APPROVED); the next sentence and Ch8 say otherwise. `modifier_required` is
not a compiled type (`schema.PREDICATE_TYPES_COMPILED`), so the reading flags no claim (an earlier note here said it
might; that was wrong). It is still a wrong statement in the KB's policy answers, to reject or fix before modifier
rules ever compile:
```sql
SELECT rule_id, review_status, reviewer, predicate FROM main.sedo.state_rules
WHERE predicate LIKE '%modifier_required%' AND (codes LIKE '%E0618%' OR codes LIKE '%E0619%');
```

The inventory now ships in `reference/` (`config.MANUAL_RULE_INVENTORY`) and v05 reads it by default. `PROMPT_VERSION`
stays "v3": no v3 run had been scored. A run made with the v6 or v6.1 prompt text is not reused (the prompt sha is
part of the cache key) and shows its own sha in v05.

**Found on SB's workspace (2026-10-18):** three cells of `00_acquire_ncci` (1-2 egress and links, 3-5 load, 6
go / no-go) held their code under the Markdown heading with no cell break, so Databricks showed the code as text and
never ran it (since v5.2; the local runners execute it anyway). Split; `tests/test_validation_notebooks.py` now checks
that no notebook has code inside a Markdown cell.

**Found on SB's workspace (2026-10-18, 04):** the newly imported 04 ran in a newer Serverless GPU environment than the
04 that worked (that one shows torch 2.9.0+cu129, environment 5 with transformers 4.57.1; the new one ran transformers
5.x). There the model load died in CUDA ("illegal memory access") while dequantizing; adding `kernels` did not help:
`kernels` 0.15 and later refuse the unversioned kernel lookup transformers makes ("Either a revision or a version must
be specified"). The code was not involved (the loader is byte-identical to v5.2). The environment is a per-notebook
setting (Environment side panel: accelerator, base environment / version): 04 must use the one the earlier runs used.
04's `%pip` cell is unchanged from v6.1 (a test refuses an unpinned `kernels` there); the loader prints the library
stack before the download and the quantization it got after.

**From the first real runs (2026-10-19, chapter 19, low vs medium):** each run lost one whole section to the model
running out of capacity: low the respite section (the S5151 list, 21 signed pairs: 5,400 tokens even split twice),
medium the day-program section (six hub lists: 8,100 tokens), and both one section to CUDA out of memory. A HYBRID run
then dropped the section's deterministic pattern rules too, so the A/B compared which section each run lost, not the
reasoning level. Fixed in the mechanics (the prompt is unchanged): a section the model cannot finish keeps its pattern
rules (labelled; still a retryable failure, never cached); out of GPU memory splits the section like a truncated answer
(and `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True` before the model loads); up to 16 pieces instead of 4; a
not_checkable reason written as the rule type becomes that lead instead of a drop (two medium rules); "are billed on /
using" counts as a rule signal (claim-form sentences the pre-filter skipped).

**Reruns of 2026-10-20 (chapter 19, low 20261020T145033 vs medium 20261020T181133, same prompt):** signed recall
0.712 vs 0.735, inventory 73 vs 81 of 131 (0.533 vs 0.607 without the prompt-example rules), pre-filter losses 0 in
both, unreviewed executable drafts 47 vs 38, duplicates 7 vs 0; 2 h 06 vs 5 h 23. Each run still failed one section,
the same as before (low the respite section, medium the day-program section), now keeping 24 and 50 pattern rules:
a single sentence listing 21 partner codes needs more output than the budget, and a sentence cannot be split. Fixed:
such a piece gets one last call at `LAST_RESORT_BUDGET_FACTOR` (4) x the first budget (greedy decoding: a larger
budget only lets the same answer finish; the cache key is unchanged). 04's `REUSE_ANSWERS_FROM` reuses the answers
of earlier run folders under the same cache key, so a rerun asks the model only for what they did not answer and a
stopped run resumes. Decision: medium for the full run (more rules found, less review), at about 2.6 x the GPU time.

**From the rerun workbooks (2026-10-21):** the three hub lists of H2015, H2020 and H0037 (about 55 pairs) gave no pair
in either run. The PDF runs each list into the next line without a period ("... or H0015 Therapeutic H2019 -",
"... or H0030 NOTE: A professional ...", "... or H0030 Refer to AMPM ..."), and the words after the last code read as a
condition on the list, so the sentence became a lead. Fixed in `post_checks.pair_roles`: after "or / and <code>", a
capitalised word that starts a new block (not Unless, Except, When, For, ...) ends the list; a capitalised condition
("For members enrolled in ALTCS") and a lower-case tail still make a lead. Second fix, found while checking that the
first reaches SB's next run: a cached HYBRID answer held the pattern rules of the code that wrote it, and the cache key
has no pattern version, so a pattern fix never reached a reused answer (`REUSE_ANSWERS_FROM`). The pattern half is now
rerun on every cache read (no GPU) and merged with the cached model half; unchanged patterns give back the cached answer
exactly, and 04 prints how many reused sections got different pattern rules. Not changed (one case, no rule): low drafted
"Only one per diem code shall be billed in a single day." as a daily cap of 1 on a code set the sentence never names
(H2020, H0036, H0037); the reviewer signed it a lead. Medium's code-set caps with codes outside the sentence (bed hold
revenue codes) match signed rules, so "every code in the sentence" would cost recall. Reviewer questions from the
workbook: the direction of the per-diem pairs (H2014 / H2017 vs the per-diem line), and whether both directions of the
symmetric pairs H2025 / H2026 / H2027 are wanted (signed both; medium drafted one).

### Verification of v6.2 (local, Spark 4.0.1, pandas 2.2.3)

Offline suite 872 passed / 10 skipped; `tests/test_sql_spark.py` + both independent oracles 211 passed;
`tests/e2e_local_spark.py --demos`: all checks passed on the final code. The critic re-checked the fixes once; its two
re-check findings are fixed and tested. Not verifiable here: how the frozen prompt reads the real PDFs (that is what
the A/B in the README measures).

**Upgrade effects (one time):** the next 04 run re-asks the model (the prompt text changed); the review workbook's row
order changes; a draft whose threshold its text never writes, or a pair narrowed by a third code, is now a lead.

## 9. PIE v6.3: the fixes from the first real chapter 19 runs, 2026-10-21

v6.3 = v6.2 + the mechanics fixes recorded in section 8 under the 2026-10-19, 2026-10-20 and 2026-10-21 findings. The
prompt is unchanged (still v3, sha 66bee8e46578), so answers of v6.2 runs are reused (`REUSE_ANSWERS_FROM`); the code
that turns them into drafts is not the same, so v6.2 and v6.3 drafts of the same answers differ.
- A section the model cannot finish keeps its pattern rules; GPU out of memory splits the section; up to 16 pieces;
  one last call at 4x the budget for a piece that cannot be split.
- A not_checkable reason written as the rule type is that lead; "are billed on / using" is a rule signal.
- `REUSE_ANSWERS_FROM`: reuse earlier runs' answers; the pattern half of a reused answer is rerun with the current code.
- Hub lists run into the next line without a period (H2015, H2020, H0037) give their pairs.
- Versions: `config.PIE_VERSION` ("6.3") and `extract_rules.CODE_SHA` (sha of extract_rules, post_checks, policy_docs,
  schema) are written into every run's manifest.json and printed by 04; v05 shows both per run and says when A and B
  ran different extraction code. Before v6.3 a run folder recorded the prompt but not the code, so two runs of the same
  prompt could not be told apart. Runs before v6.3 show "code not recorded".

Not changed: `PROMPT_VERSION` ("v3"). It names the prompt text; bumping it changes the cache key, so the model would be
asked again for every section (about 5 h 23 for chapter 19 at medium) for a prompt that did not change. It is bumped
when the prompt text changes, after the full run is scored (section 8 decisions).

