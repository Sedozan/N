"""
registers.py  -  the two policy-improvement products (definition-of-done pillars 5 and 6, first cut).

ambiguity_register   policy text that does not resolve to an executable rule, or that a reviewer
                     or the pipeline flagged as ambiguous - quoted, categorised, sized. Built from
                     state_rules (every status except rejected) plus NCCI edition disagreements.
                     2026-10-14: build B20261008T231304 had 433 entries and 235 state leads: the register
                     also holds drafts and rows the build excludes. Each entry now says where it stands
                     (in_build: lead | compiled_flagged | compiled_and_lead | pending_review | excluded:<why> |
                     not_loaded | federal; compiled_and_lead = a rule the Same Day table dated, D3: executable on
                     some dates, a lead on the dates the table allows),
                     so the two counts reconcile; nothing is dropped.
rule_overlaps        every code checked by BOTH a federal and a state rule (the AHCCCS rule-table rules
                     excepted: policy_ahcccs_conflicts covers them), with the relationship
                     computed where the predicates are comparable:
                       state_stricter / federal_stricter / same_limit      (unit caps)
                       different_basis                                     (per line vs per day ...)
                       state_not_covered_vs_federal_edit                   (contradiction CANDIDATE:
                           AHCCCS says not covered; CMS publishes an edit that presumes payment)
                       both_pair_prohibitions / different_rule_types
                     Both rules still compile - both authorities apply. This is the reconciliation
                     record; it never decides which authority wins.
contradiction_register  2026-10-14 (definition of done pillar 6): ONE table (07 writes it to
                     policy_ahcccs_conflicts, the table that held the AHCCCS-table half) with every
                     conflict kind the build computes, each with both sources quoted, the nature of the
                     conflict, the dates both apply to and a suggested resolution path:
                       the AHCCCS rule tables against a state rule, and against themselves
                         (ahcccs_tables.table_conflicts: table_allows, table_allows_unsigned_reading,
                         finding_line_differs, pair_scope_differs, provider_types_differ, provider_role_differs,
                         daily_threshold_differs,
                         file_states_two_daily_limits; and the rows recorded but not compiled,
                         not_compiled_*, which are listed but are NOT contradictions)
                       a state rule against a federal edit (rule_overlaps:
                         state_not_covered_vs_federal_edit)
                       a state rule a reviewer or the extractor made a lead because it conflicts with
                         another source (not_checkable_reason cross_source_conflict)
                     It never decides which source wins.
"""
from __future__ import annotations

import json

import pandas as pd

from schema import NOT_CHECKABLE_REASONS

AMBIGUITY_COLUMNS = ["category", "reason", "rule_id", "extraction_key", "origin", "chapter", "review_status",
                     "statement", "verbatim_quote", "codes", "source_doc", "source_locator", "source_url",
                     "doc_hash", "in_build"]
OVERLAP_COLUMNS = ["code", "relationship", "federal_rule_id", "federal_type", "federal_limit", "federal_edition",
                   "state_rule_id", "state_type", "state_limit", "state_quote", "state_source", "federal_source"]
TABLE_ORIGIN = "ahcccs_table"           # detector_gen.TABLE_ORIGIN: rules read from the AHCCCS rule tables (v5.2)

_UNIT_TYPES = {"max_units_per_line", "max_units_per_dos", "max_units_per_day", "max_units_per_period"}


def _j(v, default):
    if isinstance(v, str):
        try:
            return json.loads(v) if v else default
        except Exception:
            return default
    return default if v is None or (isinstance(v, float) and pd.isna(v)) else v


def _category(reason) -> str:
    if not reason or (isinstance(reason, float) and pd.isna(reason)):
        return "flagged_ambiguous"
    r = str(reason).strip()
    return r if r in NOT_CHECKABLE_REASONS else f"other:{r[:40]}"


def _in_build(row: dict, built: dict, excluded: dict) -> str:
    """Where a state_rules row stands in this build: lead / compiled_flagged / compiled_and_lead (the build holds it, by
    extraction_key; compiled_and_lead: D3 split it into an executable piece and a lead piece),
    pending_review (draft / needs_review: not decided), excluded:<why> (07 left the signed row out - an older document
    version, another engine, a hand-authored seed: state_rules.STALE_REASONS / ENGINE_REASONS), not_loaded (any other
    row the build does not hold)."""
    k = row.get("extraction_key")
    if isinstance(k, str) and k in built:
        return built[k]
    if row.get("review_status") in ("draft", "needs_review"):
        return "pending_review"
    why = excluded.get(row.get("rule_id"))
    return f"excluded:{why}" if why else "not_loaded"


def ambiguity_register(state_rows: pd.DataFrame, accepted_rules: list[dict],
                       excluded: dict | None = None) -> pd.DataFrame:
    """excluded: {state_rules rule_id: reason} of the signed rows 07 left out (state_report['stale'] and
    ['engine_excluded']), for the in_build column."""
    out = []
    excluded = excluded or {}
    pieces: dict = {}
    for r in accepted_rules or []:
        k = r.get("extraction_key")
        if r.get("origin") != "ncci" and isinstance(k, str) and k:
            p = r.get("predicate") or {}
            lead = r.get("machine_checkable") is False or p.get("type") == "not_checkable"
            pieces.setdefault(k, set()).add("lead" if lead else "compiled")
    built = {k: "compiled_and_lead" if len(v) == 2 else "lead" if "lead" in v else "compiled_flagged"
             for k, v in pieces.items()}
    if state_rows is not None and len(state_rows):
        # rejected decisions and drafts a later run superseded are not open policy questions
        df = state_rows[~state_rows["review_status"].isin(["rejected", "superseded"])]
        not_mc = ~df["machine_checkable"].fillna(False).astype(bool)
        flag = df["ambiguity_flag"].fillna(False).astype(bool)
        for r in df[not_mc | flag].to_dict("records"):
            pred = _j(r.get("predicate"), {})
            reason = r.get("not_checkable_reason") or pred.get("reason")
            out.append({
                "category": _category(reason) if not bool(r.get("machine_checkable")) else "flagged_ambiguous",
                "reason": " | ".join(str(x) for x in (reason, r.get("ambiguity_note")) if x and str(x) != "nan"),
                "rule_id": r.get("rule_id"), "extraction_key": r.get("extraction_key"), "origin": r.get("origin"),
                "chapter": r.get("chapter"), "review_status": r.get("review_status"),
                "statement": r.get("statement"), "verbatim_quote": r.get("verbatim_quote"),
                "codes": json.dumps(_j(r.get("codes"), [])), "source_doc": r.get("source_doc"),
                "source_locator": r.get("source_locator"), "source_url": r.get("source_url"),
                "doc_hash": r.get("doc_hash"), "in_build": _in_build(r, built, excluded)})
    for r in accepted_rules:
        if r.get("origin") == "ncci" and str(r.get("reconciliation") or "").startswith("ncci_editions_disagree"):
            out.append({"category": "ncci_edition_disagreement", "reason": r.get("ambiguity_note"),
                        "rule_id": r.get("rule_id"), "extraction_key": None, "origin": "ncci", "chapter": None,
                        "review_status": "federal", "statement": r.get("statement"), "verbatim_quote": None,
                        "codes": json.dumps(r.get("codes") or []), "source_doc": r.get("source_doc"),
                        "source_locator": r.get("source_locator"), "source_url": r.get("source_url"),
                        "doc_hash": r.get("doc_hash"), "in_build": "federal"})
    return pd.DataFrame(out, columns=AMBIGUITY_COLUMNS)


def _limit(r: dict):
    p = r.get("predicate") or {}
    return p.get("threshold")


def _unit_relationship(fed: dict, st: dict) -> str:
    if fed["predicate"]["type"] != st["predicate"]["type"] or fed["predicate"].get("period") != st["predicate"].get("period"):
        return "different_basis"            # e.g. NCCI per claim line vs AHCCCS per member-day
    a, b = int(_limit(fed)), int(_limit(st))
    return "state_stricter" if b < a else "federal_stricter" if a < b else "same_limit"


def _row(code, rel, f, s, federal_limit=None, federal_type=None):
    return {"code": code, "relationship": rel,
            "federal_rule_id": f["rule_id"], "federal_type": federal_type or f["predicate"]["type"],
            "federal_limit": federal_limit if federal_limit is not None else _limit(f),
            # the NCCI edit file the federal rule comes from (lines take one file: provider type x form)
            "federal_edition": (f.get("predicate") or {}).get("ncci_edition"),
            "state_rule_id": s["rule_id"], "state_type": s["predicate"]["type"], "state_limit": _limit(s),
            "state_quote": s.get("verbatim_quote") or s.get("notes"),
            "state_source": f"{s.get('source_doc')} | {s.get('source_locator')}",
            "federal_source": f"{f.get('source_doc')} | {f.get('source_locator')}"}


def rule_overlaps(rules: list[dict], detectors: list[dict] | None = None) -> pd.DataFrame:
    """Only COMPARABLE pairs are listed (a state unit cap is not compared with every PTP pair
    that mentions the code - that would be noise, not reconciliation):
      state unit cap      x  federal MUE on the same code
      state pair (a,b)    x  federal PTP on the same two codes, either direction
      state not-covered   x  any federal edit on the code   (one row per code)
    AHCCCS rule-table rules (origin 'ahcccs_table': Same Day Disallow, daily limits, B2 matrix) are left out
    (2026-10-04, v5.2b, critic F18): a table's daily cap next to an NCCI MUE is two authorities on purpose (units per
    member + provider + day vs units per claim line), and listing them flooded the register with one row per table code
    and quarter. Where a table agrees with, contradicts or qualifies a STATE rule, policy_ahcccs_conflicts
    (ahcccs_tables.table_conflicts) lists it."""
    compiled = None if detectors is None else {d["rule_id"] for d in detectors if d.get("compiled")}
    live = [r for r in rules if (compiled is None or r.get("rule_id") in compiled) and r.get("origin") != TABLE_ORIGIN]
    mue: dict[str, list] = {}
    ptp: dict[frozenset, list] = {}
    fed_any: dict[str, list] = {}
    for r in live:
        if r.get("origin") != "ncci":
            continue
        p = r["predicate"]
        if p["type"] in _UNIT_TYPES:
            mue.setdefault(str(p["code"]).upper(), []).append(r)
        elif p["type"] == "code_pair_prohibited":
            ptp.setdefault(frozenset((str(p["code_a"]).upper(), str(p["code_b"]).upper())), []).append(r)
        for c in r.get("codes") or []:
            fed_any.setdefault(str(c).upper(), []).append(r)
    rows = []
    for s in live:
        if s.get("origin") == "ncci":
            continue
        p = s["predicate"]
        t = p["type"]
        if t in _UNIT_TYPES:
            for code in [p.get("code")] + list(p.get("code_set") or []):
                if code:
                    for f in mue.get(str(code).upper(), []):
                        rows.append(_row(str(code).upper(), _unit_relationship(f, s), f, s))
        elif t == "code_pair_prohibited":
            key = frozenset((str(p["code_a"]).upper(), str(p["code_b"]).upper()))
            for f in ptp.get(key, []):
                rows.append(_row("/".join(sorted(key)), "both_pair_prohibitions", f, s))
        elif t == "code_not_covered":
            for code in [p.get("code")] + list(p.get("code_set") or []):
                fs = fed_any.get(str(code).upper(), []) if code else []
                if fs:
                    rows.append(_row(str(code).upper(), "state_not_covered_vs_federal_edit", fs[0], s,
                                     federal_limit=len(fs), federal_type=f"{len(fs)} federal edit(s)"))
    return pd.DataFrame(rows, columns=OVERLAP_COLUMNS)


# ------------------------------------------------------------------ contradiction register (pillar 6)
CONTRADICTION_COLUMNS = ["relationship", "codes", "window_from", "window_to", "source_a", "quote_a", "source_b",
                         "quote_b", "detail", "resolution_path", "rule_id", "rule_origin", "other_rule_id", "table_key",
                         "version_date", "table_reading", "rule_reading"]
NOT_COMPILED_PREFIX = "not_compiled_"          # ahcccs_tables.NOT_COMPILED_PREFIX: listed, not a contradiction
# a suggested resolution path per relationship (a suggestion for the policy owner, never a decision of the engine)
RESOLUTION = {
    "table_allows": "AHCCCS to say which source governs for these dates (the manual's prohibition or the table's A) and "
                    "align the other; until then the rule is a lead for the dates the table allows (D3)",
    "table_allows_unsigned_reading": "sign the Same Day readings (reference/ahcccs_table_readings.csv: D3 then dates "
                                     "the rule), or re-sign the chapter rule with an end date; until then the chapter "
                                     "rule applies as signed",
    "finding_line_differs": "AHCCCS to say which line the pair denies (the manual's or the Same Day table's) and align "
                            "the other; until then each source applies as signed (the chapter rule flags its line)",
    "pair_scope_differs": "AHCCCS to say whether the pair is barred for any provider or only the same provider, and "
                          "align the manual and the Same Day Disallow Table",
    "provider_types_differ": "AHCCCS to confirm the complete provider-type list for the code and align the manual and "
                             "the B2 Matrix",
    "provider_role_differs": "SB / AHCCCS to confirm whether the list judges the billing or the rendering provider",
    "daily_threshold_differs": "AHCCCS to confirm the daily maximum and align the manual and the daily limits table",
    "file_states_two_daily_limits": "AHCCCS to say which daily limit its edit applies (Procedure Maximum Occurrence or "
                                    "the 1-day Limit)",
    "state_not_covered_vs_federal_edit": "AHCCCS to confirm the code is not covered (a federal edit on it then never "
                                         "applies) or correct the manual",
    "cross_source_conflict": "AHCCCS to say which source governs (the review note names the other source) and align "
                             "the other",
}
NOT_COMPILED_RESOLUTION = "recorded, not compiled: compiling it needs a reading SB signs (ahcccs_table_readings.csv)"


def _iso(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    t = str(v).strip()[:10]
    return t if t and t.lower() not in ("nan", "none", "nat") else None


def _both_windows(a: dict | None, b: dict | None) -> tuple:
    """The dates two rules both apply to (ISO, None = open); (None, None) when either is unknown."""
    if not a or not b:
        return None, None
    los = [x for x in (_iso(a.get("effective_date")), _iso(b.get("effective_date"))) if x]
    his = [x for x in (_iso(a.get("end_date")), _iso(b.get("end_date"))) if x]
    return (max(los) if los else None), (min(his) if his else None)


def _text(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    t = str(v).strip()
    return t or None


def contradiction_register(table_conflicts: pd.DataFrame | None, overlaps: pd.DataFrame | None, rules: list[dict],
                           state_rows: pd.DataFrame | None = None) -> pd.DataFrame:
    """One row per conflict the build computes (CONTRADICTION_COLUMNS), from:
      table_conflicts  ahcccs_tables.table_conflicts (its window and both sources are kept as they are)
      overlaps         rule_overlaps: the rows state_not_covered_vs_federal_edit (source_a = the state rule, source_b =
                       the federal edit; the window = the dates both rules apply to)
      rules            the build's rules (accepted): every state rule that is a lead with reason cross_source_conflict
                       (source_a = the rule; source_b = the other source as the rule's notes or, from state_rows by
                       extraction_key, the reviewer's note name it), unless table_conflicts already lists that rule
    resolution_path is a suggestion (RESOLUTION), never a decision. Rows sorted by relationship, codes, window."""
    by_id = {r.get("rule_id"): r for r in rules or [] if r.get("rule_id")}
    out = []
    tc = table_conflicts if table_conflicts is not None else pd.DataFrame()
    for r in tc.to_dict("records") if len(tc) else []:
        rel = str(r.get("relationship"))
        out.append({**{c: r.get(c) for c in CONTRADICTION_COLUMNS if c in r}, "other_rule_id": None,
                    "resolution_path": (NOT_COMPILED_RESOLUTION if rel.startswith(NOT_COMPILED_PREFIX)
                                        else RESOLUTION.get(rel))})
    listed = {r.get("rule_id") for r in out if r.get("rule_id")}
    ov = overlaps if overlaps is not None else pd.DataFrame()
    for o in ov.to_dict("records") if len(ov) else []:
        if o.get("relationship") != "state_not_covered_vs_federal_edit":
            continue
        s, f = by_id.get(o.get("state_rule_id")), by_id.get(o.get("federal_rule_id"))
        lo, hi = _both_windows(s, f)
        out.append({"relationship": o["relationship"], "codes": o.get("code"), "window_from": lo, "window_to": hi,
                    "source_a": o.get("state_source"), "quote_a": _text(o.get("state_quote")),
                    "source_b": o.get("federal_source"), "quote_b": _text((f or {}).get("statement")),
                    "detail": (f"AHCCCS says {o.get('code')} is not covered; CMS publishes {o.get('federal_type')} on "
                               f"it, an edit that presumes the code can be paid"),
                    "resolution_path": RESOLUTION[o["relationship"]], "rule_id": o.get("state_rule_id"),
                    "rule_origin": (s or {}).get("origin"), "other_rule_id": o.get("federal_rule_id"),
                    "table_key": None, "version_date": None, "table_reading": None,
                    "rule_reading": f"{o.get('state_type')} (state) vs {o.get('federal_type')} (federal)"})
    notes = {}
    if state_rows is not None and len(state_rows) and "extraction_key" in state_rows:
        for k, n in zip(state_rows["extraction_key"], state_rows.get("review_note", pd.Series(dtype=object))):
            if _text(k) and _text(n):
                notes[str(k)] = _text(n)
    for r in rules or []:
        p = r.get("predicate") or {}
        reason = r.get("not_checkable_reason") or p.get("reason")
        if (r.get("origin") in ("ncci", TABLE_ORIGIN) or r.get("machine_checkable", True) is not False
                or reason != "cross_source_conflict" or r.get("rule_id") in listed):
            continue
        other = notes.get(str(r.get("extraction_key"))) or _text(r.get("ambiguity_note")) or _text(r.get("notes"))
        codes = [str(c).upper() for c in (r.get("codes") or [])]
        out.append({"relationship": "cross_source_conflict", "codes": "/".join(codes) or None,
                    "window_from": _iso(r.get("effective_date")), "window_to": _iso(r.get("end_date")),
                    "source_a": " | ".join(x for x in (_text(r.get("source_doc")), _text(r.get("source_locator"))) if x),
                    "quote_a": _text(r.get("verbatim_quote")) or _text(r.get("statement")),
                    "source_b": "another policy source, named in the review note or the rule's notes", "quote_b": other,
                    "detail": f"the rule is a lead because it conflicts with another source: {_text(r.get('statement'))}",
                    "resolution_path": RESOLUTION["cross_source_conflict"], "rule_id": r.get("rule_id"),
                    "rule_origin": r.get("origin"), "other_rule_id": None, "table_key": None, "version_date": None,
                    "table_reading": None, "rule_reading": p.get("type")})
    df = pd.DataFrame(out, columns=CONTRADICTION_COLUMNS).astype(object)
    df = df.where(df.notna(), None)
    return df.sort_values(["relationship", "codes", "window_from"], kind="mergesort", na_position="first",
                          key=lambda s: s.map(lambda v: "" if v is None else str(v))).reset_index(drop=True)


def contradictions(register: pd.DataFrame | None) -> int:
    """How many register rows are contradictions (every relationship but the not_compiled_* rows)."""
    if register is None or not len(register):
        return 0
    return int((~register["relationship"].astype(str).str.startswith(NOT_COMPILED_PREFIX)).sum())
