# Databricks notebook source
# MAGIC %md
# MAGIC # v03 · Pipeline health and the measurement bar
# MAGIC
# MAGIC **What this answers:** is the latest build and detector run sound, are the federal edits current, what did extraction do
# MAGIC with each chapter, what quality numbers exist — and, against the definition-of-done measurement bar, what is **GO** and
# MAGIC what is **NOT YET**, with the reason for each.
# MAGIC **How to read it:** the last table is the summary. A row says GO only when the number it rests on exists and meets the
# MAGIC bar; a missing number is always NOT YET, never assumed. A rate counts as *measured* only when its 95% interval is
# MAGIC narrow enough to state (`MAX_CI_WIDTH`, default ±10 points): 3 of 4 correct is a number, not a measurement.
# MAGIC Pass marks: executable-rule precision = 1.0 during the pilot: **every state rule that compiles** scored real AND
# MAGIC faithful by a person (a census, so an exact rate; v01 with `STATUSES = ["approved"]` exports every approved rule),
# MAGIC and every one explained (in the latest review of its chapter, or decided earlier and not reproduced; none
# MAGIC unexplained, no near-duplicate pair); extraction recall ≥ 0.90 (pooled; per-chapter numbers shown) and fidelity ≥ 0.95
# MAGIC on the **lower** end of the 95% interval. The engine's raw
# MAGIC drafts' precision is shown without a pass mark. Coverage counts only rules that **ran** in the latest detector run.
# MAGIC A sample-based extraction number is judged only when it was measured on the **engine's own output** (v01 with `STATUSES = None`:
# MAGIC metric `population` = `engine_latest_run`) **on the current corpus** (its `corpus_version` = the current document set)
# MAGIC **and on the current latest run of every chapter it covers** (its `sample_runs` = the latest successful run of each
# MAGIC chapter in `policy_extraction_log`: re-running 04 on the same corpus makes a sample stale), and only while no more than
# MAGIC `MAX_UNSCORED_SHARE` (10%) of the sample's drawn units were left unscored; otherwise the row is NOT YET and says why
# MAGIC (2026-10-04, critic M51-3 / M51-6 and the run follow-up). Every v01 number is weighted by stratum size.
# MAGIC Rows marked INFO carry a number without a pass mark (filter loss: dropped candidates that were real rules).
# MAGIC **Limits:** this reports what the tables say. Quality metrics come from human-scored samples (v01, v02); until those
# MAGIC are scored and ingested, extraction precision/recall/fidelity/filter loss and detector precision are unmeasured. The
# MAGIC corpus is the AHCCCS FFS Provider Billing Manual chapters and exhibits — every rate here is about that scope only.
# MAGIC AHCCCS rule tables loaded by `00b` (Same Day Disallow, Daily Limits, B2 Matrix) are named in the corpus row and leave
# MAGIC its still-to-load list; the corpus id is the documents' alone, the one v01 stamps (the engine does not read the tables).
# MAGIC Coverage and contradictions are read from what 08 and 07 recorded (the run log, the build log); nothing is recomputed.
# MAGIC
# MAGIC Read-only (one aggregate query of the claims table: the provider type codes that decide the NCCI edit file of
# MAGIC CMS-1500 / UB-04 lines, with their paid dollars - `ncci_routing.observed_types_sql`).

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import Window, functions as F
import config, quality, acquire_ncci, ingest_ncci_tables, ncci_routing, policy_docs, ahcccs_tables, registers
for _m in (config, quality, acquire_ncci, ingest_ncci_tables, ncci_routing, policy_docs, ahcccs_tables, registers):
    importlib.reload(_m)

FIDELITY_TARGET = 0.95          # pass marks, judged on the lower 95% bound (v01 prints the same bars)
EXEC_PRECISION_TARGET = 1.0     # pilot (round 4, 2026-10-17): every compiled state rule scored real AND faithful
RECALL_TARGET   = 0.90          # real rules found / (found + missed), pooled over the scored sections
MAX_CI_WIDTH    = 0.20          # a rate counts as "measured" only when its 95% interval is at most this wide
MAX_UNSCORED_SHARE = 0.10       # a bar is NOT YET while more than this share of its sample's drawn units is unscored

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def have(name):
    return spark.catalog.tableExists(T(name))


def num(v):
    try:
        return None if v is None or pd.isna(v) else v
    except (TypeError, ValueError):
        return v


GO = []            # rows of the final table


def bar(item, ok, reason):
    GO.append({"measurement bar item": item, "status": "GO" if ok else "NOT YET", "reason": reason})


def info(item, reason):
    """A number shown in the summary WITHOUT a pass mark: never GO, never NOT YET."""
    GO.append({"measurement bar item": item, "status": "INFO", "reason": reason})

# COMMAND ----------

# MAGIC %md ## 1. Latest build

# COMMAND ----------

bl = spark.table(T("policy_build_log")).orderBy(F.desc("built_at")).limit(1).toPandas() if have("policy_build_log") else pd.DataFrame()
BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0] if have("policy_rules") else None
b = bl.iloc[0].to_dict() if len(bl) else {}
if b:
    show_keys = ["build_id", "built_at", "claims_from", "claims_to", "scope_codes", "rules", "ncci_rules", "state_rules",
                 "detectors_compiled", "detectors_batched", "leads", "stale_approvals_excluded",
                 "ambiguity_register_rows", "overlap_rows", "contradiction_candidates", "ahcccs_stale_vs_claims",
                 "ahcccs_readings_sha256"]
    display(pd.DataFrame({"field": show_keys, "value": [str(b.get(k)) for k in show_keys]}))
    if BUILD_ID and b.get("build_id") != BUILD_ID:
        print(f"WARNING: the current policy_rules build ({BUILD_ID}) is not the latest build log row ({b.get('build_id')}).")
else:
    print("No build yet - run 07_build_kb.")

# COMMAND ----------

# MAGIC %md ## 2. Latest detector run

# COMMAND ----------

run, RUN_SNAPSHOT = {}, None
if have("policy_detector_runs"):
    runs = spark.table(T("policy_detector_runs"))
    rid = runs.agg(F.max("run_id")).first()[0]
    r = runs.where(F.col("run_id") == rid).toPandas()
    # the run log (RUN:snapshot JSON in `error`) of the latest run of the CURRENT build: 08's coverage of what ran (D6)
    _snaps = runs.where(F.col("rule_id") == "RUN:snapshot").toPandas()
    _snaps = _snaps[_snaps["build_id"].astype(str) == str(BUILD_ID)].sort_values("run_id")
    RUN_SNAPSHOT = quality._json(_snaps["error"].iloc[-1]) if len(_snaps) else None
    nf = spark.table(T("policy_findings")).where(F.col("run_id") == rid).count() if have("policy_findings") else 0
    # 2026-10-04 (critic M51-8): the RUN:snapshot row keeps the snapshot numbers as JSON in `error` - not a detector
    # error (08 counts the same way); a partial run says why (the `skipped` column of the queries it did not run)
    run_errors, run_problems = quality.run_completeness(r)
    run = {"run_id": rid, "build_id": r["build_id"].dropna().iloc[0] if r["build_id"].notna().any() else None,
           "detector_rows": len(r), "errors": run_errors,
           "partial_run": bool(r["partial_run"].fillna(False).astype(bool).any()) if "partial_run" in r else None,
           "detectors_eligible": int(r["detectors_eligible"].max()) if "detectors_eligible" in r and r["detectors_eligible"].notna().any() else None,
           "findings": nf, "problems": run_problems}
    display(pd.DataFrame({"field": list(run), "value": [str(v) for v in run.values()]}))
    if run["errors"]:
        display(r[r["error"].notna() & ~r["rule_id"].astype(str).str.startswith("RUN:")][["rule_id", "predicate_type", "error"]])
else:
    print("No detector run yet - run 08_run_detectors.")

# COMMAND ----------

# MAGIC %md ## 3. NCCI freshness

# COMMAND ----------

metas = ingest_ncci_tables.discover_tables(spark, config.CATALOG, config.SCHEMA)
cy, cq = acquire_ncci.current_quarter()
# 2026-10-14: measured from the CLAIMS START (the build's claims_from), not from the first loaded quarter (which showed
# "GO" while the MUE files started 2026Q2 and the claims 2024-10-01). MUE: every quarter from the claims start to today;
# PTP: the quarters after the newest (cumulative file). The lines / dollars before each MUE file's first loaded quarter
# come from the build log (07 counts them: ncci_history_gaps), so v03 stays one claims query.
CLAIMS_START = b.get("claims_from") if b else None
_hist = json.loads(b["ncci_history_gaps"]) if b and isinstance(b.get("ncci_history_gaps"), str) else {}
fresh = pd.DataFrame([{"service": f["service"], "edit": f["edit"], "first": f["first"], "latest": f["latest"],
                       "missing_from_claims_start": ", ".join(f["missing"]) or "none",
                       "ao_lines_before_first": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_lines_before_first"),
                       "ao_paid_before_first": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_paid_before_first"),
                       # v2.9 (2026-10-17): every window of a file ends with its newest loaded quarter (`through`)
                       "through": f["through"],
                       "ao_lines_after_latest": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_lines_after_latest"),
                       "ao_paid_after_latest": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_paid_after_latest")}
                      for f in acquire_ncci.ncci_freshness(metas, CLAIMS_START)])
print(f"today is in {cy}Q{cq}; claims start {CLAIMS_START or 'unknown (no build log)'}"
      + ("" if _hist else "; the build log has no ncci_history_gaps (rebuild with 07) - lines before the first quarter unknown"))
display(fresh)

# COMMAND ----------

# MAGIC %md ## 4. Extraction outcomes by chapter (current document version)

# COMMAND ----------

# the CURRENT corpus - the exact document set: policy_docs.corpus_version of each document's latest doc_hash
# (quality.current_doc_hash), the id v01 stamps on every sample and 07 on every build. The ONLY corpus id this notebook
# shows (2026-10-14: the corpus row printed a second id that also hashed the loaded AHCCCS tables, so the real run showed
# corpus-38bdddc2efe69681 here and corpus-7134c61e71b11ea5 on the v01 sample of the same 36 documents)
INV_CUR = (quality.current_doc_hash(spark.table(T("policy_document_inventory")).toPandas())
           if have("policy_document_inventory") else {})
CORPUS_VERSION = policy_docs.corpus_version(INV_CUR)
print(f"current corpus {CORPUS_VERSION}: {len(INV_CUR)} document(s)")
oc = pd.DataFrame()
if have("policy_extraction_outcomes") and INV_CUR:
    cur_df = spark.createDataFrame(pd.DataFrame({"chapter": list(INV_CUR), "doc_hash": list(INV_CUR.values())}),
                                   "chapter string, doc_hash string")
    w = Window.partitionBy("section_id", "doc_hash").orderBy(F.desc("run_id"))
    oc = (spark.table(T("policy_extraction_outcomes")).withColumn("chapter", F.col("chapter").cast("string"))
          .join(cur_df, ["chapter", "doc_hash"]).withColumn("_r", F.row_number().over(w)).where("_r = 1")
          .groupBy("chapter").pivot("outcome").count().fillna(0).toPandas())
    display(oc.sort_values("chapter", key=lambda s: s.map(lambda v: (len(v), v))))
    if have("policy_extraction_log"):
        # 2026-10-14: model_calls / model_failures were the run's running totals (6, 15, 39 ... 198); shown per chapter
        lg, _cum = quality.chapter_model_counts(spark.table(T("policy_extraction_log")).toPandas())
        lg = lg.sort_values("started_at" if "started_at" in lg.columns else "run_id").groupby("chapter").tail(1)
        print("latest extraction run per chapter (backend = how rules were found; model_failures > 0 needs a look)"
              + (f"; model counts of run(s) {', '.join(_cum)} were running totals, shown per chapter" if _cum else "")
              + ":")
        display(lg[[c for c in ("chapter", "run_id", "backend", "model_backend", "model_calls", "model_failures", "proposals",
                                "grounded", "dropped", "error") if c in lg.columns]])
else:
    print("No extraction outcomes yet (no chapter extracted with this package version).")

# COMMAND ----------

# MAGIC %md ## 5. Latest quality metrics (from v01 / v02)

# COMMAND ----------

# an extraction number is judged only when measured on the current corpus (CORPUS_VERSION, section 4; critic M51-3)
# ... and the CURRENT engine output: the latest successful run of each chapter's current document version (the notion v01
# samples from). 2026-10-04 (follow-up to critic M51-3): re-running 04 on the same corpus (another reasoning effort) left
# the older run's sample judgeable - a number is judged only while the runs its sample_runs names are still the latest.
LATEST_RUNS = quality.latest_runs(spark.table(T("policy_extraction_log")).toPandas()
                                  if have("policy_extraction_log") else None, INV_CUR)
QM_ALL = qm = pd.DataFrame()
if have("policy_quality_metrics"):
    QM_ALL = spark.table(T("policy_quality_metrics")).toPandas()
    qm = QM_ALL.sort_values("computed_at").groupby(["metric", "scope"]).tail(1)
    display(qm.sort_values(["metric", "scope"])[[c for c in (
        "metric", "scope_type", "scope", "n", "value", "ci_low", "ci_high", "unscored", "scored_units", "population",
        "corpus_version", "sample_runs", "sample_id", "computed_at", "notes") if c in qm.columns]])
    print(f"current corpus {CORPUS_VERSION}, latest runs {quality.sample_runs_text(LATEST_RUNS) or 'none'}: an "
          f"extraction number is judged only when measured on the engine's own output (population "
          f"{quality.ENGINE_POPULATION}) of this corpus and of these runs, with at most {MAX_UNSCORED_SHARE:.0%} of its "
          "drawn units unscored")
else:
    print("policy_quality_metrics does not exist: NO quality metric has been measured yet (run v01 / v02 and ingest scored workbooks).")


def precise(m):
    return (m["ci_high"] - m["ci_low"]) <= MAX_CI_WIDTH


def describe(label, m):
    txt = f"{label}: {m['value']:.2f} (95% CI {m['ci_low']:.2f}-{m['ci_high']:.2f}, n={int(m['n'])})"
    if not precise(m):
        need = quality.n_for_ci_width(m["value"], MAX_CI_WIDTH)
        txt += f" too few to state" + (f", ~{need - int(m['n']):,} more needed" if need else "")
    return txt


def metric(name, scope):
    """The metric row a bar may stand on, or None. An extraction number (v01): the latest row measured on the engine's
    own output of the current corpus and of the latest run of every chapter it covers, with n > 0
    (quality.metric_for_bar; why_not says why there is none). 2026-10-04 (critic M51-3 and its run follow-up): the
    latest row of ANY sample was taken - an approved-only one, an old export, another corpus, an older run.
    A detector number (v02): the latest row."""
    if name in quality.EXTRACTION_METRICS:
        return quality.metric_for_bar(QM_ALL, name, scope, CORPUS_VERSION, LATEST_RUNS)[0]
    if not len(qm):
        return None
    m = qm[(qm["metric"] == name) & (qm["scope"].astype(str) == str(scope))]
    return m.iloc[0].to_dict() if len(m) and int(m.iloc[0]["n"] or 0) > 0 else None


def why_not(name, scope, default):
    """Why no row of an extraction metric can be judged: what its latest row was measured on (population, corpus,
    runs, n = 0 and why) - or `default` when there is no row of it at all."""
    m, why = quality.metric_for_bar(QM_ALL, name, scope, CORPUS_VERSION, LATEST_RUNS)
    return default if m is not None or not len(QM_ALL) or why.startswith("no ") else why


def unscored_share(m):
    """The share of a metric's drawn units left unscored (0 for rows ingested before 2026-10-04: none recorded)."""
    u = quality._int_or_none(m.get("unscored")) or 0
    k = quality._int_or_none(m.get("scored_units"))
    k = int(m["n"]) if k is None else k
    return u / (u + k) if u + k else 0.0

# COMMAND ----------

# MAGIC %md ## 6. The measurement bar — GO / NOT YET

# COMMAND ----------

sr = spark.table(config.STATE_RULES_TABLE).toPandas()
ext_chapters = sorted({str(c) for c in sr.loc[sr["origin"] == "extracted", "chapter"].dropna()}, key=lambda v: (len(v), v))

for name, label in (("extraction_precision", "Extraction precision measured per chapter"),
                    ("extraction_recall", "Extraction recall measured per chapter")):
    if not ext_chapters:
        bar(label, False, "no extracted rules yet")
        continue
    ms = {c: metric(name, c) for c in ext_chapters}
    miss = [c for c in ext_chapters if ms[c] is None]
    wide = [c for c in ext_chapters if ms[c] is not None and not precise(ms[c])]
    # 2026-10-04 (critic M51-6): a chapter with too many drawn units left unscored is not measured either
    blank = [c for c in ext_chapters if ms[c] is not None and unscored_share(ms[c]) > MAX_UNSCORED_SHARE]
    vals = "; ".join(describe(f"ch {c}", ms[c]) for c in ext_chapters if ms[c] is not None)
    bar(label, not miss and not wide and not blank,
        (f"{vals}. " if vals else "")
        + (f"no judgeable sample for chapter(s) {', '.join(miss)}: "
           f"{why_not(name, miss[0], 'no scored sample (run v01 with STATUSES = None, score and ingest)')}. "
           if miss else "")
        + (f"more than {MAX_UNSCORED_SHARE:.0%} of the drawn units unscored for chapter(s) {', '.join(blank)}. "
           if blank else "")
        + ("" if miss or wide or blank else "every extracted chapter is measured to within the interval width."))

def per_chapter(name):
    """'; per chapter: ch 10 0.91 (...); ...' for the extracted chapters that have a number (shown, not judged)."""
    vals = [describe(f"ch {c}", metric(name, c)) for c in ext_chapters if metric(name, c) is not None]
    return f"; per chapter: {'; '.join(vals)}" if vals else ""


# 2026-10-14 (SB): the precision pass mark is judged on the rules that ACTUALLY compile - real AND faithful among every
# compiled state rule of the current build, each scored by a person (a census: an exact rate, no interval;
# quality.compiled_precision_bar, section 6 below). It used to be a lower 95% bound on a sample of the engine's raw drafts,
# rejected ones included (raw precision about 0.6 to 0.7: it could never pass and did not measure what flags providers).
# The raw drafts' number stays, shown without a pass mark.
# 2026-10-04 (critic M51-3 / M51-6): metric() gives only a row measured on the engine's own output of the current corpus
# (why_not says what the latest row was measured on otherwise), and a row with more than MAX_UNSCORED_SHARE of its drawn
# units unscored is NOT YET (quality.lower_bound_bar)
_er = metric("executable_rule_precision", "all")
info("Engine drafts before review: share real AND faithful among those that would compile (no pass mark)",
     (describe("pooled", _er) + per_chapter("executable_rule_precision")) if _er else
     "not measured: " + why_not("executable_rule_precision", "all", "no scored sample of the engine's drafts (run v01)"))
rc = metric("extraction_recall", "all")
ok, why = quality.lower_bound_bar(rc, RECALL_TARGET, "rules in scored sections",
                                  why_not("extraction_recall", "all", "no scored recall sample (run v01 and ingest; "
                                                                      "real_rules_found and missed_rules)"),
                                  MAX_UNSCORED_SHARE)
bar(f"Extraction recall >= {RECALL_TARGET:.2f} (lower 95% bound, pooled)", ok, why + per_chapter("extraction_recall"))

ok, why = quality.lower_bound_bar(metric("extraction_fidelity", "all"), FIDELITY_TARGET, "scored real rules",
                                  why_not("extraction_fidelity", "all", "no scored fidelity sample (run v01 and ingest)"),
                                  MAX_UNSCORED_SHARE)
bar(f"Extraction fidelity >= {FIDELITY_TARGET} (lower 95% bound)", ok, why)

# real rules the grounding / post-checks dropped (v01 DROPPED sheet): a recall loss no other number sees. No pass mark.
fl = metric("extraction_filter_loss", "all")
info("Extraction filter loss: dropped candidates that were real rules (no pass mark)",
     (describe("pooled", fl) + per_chapter("extraction_filter_loss")
      + (f". {quality._text(fl.get('notes'))}" if quality._text(fl.get("notes")) else ""))
     if fl else "not measured: " + why_not("extraction_filter_loss", "all",
                                           "no scored DROPPED sheet ingested (run v01)"))

if run.get("run_id") and have("policy_findings"):
    strata = (spark.table(T("policy_findings")).where(F.col("run_id") == run["run_id"])
              .select(F.concat_ws(" | ", "origin", "predicate_type").alias("s")).distinct().toPandas()["s"].tolist())
    ms = {x: metric("detector_precision", x) for x in strata}
    miss = [x for x in strata if ms[x] is None]
    wide = [x for x in strata if ms[x] is not None and not precise(ms[x])]
    vals = "; ".join(describe(x, ms[x]) for x in strata if ms[x] is not None)
    bar("Detector precision measured per rule type", bool(strata) and not miss and not wide,
        (f"{vals}. " if vals else "") + (f"no reviewed sample for {', '.join(miss)} (run v02). " if miss else "")
        + ("the latest run has no findings" if not strata else
           "" if miss or wide else "every rule type that fired is measured to within the interval width."))
else:
    bar("Detector precision measured per rule type", False, "no detector run yet")

# decision D6 (2026-10-14): coverage = paid $ dated inside the window of a compiled rule that RAN, over every paid line
# and over the procedure-coded lines - computed once, by 08 (gap.ran_coverage), and read here from its run log
ok, why = quality.ran_coverage_bar(RUN_SNAPSHOT)
bar("Coverage reported (% of paid $ under a compiled rule that ran)", ok, why)

# the contradiction register is ONE table, policy_ahcccs_conflicts (registers.contradiction_register: the AHCCCS tables
# against a state rule or themselves, a state rule against a federal edit, the leads conflicting with another source);
# 07 counts its contradictions (registers.contradictions: every relationship but the not_compiled_* records)
amb, contra = num(b.get("ambiguity_register_rows")), num(b.get("contradiction_candidates"))
_by = ""
if have("policy_ahcccs_conflicts"):
    _rel = spark.table(T("policy_ahcccs_conflicts")).select("relationship").toPandas()["relationship"].astype(str)
    _rel = _rel[~_rel.str.startswith(registers.NOT_COMPILED_PREFIX)].value_counts()
    _by = " (" + ", ".join(f"{k} {v}" for k, v in _rel.items()) + ")" if len(_rel) else ""
bar("Register sizes reported (ambiguities, contradictions)", amb is not None and contra is not None,
    f"{amb} ambiguity entries, {contra} contradiction candidate(s){_by} (candidates, not confirmed)"
    if amb is not None and contra is not None else "register sizes missing from the build log (run 07_build_kb)")

if run.get("run_id"):
    # errors without the RUN:snapshot row; a partial run with the reason its skipped queries record (critic M51-8)
    problems = ([f"run is on build {run['build_id']}, current is {BUILD_ID}"] if run["build_id"] != BUILD_ID else []) + \
               run["problems"]
    bar("Latest detector run complete on the current build", not problems,
        "; ".join(problems) or f"run {run['run_id']}: {run['findings']:,} findings, no errors")
else:
    bar("Latest detector run complete on the current build", False, "no detector run yet")

# NCCI freshness (2026-10-14): GO only when every edit file has every quarter it needs from the claims start through today
# and no CMS-1500 / UB-04 line is dated before an MUE file's first loaded quarter, or (v2.9) after a file's newest
# loaded quarter (per the build log)
_gaps = [f"{r.service} {r.edit}: missing {r.missing_from_claims_start}" for r in fresh.itertuples()
         if r.missing_from_claims_start != "none"]
_before = [f"{r.service} mue: {int(r.ao_lines_before_first):,} lines / ${float(r.ao_paid_before_first or 0):,.0f} before "
           f"{r.first}" for r in fresh.itertuples() if r.edit == "mue" and num(r.ao_lines_before_first)]
_before += [f"{r.service} {r.edit}: {int(r.ao_lines_after_latest):,} lines / ${float(r.ao_paid_after_latest or 0):,.0f} "
            f"after {r.through} (no check from it)" for r in fresh.itertuples() if num(r.ao_lines_after_latest)]
bar(f"NCCI edits loaded from the claims start ({CLAIMS_START or 'unknown'}) through {cy}Q{cq}",
    bool(CLAIMS_START) and not _gaps and not _before and bool(_hist),
    "; ".join(_gaps + _before) or ("every edit file covers the claims start through today" if _hist and CLAIMS_START
                                   else "claims start or ncci_history_gaps not in the build log (rebuild with 07)"))

# version binding: approvals of another document version are excluded by 07 (stale) and wait for a re-sign. Shown in the
# sign-off row below (2026-10-14: a separate "Nothing compiles without version-bound sign-off" row said GO from a config
# switch alone, even with no build; the sign-off row checks every compiled rule of the build itself)
waiting = int(((sr["review_status"] == "needs_review") & sr["prior_review"].notna()).sum()) if "prior_review" in sr else 0
VERSION_BINDING = (f"{int(num(b.get('stale_approvals_excluded')) or 0)} stale approval(s) excluded by the build; "
                   f"{waiting} rule(s) waiting for re-sign")

# 2026-10-04 (v5.2): the AHCCCS rule tables 00b loaded (a 'loaded' row in config.AHCCCS_TABLES_LOG), read once: the
# sign-off bar judges their rules by their readings (v5.2b) and the corpus bar below counts them
TABLE_LOG = (spark.table(config.AHCCCS_TABLES_LOG).toPandas()
             if spark.catalog.tableExists(config.AHCCCS_TABLES_LOG) else None)
TABLES_LOADED = ahcccs_tables.loaded_versions(TABLE_LOG)


def table_readings(key):
    """{signed, reason} of a loaded table's readings (ahcccs_tables.table_compiles). signed only when the table compiles
    AND none of its readings is unsigned: with config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off a table compiles
    unsigned, and that is not a signature."""
    try:
        ok_, why_ = ahcccs_tables.table_compiles(key)
        return {"signed": bool(ok_) and not ahcccs_tables.unsigned_readings(key), "reason": why_}
    except Exception as e:                       # read-only health check: say why, never stop
        return {"signed": False, "reason": f"{key}: its readings could not be read ({type(e).__name__}: {e})"}


TABLE_READINGS = {k: table_readings(k) for k, vs in TABLES_LOADED.items() if vs}

# 2026-10-04 (external review): checked on the current build itself, rule by rule - every compiled STATE rule (a query) must
# be approved by a named reviewer
# 2026-10-04 (v5.2b, critic F9): an AHCCCS table rule (TBL-, review_status state_table) has no reviewer of its own - it
# was listed as unsigned, so the bar could never be GO. A table's rules are signed through its readings: the bar states,
# per LOADED table, whether its readings are signed (quality.table_readings_bar) and is NOT YET when a table's rules
# compile on readings nobody signed (config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off)
SIGNOFF_ITEM = "Every executable state rule signed by a named reviewer"
PRECISION_ITEM = (f"Executable-rule precision >= {EXEC_PRECISION_TARGET:.2f} (the pilot: every state rule that compiles "
                  "scored real AND faithful)")
EXPLAINED_ITEM = ("Every compiled state rule explained (in the latest review, or decided earlier and not reproduced) "
                  "and no near-duplicate pair")
EXPLAINED = None
if have("policy_detectors") and have("policy_rules"):
    _pr = spark.table(T("policy_rules"))
    _keep = [c for c in ("review_status", "reviewer", "reviewed_at", "extraction_key", "approved_predicate_sha256",
                         "codes", "predicate", "population", "doc_hash") if c in _pr.columns]
    _dt = spark.table(T("policy_detectors"))
    compiled_state = (_dt.where("compiled AND (origin IS NULL OR origin <> 'ncci')")
                      .select("rule_id", "origin", "predicate_type",
                              *[c for c in ("effective_date", "end_date") if c in _dt.columns]).toPandas()
                      .merge(_pr.where("origin IS NULL OR origin <> 'ncci'").select("rule_id", *_keep).toPandas()
                             .drop_duplicates("rule_id", keep="last"), on="rule_id", how="left"))
    ok, why = quality.signoff_bar(compiled_state)
    ok_t, why_t = quality.table_readings_bar(compiled_state, TABLE_READINGS)
    bar(SIGNOFF_ITEM, ok and ok_t, f"build {BUILD_ID}: {why}" + (f"; {why_t}" if why_t else "") + f"; {VERSION_BINDING}")
    # 2026-10-14 (SB): the precision pass mark, on the rules that compile (v01 scores, policy_extraction_scores)
    ok, why = quality.compiled_precision_bar(
        compiled_state, spark.table(T("policy_extraction_scores")).toPandas() if have("policy_extraction_scores") else None,
        EXEC_PRECISION_TARGET)
    bar(PRECISION_ITEM, ok, f"build {BUILD_ID}: {why}")
    # 2026-10-17 (round 4, external review: 45 compiled where the review expected 42, explained by hand): every compiled
    # state rule of the build with why it is there - from state_rules (the run that last produced it), the latest
    # successful run of its chapter (LATEST_RUNS, section 5) and that run's drafts (those runs only); GO only with none
    # unexplained and no near-duplicate pair (a pair needs a reject or an end date)
    _drafts = (spark.table(T("policy_extraction_drafts")).select("run_id", "extraction_key")
               .join(spark.createDataFrame(pd.DataFrame({"run_id": sorted(set(LATEST_RUNS.values()))}), "run_id string"),
                     "run_id").toPandas()
               if LATEST_RUNS and have("policy_extraction_drafts") else None)
    EXPLAINED = quality.compiled_rule_explanations(compiled_state, sr, INV_CUR, LATEST_RUNS, _drafts)
    # 2026-10-17 (second review, finding 4): two decided readings of one sentence (07's build log) keep it NOT YET
    _ss = b.get("same_sentence_readings") if b else None              # an older build row has no such key / NaN
    ok, why = quality.explained_bar(EXPLAINED, json.loads(_ss) if isinstance(_ss, str) and _ss else None)
    bar(EXPLAINED_ITEM, ok, f"build {BUILD_ID}: {why}")
    print("every compiled state rule of the build, and why it is there (category):")
    display(EXPLAINED)
else:
    bar(SIGNOFF_ITEM, False, "no build yet (run 07_build_kb)")
    bar(PRECISION_ITEM, False, "no build yet (run 07_build_kb)")
    bar(EXPLAINED_ITEM, False, "no build yet (run 07_build_kb)")

# 2026-10-04 (external review): a rate needs an unambiguous denominator - the exact document set (CORPUS_VERSION, section
# 4) - and the corpus is complete only when every manual chapter is ingested and no rule source of config.CORPUS_PENDING
# is still to load. An AHCCCS rule table 00b loaded (a 'loaded' row in config.AHCCCS_TABLES_LOG) is named with its
# version dates and leaves the "still to load" list (its CORPUS_PENDING key is the table key); 2026-10-14: it no longer
# changes the corpus id this row prints (one id: the one v01 stamps). (TABLE_LOG / TABLES_LOADED: read above.)
# 2026-10-04 (v5.2b, critic F12): the tables whose claims run past the newest version's max age (the latest build's
# ahcccs_stale_vs_claims, 07) are named in this row - shown, not judged
TABLES_STALE = quality._json(b.get("ahcccs_stale_vs_claims")) or {}
ok, why = quality.corpus_bar(INV_CUR, config.CHAPTERS, getattr(config, "CORPUS_PENDING", {}), CORPUS_VERSION,
                             loaded_tables=TABLES_LOADED, stale_tables=TABLES_STALE)
bar(f"Corpus frozen and complete for its stated scope ({quality.CORPUS_SCOPE})", ok, why)

# v06: every query of the CURRENT build signed OK by a validator (a decision binds to the exact SQL via its sha256)
cur_sql = {}
if have("policy_detectors"):
    _dt = spark.table(T("policy_detectors"))
    _d = _dt.where("compiled AND sql IS NOT NULL").select("rule_id", "sql_sha256").toPandas()
    cur_sql.update(dict(zip(_d["rule_id"], _d["sql_sha256"])))
    if "signal_sql" in _dt.columns:          # period limits: the rolling-window signal query is validated too
        _s = _dt.where("compiled AND signal_sql IS NOT NULL").select("rule_id", "signal_sql_sha256").toPandas()
        cur_sql.update({f"SIGNAL:{r}": h for r, h in zip(_s["rule_id"], _s["signal_sql_sha256"])})
if have("policy_batch_detectors"):
    _b = spark.table(T("policy_batch_detectors")).toPandas()
    if "sql_sha256" in _b:
        cur_sql.update({f"BATCH:{r['batch']}": r["sql_sha256"] for r in _b.to_dict("records")})
signed_ok = set()
if have("policy_query_validation"):
    _v = spark.table(T("policy_query_validation")).toPandas()
    _v = _v.sort_values("validated_at").drop_duplicates(["query_id", "sql_sha256"], keep="last")
    signed_ok = {(r["query_id"], r["sql_sha256"]) for r in _v.to_dict("records") if r["validator_decision"] == "OK"}
n_ok = sum(1 for q, h in cur_sql.items() if (q, h) in signed_ok)
bar("Every query of the current build validated by a person (v06)", bool(cur_sql) and n_ok == len(cur_sql),
    f"{n_ok} of {len(cur_sql)} current queries signed OK (v06 pack: plain English + SQL + scenario auto-tests)"
    if cur_sql else "no compiled queries in the current build")

# which NCCI edit file a line takes depends on the provider-type routing table - a policy reading too. D1 (2026-10-14): a
# line takes a file only when the row that decides it is signed, so the bar reads the codes that DECIDE the lines
# (ncci_routing.observed_types_sql, 08's own reading: billing type, a group's line its servicing type) with their paid
# dollars, and says what share of those dollars NCCI will check; GO only when every deciding code is signed
_rt = ncci_routing.summary()
OBSERVED_TYPES = UNSIGNED_TYPES = ROUTED_PAID = None
try:
    _src = ncci_routing.routed_sql(config.CLAIMS_TABLE, config.CLAIM_COLS,
                                   cols={c.upper() for c in spark.table(config.CLAIMS_TABLE).columns})
    _obs = spark.sql(ncci_routing.observed_types_sql(f"{_src} rc", ncci_routing.PIE_FORM,
                                                     paid_col=config.CLAIM_COLS.get("paid_amt"),
                                                     group_unrouted=True)).collect()
    ROUTED_PAID = {r["t"]: float(r["paid"] or 0) for r in _obs}
    OBSERVED_TYPES = sorted(t for t in ROUTED_PAID if t is not None)
    UNSIGNED_TYPES = ncci_routing.unsigned_observed(OBSERVED_TYPES)
except Exception as e:                           # read-only health check: say why the bar cannot be judged, never stop
    print(f"could not read the provider types on {config.CLAIMS_TABLE}: {type(e).__name__}: {e}")
print("NCCI routing: billing provider type"
      + (f"; {len(OBSERVED_TYPES)} deciding provider type code(s) observed, {len(UNSIGNED_TYPES)} unsigned"
         if OBSERVED_TYPES is not None else ""))
ok, why = quality.routing_bar(_rt, OBSERVED_TYPES, UNSIGNED_TYPES, ROUTED_PAID)
bar("NCCI routing table (provider type -> CMS Table 2) signed for every provider type on CMS-1500 / UB-04 lines", ok, why)

go_table = pd.DataFrame(GO)
display(go_table)
_n = go_table["status"].value_counts().to_dict()
print(f"{_n.get('GO', 0)} GO, {_n.get('NOT YET', 0)} NOT YET"
      + (f", {_n.get('INFO', 0)} shown without a pass mark (INFO)" if _n.get("INFO") else "")
      + ". Done is not declarable while any measurement-bar row is NOT YET.")
