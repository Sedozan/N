# Databricks notebook source
# MAGIC %md
# MAGIC # One-time: seed `main.sedo.state_rules`
# MAGIC
# MAGIC Writes the reviewed AHCCCS state rules the build reads from. The rules come from
# MAGIC `state_seed.py` — a self-contained, cited set (Chapters 10 & 19) — so this notebook
# MAGIC does **not** depend on importing the old hand-authored modules. Grammar upgrades
# MAGIC (`code_not_covered`, `max_units_per_period`) are already applied.
# MAGIC
# MAGIC Optionally it will also pull any PoC modules that still import, but that path is
# MAGIC additive and fully guarded — if they fail, the seed alone still produces a table.
# MAGIC
# MAGIC **Since 2026-10-04 (fresh start) these hand-authored rules are a CHECKLIST, not KB rules:** v05 scores each
# MAGIC extraction run against them (what the engine must find), but they are not exported for review and never compile
# MAGIC (`config.COMPILE_HAND_AUTHORED = False`; the KB holds rules of one extraction engine, `config.KB_PROMPT_VERSIONS`).
# MAGIC
# MAGIC Re-running is safe: seed rows are upserted; drafts, approvals and rejections are kept.
# MAGIC A seed a reviewer has signed in the review workbook (approved / rejected, C4-05) keeps that
# MAGIC decision. A legacy seed row that `state_seed.py` no longer contains (e.g. the three per-code
# MAGIC CHW daily caps, now ONE combined cap) is **retired**: `review_status = superseded`, its previous
# MAGIC state kept in `prior_review` - never left compiling, never deleted.

# COMMAND ----------

import os, sys, importlib, re
# ---- find the package: this notebook's folder or its parent must contain config.py.
# No hard-coded workspace path; set PKB_PACKAGE_DIR if you keep the notebooks elsewhere.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; run this notebook from inside the pie_mvp folder "
                      f"or set PKB_PACKAGE_DIR")

import config, schema, state_rules, state_seed, kb_io
for m in (config, schema, state_seed, state_rules, kb_io):
    importlib.reload(m)

STATE_RULES_TBL = config.STATE_RULES_TABLE       # main.sedo.state_rules

# COMMAND ----------

# MAGIC %md ## Collect the hand-authored rules (state_seed.py)

# COMMAND ----------

raw = list(state_seed.seed_rules())
print(f"  state_seed.seed_rules()          {len(raw):4d} rules")
if not raw:
    raise RuntimeError("no rules collected — check state_seed imports")     # fail loud, never write empty
print(f"\n{len(raw)} rule objects collected")

# COMMAND ----------

# MAGIC %md ## Chapter tag, stable ids, de-duplicate, write

# COMMAND ----------

def chapter_of(r):
    ch = state_seed.CHAPTER_BY_DOC.get(getattr(r, "source_doc", ""))
    if ch:
        return ch
    m = re.search(r"Chapter\s+(\d+)", getattr(r, "source_doc", "") or "")
    return m.group(1) if m else "unknown"

rows, seen = [], set()
for r in raw:
    row = state_rules.rule_to_row(r, chapter=chapter_of(r), review_status="legacy_hand_authored",
                                  reviewer=None, review_note="seeded during MVP build")
    row["rule_id"] = schema.stable_rule_id(r.to_dict())     # content-derived: no collisions
    if row["rule_id"] in seen:
        continue
    seen.add(row["rule_id"])
    rows.append(row)

import pandas as pd
if rows:
    summary = (pd.DataFrame(rows).groupby(["chapter", "machine_checkable"])
                 .size().reset_index(name="rules"))
    print(summary.to_string(index=False))
else:
    print("no rows to write")

# D6: UPSERT, never overwrite. Re-running this notebook used to replace the whole table with the
# seed - deleting every extracted draft, approval and reviewer. Now a seed row replaces only the
# matching legacy_hand_authored row; everything else (drafts, approvals, rejections) is kept.
existing = kb_io.table_or_none(spark, STATE_RULES_TBL)      # None only if the table does not exist
merged, counts = state_rules.upsert_seed_rows(existing, rows)
from extract_io import guard_state_rules_merge
guard_state_rules_merge(existing, merged, STATE_RULES_TBL)
state_rules.write_state_rules(spark, STATE_RULES_TBL, merged.to_dict("records"))
print(f"state_rules: {counts}")
if counts.get("kept_signed_seed"):
    print(f"  {counts['kept_signed_seed']} seed rule(s) were signed in the review workbook - their decision is kept "
          f"(the seed text did not overwrite it)")
if counts.get("retired_seed"):
    # C4-05 / seed revision: a legacy seed row no longer produced by state_seed.py stops compiling here
    gone = merged[(merged["review_status"] == "superseded") & merged["review_note"].fillna("").str.contains("retired:")]
    print(f"  {counts['retired_seed']} legacy seed rule(s) RETIRED (no longer in state_seed.py; status superseded, "
          f"previous state in prior_review):")
    for r in gone.head(20).to_dict("records"):
        print(f"    - {r['rule_id']}  {str(r['statement'])[:110]}")
n_unsigned = int((merged["review_status"] == "legacy_hand_authored").sum())
if not getattr(config, "COMPILE_HAND_AUTHORED", False):
    print(f"  {len(merged[merged['origin'].astype(str) == 'manual'])} hand-authored rule(s) are a CHECKLIST for v05 "
          f"(what the extraction must find): never exported for review, never compiled (config.COMPILE_HAND_AUTHORED = "
          f"False; the KB holds the rules of one extraction engine).")
else:
    print(f"  {n_unsigned} seed rule(s) are unsigned (legacy_hand_authored): they never compile. Sign them in the "
          f"review workbook (05 / 06) to make them version-independent approvals.")

# COMMAND ----------

# MAGIC %md ## Verify it reads back

# COMMAND ----------

display(spark.sql(f"""
  SELECT chapter, machine_checkable, COUNT(*) AS rules
  FROM {STATE_RULES_TBL} GROUP BY chapter, machine_checkable ORDER BY chapter
"""))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding a chapter later
# MAGIC Add rows with `review_status='draft'`, export the review workbook, have a named SME
# MAGIC fill decision / reviewer, then `state_rules.ingest_review_decisions(...)`. Only
# MAGIC `approved` rows enter the KB. See `state_rules.py`.
# MAGIC The seeds written here are in the same workbook only with `config.COMPILE_HAND_AUTHORED` (origin `manual`, no
# MAGIC doc_hash): approving one makes it a signed rule that compiles.
