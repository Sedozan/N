# Databricks notebook source
# MAGIC %md
# MAGIC # Acquire NCCI — CMS Medicaid NCCI quarterly files → `main.sedo` tables (no manual reformatting)
# MAGIC
# MAGIC Replaces: download 6 zips by hand → open → rename/reformat columns → load one table per file.
# MAGIC
# MAGIC | step | what happens | fails loudly when |
# MAGIC |---|---|---|
# MAGIC | 1 | probe egress to cms.gov | cluster cannot reach the internet → switch to the drop zone (below) |
# MAGIC | 2 | read the CMS page, **discover** zip links (slugs differ quarter to quarter, so URLs are never built); classify each by its **file name only** | a quarter lacks one of the 6 files; two different files claim the same quarter/edit/edition (**error**); CMS adds an edit-like link we cannot classify (**error**) |
# MAGIC | 3 | download → `NCCI_RAW_DIR/<YYYY>q<N>/` (kept forever, SHA-256 logged) | CMS returns an HTML page instead of a zip |
# MAGIC | 4 | parse text file (Excel fallback), locate header, map columns to the **same names as the hand-loaded tables**; every non-blank line must be an edit or a recognised footer/notes line | missing column, bad date, bad modifier indicator, non-numeric MUE, malformed edit row (e.g. blank Column Two), file quarter ≠ link quarter, **Category / MUE header names another edition than the file name** |
# MAGIC | 5 | write `medicaid_ncci_edit_<service>_<ptp\|mue>_q<N>_<YYYY>`; a CMS **revision** (`...-r1-...`) replaces the table loaded from the original (status `replaced`) | table already exists (skipped, never overwritten unless `OVERWRITE = True`); a revision next to a hand-loaded table (a human must compare) |
# MAGIC | 6 | log every file to `ncci_acquisition_log` (its own SHA-256; `src_*` provenance on every load); report missing quarters | any file failed → the notebook ends red (so a scheduled Job alerts) |
# MAGIC
# MAGIC **No egress?** Download the zips from the CMS page by hand into `NCCI_RAW_DIR` (any sub-folder — folder names are
# MAGIC ignored, only the file name is read), keep the CMS file names, set `DOWNLOAD = False`. Steps 4–6 are the same.
# MAGIC **History (2026-10-14):** with `ARCHIVE = True` the notebook also reads CMS's Medicaid MUE archive page
# MAGIC (`acq.CMS_MUE_ARCHIVE`, 2020Q1 to 2026Q2 under CMS's original names) and loads every MUE quarter from the claims'
# MAGIC first date of service (`HISTORY_FROM`, default: MIN of the claims' date of service) on: the public MUE files are
# MAGIC undated and hold only the MUEs in effect (CMS 2026 Medicaid NCCI TGM s7.1.1), so a claim is checked only when its
# MAGIC quarter's file is loaded. Without egress, put the archive zips in the drop zone under their CMS names. There is no
# MAGIC Medicaid PTP archive and none is needed: the current PTP file holds every past and present edit with its dates
# MAGIC (TGM s7.1.1). Known archive gaps (checked 2026-10-14): no 2023Q2 entry for any edition; the "DME, April 1, 2025"
# MAGIC entry links the PRACTITIONER zip, so DME 2025Q2 is not on the archive page (step 6 names it as missing); 2025Q1 is
# MAGIC only the revision `2025-q1-r1` ("Effective Jan. 29, 2025"), applied from Jan. 29 (2026-10-17): Jan. 1-28 is a gap
# MAGIC (no MUE check, listed by the freshness checks), never judged by the revision or the 2024Q4 values.
# MAGIC
# MAGIC **Schedule:** a Databricks Job on this notebook, monthly (e.g. 5th of each month). CMS posts a quarter about a
# MAGIC month before it takes effect and keeps only two quarters on the page; a missed quarter is a permanent MUE gap,
# MAGIC and `mue_history` will then refuse to build. Re-runs are idempotent.
# MAGIC
# MAGIC **Then:** `01_preflight_ncci` → `07_build_kb`.

# COMMAND ----------

import os, sys
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib, re
import pandas as pd
import config, acquire_ncci as acq, ingest_ncci_tables as ing, kb_io
for m in (config, acq, ing, kb_io):
    importlib.reload(m)

# ---- parameters
DOWNLOAD         = True                    # False = read zips already in NCCI_RAW_DIR (drop zone)
OVERWRITE        = False                   # True replaces an existing quarter table - destructive, leave False
QUARTERS         = None                    # e.g. {"2026q4"}; None = every quarter listed on the page / in the drop zone
ARCHIVE          = True                    # also read the CMS Medicaid MUE archive page (download mode)
HISTORY_FROM     = None                    # "YYYY-MM-DD": load archive quarters from this date; None = the claims' first
                                           # date of service (config.CLAIMS_TABLE)
CROSS_CHECK_XLSX = False                   # also parse the Excel copy and require the same row count (slow for PTP)
CATEGORY_CHECK   = "strict"                # C2-16: "strict" refuses a Category value naming no known edition;
                                           # "lenient" loads it on the file name with a warning. A Category naming
                                           # ANOTHER edition is refused in both modes.
RAW_DIR          = config.NCCI_RAW_DIR
LOG_TABLE        = config.NCCI_ACQUISITION_LOG
CAT, SCH         = config.CATALOG, config.SCHEMA
os.makedirs(RAW_DIR, exist_ok=True)
print("raw archive:", RAW_DIR)

# COMMAND ----------

# MAGIC %md ## 1–2. Egress probe and link discovery

# COMMAND ----------

session = acq.make_session() if DOWNLOAD else None
if DOWNLOAD:
    ok, detail = acq.probe_egress(session)
    print(f"egress to cms.gov: {'OK' if ok else 'BLOCKED'} - {detail}")
    if not ok:
        raise RuntimeError("This cluster cannot reach cms.gov. Either run on compute with internet egress, or "
                           f"download the zips by hand into {RAW_DIR} and set DOWNLOAD = False.")
    html = acq._get(session, acq.CMS_PAGE).text
    links = acq.discover_links(html)
else:
    links = acq.links_from_drop_zone(RAW_DIR)

# the quarters the claims need (2026-10-14): from the claims' first date of service, not from the first quarter loaded
if HISTORY_FROM:
    CLAIMS_START = HISTORY_FROM
else:
    try:
        _dos = config.CLAIM_COLS["dos"]
        CLAIMS_START = spark.sql(f"SELECT CAST(MIN(CAST({_dos} AS DATE)) AS STRING) AS d "
                                 f"FROM {config.CLAIMS_TABLE}").collect()[0].d
    except Exception as e:                       # no claims access here: the history range must be given by hand
        print(f"WARNING cannot read the claims' first date of service ({type(e).__name__}): set HISTORY_FROM")
        CLAIMS_START = None
START_Q = acq.quarter_of(CLAIMS_START) if CLAIMS_START else None
print(f"claims start {CLAIMS_START}: NCCI MUE history is needed from {START_Q[0]}Q{START_Q[1]}" if START_Q else
      "claims start unknown (no date of service): set HISTORY_FROM")
page_names = {l.name.lower() for l in links}
if DOWNLOAD and ARCHIVE:
    arch = acq.discover_links(acq._get(session, acq.CMS_MUE_ARCHIVE).text, base=acq.CMS_MUE_ARCHIVE)
    # the archive's own entries, from the claims' first quarter on; a file the page also lists is read once
    arch = [l for l in arch if l.name.lower() not in page_names
            and (l.kind != "edits" or START_Q is None or (l.year, l.quarter) >= START_Q)]
    print(f"MUE archive: {sum(l.kind == 'edits' for l in arch)} edit file(s) from {START_Q} on")
    links = links + arch

unknown = [l for l in links if l.kind == "unknown"]
edits = [l for l in links if l.kind == "edits"]
print(f"{len(edits)} edit files, {sum(l.kind == 'change_report' for l in links)} change reports, {len(unknown)} unclassified")
for l in sorted(edits, key=lambda l: (l.label, l.edit, l.service, l.revision)):
    print(f"  {l.label}  {l.edit}  {l.service:12s}  {'r' + str(l.revision) if l.revision else '  '}  {l.name}"
          + (f"   NOTE {l.note}" if l.note else ""))
for l in unknown:
    print(f"  UNCLASSIFIED (review - CMS may have changed naming): {l.url}" + (f"   ({l.note})" if l.note else ""))
# an unclassifiable file whose name looks like an edit file is a quarter we would silently not load
edit_like_unknown = [l for l in unknown if re.search(r"ptp|mue|edit", l.name, re.I)]

# C2-15: two different files for the same quarter/edit/edition/revision is an ERROR - nothing can tell which is
# right. Both are failed by acquire() below (the rest still loads) and the notebook ends red.
duplicates = acq.duplicate_links(links)
for k, urls in duplicates.items():
    print(f"  ERROR duplicate files for {k}: {urls} - keep exactly one")
incomplete = acq.check_quarter_complete(links, allow_duplicates=True)
for q, miss in incomplete.items():
    # an archive quarter has MUE files only (no PTP archive, none needed): a missing PTP file is reported only for a
    # quarter whose PTP files the page lists
    miss = [m for m in miss if not m.startswith("ptp/") or any(l.edit == "ptp" and l.label == q for l in links)]
    if miss:
        print(f"  WARNING {q} is missing {miss}")
plan = acq.plan_loads([l for l in links if not QUARTERS or l.label in QUARTERS])
for l in edits:
    if plan.get(l.url, ("load",))[0] == "superseded":
        print(f"  revision: {l.name} is {plan[l.url][1]}")
assert edits, "no NCCI edit files found - check the page / drop zone before going further"

# COMMAND ----------

# MAGIC %md ## 3–5. Download, parse, validate, load

# COMMAND ----------

existing = ing.discover_tables(spark, CAT, SCH)
prev_counts = {}
for m in existing:                           # latest existing table per (edit, service) = the row-count baseline
    prev_counts[f"{m['edit_type']}/{m['service']}"] = m["fqn"]
prev_counts = {k: spark.table(v).count() for k, v in prev_counts.items()}

results = acq.acquire(spark, links, RAW_DIR, CAT, SCH, download_files=DOWNLOAD, overwrite=OVERWRITE,
                      session=session, quarters=QUARTERS, cross_check_xlsx=CROSS_CHECK_XLSX,
                      prev_counts=prev_counts, category_check=CATEGORY_CHECK)
res = acq.results_frame(results)
# fixed column types whatever this run contained (a run with only failures used to write 'rows' as double)
acq.write_log(spark, results, LOG_TABLE)
display(res[["quarter", "edit", "service", "revision", "status", "rows", "tolerated_rows", "fmt", "warning", "error",
             "sha256"]])

# COMMAND ----------

# MAGIC %md ## 6. Completeness and go / no-go

# COMMAND ----------

after = ing.discover_tables(spark, CAT, SCH)
FRESH = acq.ncci_freshness(after, CLAIMS_START)
print(f"quarters loaded per edit file, and the quarters still missing between the claims start ({CLAIMS_START}) and "
      f"today (MUE: every quarter; PTP: after the newest only - it is cumulative)")
for f_ in FRESH:
    print(f"  {f_['service']:12s} {f_['edit']}  {f_['quarters_loaded']} loaded ({f_['first'] or '-'} .. "
          f"{f_['latest'] or '-'})  missing: {', '.join(f_['missing']) or 'none'}")
history_gaps = [f"{f_['service']} {f_['edit']}: {', '.join(f_['missing'])}" for f_ in FRESH if f_["missing"]]

print("\nper file:")
for status in ("loaded", "replaced", "skipped_exists", "superseded", "archived_only", "failed"):
    sub = res[res["status"] == status]
    if len(sub):
        print(f"  {status:15s} {len(sub)}")
replaced = res[res["status"] == "replaced"]
for _, r in replaced.iterrows():
    print(f"  REPLACED {r['quarter']} {r['edit']}/{r['service']}: was {r['replaced_src_zip']}, now {r['src_zip']} "
          f"(Delta history keeps the old version; the old zip stays in {RAW_DIR})")
noted = res[res["note"].notna()]
for _, r in noted.iterrows():
    print(f"  note {r['quarter']} {r['edit']}/{r['service']} [{r['status']}]: {r['note']}")

failed = res[res["status"] == "failed"]
warned = res[res["warning"].notna()]
if len(warned):
    print(f"\n{len(warned)} file(s) WITH WARNINGS - read them before 07_build_kb:")
    for _, r in warned.iterrows():
        print(f"  {r['quarter']} {r['edit']}/{r['service']} [{r['status']}]: {r['warning']}")
problems = []
if len(failed):
    problems.append(f"{len(failed)} NCCI file(s) failed; nothing else was affected. "
                    + "; ".join(f"{r['quarter']} {r['edit']}/{r['service']}: {r['error'][:200]}" for _, r in failed.iterrows()))
if edit_like_unknown:
    problems.append(f"{len(edit_like_unknown)} edit-like file(s) could not be classified and were NOT loaded: "
                    + "; ".join(f"{l.name} ({l.note})" for l in edit_like_unknown))
if problems:
    raise RuntimeError(" | ".join(problems))
if history_gaps:
    print("\nWARNING quarters still missing (claims in them get no NCCI check from that file; get them from the CMS "
          "archive or the drop zone, or ask CMS / AHCCCS): " + "; ".join(history_gaps))
print("\nGO: next run 01_preflight_ncci, then 07_build_kb.")
