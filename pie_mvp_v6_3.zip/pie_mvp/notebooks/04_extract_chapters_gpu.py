# Databricks notebook source
# MAGIC %md
# MAGIC # Step 1b — Extract state rules with the model (Serverless GPU, no Spark)
# MAGIC
# MAGIC Same loop as `llm_summarization_notebook`: `gpt-oss-120b` loaded with `transformers`, read through
# MAGIC `openai-harmony`. **No Delta, no Volumes, no Spark** in this notebook — it reads what `03_stage_inputs`
# MAGIC put in Workspace files and writes a run folder there:
# MAGIC
# MAGIC ```
# MAGIC RUN_ROOT/<run_id>/  drafts.jsonl · dropped.jsonl · sections.jsonl · inventory.jsonl · log.jsonl ·
# MAGIC                     changes.jsonl · outcomes.jsonl · cache.json · manifest.json
# MAGIC ```
# MAGIC
# MAGIC `cache.json` is flushed every `config.CACHE_FLUSH_EVERY` model calls and every file is rewritten after
# MAGIC each chapter, so a crash keeps the completed chapters. Then run `05_persist_extraction` on a UC-enabled CPU
# MAGIC cluster to load the run folder into tables. Measured 2026-10-19 on chapter 19 (39 pages, 46 sections to the
# MAGIC model): **2 h at reasoning "low", 4 h 47 min at "medium"**; the whole manual is several times that.

# COMMAND ----------

# MAGIC %pip install -q pymupdf pypdf torch accelerate sentencepiece openai-harmony

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import os, sys, json, importlib, time
import pandas as pd
# ---- find the package: this notebook's folder or its parent must contain config.py.
# No hard-coded workspace path; set PKB_PACKAGE_DIR if you keep the notebooks elsewhere.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; run this notebook from inside the pie_mvp folder "
                      f"or set PKB_PACKAGE_DIR")

import config, schema, policy_docs, extract_rules, extract_io, policy_changes, state_rules
for m in (config, schema, policy_docs, extract_rules, extract_io, policy_changes, state_rules):
    importlib.reload(m)

# ---- run settings -----------------------------------------------------------
CHAPTERS_TO_RUN = ["19"]                         # first scored run: one chapter; widen after scoring (see README)
                                                 # later: config.MVP_CHAPTERS = ["4","10","13","14","19","22"]
LLM_BACKEND     = "HYBRID"                       # "HYBRID" (patterns + model) | "HFLOCAL" | "STUB" (patterns only, NOT complete)
REASONING       = config.LLM_REASONING           # "low" (default) | "medium" | "high"
ONLY_CANDIDATES = True                           # skip sections with no rule signal
ALLOW_PATTERNS_ONLY = False                      # a dead model STOPS the run unless this is True
ALLOW_DOWNLOAD  = False                          # True: try to download a PDF missing from STAGE_PDF_DIR
REUSE_ANSWERS_FROM = []                          # earlier run ids (or folders) whose model answers are reused when the
                                                 # settings match: a rerun asks only for what they did not answer, a
                                                 # stopped run resumes. e.g. ["20261020T181133"]

STAGE_DIR, PDF_DIR, RUN_ROOT = config.STAGE_DIR, config.STAGE_PDF_DIR, config.RUN_ROOT
run_id = pd.Timestamp.now().strftime("%Y%m%dT%H%M%S")
RUN_DIR = extract_io.new_run_dir(RUN_ROOT, run_id)
print(f"run {run_id} -> {RUN_DIR}")

# COMMAND ----------

# MAGIC %md ## Inputs from 03_stage_inputs (files only)

# COMMAND ----------

missing = [ch for ch in CHAPTERS_TO_RUN
           if not os.path.exists(os.path.join(PDF_DIR, os.path.basename(config.CHAPTERS[ch][1])))]
if missing and not ALLOW_DOWNLOAD:
    raise RuntimeError(f"PDFs missing from {PDF_DIR} for chapters {missing}. Run 03_stage_inputs on a UC-enabled "
                       f"CPU cluster first (or set ALLOW_DOWNLOAD=True if this compute has internet egress).")

cache, existing_rules, prev_inventory, snap_meta = extract_io.load_snapshots(STAGE_DIR)
if REUSE_ANSWERS_FROM:
    _reused = extract_io.reuse_answers(RUN_ROOT, REUSE_ANSWERS_FROM, cache)
    print(f"answers reused from earlier runs: {_reused} (only where the prompt, model, reasoning and budget match)")
# C4-08: the bytes 03_stage_inputs staged; a chapter whose PDF hash differs at extraction time is reported below
stage_manifest = policy_docs.read_stage_manifest(PDF_DIR)
staged_hash = {ch: e.get("doc_hash") for ch, e in (stage_manifest.get("files") or {}).items()}
print(f"stage manifest: {len(staged_hash)} staged PDF(s), written {stage_manifest.get('written_at', '(none - run 03 first)')}")
print(f"snapshots exported {snap_meta.get('at', '?')}: cache entries {len(cache):,} | existing state_rules "
      f"{0 if existing_rules is None else len(existing_rules)} | prior inventory rows "
      f"{0 if prev_inventory is None else len(prev_inventory)}")
if not snap_meta:
    print("WARNING: no snapshots found - drafts will be produced without cache hits or change tracking; "
          "05_persist_extraction will still merge against the live table.")

# COMMAND ----------

# MAGIC %md ## Load model — once per session, exactly as in `llm_summarization_notebook`

# COMMAND ----------

USES_LOCAL_MODEL = LLM_BACKEND == "HFLOCAL" or (LLM_BACKEND == "HYBRID" and config.HYBRID_MODEL_BACKEND == "HFLOCAL")
if USES_LOCAL_MODEL:
    rt = extract_rules.load_hf_runtime(config.HF_MODEL, config.HF_TOKEN_PATH)
    config.LLM_REASONING = REASONING
backend = extract_rules.make_backend(LLM_BACKEND, allow_patterns_only=ALLOW_PATTERNS_ONLY)
print(f"PIE {getattr(config, 'PIE_VERSION', '?')} (code {extract_rules.CODE_SHA}) | backend {backend.name}:{backend.model} | "
      f"prompt {extract_rules.PROMPT_VERSION} ({extract_rules.PROMPT_SHA}) | reasoning {REASONING}")

# COMMAND ----------

# MAGIC %md ## Model health check — one real call before any chapter is touched

# COMMAND ----------

t0 = time.time()
ok, detail = extract_rules.healthcheck(backend)
print(f"{'OK ' if ok else 'FAIL'} ({time.time() - t0:.1f}s) {detail}")
if not ok and not ALLOW_PATTERNS_ONLY:
    raise RuntimeError("Model backend is not working - see above. Fix it, or set ALLOW_PATTERNS_ONLY=True for a "
                       "deliberate regex-only smoke run (NOT a complete extraction).")
if LLM_BACKEND == "STUB" or (not ok and ALLOW_PATTERNS_ONLY):
    print("WARNING: this run is PATTERNS ONLY. Zero drafts on a chapter means nothing about that chapter.")

# COMMAND ----------

# MAGIC %md ## Run — one chapter at a time; every file rewritten after each chapter

# COMMAND ----------

inventory_rows, section_rows, log_rows, dropped_rows, change_rows, all_drafts = [], [], [], [], [], []
outcome_rows = []                                # D11: one row per section - skipped / no_rules / proposals / failed

def manifest(finished: bool) -> dict:
    mh = extract_rules.model_health(backend)
    return {"run_id": run_id, "backend": f"{backend.name}:{backend.model}", "prompt_version": extract_rules.PROMPT_VERSION,
            "prompt_sha": extract_rules.PROMPT_SHA,      # v6.2: the exact prompt text (v05 checks an A/B held it fixed)
            # v6.3: the package version and the code that turned answers into drafts (same prompt, other code = other drafts)
            "pie_version": getattr(config, "PIE_VERSION", None), "code_sha": extract_rules.CODE_SHA,
            "reasoning": REASONING, "chapters": CHAPTERS_TO_RUN, "stage_dir": STAGE_DIR,
            "snapshots_exported_at": snap_meta.get("at"), "finished": finished,
            # C3-08 / C3: what keys the cache and whether the deterministic post-checks ran
            "cache_key_tag": extract_rules._generation_tag(backend), "post_checks": getattr(config, "POST_CHECKS", True),
            # C4-08: the staged PDF versions this run was meant to read (inventory.jsonl has what it did read)
            "staged_doc_hash": {ch: staged_hash.get(ch) for ch in CHAPTERS_TO_RUN}, **mh}

def flush_cache(cache_dict):
    extract_io.write_cache(RUN_DIR, cache_dict)

for ch in CHAPTERS_TO_RUN:
    t0 = time.time()
    title = config.CHAPTERS[ch][0]
    print(f"\n=== Chapter {ch}: {title}")
    try:
        inv = policy_docs.acquire(ch, PDF_DIR, download=ALLOW_DOWNLOAD)
        if staged_hash.get(ch) and staged_hash[ch] != inv["doc_hash"]:
            print(f"  WARNING: the PDF changed since 03 staged it ({staged_hash[ch][:12]} -> {inv['doc_hash'][:12]}); "
                  f"both versions are kept in _versions/")
        pages = policy_docs.parse_pdf(inv["path"])
        secs, meta = policy_docs.segment(pages, ch, inv["doc_hash"])
        inv["revision_date"] = meta["revision_date"]
        inv["revision_history"] = meta["revision_history"]   # each draft says which entries concern it
        inventory_rows.append(policy_docs.inventory_record(inv, meta))
        for s in secs:
            section_rows.append({k: (json.dumps(v) if isinstance(v, list) else v) for k, v in s.items()} | {"run_id": run_id})
        hist = meta["revision_history"]
        print(f"  {meta['pages']} pages, rev {meta['revision_date']}, {meta['sections']} sections, "
              f"{meta['candidate_sections']} candidates ({inv['source']}) | revision history: {len(hist)} entries "
              f"from the {hist[0]['source'] if hist else 'PDF'}, {sum(1 for h in hist if not h['date'])} undated")

        drafts, dropped, stats = extract_rules.extract_chapter(
            secs, inv, backend, run_id, ONLY_CANDIDATES, cache,
            checkpoint_fn=flush_cache, checkpoint_every=config.CACHE_FLUSH_EVERY, outcomes=outcome_rows)
        changes = policy_changes.diff_chapter(existing_rules, drafts, inv, prev_inventory, run_id)
        all_drafts += drafts; dropped_rows += dropped; change_rows += changes
        stats["seconds"] = round(time.time() - t0, 1); stats["error"] = None
        log_rows.append(stats)
        print(f"  proposals {stats['proposals']} -> grounded {stats['grounded']} (dropped {stats['dropped']}, "
              f"cache hits {stats['sections_from_cache']}) | drafts {stats['drafts_unique']} | "
              f"changes {policy_changes.summarize(changes)}")
        if stats.get("cache_patterns_changed"):
            print(f"  reused answers: {stats['cache_patterns_changed']} section(s) got different pattern rules from the "
                  f"current code (the model's part is reused as it was)")
        print(f"  sections:{stats['sections_skipped_noncandidate']} skipped by pre-filter, {stats['sections_no_rules']} "
              f"no rules, {stats['sections_with_proposals']} with proposals (outcomes.jsonl has one row each)")
        print(f"  {stats['seconds']}s | model calls {stats['model_calls']} this chapter (retries {stats.get('model_retries', 0)}, "
              f"failures {stats['model_failures']}, of which truncated {stats.get('model_truncated', 0)}) | tokens "
              f"{stats.get('tokens_generated', 0):,} this chapter, {stats.get('hit_budget_calls', 0)} budget hit(s), "
              f"{stats.get('sections_split', 0)} section(s) split")
        # C3: deterministic post-checks after grounding (post_checks.py); every action is in each draft's grounding JSON
        print(f"  post-checks: {stats.get('post_check_downgrade', 0)} downgraded to not_checkable, "
              f"{stats.get('post_check_drop', 0)} dropped (pair not stated), {stats.get('post_check_rescope', 0)} rescoped, "
              f"{stats.get('post_check_map_reason', 0)} reasons mapped, {stats.get('post_check_flag', 0)} flagged | "
              f"{stats.get('duplicates', 0)} duplicate(s) logged to dropped.jsonl")
        if stats.get("last_resort_calls") or stats.get("sections_pattern_fallback"):
            print(f"  long pieces: {stats.get('last_resort_calls', 0)} last-resort call(s) at "
                  f"{config.LAST_RESORT_BUDGET_FACTOR:g}x the budget | {stats.get('sections_pattern_fallback', 0)} "
                  f"failed section(s) kept their pattern rules")
        if stats["model_failed"] or stats["degraded_patterns_only"] or stats["unparseable"]:
            print(f"  MODEL: {stats['model_failed']} section(s) failed, {stats['degraded_patterns_only']} degraded to "
                  f"patterns, {stats['unparseable']} unparseable | last error: {str(stats.get('last_model_error'))[:200]}")
    except Exception as e:
        log_rows.append({"chapter": ch, "run_id": run_id, "backend": f"{backend.name}:{backend.model}",
                         "prompt_version": extract_rules.PROMPT_VERSION, "seconds": round(time.time() - t0, 1),
                         "error": f"{type(e).__name__}: {str(e)[:400]}"})
        print(f"  FAILED: {type(e).__name__}: {e}")
    # everything so far on disk: a crash in the next chapter loses nothing done
    extract_io.write_run(RUN_DIR, inventory_rows=inventory_rows, section_rows=section_rows, log_rows=log_rows,
                         dropped_rows=dropped_rows, change_rows=change_rows, drafts=all_drafts, cache=cache,
                         manifest=manifest(finished=False), outcome_rows=outcome_rows)

counts = extract_io.write_run(RUN_DIR, inventory_rows=inventory_rows, section_rows=section_rows, log_rows=log_rows,
                              dropped_rows=dropped_rows, change_rows=change_rows, drafts=all_drafts, cache=cache,
                              manifest=manifest(finished=True), outcome_rows=outcome_rows)

# COMMAND ----------

# MAGIC %md ## Summary — this is what the persist step and the deck read

# COMMAND ----------

mh = extract_rules.model_health(backend)
print(f"{len(all_drafts)} drafts across {len(CHAPTERS_TO_RUN)} chapters; {len(dropped_rows)} proposals refused by grounding")
print(f"model {mh['model_backend']} via {mh['model_route']}: {mh['model_calls']} calls, {mh['model_failures']} failures "
      f"(of which {mh.get('model_unparseable', 0)} unparseable replies, {mh.get('model_truncated', 0)} out of budget - "
      f"those sections were split), {mh.get('model_retries', 0)} retries, {mh.get('model_tokens_generated', 0):,} tokens "
      f"generated, {mh.get('model_hit_budget_calls', 0)} budget hit(s)")
if mh["model_calls"] and mh["model_failures"] == mh["model_calls"]:
    print("*** EVERY MODEL CALL FAILED. These drafts are regex-only and are NOT an extraction. "
          f"Last error: {mh['last_model_error']} ***")
elif mh["model_failures"]:
    # C3-07: an out-of-budget call is a failure too, but its section was split and is cached if the halves succeeded
    print(f"*** {mh['model_failures']}/{mh['model_calls']} model calls failed ({mh.get('model_truncated', 0)} of them out "
          f"of budget - those sections were split and are cached when every half succeeded); the other failed sections "
          f"were NOT cached and will retry next run (log.jsonl retryable_sections). Last error: {mh['last_model_error']} ***")
by_src = {}
for d in all_drafts:
    # D2b: read the recorded provenance; parsing notes labelled every pure-HFLOCAL draft "pattern"
    src = d.get("extraction_source") or "unknown"
    by_src[src] = by_src.get(src, 0) + 1
print(f"drafts by source: {by_src}   (a healthy HYBRID run has model-found drafts)")
print(f"\nrun folder: {RUN_DIR}  {counts}")
print("Next: run 05_persist_extraction on a UC-enabled CPU cluster with RUN_ID =", run_id)
