# Databricks notebook source
# MAGIC %md
# MAGIC # d04 · Coverage and gap — how much paid money does policy actually check?
# MAGIC
# MAGIC **What this answers:** the share of paid dollars checked by a federal rule, a state rule, both, or nothing; which
# MAGIC unchecked codes carry the most money; and where AHCCCS policy text exists but nothing runs against claims.
# MAGIC **How to read it (D6, 2026-10-14):** a paid dollar is *covered* when it is dated **inside the window of a compiled
# MAGIC rule of its code whose statement RAN in the latest detector run of the current build** (a statement 08 skipped -
# MAGIC unsigned NCCI routing, a validator's PROBLEM - or that failed, did not run). Every share is given twice: of ALL paid
# MAGIC dollars (a claim line with no procedure code too: forms C, I and L mostly carry none) and of the procedure-coded
# MAGIC lines only. Before any run of the build, the notebook falls back to what 07 compiled and says so.
# MAGIC Policy text that did not become a detector (a "lead") does not count as coverage.
# MAGIC **Limits:** "covered" means some rule checks the code on that date, not that every rule for it is loaded. Federal =
# MAGIC NCCI PTP + MUE only (CMS public edit set, Arizona deactivations not applied). State = the manual chapters extracted
# MAGIC and approved so far, and the AHCCCS rule tables whose readings are signed.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import functions as F
import config, gap
for _m in (config, gap):
    importlib.reload(_m)

TOP_N = 25              # rows in each ranked list (the notebook says how many more there are)

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def show(df, what, n=TOP_N):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0]
cov = spark.table(T("policy_coverage")).where(F.col("build_id") == BUILD_ID).toPandas()
assert len(cov), f"policy_coverage has no rows for the current build {BUILD_ID} - re-run 07_build_kb"
blog = spark.table(T("policy_build_log")).where(F.col("build_id") == BUILD_ID).toPandas()
b = blog.iloc[0] if len(blog) else {}
PAID = config.CLAIM_COLS.get("paid_amt")
# the latest detector run OF THIS BUILD (a run of an older build ran other rules)
RUN_ID = None
if spark.catalog.tableExists(T("policy_detector_runs")):
    RUN_ID = (spark.table(T("policy_detector_runs")).where(F.col("build_id") == BUILD_ID)
              .agg(F.max("run_id")).first()[0])
if RUN_ID:
    run_rows = spark.table(T("policy_detector_runs")).where(F.col("run_id") == RUN_ID).toPandas()
    exp, SHARES = gap.ran_coverage(spark, KB, BUILD_ID, run_rows, config.CLAIMS_TABLE, PAID)
    BASIS = f"a rule whose statement RAN in detector run {RUN_ID} ({SHARES.get('statements_ran')} statement(s) ran)"
else:
    # D6: coverage means a rule that RAN - with no run of this build there is no coverage share; the per-code tables
    # below show the COMPILED rules' windows (07's policy_coverage), labelled so
    exp, SHARES = cov, None
    BASIS = "a COMPILED rule (no detector run of this build yet - 08 has not run it, so nothing has checked these dollars)"
print(f"build {BUILD_ID} | claims {b.get('claims_from')} to {b.get('claims_to')} | {exp['code'].nunique():,} paid code(s) "
      f"on {len(exp):,} code/form/edit-file row(s) | covered = dated inside the window of {BASIS}")

# COMMAND ----------

# MAGIC %md ## 1. Share of paid dollars by who checks it

# COMMAND ----------

if SHARES:
    print(gap.shares_text(SHARES, f"inside the window of {BASIS.split(' (')[0]}"))
    print(f"All paid dollars: ${SHARES['paid_all_lines'] or 0:,.2f}; on procedure-coded lines: "
          f"${SHARES['paid_proc_coded_lines'] or 0:,.2f}. Federal and state overlap, so their shares can add to more "
          "than the share checked by any rule.")
else:
    print("No coverage share: no detector run of this build yet (coverage counts only the rules that ran). Run "
          "08_run_detectors; below, the procedure-coded dollars by the COMPILED rules' windows.")
LABEL = {"both": "federal and state", "federal_only": "federal only (NCCI)", "state_only": "state only (AHCCCS)",
         "none": "nothing checks it"}
summ = gap.coverage_summary(exp) if RUN_ID else \
    spark.table(T("policy_coverage_summary")).where(F.col("build_id") == BUILD_ID).toPandas()
summ["checked_by"] = summ["coverage"].map(LABEL).fillna(summ["coverage"])
print("Procedure-coded lines by who checks them (a code with dollars inside and outside a rule's window counts in two "
      "classes; lines and dollars add up):")
display(summ[["checked_by", "codes", "lines", "paid_dollars", "pct_lines", "pct_paid"]].sort_values("paid_dollars",
                                                                                                   ascending=False))
print("Read these as an upper bound. A code counts as checked on a date if ANY rule that ran looks at it, even a narrow "
      "one: a pair rule checks a code only when its partner code is billed the same day, yet the code's dollars count as "
      "covered. And coverage does not mean every policy for the code is loaded.")

# COMMAND ----------

# MAGIC %md ## 2. The gap — unchecked codes ranked by paid dollars

# COMMAND ----------

num = (lambda c: pd.to_numeric(exp[c], errors="coerce").fillna(0))
exp["paid_dollars_unchecked"] = num("paid_dollars") - num("paid_dollars_any_window")
leads = cov.groupby("code")["state_leads"].max() if "state_leads" in cov else pd.Series(dtype=int)
exp["state_leads"] = exp["code"].map(leads).fillna(0).astype(int)
gap_none = exp[exp["paid_dollars_unchecked"] > 0.005].sort_values("paid_dollars_unchecked", ascending=False)
print(f"{len(gap_none):,} paid code/form/edit-file row(s) with dollars NO rule checked - no rule ran on them, or they "
      f"are dated outside every such rule's window (an NCCI rule checks only the lines of its edit file; never dental, "
      f"pharmacy, inpatient or residential lines). Lines with no procedure code are not listed (no code to rank)"
      + (f": ${(SHARES['paid_all_lines'] or 0) - (SHARES['paid_proc_coded_lines'] or 0):,.2f} paid." if SHARES else "."))
show(gap_none[["code", "form_typ", "ncci_edition", "lines", "paid_dollars", "paid_dollars_unchecked", "state_leads"]],
     "codes with unchecked dollars")
fed_only = exp[(num("paid_dollars_federal_window") > 0) & (num("paid_dollars_state_window") == 0)]
fed_only = fed_only.sort_values("paid_dollars_federal_window", ascending=False)
print(f"\n{len(fed_only):,} paid code/form/edit-file row(s) checked ONLY by NCCI (no AHCCCS rule judged them):")
show(fed_only[["code", "form_typ", "ncci_edition", "lines", "paid_dollars", "paid_dollars_federal_window", "state_leads"]],
     "federal-only codes")

# COMMAND ----------

# MAGIC %md ## 3. Policy text exists, but nothing state-side runs
# MAGIC Codes with AHCCCS policy text in the knowledge base (`state_leads` > 0) whose dollars no state rule judged.
# MAGIC These are the cheapest coverage gains: the reason column says what is missing.

# COMMAND ----------

st_unjudged = exp.groupby("code").agg(paid_dollars=("paid_dollars", "sum"),
                                      state_judged=("paid_dollars_state_window",
                                                    lambda s_: float(pd.to_numeric(s_, errors="coerce").fillna(0).sum())),
                                      state_leads=("state_leads", "max")).reset_index()
lead_codes = st_unjudged[(st_unjudged["state_leads"] > 0) & (st_unjudged["state_judged"] == 0)].sort_values(
    "paid_dollars", ascending=False)
if len(lead_codes):
    rules = spark.table(T("policy_rules")).where("origin <> 'ncci'").toPandas()
    dets = spark.table(T("policy_detectors")).where("NOT compiled").select("rule_id", "reason").toPandas()
    rules = rules.merge(dets, on="rule_id")
    rules["code_list"] = rules["codes"].map(lambda s: json.loads(s) if isinstance(s, str) else [])
    ex = rules.explode("code_list")
    why = (ex[ex["code_list"].isin(set(lead_codes["code"]))].groupby("code_list")
           .agg(reasons=("reason", lambda s: "; ".join(sorted({str(x) for x in s}))),
                example=("statement", "first")).reset_index().rename(columns={"code_list": "code"}))
    out = lead_codes.merge(why, on="code", how="left")
    print(f"{len(out):,} code(s) have policy text but no state rule judged their dollars:")
    show(out[["code", "paid_dollars", "state_leads", "reasons", "example"]], "codes")
else:
    print("No paid code has state policy text that failed to compile while no state rule judged its dollars.")
