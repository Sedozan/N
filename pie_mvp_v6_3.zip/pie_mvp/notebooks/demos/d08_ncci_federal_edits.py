# Databricks notebook source
# MAGIC %md
# MAGIC # d08 · Federal NCCI edits — what is loaded, how fresh, and what fires
# MAGIC
# MAGIC **What this answers:** which CMS Medicaid NCCI files were loaded and verified, which quarters are missing between the
# MAGIC claims' first date of service and today (with the claim lines and dollars before each MUE file's first loaded
# MAGIC quarter, and after each file's newest loaded quarter), how many edits the master table holds, and which NCCI edits
# MAGIC flag the most paid dollars.
# MAGIC **How to read it:** PTP files are cumulative (CMS 2026 Medicaid NCCI TGM s7.1.1: the current file holds every past
# MAGIC and present edit with its dates), so only the newest PTP quarter is used — what matters is that the *current* quarter
# MAGIC is loaded. MUE files are undated and hold only the MUEs in effect, so EVERY quarter from the claims start is needed
# MAGIC (`00_acquire_ncci` reads CMS's MUE archive). Nothing is assumed past the newest loaded quarter of a file (v2.9):
# MAGIC its windows end there, and later claims get no check from it. Each claim line takes ONE edit file (provider type x
# MAGIC claim form, CMS TGM Table 2), and only through a signed routing row.
# MAGIC **Limits:** NCCI findings are CMS Medicaid NCCI reference findings: the CMS public edit set, with Arizona-specific
# MAGIC deactivations (state files on RISSNET) **not** applied, never AHCCCS-authoritative violations.
# MAGIC A PTP edit applies on its deletion date (TGM App. B: "the last date that an edit is active").
# MAGIC Findings are candidates for review, not confirmed overpayments.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import functions as F
import config, acquire_ncci, ingest_ncci_tables
for _m in (config, acquire_ncci, ingest_ncci_tables):
    importlib.reload(_m)

RUN_ID   = None         # None = the latest detector run
MAX_ROWS = 25           # longest list shown per section (the notebook says how many more there are)

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def show(df, what, n=MAX_ROWS):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


print(f"NCCI source: {getattr(config, 'NCCI_SOURCE', '?')} — per the CMS public edit set; Arizona deactivations are NOT applied.")
print(f"PTP deletion date treated as the last day in force: {config.NCCI_DELETION_DATE_INCLUSIVE} (CMS TGM App. B).")

# COMMAND ----------

# MAGIC %md ## 1. Acquisition log — what was downloaded, checked and loaded

# COMMAND ----------

if spark.catalog.tableExists(config.NCCI_ACQUISITION_LOG):
    log = spark.table(config.NCCI_ACQUISITION_LOG).toPandas()
    log["sha256"] = log["sha256"].astype(str).str[:16]
    print(f"{len(log):,} file(s) logged: {log['status'].value_counts().to_dict()}")
    show(log.sort_values(["quarter", "edit", "service"], ascending=[False, True, True])[
        ["quarter", "edit", "service", "status", "rows", "sha256", "table", "loaded_at", "warning", "error"]], "log rows")
else:
    print(f"No {config.NCCI_ACQUISITION_LOG}: NCCI tables were loaded by hand (before 00_acquire_ncci existed).")

# COMMAND ----------

# MAGIC %md ## 2. Quarters loaded, and quarters missing from the claims start to today

# COMMAND ----------

metas = ingest_ncci_tables.discover_tables(spark, config.CATALOG, config.SCHEMA)
cy, cq = acquire_ncci.current_quarter()
_bl = (spark.table(T("policy_build_log")).orderBy(F.desc("built_at")).limit(1).toPandas()
       if spark.catalog.tableExists(T("policy_build_log")) else pd.DataFrame())
_b = _bl.iloc[0].to_dict() if len(_bl) else {}
CLAIMS_START = _b.get("claims_from")
_hist = json.loads(_b["ncci_history_gaps"]) if isinstance(_b.get("ncci_history_gaps"), str) else {}
fresh = pd.DataFrame([{"service": f["service"], "edit": f["edit"], "quarters_loaded": f["quarters_loaded"],
                       "first": f["first"], "latest": f["latest"],
                       "missing_from_claims_start": ", ".join(f["missing"]) or "none",
                       "ao_lines_before_first": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_lines_before_first"),
                       "ao_paid_before_first": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_paid_before_first"),
                       "through": f["through"],
                       "ao_lines_after_latest": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_lines_after_latest"),
                       "ao_paid_after_latest": (_hist.get(f"{f['service']}/{f['edit']}") or {}).get("ao_paid_after_latest")}
                      for f in acquire_ncci.ncci_freshness(metas, CLAIMS_START)])
print(f"today is in {cy}Q{cq}; the claims start {CLAIMS_START or 'unknown (no build yet)'}. MUE: every quarter is needed; "
      f"PTP: only the newest (cumulative). Every window of a file ends with its newest loaded quarter (`through`): "
      f"nothing is carried forward. Lines / dollars: CMS-1500 / UB-04 lines dated before the MUE file's first loaded "
      f"quarter, and after `through` (no check from that file), counted by the latest build (07).")
show(fresh, "edit files")
if (fresh["missing_from_claims_start"] != "none").any():
    print("Quarters are missing: claims dated in them get no check from that file. Run 00_acquire_ncci (ARCHIVE = True) "
          "or put the CMS zips in the drop zone.")

# COMMAND ----------

# MAGIC %md ## 3. The NCCI master table: every edit of every edit file and window
# MAGIC `policy_ncci_edits_master` (07) holds every row of the newest PTP file and of every MUE quarter of each edit file,
# MAGIC NOT scoped to the claims, with a status that says whether it becomes a rule. Editions are never merged: a line takes
# MAGIC ONE edit file, so a code with different values in two files simply has one rule per file.

# COMMAND ----------

if spark.catalog.tableExists(T("policy_ncci_edits_master")):
    m = (spark.table(T("policy_ncci_edits_master")).groupBy("edit_file", "edit_type", "status").count()
         .orderBy("edit_file", "edit_type", "status").toPandas())
    print(f"{int(m['count'].sum()):,} NCCI edits in the master table (build {_b.get('build_id')}).")
    show(m, "file / type / status rows")
else:
    print("No policy_ncci_edits_master yet: run 07_build_kb.")

# COMMAND ----------

# MAGIC %md ## 4. NCCI edits that flag the most paid dollars (latest run)

# COMMAND ----------

RUN_ID = RUN_ID or spark.table(T("policy_detector_runs")).agg(F.max("run_id")).first()[0]
f = spark.table(T("policy_findings")).where((F.col("run_id") == RUN_ID) & (F.col("origin") == "ncci"))
n = f.count()
lines = f.dropDuplicates(["claim_id", "line_no"])
tot = lines.agg(F.count("*").alias("n"), F.sum("paid_amt").alias("paid")).first()
print(f"run {RUN_ID}: {n:,} NCCI finding(s) on {tot['n']:,} distinct claim line(s), ${float(tot['paid'] or 0):,.2f} paid "
      "(each line once, even when several edits flag it).")
# C4-19: the rule text AS IT WAS in the build that produced the run (policy_rules_history), not today's rules
top = (f.dropDuplicates(["rule_id", "claim_id", "line_no"]).groupBy("build_id", "rule_id", "predicate_type", "finding_severity")
       .agg(F.count("*").alias("lines"), F.round(F.sum("paid_amt"), 2).alias("paid"))
       .join(spark.table(T("policy_rules_history")).select("build_id", "rule_id", "statement", "doc_version")
             .dropDuplicates(["build_id", "rule_id"]), ["build_id", "rule_id"], "left")
       .orderBy(F.desc("paid"), "rule_id").toPandas())
print("By edit (a line flagged by two edits counts under both, so these rows can add to more than the total):")
show(top, "edits")
