"""
post_checks.py  -  deterministic meaning checks on a GROUNDED proposal, before it becomes a draft (C3 critic).

extract_rules.ground() proves the quote is in the section and every code is in the section. It does not prove the
predicate means what the sentence means. The first real run (2026-09-30: 242 drafts, AI pre-review in
/home/claude/review) showed the failure patterns these checks catch, using only the proposal, its SOURCE
sentence(s) and the section text. No model, no Spark. extract_rules.extract_chapter calls, in order:

    repair(proposal)                         BEFORE grounding. A predicate the grammar refuses but whose obligation
                                             is real (modifier_required with no codes, "UA/UB/UC/UD" as one modifier,
                                             period "lifetime", provider types that are not codes) becomes a
                                             not_checkable lead instead of being dropped as 'invalid predicate'.
    check(proposal, g, section_text, ctx)    AFTER grounding, one proposal -> (proposal', actions); since 2026-10-17
                                             (external review B1) it also reads every field the SQL reads (threshold
                                             basis and period, provider types and role, scope, modifier) from the
                                             source sentence(s)
    section_pass(items, section_text, ctx)   cross-proposal: merge per-code caps the text calls combined (C3-04);
                                             one code carrying several dollar caps cannot be checked

An action is {"check": id, "finding": "C3-xx", "action": a, "detail": str, "attention": bool}. Actions:
    downgrade   predicate replaced by not_checkable(reason); the proposed predicate is kept in
                proposal["pre_check_predicate"] (and in the draft's grounding JSON)
    rescope     a predicate field changed (scope, type, code_set, exception, discretionary, direction, population)
    map_reason  a not_checkable reason replaced by one from schema.PROMPT_REASONS (the original is in `detail`)
    drop        the text does not state the proposal (written to `dropped`, `detail` is the drop_reason)
    duplicate   merged into another proposal of the same section (written to `dropped`)
    flag        nothing changed; the reviewer is told where to look
`attention` = the reviewer should look (extract_rules caps the draft's confidence at 0.5 and the note leads the
ambiguity_note); False for contract defaults (an explicit narrow pair scope, indicator "0") and for labels that
only qualify findings (exception / discretionary).

Safety contract: every action narrows, labels or leaves a rule - fewer, narrower or more clearly labelled SQL
findings - with ONE deliberate exception: the combined-cap merge (C3-04) sums several codes under one cap, which
flags more lines than a per-code cap. It runs only when the source sentence itself says the cap is combined
("inclusive of", "total", "combined", "in any combination"). No check turns a not_checkable rule into an
executable one, widens a pair scope, removes an age / exception / date, or adds an age.
"""
from __future__ import annotations

import copy
import re

import schema
from policy_docs import CODE_RE, WORD_NUMBERS, clean_chars, code_ranges, date_cues, sentence_spans

REASONS = tuple(r for r, _ in schema.PROMPT_REASONS)
COMPILED = set(schema.PREDICATE_TYPES_COMPILED)
EXECUTABLE = set(schema.PREDICATE_TYPES) - {"not_checkable", "edit_failure"}     # compiled + authorable
PERIODS = set(schema.PERIODS)
_TWO_CHAR = re.compile(r"^[A-Z0-9]{2}$")


# ------------------------------------------------------------------ helpers
def norm(s: str | None) -> str:
    """Comparison form: extract_rules._norm's character table (policy_docs.clean_chars), lower-case, single spaces."""
    s = clean_chars(s).lower()
    return re.sub(r"\s+", " ", s).strip().rstrip(".;:")


def codes_of(p: dict | None) -> list[str]:
    return schema.predicate_codes(p or {})


def has_code(code: str, text: str) -> bool:
    """Word-boundary code test (C3-19: a substring test let '9896' match '98960')."""
    return re.search(rf"(?<![A-Za-z0-9]){re.escape(str(code).upper())}(?![A-Za-z0-9])", (text or "").upper()) is not None


def text_codes(text: str) -> list[str]:
    return list(dict.fromkeys(CODE_RE.findall(text or "")))


def strip_code_descriptors(text: str) -> str:
    """'99070 (Supplies and materials, except spectacles, provided by ...)' -> '99070'. A CPT/HCPCS descriptor in
    parentheses right after a code is not a condition (the approved 99070 rule read 'except spectacles' as one)."""
    return re.sub(r"(\b(?:\d{4}[A-Z0-9]|[A-Z]\d{4})\b)\s*" + _NOT_CONDITION_PAREN, r"\1", text or "")


# 2026-10-16 (review): a parenthesis that opens with a condition word is a condition, never a code descriptor:
# "H2012 shall not be billed with H0036 (unless the member is transitioning ...)" lost its 'unless'
_NOT_CONDITION_PAREN = r"\((?!\s*(?i:unless|except|if|when|only)\b)[^()]{0,200}\)"


def _act(actions: list, check: str, finding: str, action: str, detail: str, attention: bool = True) -> None:
    actions.append({"check": check, "finding": finding, "action": action, "detail": detail, "attention": attention})


def _downgrade(prop: dict, actions: list, check: str, finding: str, reason: str, detail: str) -> None:
    p = prop.get("predicate") or {}
    if p.get("type") == "not_checkable":
        return
    prop.setdefault("pre_check_predicate", copy.deepcopy(p))
    prop["predicate"] = {"type": "not_checkable", "reason": reason}
    prop["not_checkable_reason"] = reason
    prop["ambiguous"] = True
    _act(actions, check, finding, "downgrade", f"{detail} -> not_checkable {reason}")


def _rescope(prop: dict, actions: list, check: str, finding: str, detail: str, attention: bool = True) -> None:
    prop.setdefault("pre_check_predicate", copy.deepcopy(prop.get("_orig_predicate") or prop.get("predicate")))
    _act(actions, check, finding, "rescope", detail, attention)


# ------------------------------------------------------------------ vocabulary
# non-coverage wording; a code_not_covered whose source sentence has none of it may be inverted ("Providers shall
# bill using Code A0110 ..." was proposed as 'A0110 not covered')
NONCOV_RE = re.compile(
    r"\bnot\s+(?:an?\s+)?(?:ahcccs[- ])?(?:covered|reimburs\w*|billable|payable|allowed|separately\s+\w+)"
    r"|\b(?:do|does|must|shall|may|can|will|should)\s?(?:not|n't)\s+(?:be\s+)?(?:bill\w*|reimburs\w*|cover\w*|pa(?:y|id)|"
    r"use\w*|submit\w*|report\w*)"
    r"|\bcannot\s+(?:be\s+)?(?:bill\w*|reimburs\w*|use\w*|submit\w*)|\bnon-?covered\b|\bprohibited from\b|\bwill be denied\b"
    r"|\bno longer (?:an?\s+)?(?:ahcccs[- ])?(?:covered|valid|accepted|billable|reimburs\w*)\b|\bnot eligible for\b|\bexcluded\b",
    re.I)
# a bar that holds only for a service / setting / circumstance: the code itself is payable otherwise (C3-03)
CONTEXT_SUBJECT_RE = re.compile(
    r"\b(?!services?\b)([a-z][a-z/-]+(?:\s+(?:and|or|of)?\s*[a-z/-]+){0,5})\s+(?:services?\s+)?"
    r"(?:may|must|shall|can|should)\s+not\s+be\s+billed\s+(?:using|with|under)\b", re.I)
CONTEXT_RE = re.compile(
    r"\bprovided\s+(?:at|in|by|to|through)\b|\bdirectly\s+precede\w*|\bseparately\b|\bwhen\s+(?:provided|billed\s+for|"
    r"delivered|furnished|performed|rendered|used\s+for)\b|\bif\s+(?:provided|delivered|furnished|performed|rendered)\b"
    r"|\bfor\s+(?:the\s+)?(?:purpose|treatment|management)\s+of\b|\bin\s+(?:a|an|the)\s+[\w/-]+\s+(?:setting|facility|program)\b"
    r"|\bduring\s+(?:a|an|the)\s+[\w/-]+\s+(?:stay|admission|visit|episode)\b", re.I)
SETTING_RE = re.compile(r"\b(?:provided\s+(?:at|in)|setting|facility|location|hospital|organization|precede\w*|admission|"
                        r"separately|inpatient|claim)\b", re.I)
# a condition on WHEN a modifier applies; the claim cannot show it (C3-05: 16 of 17 modifier rules were conditional)
MOD_COND_RE = re.compile(
    r"\b(when|whenever|if|unless|except|only\s+(?:when|if|for)|provided\s+(?:that|by|at|in)|in\s+the\s+case\s+of"
    r"|to\s+(?:designate|indicate|identify)|serving|directly\s+precede\w*|separately|as\s+part\s+of"
    r"|included\s+in\s+the\s+rate|for\s+the\s+(?:[a-z-]+\s+){1,3}(?:team|approach|exception)|for\s+court|for\s+assistant)\b",
    re.I)
PROVIDER_CLASS_SUBJECT_RE = re.compile(
    r"^\W*(?:[\w/-]+\s+){0,4}(?:providers?|therapists?|nutritionists?|physicians?|surgeons?|dentists?|pharmacies|"
    r"pharmacists?|hospitals?|facilities|agencies|clinics?|bhrfs?|msics?)\b(?:\s+\([^)]*\))?\s+(?:must|shall|should|may|can|are|will)\b",
    re.I)
NO_CLAIM_FIELD_COND_RE = re.compile(r"\bto\s+(?:designate|indicate|identify)\b|\bwhen\s+billing\s+for\b|\bteaching\s+physician\b"
                                    r"|\bcourt\b|\bdestination\b|\bet3\b|\btreat\s+and\s+refer\b|\blocum\b", re.I)
# combined caps (C3-04)
INCLUSIVE_RE = re.compile(r"\b(inclusive\s+of|combined|in\s+(?:any\s+)?combination|total\s+(?:units|of)|in\s+total|aggregate"
                          r"|all\s+(\d+|two|three|four|five|six)\s+(?:billable\s+)?codes)\b", re.I)
PER_PROVIDER_RE = re.compile(r"\bper\s+(?:msic|provider|facility|clinic|agency|pharmacy|practitioner|physician|biller)\b"
                             r"|\b(?:single|same|one)\s+(?:provider|practitioner|physician|clinician|agency|facility|biller|msic)\b"
                             r"|\bby\s+the\s+same\s+(?:provider|practitioner)\b", re.I)
MEMBER_SCOPE_RE = re.compile(r"\bsame\s+(?:member|recipient|patient|person)\b|\bany\s+(?:other\s+)?provider\b"
                             r"|\bregardless\s+of\s+(?:the\s+)?provider\b|\bdifferent\s+providers?\b|\bmore\s+than\s+one\s+provider\b",
                             re.I)
UNIT_DEF_RE = re.compile(r"\b(billing\s+unit|unit\s+of\s+service|is\s+equal\s+to\s+one\s+unit|equals\s+one\s+unit|"
                         r"one\s+unit\s+(?:is|equals))\b", re.I)
FINITE_VERB_RE = re.compile(r"\b(must|may|shall|should|will|can|cannot|is|are|be|bill|billed|do|does|not|require\w*|cover\w*)\b",
                            re.I)
STARTS_WITH_CODE_RE = re.compile(r"^\s*[•·\-–]?\s*(?:\d{4}[A-Z0-9]|[A-Z]\d{4})\b")
PERIOD_TEXT_RE = re.compile(r"\b(per|each|a|every|one|any)\s+(day|week|month|year|contract\s+year|benefit\s+year|calendar\s+year|"
                            r"quarter)\b|\b(daily|weekly|monthly|annually|yearly|lifetime)\b", re.I)
PROGRAM_RE = re.compile(r"\b(altcs|aihp|fesp?|federal\s+emergency|tribal|kidscare|qmb|dual\s+eligible|medicare\s+part\s+d|ihs)\b",
                        re.I)
AGE_RE = re.compile(
    r"\b(?:members?|individuals?|persons?|recipients?|enrollees?|patients?|children|adults?|youth|those)\s+(?:who\s+are\s+)?"
    r"(?:aged?\s+)?(?:under|younger\s+than|less\s+than|over|older\s+than|at\s+least)\s+(?:the\s+)?(?:age\s+(?:of\s+)?)?\d{1,2}\b"
    r"|\b(?:ages?|aged)\s+(?:of\s+)?\d{1,2}\b|\b\d{1,2}\s+years?\s+(?:of\s+age|old)\b"
    r"|\b\d{1,2}\s+(?:years?\s+)?(?:and|or)\s+(?:older|over|above|younger)\b|\b(?:under|over)\s+(?:age\s+)?\d{1,2}\b"
    r"|\bepsdt\b|\badults?\b|\bchildren\b", re.I)
REPLACED_RE = re.compile(r"\breplac(?:es|ed|ement)\b|\bretired\b|\bdiscontinued\b|\bdeleted\b|\binstead\s+of\b|\bend[- ]dated\b"
                         r"|\bno\s+longer\s+(?:valid|accepted|used|active)\b|\bhas\s+been\s+replaced\b", re.I)
PRICING_RE = re.compile(r"\b(reimbursed\s+at|paid\s+at|percent\s+of|%\s+of|discount|penalty|pricing|priced|fee\s+schedule\s+rate"
                        r"|capped\s+fee)\b", re.I)
EDI_RE = re.compile(r"\b(loop|segment|nte\d*|837[pid]?|qualifier|transaction\s+set)\b", re.I)
BACKGROUND_RE = re.compile(r"\b(section\s+\d+\s+of\s+the|balanced\s+budget\s+act|affordable\s+care\s+act)\b", re.I)
PROCESS_RE = re.compile(
    r"\b(cms[- ]?1500|ub-?0?4|ub-?92|ada\s+20\d\d|claim\s+form|form\s+locator|field\s+\d+|fl\s?\d+|bill\s+type|on\s+one\s+claim"
    r"|single\s+claim|separate\s+claims?|notif\w+|enrol\w+|regist\w+|timely\s+filing|resubmi\w+|attach\w*|trip\s+report|eomb"
    r"|remittance|within\s+(?:\w+|\d+)\s+(?:hours|days|months)\s+(?:of|from|after)|submitted\s+(?:with|on|within)"
    r"|must\s+be\s+submitted|must\s+(?:bill|be\s+billed)\s+on|prior\s+authori[sz]ation)\b", re.I)
# condition clauses: an exempting one is the exception (the finding becomes verify_exception); one that narrows when the
# rule applies makes it a lead; the rule's own trigger ("when billed on the same day") is neither (_is_own_trigger)
EXCEPTION_RE = re.compile(r"\b(unless|except(?:\s+(?:for|when|if|that|as))?|excluding|only\s+if|only\s+when|provided\s+that|"
                          r"does\s+not\s+apply|whenever|when|if|only\s+(?:in|at|for|during))\b", re.I)
# 2026-10-17 (second review, finding 1): a condition that EXEMPTS from a rule is its exception (verify_exception); one
# that NARROWS when it applies ("when rendered in an inpatient setting", "if billed with modifier HQ") is not - as an
# exception the rule would flag every other case - so the rule is a lead
_EXEMPT_RE = re.compile(r"^\(?\s*(?:unless|except|excluding|does\s+not\s+apply)\b", re.I)
DISCRETIONARY_RE = re.compile(r"\bmay\s+(?:be\s+)?(?:denied|disallowed|recouped|reduced)\b|\bmay\s+deny\b"
                              r"|\bmay\s+not\s+be\s+(?:reimbursed|paid|payable|covered)\b|\bmay\s+not\s+reimburse\b", re.I)

# ------------------------------------------------------------------ code pairs (C3-01 / C3-12 / C3-13)
PROHIBIT_RE = re.compile(
    r"\b(?:cannot|can\s+not|can't|may\s+not|must\s+not|shall\s+not|should\s+not|will\s+not|are\s+not\s+to|is\s+not\s+to)\s+"
    r"(?:be\s+)?(?:billed|bill|reported|report|submitted|submit|reimbursed|paid|used|claimed|claim)\b"
    r"|\b(?:may|will|shall)\s+be\s+denied\b|\bprohibited\s+from\s+billing\b"
    r"|\bnot\s+(?:be\s+)?(?:separately\s+)?(?:billable|payable|reimbursable)\b", re.I)
_LINK_RE = re.compile(r"\b(?:with|as|alongside|along\s+with|in\s+addition\s+to)\b", re.I)
CATEGORY_RE = re.compile(r"\b(?:any|a|an|all|other|the)\s+(?:[\w/&-]+\s+){0,3}?(per\s+diem|e/m|evaluation\s+and\s+management|"
                         r"surgical|anesthesia|case\s+management|room\s+and\s+board|global)\s+(?:codes?|services?|rates?)\b", re.I)
REFERENCE_RE = re.compile(r"\b(?:these|those|both|the\s+above|the\s+following|such|either|the\s+two|all\s+(?:\d+|two|three|four|"
                          r"five|six)(?:\s+billable)?)\s+codes?\b|^\W*codes?\b|\bthe\s+(?:billable\s+)?codes\b", re.I)
# D4 (2026-10-14): a run-in heading "H0037– Community Psychiatric Supportive Treatment Program:" (a code, a dash, a title,
# a colon). Ch.19 p.15-16 sets one right after each hub list; when the list line ends with a comma ("... or S9480,") the
# PDF lines join and the next code's heading lands inside the list. A hub list stops there.
_CODE_TOK = r"(?:\d{4}[A-Z0-9]|[A-Z]\d{4})"
RUN_IN_HEADING_RE = re.compile(rf"(?<![A-Za-z0-9]){_CODE_TOK}\s*(?:--|[-‐-―])\s*[A-Z][a-z][^:.;]{{0,100}}:")
# 2026-10-16 (review): clauses. A boundary before the barred codes; a billing verb (permission or prohibition); a new
# clause inside a list (a code followed by a verb: "..., S9480, H0038 is billed per diem"); what may follow the last
# listed code without making the list conditional (punctuation, a conjunction, the pair's own scope words)
_CLAUSE_BOUNDARY_RE = re.compile(r"\bbut\b|;", re.I)
EACH_OTHER_RE = re.compile(r"\s*with\s+(?:each\s+other|one\s+another)\b", re.I)    # the subjects' own partners
# "cannot be billed on the same day with the HQ modifier": the partner comes after the same-day words (second review)
_SAME_DAY_HEAD_RE = re.compile(r"^\s*(?:together\s+)?(?:on|for)\s+the\s+same\s+(?:day|date(?:\s+of\s+service)?)\b",
                               re.I)
_BILL_VERB_RE = re.compile(r"\b(?:may|shall|must|can|cannot|should|will)\s+(?:not\s+)?(?:only\s+)?be\s+billed\b"
                           r"|\b(?:is|are)\s+(?:not\s+)?(?:only\s+)?billed\b|\bcan\s+not\s+be\s+billed\b", re.I)
_NEW_CLAUSE_RE = re.compile(rf"(?<![A-Za-z0-9]){_CODE_TOK}\s+(?i:may|shall|must|cannot|can|should|will|is|are|do|does"
                            rf"|has|have|requires?)\b")
_HARMLESS_TAIL_RE = re.compile(r"(?:[\s,.;:]|\band\b|\bor\b|\b(?:on|for|by)\s+the\s+same\s+(?:day|date\s+of\s+service|date"
                               r"|member|recipient|provider)\b)*", re.I)
# a list item shaped like a code but not one ("S109" in four Ch.19 hub lists, a typo): reported, never paired or rewritten
INVALID_LIST_CODE_RE = re.compile(r"(?:,|\bwith|\bor|\band)\s+([A-Z]\d{3}|[A-Z]\d{5})(?=\s*(?:,|\bor\b|\band\b|\.|$))")


_LIST_CLOSED_RE = re.compile(r"(?:\bor\b|\band\b|&)\s*$", re.I)
_NEW_BLOCK_RE = re.compile(r"(?:NOTE\b|(?!(?:Unless|Except|Excluding|Only|When|Whenever|If|For|By|On|In|With|Per|From|"
                           r"Within|During|After|Before|Under|Over|And|Or|Provided|Billed|Unless)\b)[A-Z][a-z]{2,}\b)")


def pair_roles(sentence: str) -> dict:
    """Who is barred with whom in ONE sentence.
    kind  'hub'       "T1016 cannot be billed on the same day as H0018, H0014 or H0035" / "prohibited from billing S5151
                      with H0001, ..." / "H2012 shall not be billed with H0036, H2015. H0018, ..." (D4) -> subjects
                      [T1016], objects [H0018, ...]: only subject x object pairs are stated
          'category'  "H2014 and H2017 may be denied when billed on the same day any per diem codes are billed"
          'symmetric' "Service codes H2025, H2026, and H2027 cannot be billed on the same day" -> every combination
          'reference' "codes cannot be billed together ..." / "cannot bill both codes": the codes are named elsewhere
          'single'    one code and no partner in the sentence
          None        no prohibition wording
    subjects are the codes the text says may not be billed / may be denied: in a pair they are code_b (the line the
    compiler flags; detector_gen.compile_code_pair reports line b). D4: the codes of a run-in heading glued before the
    subject or after the list are neither (RUN_IN_HEADING_RE); `invalid` lists code-shaped list items that are not codes
    ('S109') for the reviewer; `category` is set for a hub list too ("... H0030 or any other per diem code")."""
    s = strip_code_descriptors(sentence or "")
    m = PROHIBIT_RE.search(s)
    allc = text_codes(s)
    if not m:
        return {"kind": None, "subjects": allc, "objects": [], "category": None, "invalid": []}
    before, after = s[:m.start()], s[m.end():]
    heads = list(RUN_IN_HEADING_RE.finditer(before))
    if heads:
        before = before[heads[-1].end():]
    head = RUN_IN_HEADING_RE.search(after)
    if head:
        after = after[:head.start()]
    # 2026-10-16 (review): one clause only. The barred codes are read after the last clause boundary ("but", ";"), none
    # when a billing verb precedes them ("H0004 may be billed with H2017 but shall not be billed with H2014": not
    # H2017); the list stops where a new clause starts ("... and H0003 may not be billed with H0004", "..., S9480,
    # H0038 is billed per diem"), which is returned as `rest`.
    bound = list(_CLAUSE_BOUNDARY_RE.finditer(before))
    if bound:
        before = before[bound[-1].end():]
    unclear = bool(_BILL_VERB_RE.search(before))
    rest = None
    nc = _NEW_CLAUSE_RE.search(after)
    stop = min([x.start() for x in (nc, _BILL_VERB_RE.search(after), _CLAUSE_BOUNDARY_RE.search(after)) if x]
               or [len(after)])
    if stop < len(after):
        if nc and nc.start() == stop:
            rest = after[stop:].strip()
            # "with H0002 and H0003 may not be billed with H0004": is H0002 listed, or a second subject? Unknown
            unclear = unclear or bool(re.search(rf"{_CODE_TOK}\s*(?:\band\b|\bor\b|&)\s*$", after[:stop]))
        after = after[:stop]
    # 2026-10-20 (SB's ch19 runs, both levels): a list closed by "or / and <code>" and followed by a capitalised word
    # is a new block the PDF ran into without a period ("... S9480, or H0015 Therapeutic H2019 - ...", "... H0038, or
    # H0030 NOTE: A professional ...", "... or H0030 Refer to AMPM 310-B ..."): the list ends there. It made the H2015,
    # H2020 and H0037 hub lists leads (about 55 pairs). A lower-case tail, or a capitalised condition ("For ...",
    # "When ...", "Unless ..."), still reads as words after the list.
    last0 = None
    for last0 in re.finditer(rf"(?<![A-Za-z0-9])(?:{_CODE_TOK}|[A-Z]\d{{3,5}})(?![A-Za-z0-9])", after):
        pass
    if last0 is not None and _LIST_CLOSED_RE.search(after[:last0.start()]) and \
            _NEW_BLOCK_RE.match(after[last0.end():].strip(" ,.;:")):
        after = after[:last0.end()]
    invalid = list(dict.fromkeys(INVALID_LIST_CODE_RE.findall(after)))
    active = bool(re.search(r"(?:bill|billing|report|submit|claim)$", m.group(0), re.I))
    if active:                                                                          # active voice
        lk = _LINK_RE.search(after)
        subjects = text_codes(after[:lk.start()] if lk else after)
        objects = text_codes(after[lk.end():]) if lk else []
        if not lk:
            subjects = text_codes(after)
    else:
        subjects, objects = text_codes(before), text_codes(after)
    last = None
    for last in re.finditer(rf"(?<![A-Za-z0-9])(?:{_CODE_TOK}|[A-Z]\d{{3,5}})(?![A-Za-z0-9])", after):
        pass
    trailing = after[last.end():] if (last and objects) else ""
    trailing = "" if _HARMLESS_TAIL_RE.fullmatch(trailing) else trailing.strip()
    cat = CATEGORY_RE.search(after)
    if unclear or (bound and objects and not subjects):
        kind = "unclear"                 # which code the clause bars, or which list a code is in, is not certain
    elif subjects and objects:
        kind = "hub"
    elif subjects and cat:
        kind = "category"
    elif subjects and not active and re.match(r"\s*with\b", _SAME_DAY_HEAD_RE.sub("", after)) and \
            not EACH_OTHER_RE.match(_SAME_DAY_HEAD_RE.sub("", after)):
        kind = "other_partner"           # "H2014 and H2017 shall not be billed with the HQ modifier": not with each other
    elif len(subjects) >= 2:
        kind = "symmetric"
    elif not allc and REFERENCE_RE.search(s):
        kind = "reference"
    else:
        kind = "single" if len(allc) == 1 else ("reference" if REFERENCE_RE.search(s) else None)
    return {"kind": kind, "subjects": subjects, "objects": objects, "category": cat.group(1).lower() if cat else None,
            "invalid": invalid, "trailing": trailing, "rest": rest}


# the words of a pair's own scopes (member_provider_day = the servicing provider): "per facility", "per MSIC", "per
# agency" are not, and stay words no check reads (final critic B2)
_SERVICING_SCOPE_RE = re.compile(r"\b(?:per|same|single|one)\s+(?:provider|practitioner|physician|clinician)\b"
                                 r"|\bby\s+the\s+same\s+(?:provider|practitioner)\b", re.I)


def unhandled_tail(tail: str) -> bool:
    """Words after the last listed code (pair_roles 'trailing') that no other check reads: not an exception clause
    (labelled), a date (rule_dates), an age or a member program (their own checks), a category, or a reason ('as ...')."""
    t = (tail or "").strip(" ,.;:")
    # the pair's own scope words ("for the same member", "by any provider", "on the same day") are read by the scope
    # check; what is left decides (2026-10-17: also on same-day sentences, "... on the same claim")
    t = re.sub(r"\b(?:on|for|by|from)\s+(?:the\s+same|any(?:\s+other)?|a\s+different)\s+(?:day|date(?:\s+of\s+service)?"
               r"|member|recipient|patient|provider)s?\b", " ", t, flags=re.I)
    t = MEMBER_SCOPE_RE.sub(" ", _SERVICING_SCOPE_RE.sub(" ", t))
    t = re.sub(r"\b(?:and|or|on|for|by|from|the)\b", " ", t, flags=re.I).strip(" ,.;:")
    if not t:
        return False
    return not (re.match(r"\(?\s*(?:unless|except|excluding|only\s+if|only\s+when|when|if|as|because|since)\b", t, re.I)
                or date_cues(t) or AGE_RE.search(t) or PROGRAM_RE.search(t) or CATEGORY_RE.search(t))


def clause_roles(sentence: str) -> list[dict]:
    """pair_roles of each clause of a sentence ("H0001 may not be billed with H0002 and H0003 may not be billed with
    H0004" -> two clauses)."""
    out, s = [], sentence
    while s and len(out) < 10:
        r = pair_roles(s)
        out.append(r)
        s = r.get("rest")
    return out


def _category_labels(code: str, cat: str, section_text: str) -> bool:
    """Does the section call `code` a `cat` code ('H2018 - Psychosocial rehabilitation services, per diem')?"""
    c, w = re.escape(code.upper()), re.escape(cat).replace(r"\ ", r"\s+")
    t = clean_chars(section_text)
    return bool(re.search(rf"(?<![A-Za-z0-9]){c}(?![A-Za-z0-9])[^.;\n]{{0,90}}\b{w}\b", t, re.I)
                or re.search(rf"\b{w}\b[^.;\n]{{0,40}}(?<![A-Za-z0-9]){c}(?![A-Za-z0-9])", t, re.I))


def _check_pair(prop: dict, actions: list, src: str, section_text: str) -> None:
    p = prop["predicate"]
    a, b = str(p.get("code_a") or "").upper(), str(p.get("code_b") or "").upper()
    # ---- fields the compiler reads (C3-01): explicit, never silently wide
    if p.get("modifier_indicator") in (None, "") or str(p.get("modifier_indicator")).strip() == "":
        p["modifier_indicator"] = "0"
        _rescope(prop, actions, "pair_indicator_default", "C3-10", "modifier_indicator blank -> '0' (a state pair has "
                 "no NCCI modifier bypass)", attention=False)
    elif str(p.get("modifier_indicator")).strip() not in ("0", "0.0"):
        _act(actions, "pair_indicator_bypass", "C3-10", "flag", f"modifier_indicator {p.get('modifier_indicator')!r}: the "
             "text must name the modifier that allows the pair")
    if not p.get("service_category"):
        p["service_category"] = "state"
    s_low = src or ""
    provider_said = PER_PROVIDER_RE.search(s_low)
    member_said = MEMBER_SCOPE_RE.search(s_low)
    scope = p.get("scope")
    if scope not in schema.PAIR_SCOPES:
        p["scope"] = "member_provider_day"
        hint = (f"; the text says {member_said.group(0)!r}: member_day (any provider) only if a reviewer signs the "
                f"wider reading" if member_said and not provider_said else "")
        _rescope(prop, actions, "pair_scope_default", "C3-01", f"scope {scope!r} -> member_provider_day (narrow "
                 f"default){hint}", attention=bool(hint))
    elif scope == "member_day" and provider_said:
        p["scope"] = "member_provider_day"
        _rescope(prop, actions, "pair_scope_narrowed", "C3-01", f"text says {provider_said.group(0)!r}: member_day -> "
                 "member_provider_day")
    elif scope == "member_day" and not member_said:
        p["scope"] = "member_provider_day"
        _rescope(prop, actions, "pair_scope_narrowed", "C3-01", "member_day (any provider) is not stated by the text -> "
                 "member_provider_day")
    elif scope != "member_day" and member_said and not provider_said:
        # 2026-10-17 (review B1): the text's scope is wider than the predicate's; it is never widened here. A narrower
        # scope flags only lines that break the wider rule too: kept, flagged (final critic M1)
        _flag_field(prop, actions, "pair_scope_narrower_than_text", f"the text says {member_said.group(0)!r} "
                    f"(member_day, any provider); scope {scope} counts one provider's lines: it misses pairs billed by "
                    f"two providers")

    # ---- is the pair stated by the source sentence(s)? (C3-03 invented pair, C3-12 hub spokes, C3-13 direction)
    units = [src[x:y] for x, y in sentence_spans(src)] or [src]
    verb_units = [u for u in units if PROHIBIT_RE.search(strip_code_descriptors(u))]
    unit = next((u for u in verb_units if has_code(a, u) and has_code(b, u)), None) or \
        next((u for u in verb_units if has_code(a, u) or has_code(b, u)), None) or (verb_units[0] if verb_units else src)
    clauses = clause_roles(unit)
    # the clause that names both codes (2026-10-16: a sentence of two clauses is read clause by clause)
    roles = next((r for r in clauses if {a, b} <= set(r["subjects"]) | set(r["objects"])), clauses[0])
    subj, obj = set(roles["subjects"]), set(roles["objects"])
    in_src = {c for c in (a, b) if has_code(c, src)}

    def _swap(why):
        p["code_a"], p["code_b"] = b, a
        _rescope(prop, actions, "pair_direction", "C3-13", f"{why}: code_b must be the code the text bars "
                 f"({a} <-> {b})", attention=False)

    if len(in_src) == 2:
        if roles["kind"] == "unclear" or (roles["kind"] == "hub" and unhandled_tail(roles["trailing"])):
            # two clauses whose grouping is not certain, or words after a "billed with" list that no other check reads
            # ("... with H2017 on the same claim", "by provider type 77"): a lead for the reviewer
            return _downgrade(prop, actions, "pair_clause_or_condition", "C3-12", "ambiguous_source",
                              "the sentence's clauses or the words after its code list ("
                              f"{(roles['trailing'] or 'two clauses')[:60]!r}) decide the pair")
        if roles["kind"] == "other_partner":
            prop["_drop"] = True
            _act(actions, "pair_other_partner", "C3-12", "drop", f"the sentence bars {sorted(subj)} with a partner "
                 "that is not a code (a modifier, a place of service), not with each other")
            return
        if roles["kind"] == "hub":
            # 2026-10-17 (second review, finding 7): the finding sits on the barred code's line (D4); the text does not
            # say which line AHCCCS denies - the reviewer decides
            if (b in subj and a in obj) or (a in subj and b in obj):
                _act(actions, "pair_finding_line", "D4", "flag", f"the finding is on {(b if b in subj else a)}'s line "
                     f"(the code the sentence bars); which line AHCCCS denies is not stated; where the Same Day table "
                     f"lists the pair, it names the row code's line", attention=False)
            if b in subj and a in obj:
                return
            if a in subj and b in obj:
                return _swap("hub sentence")
            prop["_drop"] = True
            _act(actions, "pair_hub_spoke", "C3-12", "drop", f"the sentence bars {sorted(subj)} with each listed code; "
                 f"{a}/{b} is not stated")
            return
        if roles["kind"] == "category":
            if a in subj and b in subj:
                prop["_drop"] = True
                _act(actions, "pair_both_barred", "C3-12", "drop", f"{a} and {b} are both barred with {roles['category']} "
                     "codes; the text does not bar them with each other")
                return
            if a in subj and b not in subj:
                _swap("category sentence")
            return
        if roles["kind"] is None:
            _act(actions, "pair_no_prohibition_wording", "C3-03", "flag", "both codes are in the sentence but no "
                 "'cannot be billed / may be denied' wording was recognised")
        elif roles["kind"] == "single":
            _act(actions, "pair_partner_in_other_sentence", "C3-03", "flag", "the prohibition sentence names one code; "
                 "the partner comes from a neighbouring sentence - confirm the pair")
        return
    missing = sorted({a, b} - in_src)
    ref = REFERENCE_RE.search(strip_code_descriptors(src))
    cat = roles.get("category") or (CATEGORY_RE.search(src).group(1).lower() if CATEGORY_RE.search(src) else None)
    if ref and all(has_code(c, section_text) for c in missing):
        _act(actions, "pair_codes_by_reference", "C3-03", "flag", f"{missing} named outside the sentence "
             f"({ref.group(0).strip()!r}); confirm the pair")
        return
    if cat and len(missing) == 1 and _category_labels(missing[0], cat, section_text):
        _act(actions, "pair_code_from_category", "C3-03", "flag", f"{missing[0]} is not in the sentence; the section "
             f"labels it {cat!r}")
        present = (in_src or {None}).pop()
        if present and present == a and (present in subj or not subj):
            _swap("category sentence")
        return
    prop["_drop"] = True
    why = (f"{missing[0]} is inferred from {cat!r} but the section never labels it so" if cat and len(missing) == 1
           else f"pair codes {missing} are not in the quoted sentence(s) and the sentence names no code list")
    _act(actions, "pair_codes_not_in_sentence", "C3-03", "drop", why)


# ------------------------------------------------------------------ field checks (2026-10-17, external review B1)
# Grounding proves the quote, its codes and its number are in the PDF; it never proved that the fields the SQL reads
# mean what the sentence says ("4 units per month" proposed per year, or per day, kept score 1.0). Each field that
# changes the SQL is read from the source sentence(s): a field the text contradicts makes the rule a lead (the conflict
# named), a field the text does not state is flagged for the reviewer; no check adds meaning.
_NUM_WORDS = "|".join(sorted((re.escape(w) for w in WORD_NUMBERS), key=len, reverse=True))
# (a five-digit number is a CPT code, never a threshold: "four (4) units of 98960 ... per day")
_NUM_RE = re.compile(rf"(?<![\w.,/-])(\d{{1,3}}(?:,\d{{3}})+|\d{{1,4}})(?:\.\d+)?(?![\w/%-])|\b(once|twice|{_NUM_WORDS})\b",
                     re.I)
_HOURS_AFTER_RE = re.compile(r"\s*(?:\(\s*\d+\s*\)\s*)?(?:hours?|hrs?)\b", re.I)
_NOT_A_DAY = r"(?![\s-]+(?:programs?|treatment|care|centers?|services?|habilitation|hospital\w*))"
# the unit basis a threshold is written with; the order decides ties ('per contract year' is not 'per year')
_BASES = (
    ("benefit_year", r"(?:(?:per|a|each|every|one|any|in\s+a|in\s+any)\s+)?(?:contract|benefit)\s+years?\b"),
    ("year", r"\bper\s+(?:calendar\s+)?year\b|\b(?:a|each|every|one|any|in\s+a)\s+(?:calendar\s+)?year\b"
             r"|\bcalendar\s+year\b|\bannually\b|\bannual\s+(?:limit|maximum|max|cap)\b|\byearly\b"),
    ("month", r"\bper\s+(?:calendar\s+)?month\b|\b(?:a|each|every|one|any|in\s+a)\s+(?:calendar\s+)?month\b"
              r"|\bcalendar\s+month\b|\bmonthly\b"),
    ("week", r"\bper\s+week\b|\b(?:a|each|every|one|any|in\s+a)\s+week\b|\bweekly\b"),
    ("day", rf"\bper\s+(?:calendar\s+)?day\b{_NOT_A_DAY}|\b(?:a|each|every|one|any)\s+(?:calendar\s+)?day\b{_NOT_A_DAY}"
            r"|\bper\s+date\s+of\s+service\b|\bper\s+dos\b|\bdaily\b(?!\s+living)|\bin\s+(?:a|one|any)\s+(?:single\s+)?day\b"
            r"|\bon\s+the\s+same\s+(?:day|date)\b"),
    ("lifetime", r"\blifetime\b"),
    ("line", r"\bper\s+(?:claim\s+)?line(?:\s+item)?\b|\b(?:on|in)\s+(?:a|one|the\s+same)\s+(?:claim\s+)?line\b"),
    ("claim", r"\bper\s+claim\b|\b(?:on|in)\s+(?:a|one|the\s+same)\s+claim\b"),
    ("visit", r"\bper\s+(?:visit|session|encounter)\b"),
    ("episode", r"\bper\s+(?:episode|admission|stay)\b|\b(?:within|in|during)\s+(?:a|one|the)\s+(?:single\s+)?"
                r"(?:[a-z-]+\s+)?(?:episode|admission)\b"),
)
_BASIS_RE = re.compile("|".join(f"(?P<{k}>{rx})" for k, rx in _BASES), re.I)
_BASIS_LABEL = {"benefit_year": "contract / benefit year", "year": "year", "month": "month", "week": "week",
                "day": "day", "lifetime": "lifetime", "line": "claim line", "claim": "claim", "visit": "visit",
                "episode": "episode"}
_NO_GRAMMAR_BASIS = {"week", "lifetime", "claim", "visit", "episode"}
_CAP_BASIS = {"max_units_per_day": "day", "max_units_per_dos": "day", "max_units_per_line": "line"}
_PERIOD_TYPES = ("max_units_per_period", "max_dollars_per_period", "frequency_limit")


def _num_value(m) -> int | None:
    if m.group(1):
        v = float(m.group(0).replace(",", ""))
        return int(v) if v.is_integer() else None
    w = m.group(2).lower()
    return {"once": 1, "twice": 2}.get(w) or WORD_NUMBERS.get(w)


def threshold_bindings(text: str) -> list[dict]:
    """Every number of the text with the unit basis written next to it: {value, basis, hours}. The basis is the first
    basis phrase after the number (before the next number of another value, a ';' or the sentence end: "4 units per
    day and 24 units per month" binds 4 to day and 24 to month; a number in a parenthesis restating it does not end it:
    "48 units (12 hours) per day"), else an unused one just before it ("a daily maximum of 4 units"); a basis that
    closes a list after a comma applies to each number of the list still unbound ("nine days, and bed hold days may not
    exceed 12 days, per contract year"); None when the text writes none. hours = the number counts hours."""
    t = clean_chars(text or "")
    ages = [(m.start(), m.end()) for m in AGE_RE.finditer(t)]          # "aged 21 and older" is no threshold (M3)
    nums = [(m.start(), m.end(), _num_value(m)) for m in _NUM_RE.finditer(t)]
    nums = [n for n in nums if n[2] is not None and not any(a <= n[0] < b for a, b in ages)]
    bases = [(m.start(), m.end(), m.lastgroup) for m in _BASIS_RE.finditer(t)]
    parens = [(m.start(), m.end()) for m in re.finditer(r"\([^()]*\)", t)]
    in_paren = lambda x, a: any(pa < x < pb and not pa < a < pb for pa, pb in parens)    # noqa: E731
    out, used = [], set()
    for i, (a, b, v) in enumerate(nums):
        stop = min([x[0] for x in nums[i + 1:] if x[2] != v and not in_paren(x[0], a)] + [len(t), b + 90])
        end = re.search(r";|\.(?:\s|$)", t[b:stop])
        stop = b + end.start() if end else stop
        j = next((j for j, (x, y, _) in enumerate(bases) if b <= x and y <= stop), None)
        if j is not None:
            used.add(j)
        out.append({"value": v, "basis": bases[j][2] if j is not None else None,
                    "hours": bool(_HOURS_AFTER_RE.match(t[b:])), "at": a})
    for i, rec in enumerate(out):
        if rec["basis"] is None:
            a = nums[i][0]
            start = max([x[1] for x in nums[:i] if x[2] != nums[i][2]] + [0, a - 60])
            cut = list(re.finditer(r";|\.(?:\s|$)", t[start:a]))
            start = start + cut[-1].end() if cut else start
            prev = [j for j, (x, y, _) in enumerate(bases) if j not in used and start <= x and y <= a]
            if prev:
                used.add(prev[-1])
                rec["basis"] = bases[prev[-1]][2]
    for x, _, k in bases:                                    # ", per contract year" closing a list of numbers
        if t[:x].rstrip().endswith(","):
            cut = list(re.finditer(r";|\.(?:\s|$)", t[:x]))
            lo = cut[-1].end() if cut else 0
            for rec in out:
                if rec["basis"] is None and lo <= rec["at"] < x:
                    rec["basis"] = k
    return out


def code_clauses(text: str) -> list[tuple[str, set]]:
    """The clauses of a sentence with the codes each states a limit or a list for: split at ';' and before a code that
    follows a verb of the clause before it ("H2014 may be billed up to 8 units per day, and H2017 up to 4 units per
    day"; never inside "H2014 and H2017 are each limited to ..."). A clause that names no code takes the codes of the
    clause before it."""
    out, last = [], set()
    for piece in re.split(r";", clean_chars(text or "")):
        cuts, prev = [0], None
        for m in CODE_RE.finditer(piece):
            if prev is not None and FINITE_VERB_RE.search(piece[prev:m.start()]):
                cuts.append(m.start())
            prev = m.end()
        cuts.append(len(piece))
        for a, b in zip(cuts, cuts[1:]):
            if piece[a:b].strip():
                last = set(text_codes(piece[a:b])) or last
                out.append((piece[a:b], set(last)))
    return out


def _own_clauses(prop: dict, actions: list, text: str, what: str) -> list[tuple[str, set]] | None:
    """The clause(s) of the source that state the rule's own codes, each with which of them it names ({} = the text
    names none of them: the whole text); None (flagged) when the sentence states it for several codes and none of its
    clauses names the rule's codes - the binding is unclear."""
    pcs = set(codes_of(prop["predicate"]))
    cl = code_clauses(text)
    own = [(c, cs & pcs) for c, cs in cl if cs & pcs]
    if own:
        return own
    if len({frozenset(cs) for _, cs in cl if cs}) >= 2:
        _flag_field(prop, actions, f"{what}_clause_unclear", f"the sentence states {what.replace('_', ' ')}s for "
                    f"several codes and no clause names {sorted(pcs)}: which one is this rule's is unclear")
        return None
    return [(text, set())]


def _text_or_none(v) -> str | None:
    return v.strip() if isinstance(v, str) and v.strip() else None


def _flag_field(prop: dict, actions: list, check: str, detail: str) -> None:
    """The text does not state the field: the rule keeps its type, flagged ambiguous (its confidence is capped)."""
    prop["ambiguous"] = True
    _act(actions, check, "B1", "flag", detail)


def _hour_billing_unit(codes, text: str, section_text: str = "") -> bool:
    """The billing unit is one hour - in the sentence, or in the run-in block of one of the codes ("H2012 -- Behavioral
    Health Day Treatment (Supervised): Billing Unit: Per hour"): a limit in hours is then a number of units (M2)."""
    if _HOUR_UNIT_RE.search(text or ""):
        return True
    heads = list(RUN_IN_HEADING_RE.finditer(section_text or ""))
    for i, m in enumerate(heads):
        if any(m.group(0).upper().startswith(str(c).upper()) for c in codes):
            end = heads[i + 1].start() if i + 1 < len(heads) else len(section_text)
            if _HOUR_UNIT_RE.search(section_text[m.start():end]):
                return True
    return False


_HOUR_UNIT_RE = re.compile(r"\bbilling\s+unit\s*(?::|is|=)?\s*(?:per|one|1|an?)\s+hour\b", re.I)


def _interleaved_mismatch(p: dict, n: int, text: str) -> bool:
    """One clause names several codes and several limits, codes between the numbers ("2 units per day of H2014 and 4
    units of H2017 per day"): n must sit next to one of the rule's own codes (the nearest code to it), else unclear."""
    t = clean_chars(text or "")
    codes = [(m.start(), m.group(0).upper()) for m in CODE_RE.finditer(t)]
    b = threshold_bindings(t)
    if len({c for _, c in codes}) < 2 or len({x["value"] for x in b}) < 2:
        return False
    pos = sorted(x["at"] for x in b)
    if not any(pos[0] < a < pos[-1] for a, _ in codes):
        return False                                        # the codes share their limits ("are each limited to")
    own = set(codes_of(p))
    # each number next to its own code: "4 units of H2017" (the code just after its unit) or "H2017: 4 units" (just
    # before it, nothing but punctuation / 'is limited to' between); anything else is unclear
    mine = []
    for x in b:
        if x["value"] != n:
            continue
        after = re.match(rf"\W*\w+(?:\s+[a-z]+){{0,4}}?\s+(?:of|for)\s+(?:codes?\s+)?({_CODE_TOK})", t[x["at"]:])
        before = re.search(rf"({_CODE_TOK})(?:\s*[:,-]|\s+(?:is|are)?\s*(?:limited\s+to|up\s+to|a\s+maximum\s+of))?\s*$",
                           t[max(0, x["at"] - 40):x["at"]])
        mine.append((after or before).group(1).upper() if (after or before) else None)
    return not any(c in own for c in mine)


def _basis_verdict(p: dict, want: str, n: int, text: str, hour_unit: bool = False) -> tuple:
    """('ok', note) | ('downgrade', check, reason, detail) | ('flag', check, detail) for one clause."""
    b = threshold_bindings(text)
    same = [x for x in b if x["value"] == n]
    units = p.get("type", "").startswith("max_units") and not hour_unit
    lab = _BASIS_LABEL.get(want, want)
    if _interleaved_mismatch(p, n, text):
        return ("flag", "threshold_code_unclear", f"the clause states several limits for several codes and {n} does "
                f"not sit next to {sorted(codes_of(p))}: which limit is this rule's is unclear")
    if any(x["basis"] == want for x in same):
        if units and all(x["hours"] for x in same if x["basis"] == want):
            return ("downgrade", "threshold_in_hours", "unit_incommensurability",
                    f"{n} is written as hours per {lab}; the claim counts units")
        return ("ok", f"threshold {n} per {lab} as written")
    other = next((x["basis"] for x in same if x["basis"]), None)
    if other:
        return ("downgrade", "threshold_basis_mismatch",
                "predicate_not_in_grammar" if other in _NO_GRAMMAR_BASIS else "ambiguous_source",
                f"the text writes {n} per {_BASIS_LABEL[other]}; the predicate counts it per {lab}")
    there = next((x["value"] for x in b if x["basis"] == want and x["value"] != n), None)
    if there is not None and not same:
        # the text never writes n: its limit for that basis is another number. (A number the text writes with no
        # basis of its own is never 'contradicted' by another number's basis: flagged below.)
        return ("downgrade", "threshold_basis_mismatch", "ambiguous_source",
                f"the text's limit per {lab} is {there}, not {n}")
    if units and any(x["hours"] for x in same):
        return ("downgrade", "threshold_in_hours", "unit_incommensurability",
                f"{n} is a number of hours; the claim counts units")
    return ("flag", "threshold_basis_not_stated",
            f"the text writes no unit basis next to {n}: per {lab} is a reading the reviewer must confirm")


_SINGLE_RE = re.compile(r"\bsingle\b|\ba\s+(?:unit|visit|dose|session)\s+(?:per|a|each)\b|\bannually\b|\byearly\b",
                        re.I)


def _check_threshold_basis(prop: dict, actions: list, src_clean: str, passed: list, section_text: str = "") -> None:
    """The threshold must be written with the basis the predicate counts it on: per day for a daily cap, the SAME period
    for a period cap (contract year = benefit_year), per claim line for a line cap - read in the clause(s) that state
    the rule's own codes ("H2014 ... 4 units per day; H2017 ... 4 units per month": H2017's 4 is per month)."""
    p = prop["predicate"]
    t = p.get("type")
    want = _CAP_BASIS.get(t) or (p.get("period") if t in _PERIOD_TYPES else None)
    n = schema.integral(p.get("threshold"))
    if n is None:
        return
    # v6.2 (critic): a number the text never writes as a limit was copied (from a prompt example) or invented;
    # grounding only flagged it ("treat as derived"), so it stayed executable. Checked after the basis verdicts, whose
    # downgrades name the text's own number ("the text's limit per day is 4, not 21")
    unwritten = n not in {x["value"] for x in threshold_bindings(src_clean)} and \
        not (n == 1 and _SINGLE_RE.search(clean_chars(src_clean)))

    def _unwritten():
        _downgrade(prop, actions, "threshold_not_in_text", "B1", "ambiguous_source",
                   f"the text never writes {n} as a limit: a threshold is read from the text, never derived or copied")
    if not want:
        return _unwritten() if unwritten else None
    clauses = _own_clauses(prop, actions, src_clean, "threshold")
    if clauses is None:
        return _unwritten() if unwritten else None
    hour = _hour_billing_unit(codes_of(p), src_clean, section_text)
    # per code of the rule: its clauses that write a number (a clause with none says nothing of the threshold); one
    # contradiction is a lead, one clause as written is enough, none -> flagged; the rule takes its worst code
    by_code: dict = {}
    for c, cs in clauses:
        if _NUM_RE.search(clean_chars(c)):
            for k in cs or {""}:
                by_code.setdefault(k, []).append(_basis_verdict(p, want, n, c, hour))
    per = [next((v for v in vs if v[0] == "downgrade"), None) or next((v for v in vs if v[0] == "ok"), None) or vs[0]
           for vs in by_code.values()] or [_basis_verdict(p, want, n, src_clean, hour)]
    worst = next((v for k in ("downgrade", "flag") for v in per if v[0] == k), per[0])
    if worst[0] == "downgrade":
        return _downgrade(prop, actions, worst[1], "B1", worst[2], worst[3])
    if unwritten:
        return _unwritten()
    if worst[0] == "flag":
        return _flag_field(prop, actions, worst[1], worst[2])
    passed.append(worst[1])


# provider types: a two-character AHCCCS code as written ("B2", "05s", "PT 77", "PT-ES")
_PT_TOKEN = r"(?:PT[-\s]?)?([0-9]{2}|[A-Z][A-Z0-9]|[0-9][A-Z])s?(?![A-Za-z0-9])"
_PT_TOKEN_RE = re.compile(rf"(?<![A-Za-z0-9]){_PT_TOKEN}")
_PT_INTRO = r"\b(?:provider\s+types?|PT)\b"
_PT_ITEM_RE = re.compile(rf"^(?:.*?(?:{_PT_INTRO}|\b(?:types?|are|includes?|including)\b)[-\s]*)?{_PT_TOKEN}"
                         r"(?!\s*(?:units?|hours?|days?|years?|minutes?|months?|%|percent)\b)", re.I)
# what ends a provider-type list: modifiers, places of service, revenue / category-of-service codes are other lists
# (HO, 12, 53 are provider types too)
_PT_LIST_STOP_RE = re.compile(r"\bmodifiers?\b|\bplaces?\s+of\s+service\b|\bPOS\b|\brevenue\s+codes?\b"
                              r"|\bcategor(?:y|ies)\s+of\s+service\b|\bCOS\b|\bbill\s+types?\b|\bform\s+types?\b", re.I)
_BILL_WORDS_RE = re.compile(r"\bbill(?:s|ed|ing)?\b|\bsubmit(?:s|ted)?\b", re.I)
_RENDER_WORDS_RE = re.compile(r"\b(?:rendered|provided|performed|furnished|delivered)\s+(?:only\s+)?by\b"
                              r"|\brender(?:s|ing)?\b|\bservicing\b", re.I)
_PT_VOCAB: set | None = None


def _pt_vocab() -> set:
    global _PT_VOCAB
    if _PT_VOCAB is None:
        import ncci_routing
        try:
            _PT_VOCAB = {r["sprov_type"] for r in ncci_routing.load_table()}
        except (OSError, ValueError):
            _PT_VOCAB = set()
    return _PT_VOCAB


def provider_type_lists(text: str) -> tuple[set, list[list[str]]]:
    """(every provider-type token of the text, the lists it writes): a list opens with an item after "provider type(s)"
    or "PT" and runs over items separated by ',', ';', 'and', 'or', each opening with a type code ("B2 Residential
    Treatment Center ..., 02 Hospital, and 71 ..."; "(PT 77)" counts as an item); it ends at a piece that is no item, or
    at modifiers / place of service / POS / revenue or category-of-service codes (whose codes are not provider types)."""
    import ncci_routing
    t = clean_chars(text or "")
    tokens = {ncci_routing.norm_type(m.group(1)) for m in _PT_TOKEN_RE.finditer(t)}
    t = re.sub(r"\(\s*(?:PT|provider\s+types?)[-\s]*([A-Z0-9]{2})\s*\)", r" PT \1 ", t, flags=re.I)
    lists, cur, opened = [], [], False
    for piece in re.split(r",|;|:|\.(?=\s|$)|\band\b|\bor\b|&", re.sub(r"\([^()]*\)", " ", t)):
        s = piece.strip()
        if not s:
            continue
        m = _PT_ITEM_RE.match(s)
        tok = bool(m) and m.group(1) == m.group(1).upper() and not _PT_LIST_STOP_RE.search(s[:m.start(1)])
        intro = re.search(_PT_INTRO, s[:m.start(1)] if tok else s, re.I)
        item = tok and (bool(cur) or opened or bool(intro))
        # "... the approved provider types are as follows:" opens the list of the next piece
        opened = bool(intro) and not item and not _PT_LIST_STOP_RE.search(s)
        if item:
            cur.append(ncci_routing.norm_type(m.group(1)))
            # a numbered list with no commas ("10. MD-Physician (PT 08) 11.Physician Assistant (PT 18)"): every "PT xx"
            cur += [ncci_routing.norm_type(x) for x in re.findall(r"\bPT[-\s]?([A-Z0-9]{2})(?![A-Za-z0-9])", s[m.end():])]
        if (not item or _PT_LIST_STOP_RE.search(s[m.end():])) and cur:
            lists.append(cur)
            cur = []
    if cur:
        lists.append(cur)
    return tokens, lists


def _check_provider_types(prop: dict, actions: list, src: str, passed: list) -> None:
    """Every listed type is in the text, the list is the text's whole list (a narrower allowed list flags lawful
    lines), and provider_role is what the verbs say: billed by -> billing / billing_or_rendering, rendered / provided /
    performed by -> servicing - read in the clause(s) that state the rule's own codes."""
    import ncci_routing
    p = prop["predicate"]
    pts = [ncci_routing.norm_type(x) for x in p.get("provider_types") or []]
    clauses = _own_clauses(prop, actions, src, "provider_type_list")
    if clauses is None:
        return
    src = " ".join(c for c, _ in clauses)
    tokens, lists = provider_type_lists(src)
    missing = [x for x in pts if x not in tokens]
    if missing:
        return _downgrade(prop, actions, "provider_type_not_in_text", "B1", "ambiguous_source",
                          f"provider type(s) {missing} are not in the source sentence")
    extra = sorted({x for li in lists if set(li) & set(pts) for x in li if x not in pts and x in _pt_vocab()})
    if extra:
        return _downgrade(prop, actions, "provider_types_narrower_than_text", "B1", "ambiguous_source",
                          f"the text lists {extra} too: an allowed list without them flags their lawful lines")
    passed.append(f"provider types {pts} as listed")
    role = p.get("provider_role") or "billing"
    bill, rend = _BILL_WORDS_RE.search(src), _RENDER_WORDS_RE.search(src)
    if bill and rend:
        return _flag_field(prop, actions, "provider_role_two_readings", f"the sentence has billing ({bill.group(0)!r}) "
                           f"and rendering ({rend.group(0)!r}) words: provider_role {role} is the reviewer's call")
    if not (bill or rend):
        return _flag_field(prop, actions, "provider_role_not_stated", f"the sentence says neither billed nor rendered "
                           f"by: provider_role {role} is a reading the reviewer must confirm")
    if (role == "servicing") != bool(rend):
        word = (rend or bill).group(0)
        return _downgrade(prop, actions, "provider_role_contradicted", "B1", "ambiguous_source",
                          f"the text says {word!r}; provider_role {role} reads the "
                          f"{'servicing' if role == 'servicing' else 'billing'} provider")
    passed.append(f"provider_role {role} ({(rend or bill).group(0)!r})" + {
        "billing_or_rendering": ": a group biller (type 01) is judged on its rendering practitioner's type (FFS Ch.3 p.3)",
        "billing": ": a group biller (type 01) is judged as 01 itself; billing_or_rendering would judge its rendering "
                   "practitioner (FFS Ch.3 p.3)"}.get(role, ""))


# ------------------------------------------------------------------ reasons (C3-14)
_REASON_SYNONYMS = {
    "requires_claim_field": "no_claim_field", "requires_claim_attribute": "no_claim_field",
    "missing_claim_field": "no_claim_field", "claim_field": "no_claim_field", "not_on_claim": "no_claim_field",
    "requires_provider_attribute": "process_obligation", "provider_obligation": "process_obligation",
    "process": "process_obligation", "administrative": "process_obligation", "documentation_requirement": "process_obligation",
    "requires_documentation": "requires_medical_record", "medical_necessity": "requires_medical_record",
    "requires_medical_necessity": "requires_medical_record", "requires_diagnosis": "requires_medical_record",
    "requires_prior_authorization": "process_obligation", "prior_authorization": "process_obligation",
    "requires_member_eligibility": "requires_member_attribute", "requires_program": "requires_member_attribute",
    "member_attribute": "requires_member_attribute", "code_range": "predicate_not_in_grammar",
    "not_in_grammar": "predicate_not_in_grammar", "grammar": "predicate_not_in_grammar",
    "monthly_aggregation_not_in_grammar": "predicate_not_in_grammar", "ambiguous": "ambiguous_source",
    "unclear": "ambiguous_source", "conflict": "cross_source_conflict", "reference": "policy_reference",
    "unit_mismatch": "unit_incommensurability",
}
_REASON_KEYWORDS = (
    ("medical|record|document|necess|diagnos|clinic", "requires_medical_record"),
    ("member|eligib|program|enrollee|age", "requires_member_attribute"),
    ("provider|process|form|notif|regist|enrol|submit|obligation|authori", "process_obligation"),
    ("refer|follow|see_", "policy_reference"),
    ("conflict", "cross_source_conflict"),
    ("ambig|unclear|contradict", "ambiguous_source"),
    ("unit", "unit_incommensurability"),
    ("grammar|range|lifetime|episode|aggregat|period", "predicate_not_in_grammar"),
    ("field|claim|attribute", "no_claim_field"),
)


def map_reason(reason, text: str = "") -> str:
    """An off-list not_checkable reason -> the closest schema.PROMPT_REASONS entry (C3-14). Claim-field and provider
    wording that describes a form / enrollment / submission duty is a process_obligation (5/5 in the first run)."""
    r = str(reason or "").strip().lower()
    if r in REASONS:
        return r
    new = _REASON_SYNONYMS.get(r)
    if new is None:
        new = next((v for k, v in _REASON_KEYWORDS if re.search(k, r)), "ambiguous_source")
    if new in ("no_claim_field", "requires_member_attribute") and r.startswith(("requires_claim", "requires_provider")) \
            and PROCESS_RE.search(text or ""):
        new = "process_obligation"
    if r.startswith("requires_provider") and new != "process_obligation":
        new = "process_obligation" if PROCESS_RE.search(text or "") else "no_claim_field"
    return new


# ------------------------------------------------------------------ ages (schema AGE contract)
def ages_in_text(text: str) -> list[dict]:
    """Age conditions the text states, in the schema form ({"min": 21} / {"below": 21} / {"min": 21, "below": 65}).
    'EPSDT' as an age rule is under 21; 'does not apply to EPSDT members' is 21 and older."""
    t = clean_chars(text or "").lower()
    out = []
    for m in re.finditer(r"\b(\d{1,2})\s*(?:-|to|through|thru)\s*(\d{1,2})\b(?=[^.;]{0,25}\b(?:years?|age|old)\b)"
                         r"|\bages?\s+(\d{1,2})\s*(?:-|to|through|thru)\s*(\d{1,2})\b", t):
        lo, hi = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        if int(lo) < int(hi):
            out.append({"min": int(lo), "below": int(hi) + 1})
    for m in re.finditer(r"\b(?:under|younger\s+than|less\s+than|below)\s+(?:the\s+)?(?:age\s+(?:of\s+)?)?(\d{1,2})\b", t):
        out.append({"below": int(m.group(1))})
    for m in re.finditer(r"\b(\d{1,2})\s+(?:years?\s+)?(?:of\s+age\s+)?(?:or|and)\s+younger\b", t):
        out.append({"below": int(m.group(1)) + 1})
    for m in re.finditer(r"\b(\d{1,2})\s+(?:years?\s+)?(?:of\s+age\s+)?(?:and|or)\s+(?:older|over|above)\b"
                         r"|\b(?:at\s+least|age)\s+(\d{1,2})\s+(?:years?\s+)?(?:and|or)\s+(?:older|over)\b", t):
        out.append({"min": int(m.group(1) or m.group(2))})
    if re.search(r"\b(?:does\s+not|do\s+not)\s+apply\s+to\s+epsdt\b|\bnon-epsdt\b", t):
        out.append({"min": 21})
    elif re.search(r"\bepsdt\b", t):
        out.append({"below": 21})
    # "adults" / "children" alone are NOT mapped: the manual uses 18 and 21 for them in different programs, so a
    # model age read from them is 'not stated' and goes to a reviewer. "over 21" is not mapped either (21 or 22?).
    uniq = []
    for a in out:
        if a not in uniq:
            uniq.append(a)
    return uniq


def _age_norm(a) -> dict | None:
    """{"min": "21"} / {"min": 21.0} -> {"min": 21}; anything unreadable -> None (never equal to a stated age)."""
    if not isinstance(a, dict):
        return None
    out = {}
    for k, v in a.items():
        n = schema.integral(v)
        if k not in schema.AGE_KEYS or n is None:
            return None
        out[k] = n
    return out


# ------------------------------------------------------------------ repair (before grounding)
def repair(proposal: dict) -> tuple[dict, list[dict]]:
    """Predicates the grammar refuses but whose obligation is real become not_checkable LEADS (never executable).
    In the first run 6 'modifier X on any code' rules had code_set [] and one had modifier 'UA/UB/UC/UD'; the
    reviewer kept all 7 as uncheckable leads. schema.validate_predicate now refuses them, so without this they
    would be dropped at grounding and never reach a reviewer."""
    prop = copy.deepcopy(proposal)
    p = prop.get("predicate")
    actions: list[dict] = []
    if not isinstance(p, dict):
        return prop, actions
    t = p.get("type")
    prop["_orig_predicate"] = copy.deepcopy(p)
    text = f"{prop.get('statement') or ''} {prop.get('verbatim_quote') or ''}"
    if t in REASONS:
        # 2026-10-19 (SB's ch19 medium run): the model wrote a not_checkable REASON as the type ({"type":
        # "process_obligation"}); grounding dropped both rules as an unknown type. The reason is the reading.
        prop["predicate"] = p = {"type": "not_checkable", "reason": t}
        prop["not_checkable_reason"] = t
        _act(actions, "reason_as_type", "C3-14", "map_reason", f"type {t!r} is a not_checkable reason -> not_checkable {t}")
    elif t == "modifier_required":
        if not codes_of(p):
            _downgrade(prop, actions, "modifier_no_codes", "C3-05", "no_claim_field", "modifier_required names no code "
                       "(the trigger is a provider role or circumstance the claim does not show)")
        elif not _TWO_CHAR.match(str(p.get("modifier") or "").strip().upper()):
            _downgrade(prop, actions, "modifier_not_single", "C3-05", "no_claim_field", f"modifier {p.get('modifier')!r} "
                       "is not one two-character modifier")
    elif t == "provider_type_allowed":
        pts = [str(x).strip().upper() for x in (p.get("provider_types") or [])]
        if not pts or not all(_TWO_CHAR.match(x) for x in pts):
            _downgrade(prop, actions, "provider_type_not_a_code", "C3-03", "no_claim_field", f"provider types {pts} are "
                       "not AHCCCS provider-type codes")
    elif t in ("max_units_per_period", "max_dollars_per_period", "frequency_limit"):
        per = p.get("period")
        if per not in PERIODS and not (t == "frequency_limit" and per is None):
            _downgrade(prop, actions, "period_not_in_grammar", "C3-03", "predicate_not_in_grammar", f"period {per!r} is "
                       f"not in the grammar ({'/'.join(sorted(PERIODS))}); a lifetime cap is not expressible yet")
    elif t == "not_checkable" and p.get("reason") not in REASONS:
        new = map_reason(p.get("reason"), text)
        _act(actions, "reason_off_list", "C3-14", "map_reason", f"{p.get('reason')!r} is not a schema reason -> {new}")
        p["reason"] = prop["not_checkable_reason"] = new
    if not actions:
        prop.pop("_orig_predicate", None)
    return prop, actions


# ------------------------------------------------------------------ per proposal (after grounding)
def check(proposal: dict, g: dict | None = None, section_text: str = "", ctx: dict | None = None) -> tuple[dict, list[dict]]:
    """Return (checked copy of the proposal, actions). Pure; never raises on odd input.
    g: extract_rules.ground() output; its `source_sentences` (the full sentence(s) the quote lies in) is the text
    the checks read. ctx: {"chapter", "chapter_title", "heading"}."""
    ctx = ctx or {}
    g = g or {}
    prop = copy.deepcopy(proposal)
    actions: list[dict] = []
    p = prop.get("predicate") if isinstance(prop.get("predicate"), dict) else {}
    prop["predicate"] = p
    prop.setdefault("_orig_predicate", copy.deepcopy(p))
    quote = prop.get("verbatim_quote") or ""
    src = g.get("source_sentences") or g.get("source_quote") or quote
    src_clean = strip_code_descriptors(src)
    stmt = prop.get("statement") or ""
    heading, chapter_title = ctx.get("heading") or "", ctx.get("chapter_title") or ""
    t = p.get("type")

    # ---- not_checkable reason must be one the schema knows (C3-14); the original stays in the detail
    if t == "not_checkable" and p.get("reason") not in REASONS:
        new = map_reason(p.get("reason"), f"{stmt} {quote}")
        _act(actions, "reason_off_list", "C3-14", "map_reason", f"{p.get('reason')!r} is not a schema reason -> {new}")
        p["reason"] = prop["not_checkable_reason"] = new
    if t == "not_checkable" and prop.get("not_checkable_reason") not in (None, "", p.get("reason")):
        prop["not_checkable_reason"] = p.get("reason")

    # ---- modifier_required: the modifier must belong on EVERY line of the codes (C3-05)
    if t == "modifier_required":
        m = MOD_COND_RE.search(src_clean) or PROVIDER_CLASS_SUBJECT_RE.search(src_clean)
        if m:
            reason = "no_claim_field" if (NO_CLAIM_FIELD_COND_RE.search(src_clean)
                                          or PROVIDER_CLASS_SUBJECT_RE.search(src_clean)) else "requires_medical_record"
            _downgrade(prop, actions, "modifier_conditional", "C3-05", reason,
                       f"modifier required only in a circumstance ({m.group(0).strip()!r}) the claim does not show")
    p = prop["predicate"]
    t = p.get("type")

    # ---- code_not_covered: the sentence must bar the CODE, in every context (C3-03)
    if t == "code_not_covered":
        if not NONCOV_RE.search(src_clean):
            _downgrade(prop, actions, "noncoverage_wording_missing", "C3-03", "ambiguous_source",
                       "the source sentence has no not-covered / do-not-bill wording (the meaning may be inverted)")
        else:
            m = CONTEXT_SUBJECT_RE.search(src_clean) or CONTEXT_RE.search(src_clean)
            if m:
                reason = "no_claim_field" if SETTING_RE.search(m.group(0)) else "requires_medical_record"
                _downgrade(prop, actions, "noncoverage_context_limited", "C3-03", reason,
                           f"barred only in a context ({m.group(0).strip()!r}), not in general")
            elif REPLACED_RE.search(src_clean) and not (prop.get("effective_date") or prop.get("end_date")
                                                        or date_cues(src)):
                _downgrade(prop, actions, "replaced_code_without_date", "C3-03", "predicate_not_in_grammar",
                           f"a retired / replaced code ({REPLACED_RE.search(src_clean).group(0)!r}) with no date in the "
                           "text; without a start date every older claim would be flagged")
            elif codes_of(p) and not all(has_code(c, src) for c in codes_of(p)):
                _act(actions, "noncovered_code_not_in_sentence", "C3-03", "flag",
                     "the non-covered code is not named in the source sentence")
    p = prop["predicate"]
    t = p.get("type")

    # ---- unit caps (C3-03 / C3-04)
    if t in ("max_units_per_day", "max_units_per_dos", "max_units_per_period", "max_units_per_line"):
        if STARTS_WITH_CODE_RE.match(src) and not FINITE_VERB_RE.search(re.sub(r"^\W*\S+", "", src_clean)):
            _downgrade(prop, actions, "cap_from_code_descriptor", "C3-03", "ambiguous_source",
                       "the quote is a code descriptor line (list or table entry), not a sentence stating a limit")
        elif UNIT_DEF_RE.search(src_clean):
            _downgrade(prop, actions, "cap_is_unit_definition", "C3-03", "ambiguous_source",
                       "the sentence defines the billing unit; that is not a cap")
        elif t == "max_units_per_day" and PER_PROVIDER_RE.search(src_clean):
            per = PER_PROVIDER_RE.search(src_clean).group(0)
            cs = codes_of(p)
            if len(cs) == 1:
                prop["predicate"] = {k: v for k, v in p.items() if k != "code_set"}
                prop["predicate"].update(type="max_units_per_dos", code=cs[0])
                _rescope(prop, actions, "cap_is_per_provider", "C3-03", f"the cap is per provider ({per!r}): "
                         "max_units_per_day -> max_units_per_dos (same member, same provider, same day)")
            else:
                _downgrade(prop, actions, "cap_is_per_provider", "C3-03", "predicate_not_in_grammar",
                           f"a per-provider cap ({per!r}) over several codes is not expressible yet")
        elif MEMBER_SCOPE_RE.search(src_clean) and (t == "max_units_per_dos" or (
                t == "max_units_per_day" and p.get("scope") in ("member_provider_day", "member_servicing_billing_day"))):
            # 2026-10-17 (review B1): a narrower scope than the text is never widened here; it flags only lines that
            # break the wider cap too: kept, flagged (final critic M1)
            _flag_field(prop, actions, "cap_scope_narrower_than_text", f"the text says "
                        f"{MEMBER_SCOPE_RE.search(src_clean).group(0)!r} (any provider); the cap counts one provider's "
                        f"units: it misses units billed by several providers")
        elif t in ("max_units_per_day", "max_units_per_period") and INCLUSIVE_RE.search(src_clean):
            prop["_combined_cap"] = INCLUSIVE_RE.search(src_clean).group(0)          # section_pass merges siblings
    p = prop["predicate"]
    t = p.get("type")

    # ---- code pairs (C3-01 / C3-03 / C3-12 / C3-13)
    if t == "code_pair_prohibited":
        _check_pair(prop, actions, src, section_text or src)
    p = prop["predicate"]
    t = p.get("type")

    # ---- member program scoping on an executable rule (C3-03: T1016 in the ALTCS chapter)
    pop = (prop.get("population") or "all").strip().lower()
    if t in EXECUTABLE and pop in ("all", "", "any", "all members"):
        m = (PROGRAM_RE.search(src_clean) or PROGRAM_RE.search(heading) or
             re.search(r"\b(altcs|fesp?|federal\s+emergency)\b", chapter_title, re.I))
        if m:
            _downgrade(prop, actions, "program_scoped", "C3-03", "requires_member_attribute",
                       f"applies to a member program ({m.group(0)!r}) the claim does not carry; population was 'all'")
    p = prop["predicate"]
    t = p.get("type")

    # ---- age (schema AGE contract): an age-limited rule compiles only with an age condition the text states
    if t in EXECUTABLE:
        stated = ages_in_text(src_clean)
        if p.get("age"):
            if _age_norm(p["age"]) not in stated:
                _downgrade(prop, actions, "age_not_stated", "C3-15", "ambiguous_source",
                           f"age condition {p['age']} is not what the text states ({stated or 'no age'})")
        elif pop in ("all", "", "any", "all members") and AGE_RE.search(src_clean):
            phrase = AGE_RE.search(src_clean).group(0)
            prop["population"] = phrase
            _rescope(prop, actions, "age_scoped_population", "C3-15",
                     f"the text limits it by age ({phrase!r}) but the predicate has no age condition: population set to "
                     f"the phrase so it stays a lead until a reviewer adds predicate.age "
                     f"({' or '.join(schema.age_label(a) for a in stated) or 'age as written'})")
    p = prop["predicate"]
    t = p.get("type")

    # ---- periods and dollar caps (prompt v2: never add a period the text does not state)
    if t in ("max_units_per_period", "max_dollars_per_period", "frequency_limit") and p.get("period") and \
            not PERIOD_TEXT_RE.search(src_clean):
        _downgrade(prop, actions, "period_not_stated", "C3-03", "ambiguous_source",
                   f"the text states no period; {p.get('period')!r} was added by the model")
    p = prop["predicate"]
    t = p.get("type")

    # ---- provider_type_allowed (compiles since 2026-10-03: every type NOT listed is flagged, so the list must be the
    # complete one the text gives)
    if t == "provider_type_allowed":
        if re.search(r"\b(category\s+of\s+service|cos)\b", src_clean, re.I):
            _downgrade(prop, actions, "provider_type_is_category_of_service", "C3-03", "no_claim_field",
                       "the text is about Category of Service, not provider type")
        elif not re.search(r"\b(only|must\s+be|limited\s+to|restricted\s+to|eligible)\b", src_clean, re.I):
            _downgrade(prop, actions, "provider_type_permissive", "C3-03", "ambiguous_source",
                       "permissive wording ('may'): not an exclusive provider list")
        elif re.search(r"\binclud(?:e|es|ing)\b", src_clean, re.I) and not re.search(r"\bonly\b", src_clean, re.I):
            _downgrade(prop, actions, "provider_type_list_may_be_partial", "C3-03", "ambiguous_source",
                       "the list is introduced by 'include' with no 'only': it may not be the complete list, and every "
                       "type left out would be flagged (A0110, Ch14 p.25)")
    p = prop["predicate"]
    t = p.get("type")

    # ---- 2026-10-17 (review B1): the fields that change the SQL, against the source sentence(s); what passed is
    # written to the reviewer's note (extract_rules.to_draft_row)
    passed: list[str] = []
    if t in _CAP_BASIS or t in _PERIOD_TYPES:
        _check_threshold_basis(prop, actions, src_clean, passed, section_text)
    elif t == "provider_type_allowed":
        _check_provider_types(prop, actions, src, passed)
    elif t == "modifier_required" and p.get("modifier"):
        if not has_code(str(p["modifier"]).strip(), src):
            _downgrade(prop, actions, "modifier_not_in_text", "B1", "ambiguous_source",
                       f"modifier {p['modifier']!r} is not in the source sentence")
        else:
            passed.append(f"modifier {str(p['modifier']).strip().upper()} as written")
    if passed:
        prop["_field_checks"] = passed
    p = prop["predicate"]
    t = p.get("type")

    # ---- code ranges: a range endpoint is not a code list (prompt v2)
    ends = {x for r in code_ranges(src) for x in r}
    if t in EXECUTABLE and ends & set(codes_of(p)):
        _downgrade(prop, actions, "codes_from_range", "C3-03", "predicate_not_in_grammar",
                   f"codes taken from a code range {sorted(ends & set(codes_of(p)))}")
    p = prop["predicate"]
    t = p.get("type")

    # ---- qualifiers on what compiles: exception clause and 'may be denied'
    narrow = narrowing_clause(src, p) if t in COMPILED else None
    if narrow:
        _downgrade(prop, actions, "condition_narrows_rule", "C3-05", "ambiguous_source",
                   f"the rule applies only {narrow!r}: a condition that narrows when it applies is not an exception "
                   f"(as one, every other case would be flagged)")
    p = prop["predicate"]
    t = p.get("type")
    if t in COMPILED:
        if p.get("exception"):
            if norm(p["exception"]) not in norm(section_text or src):
                _act(actions, "exception_not_verbatim", "C3-05", "flag",
                     "predicate.exception is not verbatim in the source; the reviewer must quote the clause")
        else:
            clause = exception_clause(src)
            if clause:
                p["exception"] = clause
                _rescope(prop, actions, "exception_from_sentence", "C3-05",
                         f"the source sentence carries a condition: exception = {clause!r} (findings become "
                         "verify_exception)", attention=False)
        if p.get("discretionary") is not True and DISCRETIONARY_RE.search(src_clean):
            p["discretionary"] = True
            _rescope(prop, actions, "discretionary_wording", "C3-05",
                     f"the text says {DISCRETIONARY_RE.search(src_clean).group(0)!r}: discretionary (findings labelled "
                     "discretionary)", attention=False)
        elif p.get("discretionary") is True and not DISCRETIONARY_RE.search(src_clean):
            # 2026-10-17 (review B1): a 'may be denied' label the text does not carry
            _flag_field(prop, actions, "discretionary_not_stated", "discretionary is true but the text has no 'may be "
                        "denied / may not be paid' wording")

    # ---- flags only: the statement must come from the quote; pricing / EDI / background is not an obligation
    sn, qn_ = _numbers(stmt), _numbers(src)
    extra = sorted(sn - qn_, key=int)
    cs_, cq = _content(stmt), _content(src)
    overlap = len(cs_ & cq) / max(1, len(cs_))
    if extra or (len(cs_) >= 4 and overlap < 0.34):
        _act(actions, "statement_not_from_quote", "C3-18", "flag",
             f"statement numbers {extra} are not in the quote" if extra else f"statement/quote word overlap {overlap:.2f}")
    m = PRICING_RE.search(src) or EDI_RE.search(src) or BACKGROUND_RE.search(src)
    if m:
        _act(actions, "possibly_not_a_rule", "C3-18", "flag", f"pricing / EDI / background wording ({m.group(0)!r})")
    qconds = {x.lower() for x in re.findall(r"\b(unless|except|does not apply|only|prior to|effective|before|after)\b",
                                            src_clean, re.I)}
    sconds = {x.lower() for x in re.findall(r"\b(unless|except|does not apply|only|prior to|effective|before|after)\b",
                                            stmt, re.I)}
    if qconds - sconds:
        _act(actions, "statement_drops_condition", "C3-06", "flag", f"the quote says {sorted(qconds - sconds)}; the "
             "statement does not")
    return prop, actions


_DESCRIPTOR_SPAN_RE = re.compile(r"\b(?:\d{4}[A-Z0-9]|[A-Z]\d{4})\b\s*" + _NOT_CONDITION_PAREN)


def condition_clauses(src: str) -> list[str]:
    """The condition clauses of the source sentence(s), VERBATIM (original characters): from the condition word to the
    end of its clause. A condition word inside a code descriptor is skipped ('99070 (Supplies and materials, except
    spectacles, ...)'); 'when billed on the same day / together / with <code>' is the pair's own trigger."""
    src = src or ""
    skip = [(m.start(), m.end()) for m in _DESCRIPTOR_SPAN_RE.finditer(src)]
    out = []
    for m in EXCEPTION_RE.finditer(src):
        if any(a <= m.start() < b for a, b in skip):
            continue
        rest = src[m.start():]
        end = re.search(r"[.;)]|\s\(|$", rest)
        clause = rest[:end.start()].strip(" ,")
        if len(clause.split()) < 3:
            continue
        out.append(clause)
    return out


# the words a rule's own trigger is written with: the co-billing ("when both are billed on the same day", "if billed
# with H0036"), its scope ("by the same provider") and its threshold ("if more than 4 units are billed per day")
_TRIGGER_WORDS = set("""when whenever if only provided that billed bill bills billing submitted submit reported report
    claimed claim is are be been being it they these those both together on the same day days date dates of service with
    each other one another code codes procedure and or a an in addition to as more than over above exceed exceeds
    exceeding units unit per any also by for from member members recipient recipients provider providers rendered
    performed furnished delivered""".split())
# co-billing words: the trigger of a code pair (and only when the clause names that pair's codes or their category);
# for a cap or a not-covered rule a co-billing condition narrows it ("... when H2017 is also billed": a lead; N3)
_CO_BILLING = {"with", "both", "together", "addition", "also", "another", "other", "each"}
_AGE_WORDS = {"years", "year", "age", "aged", "old", "older", "younger", "under", "over", "and", "or", "of", "members",
              "member", "individuals", "persons", "recipients"}


def _is_own_trigger(clause: str, p: dict, codes=()) -> bool:
    """True when the clause, after its codes, numbers, basis phrases, categories and (for an age the predicate states)
    its age phrase are removed, holds nothing but trigger words - else it names a setting, a place, a population, a
    provider or a claim: it narrows when the rule applies (final critic B2). Co-billing words count only for a code
    pair whose clause names the pair's codes (or their category); a cap or not-covered rule conditioned on another
    code, or on being billed with something, is narrowed (N3)."""
    t = clean_chars(clause)
    own = {str(c).upper() for c in list(codes) + codes_of(p)}
    named = {c.upper() for c in CODE_RE.findall(t)}
    ref_only = False
    if p.get("type") == "code_pair_prohibited":
        # v6.2 (critic): "if both codes are billed on the same day" names the pair by reference: its own trigger - but
        # not when the clause names a third code or "another" one ("if both are billed with H0001" narrows)
        co = bool(named & own) or bool(CATEGORY_RE.search(t))
        if not co and not (named - own) and (REFERENCE_RE.search(t) or re.search(r"\bboth\b", t, re.I)):
            co = ref_only = True
    else:
        if named - own:
            return False
        co = False
    allowed = set(_TRIGGER_WORDS) - (set() if co else _CO_BILLING) - ({"another", "other"} if ref_only else set())
    if p.get("age") and _age_norm(p["age"]) in ages_in_text(t):
        t, allowed = AGE_RE.sub(" ", t), allowed | _AGE_WORDS
    for rx in (CODE_RE, _NUM_RE, _BASIS_RE, CATEGORY_RE):
        t = rx.sub(" ", t)
    return all(w in allowed for w in re.findall(r"[a-z]+", t.lower()))


def exception_clause(src: str) -> str | None:
    """The first clause that EXEMPTS from the rule (unless / except / excluding / does not apply): its exception."""
    return next((c for c in condition_clauses(src) if _EXEMPT_RE.match(c)), None)


def narrowing_clause(src: str, p: dict | None = None, codes=()) -> str | None:
    """The first condition clause that NARROWS when the rule applies (when / if / whenever / only if / only in ... a
    setting, place, population, modifier, claim) - or the predicate's own exception when it is one. Not narrowing: an
    exempting clause (exception_clause), and the rule's own trigger: a clause that, without its codes, numbers and
    co-billing / threshold / scope words, says nothing more ("if both codes are billed on the same day", "if more than
    4 units are billed per day"); "when H2017 is provided in a residential setting" narrows."""
    p = p or {}
    for c in condition_clauses(src) + ([p["exception"]] if _text_or_none(p.get("exception")) else []):
        if _EXEMPT_RE.match(c) or _is_own_trigger(c, p, codes):
            continue
        return c
    return None


_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
_ONES = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9}


def _numbers(s: str) -> set[str]:
    s = norm(s)
    s = re.sub(r"\b(" + "|".join(_TENS) + r")[- ](" + "|".join(_ONES) + r")\b",
               lambda m: str(_TENS[m.group(1)] + _ONES[m.group(2)]), s)
    s = re.sub(r"\b(?:\d{4}[a-z0-9]|[a-z]\d{4})\b", " ", s)               # procedure codes are not numbers
    s = re.sub(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b", " ", s)                     # dates
    out = {str(int(x.replace(",", ""))) for x in re.findall(r"\d[\d,]*", s) if x.replace(",", "").isdigit()}
    for w, v in WORD_NUMBERS.items():
        if " " not in w and re.search(rf"\b{re.escape(w)}\b", s):
            out.add(str(v))
    for w, v in (("once", 1), ("twice", 2)):
        if re.search(rf"\b{w}\b", s):
            out.add(str(v))
    return out


_STOP = set("""a an the of to for and or in on at by with be is are was were may must shall should will can not no
this that these those any all each per as from than which who when if only under over within such its their it
ahcccs member members provider providers service services claim claims billed bill billing code codes""".split())


def _content(s: str) -> set[str]:
    return {w[:6] for w in re.findall(r"[a-z]{3,}", norm(s)) if w not in _STOP}


# ------------------------------------------------------------------ cross-proposal
_CODE_ANYCASE_RE = re.compile(r"(?<![a-z0-9])(?:\d{4}[a-z0-9]|[a-z]\d{4})(?![a-z0-9])")


def _codes_before(section_text: str, quote: str) -> list[str]:
    """Distinct codes that appear in the section BEFORE the quote, nearest first ('Billable codes: 98960, 98961,
    98962. ... inclusive of all 3 billable codes')."""
    t, q = norm(section_text), norm(quote)
    pos = t.find(q) if q else -1
    if pos < 0:
        return []
    found = [m.group(0).upper() for m in _CODE_ANYCASE_RE.finditer(t[:pos])]
    return list(dict.fromkeys(reversed(found)))


def section_pass(items: list[tuple[dict, list]], section_text: str = "", ctx: dict | None = None):
    """Merge per-code caps that the source sentence calls combined into one code_set rule (C3-04: 'a maximum of four
    units per day ... inclusive of all 3 billable codes' was extracted as 98960 alone), and demote dollar caps that
    share one code with different thresholds (a claim cannot tell which service it paid: T2028)."""
    out = [(copy.deepcopy(p), list(f)) for p, f in items]
    groups: dict = {}
    for i, (p, f) in enumerate(out):
        if p.get("_combined_cap") and not p.get("_drop"):
            pr = p["predicate"]
            groups.setdefault((pr.get("type"), pr.get("threshold"), pr.get("period"), norm(p.get("verbatim_quote"))),
                              []).append(i)
    for (ptype, thr, period, qn), idx in groups.items():
        codes = sorted({c for i in idx for c in codes_of(out[i][0]["predicate"])})
        cue = out[idx[0]][0]["_combined_cap"]
        want = re.search(r"all\s+(\d+|two|three|four|five|six)\s+(?:billable\s+)?codes", cue + " " + qn, re.I)
        n = (int(want.group(1)) if want.group(1).isdigit() else WORD_NUMBERS.get(want.group(1).lower())) if want else None
        sec_codes = sorted(set(text_codes(section_text)))
        if n and len(codes) < n and len(sec_codes) == n:
            codes = sec_codes                                  # "all 3 billable codes" and the section has exactly 3
        elif n and len(codes) < n:
            near = _codes_before(section_text, out[idx[0]][0].get("verbatim_quote") or "")[:n]
            if len(near) == n and set(codes) <= set(near):
                codes = sorted(near)                           # the n codes listed just before the cap sentence
        keep_p, keep_f = out[idx[0]]
        if len(idx) == 1 and sorted(codes_of(keep_p["predicate"])) == codes and keep_p["predicate"].get("code_set"):
            keep_p.pop("_combined_cap", None)          # already the combined code_set rule: nothing to merge
            continue
        if (n and len(codes) != n) or len(codes) < 2:
            _act(keep_f, "combined_cap_incomplete", "C3-04", "flag",
                 f"the text says the cap is combined ({cue!r}) but only {codes} were identified: the reviewer must list "
                 "the code_set (a per-code cap never over-flags; it misses)")
            for i in idx:
                out[i][0].pop("_combined_cap", None)
            continue
        new_p = {"type": ptype, "code_set": codes, "threshold": thr}
        if ptype == "max_units_per_period":
            new_p["period"] = period
        for q in ("age", "exception", "discretionary"):
            if keep_p["predicate"].get(q) not in (None, ""):
                new_p[q] = keep_p["predicate"][q]
        keep_p.setdefault("pre_check_predicate", copy.deepcopy(keep_p["predicate"]))
        keep_p["predicate"], keep_p["codes"] = new_p, codes
        _act(keep_f, "combined_cap_merged", "C3-04", "rescope",
             f"the text says the cap is combined ({cue!r}): one code_set cap {codes}")
        for i in idx[1:]:
            out[i][0]["_duplicate"] = True
            _act(out[i][1], "combined_cap_merged", "C3-04", "duplicate", f"merged into the combined code_set cap {codes}")
        for i in idx:
            out[i][0].pop("_combined_cap", None)
    # one code, several dollar caps with different thresholds
    by_code: dict = {}
    for p, _ in out:
        if p["predicate"].get("type") == "max_dollars_per_period" and not p.get("_drop"):
            for c in codes_of(p["predicate"]):
                by_code.setdefault(c, set()).add(p["predicate"].get("threshold"))
    for p, f in out:
        if p["predicate"].get("type") == "max_dollars_per_period":
            shared = [c for c in codes_of(p["predicate"]) if len(by_code.get(c, ())) > 1]
            if shared:
                _downgrade(p, f, "dollar_caps_share_code", "C3-03", "no_claim_field",
                           f"{shared} carries several services with different caps; a claim cannot tell which was paid")
    for p, _ in out:
        p.pop("_combined_cap", None)
    return out


def summarize(actions: list[dict], limit: int = 180) -> str:
    """A short note for the draft's ambiguity_note (each detail clipped; the grounding JSON keeps them in full)."""
    def clip(s):
        return s if len(s) <= limit else s[:limit - 3] + "..."
    return ("post-checks: " + "; ".join(f"[{a['check']}] {clip(a['detail'])}" for a in actions)) if actions else ""
