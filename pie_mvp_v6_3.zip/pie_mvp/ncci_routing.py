"""
ncci_routing.py  -  which Medicaid NCCI edit file applies to a claim line.

CMS decides it by PROVIDER TYPE and CLAIM FORM (2026 Medicaid NCCI Technical Guidance Manual, s6.0 Table 2,
verified 2026-10-02 at https://www.cms.gov/files/document/2026-medicaid-ncci-technical-guidance-manual-02282026.pdf):

    provider type                             mandatory   CMS-1500 / 837P: rendering   UB-04 / 837I
                                                          identified / not identified
    Physician / Nonphysician Practitioner     yes         PRA / PRA                    OPH
    Ambulatory Surgical Center (ASC)          yes         PRA / PRA                    PRA
    Outpatient Services in Hospitals          yes         OPH / OPH                    OPH
    Durable/Home Medical Equipment            yes         DME / DME                    DME
    Nonhospital-Based Testing Facilities      optional    PRA / PRA                    PRA
    Other Providers of Outpatient Services    optional    PRA / OPH                    OPH

    WHICH provider (2026-10-03): the TGM requires the methodologies for "claims ... from the following types of
    providers" (s5.3) and makes them optional for "claims from other types of providers of outpatient services" such
    as FQHCs, RHCs and community mental health centers (s5.5): the provider type is the one that SUBMITS the claim -
    the BILLING provider (config.CLAIM_COLS['billing_type'] = BProv_Type). D2 (2026-10-14): a GROUP billing type
    (config.GROUP_BILLING_PROVIDER_TYPES, AHCCCS type 01: "organizations electing to act as financial representatives"
    that "do not independently provide services to members", AHCCCS Group Biller one-pager) submits for its
    rendering practitioners, so the SERVICING type's row decides a group line; a group line whose servicing type is
    missing or not in the table takes no file. "Rendering practitioner identified" is read from the SERVICING
    provider: an individual practitioner type (Table 2's footnotes 14 and 17) is a rendering practitioner; an
    organisation (the clinic itself, a group billing type) is not. It only matters in the 'Other Providers' row.
    Dentists are physician practitioners (footnote 14); their ADA dental claims take no file (s5.2).
    TGM s5.2: NCCI does not apply to ADA dental claims, NDC / revenue-code-only claims, or inpatient and residential
    facility claims. Footnote 19: "Identical edits for the Medicaid NCCI methods are found in standalone DME edit files
    and the PRA and OPH files" - so a line takes ONE edit file, never a merge of several.
    D1 (2026-10-14): with config.NCCI_REQUIRE_SIGNED_ROUTING (default) a line takes a file only when the routing row
    that decides it is SIGNED (status 'signed' + a reviewer); a line whose deciding row is unsigned takes none - 01 and
    08 report those lines and dollars. A line no row decides takes no file whatever the switch (2026-10-16: the
    exploratory NCCI_ROUTE_BY "form" / "provider_type" and NCCI_UNMAPPED_PROVIDER_TYPE "form" branches are removed).

AHCCCS provider types are mapped to those rows in a reviewed reference table, keyed on the provider type CODE (the
description can change, so it is display-only): reference/ncci_provider_type_routing.csv - one code list, used for the
billing and the servicing provider alike. The snapshot (detector_gen.snapshot_select_sql) stamps every line with
`pie_ncci_edition` = practitioner | outpatient | dme | NULL using edition_sql(); NCCI rules carry the edition they
come from (predicate['ncci_edition']) and run only on lines of that edition.
"""
from __future__ import annotations

import csv
import hashlib
import os
import re

import config

EDITIONS = ("practitioner", "outpatient", "dme")
FORM_KIND = {"A": "professional", "O": "institutional"}        # NCCI never runs on C, D, I, L (TGM s5.2)
# category -> (Table 2 row, mandatory?, {"professional_identified" | "professional" | "institutional": edition})
# "professional_identified" = CMS-1500 with a rendering practitioner identified; "professional" = not identified.
TABLE2 = {
    "practitioner":        ("Physician / Nonphysician Practitioner", True,
                            {"professional_identified": "practitioner", "professional": "practitioner",
                             "institutional": "outpatient"}),
    "asc":                 ("Ambulatory Surgical Center (ASC)", True,
                            {"professional_identified": "practitioner", "professional": "practitioner",
                             "institutional": "practitioner"}),
    "outpatient_hospital": ("Outpatient Services in Hospitals", True,
                            {"professional_identified": "outpatient", "professional": "outpatient",
                             "institutional": "outpatient"}),
    "dme":                 ("Durable/Home Medical Equipment", True,
                            {"professional_identified": "dme", "professional": "dme", "institutional": "dme"}),
    "testing_facility":    ("Nonhospital-Based Testing Facilities", False,
                            {"professional_identified": "practitioner", "professional": "practitioner",
                             "institutional": "practitioner"}),
    "other_outpatient":    ("Other Providers of Outpatient Services", False,
                            {"professional_identified": "practitioner", "professional": "outpatient",
                             "institutional": "outpatient"}),
    "not_applicable":      ("(no NCCI: dental, pharmacy, inpatient / residential, LTC / HCBS, administrative)", None, {}),
}
OPTIONAL = tuple(k for k, (_, mand, _e) in TABLE2.items() if mand is False)


NULL_TEXT = ("NAN", "NONE", "NULL")      # a missing value written as text by an export (2026-10-03, oracle S07/S08)


def norm_type(v) -> str | None:
    """A provider type code as the table keys it: text, spaces trimmed (only the space character, as SQL TRIM), upper
    case, a lone digit zero-padded ('8' -> '08', the way a numeric column would hold '08'), a whole number written with
    decimals read as the number ('8.0' -> '08'); '' / None / the text NONE, NAN or NULL -> None (missing)."""
    if v is None:
        return None
    s = str(v).strip(" ").upper()
    if s in ("",) + NULL_TEXT:
        return None
    s = re.sub(r"\.0+$", "", s) if re.fullmatch(r"\d+\.0+", s) else s
    return s.zfill(2) if s.isdigit() and len(s) == 1 else s


def table_path() -> str:
    return getattr(config, "NCCI_PROVIDER_TYPE_TABLE", None) or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "reference", "ncci_provider_type_routing.csv")


def load_table(path: str | None = None) -> list[dict]:
    """Rows of the routing table, validated: every code once (after norm_type), every category known."""
    path = path or table_path()
    with open(path, newline="", encoding="utf-8") as f:
        rows = [dict(r) for r in csv.DictReader(f)]
    seen, bad = {}, []
    for r in rows:
        c = norm_type(r.get("sprov_type"))
        if c is None:
            bad.append(f"blank provider type code in {r}")
            continue
        if not re.fullmatch(r"[A-Z0-9]{1,4}", c):
            bad.append(f"provider type {c!r}: letters and digits only")
        if r.get("cms_category") not in TABLE2:
            bad.append(f"provider type {c!r}: unknown cms_category {r.get('cms_category')!r} (one of {sorted(TABLE2)})")
        if c in seen:
            bad.append(f"provider type {c!r} listed twice")
        seen[c] = r
        r["sprov_type"] = c
    if bad:
        raise ValueError(f"{path}: " + "; ".join(bad[:10]))
    return rows


def table_sha256(path: str | None = None) -> str:
    with open(path or table_path(), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def optional_on() -> tuple[str, ...]:
    on = tuple(getattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", ()) or ())
    bad = [c for c in on if c not in OPTIONAL]
    if bad:
        raise ValueError(f"config.NCCI_OPTIONAL_CATEGORIES_ON: {bad} are not optional Table 2 rows {list(OPTIONAL)}")
    return on


def category_edition(category: str, form: str | None, identified: bool = False) -> str | None:
    """The edit file Table 2 gives a category on a form (None: no NCCI). Optional rows only when switched on.
    identified: a rendering practitioner is identified (only the CMS-1500 column of the 'Other Providers' row cares)."""
    kind = FORM_KIND.get(str(form or "").strip().upper())
    if kind is None or category not in TABLE2:
        return None
    _, mandatory, by_kind = TABLE2[category]
    if mandatory is False and category not in optional_on():
        return None
    if kind == "professional" and identified:
        return by_kind.get("professional_identified")
    return by_kind.get(kind)


def group_types() -> frozenset:
    """config.GROUP_BILLING_PROVIDER_TYPES cleaned like the column (norm_type: '1', ' 01 ', '01.0' -> 01)."""
    return frozenset(t for t in (norm_type(v) for v in (getattr(config, "GROUP_BILLING_PROVIDER_TYPES", ()) or ())) if t)


def require_signed() -> bool:
    """D1: config.NCCI_REQUIRE_SIGNED_ROUTING - a line takes a file only through a SIGNED routing row."""
    return bool(getattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True))


def individual_practitioners(table: list[dict] | None = None) -> list[str]:
    """Codes whose servicing provider is a rendering practitioner (a person): the practitioner category, less any
    group billing type."""
    rows = table if table is not None else load_table()
    groups = group_types()
    return sorted(r["sprov_type"] for r in rows if r["cms_category"] == "practitioner" and r["sprov_type"] not in groups)


def _decide(st: str | None, bt: str | None, codes) -> tuple[str | None, str]:
    """(the code whose row decides the line, how): QUERY_SEMANTICS s1a steps 1-4. st / bt cleaned (norm_type)."""
    if bt is not None:
        if bt in group_types():                                  # D2: a group submits for its rendering practitioner
            return (st, "group_servicing") if st in codes else (None, "group_no_servicing")
        if bt in codes:
            return bt, "billing"
    if st in codes:
        return st, "servicing"
    return None, "unmapped"


def deciding_type(form, prov_type, billing_type=None, table: list[dict] | None = None) -> str | None:
    """The provider type code whose routing row decides the edit file of a line (None: no row decides - a form NCCI
    never applies to, a group line with no servicing type in the table, neither type in the table)."""
    if str(form or "").strip().upper() not in FORM_KIND:
        return None
    rows = table if table is not None else load_table()
    return _decide(norm_type(prov_type), norm_type(billing_type), {r["sprov_type"] for r in rows})[0]


def edition(form, prov_type, table: list[dict] | None = None, billing_type=None, signed_only: bool | None = None) -> str | None:
    """Python reference of edition_sql(): the edit file a line takes.
    prov_type = the SERVICING provider type code, billing_type = the BILLING provider type code (missing: None).
    A group billing type -> the servicing type's row or no file (D2); else the billing type's row, else the servicing
    type's row, else no file. The servicing type says whether a rendering practitioner is identified. signed_only
    (default config.NCCI_REQUIRE_SIGNED_ROUTING, D1): the deciding row must be signed, else no file."""
    optional_on()                                        # validate the switch on every call (fail loudly)
    f = str(form or "").strip().upper()
    if f not in FORM_KIND:
        return None
    so = require_signed() if signed_only is None else bool(signed_only)
    rows = {r["sprov_type"]: r for r in (table if table is not None else load_table())}
    st, bt = norm_type(prov_type), norm_type(billing_type)
    code, _how = _decide(st, bt, rows)
    if code is None:
        return None
    if so and not is_signed(rows[code]):
        return None
    identified = st in set(individual_practitioners(list(rows.values())))
    return category_edition(rows[code]["cms_category"], f, identified)


def type_sql(col_expr: str) -> str:
    """SQL twin of norm_type(). Linear (the column appears once): the expression is inlined wherever a type is
    compared, and a nested CASE that repeated it pushed Spark's generated code past 64 KB (2026-10-03 simulation)."""
    nulls = "|".join(NULL_TEXT)
    t = f"REGEXP_REPLACE(UPPER(TRIM(CAST({col_expr} AS STRING))), '^({nulls})$', '')"
    t = f"REGEXP_REPLACE({t}, '^([0-9]+)\\\\.0+$', '$1')"           # '8.0' -> '8'
    t = f"REGEXP_REPLACE({t}, '^([0-9])$', '0$1')"                  # '8' -> '08'
    return f"NULLIF({t}, '')"


def _in(codes) -> str:
    return ",".join(f"'{c}'" for c in sorted(codes))


def deciding_type_sql(type_expr: str, billing_expr: str | None = None, table: list[dict] | None = None) -> str:
    """SQL twin of deciding_type() without the form test (the caller filters forms A / O): the (cleaned) code whose
    routing row decides the line, NULL when none does."""
    rows = table if table is not None else load_table()
    codes = _in([r["sprov_type"] for r in rows])
    whens = []
    if billing_expr:
        if group_types():
            whens.append(f"WHEN {billing_expr} IN ({_in(group_types())}) THEN "
                         f"CASE WHEN {type_expr} IN ({codes}) THEN {type_expr} END")
        whens.append(f"WHEN {billing_expr} IN ({codes}) THEN {billing_expr}")
    whens.append(f"WHEN {type_expr} IN ({codes}) THEN {type_expr}")
    return "CASE " + " ".join(whens) + " END"


def edition_sql(form_expr: str, type_expr: str, table: list[dict] | None = None, billing_expr: str | None = None,
                signed_only: bool | None = None) -> str:
    """SQL CASE: the edit file a line takes, from its (normalised) claim form, servicing provider type code
    (type_expr) and billing provider type code (billing_expr; None = not available -> the servicing type decides).
    The SQL twin of edition()."""
    optional_on()
    so = require_signed() if signed_only is None else bool(signed_only)
    forms = ",".join(f"'{f}'" for f in FORM_KIND)
    rows = table if table is not None else load_table()
    by_cat: dict[str, list[str]] = {}
    for r in rows:
        if not so or is_signed(r):                       # D1: an unsigned row gives no file
            by_cat.setdefault(r["cms_category"], []).append(r["sprov_type"])
    indiv = individual_practitioners(rows)
    identified = f"COALESCE({type_expr} IN ({_in(indiv)}), FALSE)" if indiv else "FALSE"
    lit = lambda e: f"'{e}'" if e else "NULL"

    def by_category(key_expr: str) -> str:
        whens = []
        for cat in TABLE2:
            codes = by_cat.get(cat)
            if not codes:
                continue
            a_id, a, o = category_edition(cat, "A", True), category_edition(cat, "A"), category_edition(cat, "O")
            a_val = lit(a) if a_id == a else f"CASE WHEN {identified} THEN {lit(a_id)} ELSE {lit(a)} END"
            val = lit(a) if (a_id == a == o) else f"CASE WHEN {form_expr} = 'A' THEN {a_val} ELSE {lit(o)} END"
            whens.append(f"WHEN {key_expr} IN ({_in(codes)}) THEN {val}")
        return ("CASE " + " ".join(whens) + " END") if whens else "CAST(NULL AS STRING)"

    all_codes = _in([r["sprov_type"] for r in rows])
    out = [f"WHEN {form_expr} IS NULL OR {form_expr} NOT IN ({forms}) THEN NULL"]
    if billing_expr:
        if group_types():                                # D2: the servicing type's row, or no file
            out.append(f"WHEN {billing_expr} IN ({_in(group_types())}) THEN {by_category(type_expr)}")
        out.append(f"WHEN {billing_expr} IN ({all_codes}) THEN {by_category(billing_expr)}")
    out.append(f"WHEN {type_expr} IN ({all_codes}) THEN {by_category(type_expr)}")
    return "CASE " + " ".join(out) + " ELSE NULL END"


PIE_FORM, PIE_PROV_TYPE, PIE_BPROV_TYPE, PIE_EDITION = "pie_form", "pie_prov_type", "pie_bprov_type", "pie_ncci_edition"


def routed_sql(table: str, cc: dict, quote=lambda x: x, cols: set | None = None) -> str:
    """A RAW claims table (01, 07, gap) with the routing columns added: pie_form, pie_prov_type, pie_bprov_type and
    pie_ncci_edition - the values the detection snapshot stamps. The cleaned codes are computed ONCE per row and the
    edit file from them (inlining the clean-up into every comparison made Spark's generated code exceed 64 KB).
    cc: config.CLAIM_COLS-like {logical: physical}; quote: how a column is quoted; cols: the table's columns (upper
    case) - a configured column the table lacks is treated as missing. Returns a parenthesised subquery."""
    have = lambda k: bool(cc.get(k)) and (cols is None or str(cc[k]).upper() in cols)
    form = f"UPPER(TRIM(CAST({quote(cc['form'])} AS STRING)))" if have("form") else "CAST(NULL AS STRING)"
    pt = type_sql(quote(cc["prov_type"])) if have("prov_type") else "CAST(NULL AS STRING)"
    bt = type_sql(quote(cc["billing_type"])) if have("billing_type") else "CAST(NULL AS STRING)"
    ed = edition_sql(PIE_FORM, PIE_PROV_TYPE, billing_expr=PIE_BPROV_TYPE if have("billing_type") else None)
    return (f"(SELECT r.*, {ed} AS {PIE_EDITION} FROM (SELECT t.*, {form} AS {PIE_FORM}, {pt} AS {PIE_PROV_TYPE}, "
            f"{bt} AS {PIE_BPROV_TYPE} FROM {table} t) r)")


def is_signed(row: dict) -> bool:
    """A routing row counts as signed when its status says 'signed' AND a reviewer is named."""
    return str(row.get("status") or "").strip().lower() == "signed" and bool(str(row.get("reviewer") or "").strip())


def unsigned_observed(codes, table: list[dict] | None = None) -> list[str]:
    """The provider type codes whose routing row is NOT signed - not in the table, or in it unsigned. Given the codes
    that DECIDE routing on CMS-1500 / UB-04 lines (observed_types_sql), these are the types whose lines take no NCCI
    file under config.NCCI_REQUIRE_SIGNED_ROUTING (D1), or run on an unsigned reading with the switch off."""
    rows = {r["sprov_type"]: r for r in (table if table is not None else load_table())}
    seen = {norm_type(c) for c in codes} - {None}
    return sorted(c for c in seen if c not in rows or not is_signed(rows[c]))


def observed_types_sql(table: str, form_col: str, prov_col: str = None, billing_col: str | None = None,
                       paid_col: str | None = None, group_unrouted: bool = False) -> str:
    """SQL: one row per provider type code `t` that DECIDES the edit file of lines of `table` on a form NCCI applies
    to (CMS-1500 'A' / UB-04 'O'; deciding_type_sql: a group's line -> its servicing type, else the billing type when
    in the table, else the servicing type), with its `lines` and (paid_col given) `paid` dollars.
    The columns must already be cleaned (the snapshot's pie_* columns). 01 and 08 list the unsigned ones (D1).
    group_unrouted (08, 2026-10-16): one more row with t NULL - the group-billed lines whose servicing type is missing or
    not in the table, which no row decides and so take no file (D2)."""
    prov_col = prov_col or PIE_PROV_TYPE
    billing_col = billing_col or PIE_BPROV_TYPE
    forms = ",".join(f"'{f}'" for f in FORM_KIND)
    t = deciding_type_sql(prov_col, billing_col)
    paid = f", SUM({paid_col}) AS paid" if paid_col else ""
    keep = "t IS NOT NULL"
    g = ""
    if group_unrouted:
        g = (f", COALESCE({billing_col} IN ({_in(group_types())}), FALSE) AS g" if group_types() else ", FALSE AS g")
        keep = "(t IS NOT NULL OR g)"
    return (f"SELECT t, COUNT(*) AS lines{paid} FROM (SELECT {t} AS t{g}{', ' + paid_col if paid_col else ''} "
            f"FROM {table} WHERE {form_col} IN ({forms})) u WHERE {keep} GROUP BY t ORDER BY t")


def summary(table: list[dict] | None = None) -> dict:
    """For the build log: how the routing was configured."""
    rows = table if table is not None else load_table()
    return {"optional_on": list(optional_on()), "table": os.path.basename(table_path()), "table_sha256": table_sha256(),
            "types_mapped": len(rows), "types_signed": sum(1 for r in rows if is_signed(r)),
            "require_signed": require_signed(), "group_billing_types": sorted(group_types()),
            "by_category": {c: sum(1 for r in rows if r["cms_category"] == c) for c in TABLE2}}
