"""
config.py  -  environment and claims-schema mapping for the Policy KB.

Everything that names a table or a column lives here. Nothing else in the
package hard-codes a physical column name.
"""
import os

# The package version (04 writes it, and extract_rules.CODE_SHA, into every run's manifest.json). 6.3 = 6.2 + the
# fixes from the first real chapter 19 runs (docs/V6_CHANGES.md section 9). The prompt is still v3, unchanged.
PIE_VERSION = "6.3"


# ---------------------------------------------------------------- sources
CATALOG = os.environ.get("PKB_CATALOG", "main")
SCHEMA = os.environ.get("PKB_SCHEMA", "sedo")                                   # NCCI tables + state_rules live here
STATE_RULES_TABLE = f"{CATALOG}.{SCHEMA}.state_rules"

# ---------------------------------------------------------------- outputs
OUTPUT_CATALOG = os.environ.get("PKB_OUTPUT_CATALOG", "main")
OUTPUT_SCHEMA = os.environ.get("PKB_OUTPUT_SCHEMA", "policy_kb")
KB = f"{OUTPUT_CATALOG}.{OUTPUT_SCHEMA}"
# Delta on Databricks. The offline end-to-end test (tests/e2e_local_spark.py) sets parquet,
# because open-source Spark here has no Delta jars. Never change this on the cluster.
TABLE_FORMAT = os.environ.get("PKB_TABLE_FORMAT", "delta")

# ---------------------------------------------------------------- claims
CLAIMS_TABLE = os.environ.get("PKB_CLAIMS", "main.prod_input.all_data_C_A")

# logical name -> physical column (verified against DESCRIBE all_data_C_A)
CLAIM_COLS = {
    "claim_id":            "ClaimID",
    "line_no":             "LN_NO",
    "member":              "MEMBER_KEY",
    "servicing_provider":  "SProv_ID",
    "billing_provider":    "BProv_ID",
    "dos":                 "Svc_Begin_Dt",
    "code":                "PROC_CD",
    "units":               "QUANTITY_PAID",      # confirmed: units of service, decimal(15,4)
    "paid_amt":            "PMT_AMT",
    "pos":                 "POS_CODE",
    "form":                "FORM_TYP",
    "mods":                ["PROC_MOD_1", "PROC_MOD_2", "PROC_MOD_3", "PROC_MOD_4"],
    # Prior-authorization number (SB, 2026-09-20): populated => a PA exists for this
    # procedure transaction. It does NOT tell us the PA's authorized units or dates,
    # so a populated value DOWNGRADES a state over-limit finding to 'verify_pa';
    # it never suppresses one, and it never touches NCCI edits (CMS: PA is not an
    # NCCI bypass).
    "pa_no":               "EVENT_PA_NO",
    # Member date of birth (SB, 2026-10-02: `date_of_birth` is in all_data_C_A). Age-scoped rules use
    # the member's age ON THE DATE OF SERVICE. A line with no usable date of birth never matches an
    # age condition (it can only be missed, never wrongly flagged); 08 reports how many there are.
    "dob":                 "date_of_birth",
    # Servicing provider type CODE (SB, 2026-10-02: SProv_Type; SProv_Type_Desc is its description). Decides which
    # NCCI edit file a line takes (CMS TGM s6.0 Table 2: provider type x claim form; see ncci_routing.py). The
    # CODE is the key - the boss's call: a description can change, a code does not. The description is never read.
    "prov_type":           "SProv_Type",
    # Billing provider type CODE (SB, 2026-10-03: BProv_Type). CMS applies NCCI to "claims FROM" a type of provider
    # (TGM s5.3 / s5.5), so the provider that SUBMITS the claim decides the NCCI edit file; the servicing type only
    # says whether a rendering practitioner is identified (Table 2's CMS-1500 column). Provider-type rules
    # ("billed only by provider types ...", provider_type_allowed) read it too.
    "billing_type":        "BProv_Type",
}

# all_data_C_A holds PAID lines only (SB, 2026-09-20). No paid-status filter is
# needed in detectors. Sanity check worth running once on the cluster:
#   SELECT COUNT(*) FROM main.prod_input.all_data_C_A WHERE PMT_AMT < 0
# (reversals sometimes ride as negative-amount paid lines).
CLAIMS_PAID_ONLY = True

# NCCI Delta tables were built from CMS PUBLIC files (SB, 2026-09-20), not the
# RISSNET state implementation files. CMS notes state files may carry
# state-specific deactivations, so NCCI findings are "per CMS public edit set;
# Arizona deactivations not applied".
NCCI_SOURCE = "cms_public"
# MUE validity is reconstructed from consecutive quarterly snapshots (public MUE files are undated and hold only the
# MUEs in effect that quarter). A missing quarter table CLOSES the MUE run at the end of the last loaded quarter and a
# new run starts with the next loaded one: nothing is inferred across the hole, so no claim is judged by a value CMS
# did not publish; only recall for the missing quarter is lost (2026-10-16 decision: the CMS archive lacks DME 2025Q2).
# The gap is still listed in 01 (check 1), the 07 build log, v03 and d08.
# True (default) = build with the gap; False = 07 refuses and names the missing quarter.
NCCI_ALLOW_MUE_GAPS = True
# D9: bad NCCI rows (modifier indicator not 0/1/9, missing effective date, non-numeric MUE)
# raise instead of being dropped or patched silently. False = load with a printed warning.
NCCI_STRICT = True
# D9: no medicaid_ncci_edit_* tables -> 07_build_kb stops. True = build state rules only.
NCCI_ALLOW_EMPTY = False
# D10 (VERIFIED 2026-10-02): a PTP edit IS in force on its deletion date. CMS 2026 Medicaid NCCI Technical
# Guidance Manual, App. B p.35: "Deletion date - The last date that an edit is active. Claims with dates
# of service on or before the deletion date and on or after the effective date must be subject to the
# edit." Same for MUEs (App. C p.39). And: "Bypass the edit if the effective date and the deletion date
# are the same" (retroactive deletion) - ingest drops those rows.
NCCI_DELETION_DATE_INCLUSIVE = True

# ------------------------------------------------------------- governance

def _env_flag(name: str, default: str) -> bool:
    return os.environ.get(name, default).strip().lower() not in ("0", "false", "no", "off", "")


# 2026-10-04 (SB, fresh start): the KB holds rules from ONE extraction engine. Hand-authored rules (state_seed.py,
# origin 'manual') are a CHECKLIST of what the engine must find (v05 scores runs against them) - not KB rules:
# False = never exported for review and never compiled, whatever their status. True (env PKB_COMPILE_HAND_AUTHORED=1)
# = exported and compiled once signed, as before 2026-10-04.
COMPILE_HAND_AUTHORED = _env_flag("PKB_COMPILE_HAND_AUTHORED", "0")
# An extracted rule compiles only when the LAST run that produced it (state_rules.extraction_run_id) used one of these
# prompt versions (policy_extraction_log.prompt_version): rules an older engine produced stay out of the KB until the
# current engine produces them again. Empty = any engine (env PKB_KB_PROMPT_VERSIONS, comma-separated; "any" = empty).
# 2026-10-16: v2 and v3 (extract_rules.PROMPT_VERSION): rules decided on v2 drafts keep compiling; v3 runs add to them.
_kbp = os.environ.get("PKB_KB_PROMPT_VERSIONS", "v2,v3").strip()
KB_PROMPT_VERSIONS: tuple = () if _kbp.lower() in ("", "any") else tuple(v.strip() for v in _kbp.split(",") if v.strip())

# ------------------------------------------------------------- detection (08)
# Every detector reads this snapshot, rebuilt at the start of each 08 run from CLAIMS_TABLE:
# codes/modifiers trimmed + upper-cased, exact duplicate rows removed, rows with no member dropped,
# pie_payable / pie_reversal / pie_cancelled / pie_dob added (detector_gen.snapshot_sql). 08 records
# its Delta version per run, so an auditor can re-run any stored query on exactly the data it saw.
DETECT_SNAPSHOT_TABLE = os.environ.get("PKB_DETECT_SNAPSHOT", f"{OUTPUT_CATALOG}.{OUTPUT_SCHEMA}.policy_claims_snapshot")
# Format of date_of_birth when it is a STRING that a plain cast cannot read (e.g. "MM/dd/yyyy").
# None = TRY_CAST(... AS DATE) (a DATE / TIMESTAMP / ISO-string column). 08 prints how many lines have
# no usable date of birth; age rules never match those lines.
DOB_FORMAT = None
# State rules and the claims scope (2026-10-02). False (default): EVERY signed state rule compiles, whether or not its
# code is paid in the claims table - one query per signed rule, a code not paid simply finds nothing, and the KB does
# not lose a signed rule because this month's extract lacks the code. True: only rules touching a paid code (the
# behaviour before 2026-10-02). NCCI is always scoped to paid codes (hundreds of thousands of edits).
STATE_RULES_CLAIMS_SCOPE = False

# Query validation (v06 -> policy_query_validation) and 08 (2026-10-03). A query a validator marked PROBLEM for its
# current SQL never runs. False (default): every other query runs and each finding says whether its query was signed
# OK (`query_validation` = OK / not_validated) - the validator can work through a SAMPLE. True: ONLY queries signed OK
# for their current SQL run (the setting once validation is complete).
RUN_ONLY_VALIDATED_QUERIES = False

# Rolling-window utilization SIGNALS (not findings) for period limits: window length in days.
ROLLING_WINDOW_DAYS = {"month": 30, "year": 365, "benefit_year": 365}
# Keep every build's NCCI edit rows (policy_ncci_*_edits_history) so an old finding can be replayed
# with the exact edit data. Scoped to paid codes, so it grows by roughly one edit table per build.
KEEP_NCCI_EDIT_HISTORY = True

# Logical claim fields a rule may require. The gate downgrades a rule that
# needs anything not listed here to a review lead (reason=missing_claim_field)
# instead of emitting SQL that silently returns nothing.
AVAILABLE_CLAIM_FIELDS = {
    "proc_cd", "member_id", "provider_id", "billing_provider_id", "srvc_bgn_dt",
    "units", "quantity_paid", "mod_1", "mod_2", "mod_3", "mod_4",
    "claim_id", "line_no", "pos_cd", "paid_amt", "paid_ind", "form_type", "pa_no",
    "dob", "member_age", "prov_type", "billing_type",
}

# AHCCCS Form Type codes (AHCCCS Reference Tables, "AHCCCS Form Type", verified 2026-10-02:
# https://www.azahcccs.gov/Resources/Downloads/Solicitations/Open/RFPs/YH24-0001_ALTCSEPD/AHCCCSFormType.pdf):
#   A = CMS 1500 professional and other services   C = Universal Claim Form, prescription drugs (NCPDP)
#   D = ADA dental services                         I = UB-04 inpatient hospital
#   L = UB-04 long-term care facility               O = UB-04 outpatient hospital
# CORRECTION (2026-10-02): this file used to map 'D' to "outpatient" and said 'D' was a facility form.
# 'D' is DENTAL. The claims hold A, C, D, I, L and O (01 form inventory, run of 2026-10-08; an older note said only
# 'A' and 'D'). NCCI applies to A and O only (TGM s5.2).
FORM_TYPE_MAP = {"A": "professional", "C": "pharmacy", "D": "dental", "I": "inpatient",
                 "L": "long_term_care", "O": "outpatient_hospital"}

# Which Medicaid NCCI edit file a claim line takes (2026-10-03). CMS 2026 Medicaid NCCI Technical Guidance Manual
# s6.0 Table 2 decides it by PROVIDER TYPE and CLAIM FORM (e.g. an ambulatory surgical center takes the practitioner
# file even on a UB-04; a DME supplier the DME file); s5.2: never on dental, pharmacy, inpatient or residential claims.
# ncci_routing.py implements the table; AHCCCS provider types are mapped to its rows in
# reference/ncci_provider_type_routing.csv (keyed on the SProv_Type CODE; PROPOSED until signed - v03 shows it).
# Routing (QUERY_SEMANTICS s1a): Table 2 on the BILLING provider type (BProv_Type; CMS: "claims from" a type of
# provider), the servicing type deciding only "rendering practitioner identified"; a GROUP billing type
# (GROUP_BILLING_PROVIDER_TYPES) routes on the SERVICING type's row (D2); a missing / unmapped billing type falls back to
# the servicing type; a line no row decides takes no file. (2026-10-16: the exploratory NCCI_ROUTE_BY "form" /
# "provider_type" and NCCI_UNMAPPED_PROVIDER_TYPE "form" are removed.)
#   NCCI_OPTIONAL_CATEGORIES_ON  Table 2 rows CMS marks OPTIONAL: "testing_facility" (independent labs / testing
#                                 facilities) and "other_outpatient" (clinics incl. FQHC/RHC and BH outpatient
#                                 clinics, home health, dialysis, transport ...). Off until AHCCCS / the boss says
#                                 AHCCCS applies NCCI to them; 01 and 07 report the lines and dollars left out.
#   NCCI_REQUIRE_SIGNED_ROUTING  True (default; D1, 2026-10-14): the NCCI statements always run, and a line takes an
#                                 edit file only when the routing row that DECIDES it is signed (status 'signed' and a
#                                 named reviewer); a line whose deciding row is unsigned takes no file. 01 and 08 list
#                                 those provider types with their lines and dollars. False = a preview on the PROPOSED
#                                 rows (findings carry ncci_routing = 'unsigned' when an observed deciding row is not
#                                 signed). A line no row decides takes no file either way; 01 lists those combinations.
PROV_TYPE_DESC_COL = "SProv_Type_Desc"     # shown next to the code in 01 so a person can check the mapping; never logic
BILLING_TYPE_DESC_COL = "BProv_Type_Desc"  # the same, for the billing type (01 skips it if the column does not exist)
NCCI_PROVIDER_TYPE_TABLE = os.environ.get("PKB_NCCI_PROVIDER_TYPE_TABLE") or os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "reference", "ncci_provider_type_routing.csv")
NCCI_OPTIONAL_CATEGORIES_ON: tuple = ()
NCCI_REQUIRE_SIGNED_ROUTING = (os.environ.get("PKB_NCCI_REQUIRE_SIGNED_ROUTING", "1").strip().lower()
                               not in ("0", "false", "no", "off"))

# ------------------------------------------------------- policy documents
# AHCCCS FFS Provider Billing Manual. URLs verified against
# azahcccs.gov/PlansProviders/RatesAndBilling/FFS/providermanual.html on 2026-09-18.
# The file-name pattern is NOT uniform across chapters, so every URL is explicit.
_FFS = "https://www.azahcccs.gov/PlansProviders/Downloads/FFSProviderManual/"
CHAPTERS = {
    "1":  ("Introduction to AHCCCS",                          _FFS + "FFSChapter1IntroductiontoAHCCCS.pdf"),
    "2":  ("Eligibility",                                     _FFS + "FFSChapter2Eligibility.pdf"),
    "3":  ("Provider Records and Registration",               _FFS + "FFSChapter3ProviderRecordsandRegistration.pdf"),
    "4":  ("General Billing Rules",                           _FFS + "FFS_Chap04GeneralBillingRules.pdf"),
    "5":  ("Billing on the CMS 1500 Claim Form",              _FFS + "FFS_Chap05.pdf"),
    "6":  ("Billing on the UB-04 Claim Form",                 _FFS + "FFS_Chap06.pdf"),
    "7":  ("Billing on the ADA 2012 Claim Form",              _FFS + "FFS_Chap07.pdf"),
    "8":  ("Prior Authorizations",                            _FFS + "FFSChap08PriorAuthorizations.pdf"),
    "9":  ("Medicare/Other Insurance Liability",              _FFS + "FFS_Chap09Medicare.pdf"),
    "10": ("Individual Practitioner Services",                _FFS + "FFS_Chap10.pdf"),
    "10A": ("FQHC/RHC (Chapter 10 Addendum)",                 _FFS + "FFS_Chap_10AddendumFQHC.pdf"),
    "11": ("Hospital Services",                               _FFS + "FFSChap11_HospitalServices.pdf"),
    "11A": ("APR-DRG Payment Policies (Chapter 11 Addendum)", _FFS + "FFS_Chap11_Addendum.pdf"),
    "12": ("Pharmacy Services",                               _FFS + "FFS_Chap12Pharmacy.pdf"),
    "13": ("DME, Orthotics, Prosthetics, Medical Supplies",   _FFS + "FFS_Chap13DME.pdf"),
    "14": ("Transportation Services",                         _FFS + "FFS_Chap14Transportation.pdf"),
    "15": ("Dialysis Services",                               _FFS + "FFS_Chap15Dialysis.pdf"),
    "16": ("Free-Standing Ambulatory Surgery Centers",        _FFS + "FFS_Chap16AmbulatorySurgeryCenters.pdf"),
    "17": ("Free Standing Birthing Centers",                  _FFS + "FFS_Chap17BirthingCenters.pdf"),
    "18": ("Federal Emergency Services Program",              _FFS + "FFS_Chap18EmergencyServicesProgram.pdf"),
    "19": ("Behavioral Health Services",                      _FFS + "FFS_Chap19BehavioralHealth.pdf"),
    "20": ("Home Health Care Services",                       _FFS + "FFS_Chap20HomeHealthCare.pdf"),
    "21": ("ALTCS Services",                                  _FFS + "FFS_Chap21ALTCS.pdf"),
    "22": ("Nursing Facility Services",                       _FFS + "FFS_Chap22NursingFacility.pdf"),
    "23": ("Hospice Services",                                _FFS + "FFS_Chap23Hospice.pdf"),
    "24": ("Transplants",                                     _FFS + "FFS_Chap24Transplants.pdf"),
    "25": ("Claims Processing",                               _FFS + "FFS_Chap25ClaimsProcessing.pdf"),
    "26": ("Correcting Claim Errors",                         _FFS + "FFS_Chap26ClaimErrors.pdf"),
    "27": ("Understanding the Remittance Advice",             _FFS + "FFS_Chap27RemittanceAdvice.pdf"),
    "28": ("Claim Disputes",                                  _FFS + "FFS_Chap28ClaimDisputes.pdf"),
    "29": ("Housing and Health Opportunities (H2O) Services", _FFS + "FFS_Chap29H2OServices.pdf"),
    # 2026-10-04 (external review): "the manual consists of the following chapters with their associated exhibits".
    # The exhibits that state billing content (what a per diem or a visit already includes; outlier exclusions) are
    # part of the corpus; forms, directories and sample remittance advices (1-3, 1-4, 10-1, 11-4, 12-1, 14-x, 21-x,
    # 27-x) state no billing rule. URLs from providermanual.html, 2026-10-04.
    "11-2": ("Exhibit 11-2: FFS Outlier Exclusion List",       _FFS + "Exhibit11-2.pdf"),
    "20-1": ("Exhibit 20-1: Medical Supplies Included in FFS Home Health Nursing Visits", _FFS + "Exh20-1.pdf"),
    "20-2": ("Exhibit 20-2: Home Health Skilled Nursing Services", _FFS + "Exh20-2.pdf"),
    "22-1": ("Exhibit 22-1: DME Included in the Nursing Facility and ICF FFS Per Diem Rate", _FFS + "Exh22-1.pdf"),
    "22-2": ("Exhibit 22-2: Medical Supplies Included in the Nursing Facility FFS Per Diem Rate", _FFS + "Exh22-2.pdf"),
}
# Rule sources IN SCOPE but NOT YET LOADED (2026-10-04). AHCCCS publishes them as structured tables on
# https://azahcccs.gov/PlansProviders/MedicalCodingResources.html - rule DATA (like the NCCI files), to be loaded by a
# deterministic table loader, not read by the model. Until they are, the corpus is "the FFS Provider Billing Manual
# chapters and exhibits above", never "AHCCCS policy" (v03 lists them as NOT YET).
_MCR = "https://azahcccs.gov/PlansProviders/Downloads/MedicalCodingResources/"
CORPUS_PENDING = {
    "same_day_disallow": ("AHCCCS Same Day Disallow Table (updated 10/01/2026): per diem, single day, counseling, "
                          "treatment and assessment code combinations", _MCR + "SameDayDisallowTable.xlsx"),
    "daily_limits":      ("HCPCS - CPT Procedures Daily Limits Guidelines (updated 09/15/2026)",
                          _MCR + "HCPCSCPTProcedureswithDailyLimits.xlsx"),
    "b2_matrix":         ("B2 Matrix - Behavioral Health Services Matrix (updated 10/01/2026): codes x provider types",
                          _MCR + "B2Matrix.xlsx"),
    "pa_guidelines":     ("FFS Prior Authorization Guidelines (updated 07/10/2026)",
                          _MCR + "FFSPriorAuthorizationGuidelines.xlsx"),
    "opfs_modifiers":    ("OPFS Allowed Modifiers Extract (updated 07/16/2026)", _MCR + "RF121Extract.xlsx"),
    "cbhsg":             ("AHCCCS Covered Behavioral Health Services Guide (updated 09/30/2026)",
                          _MCR + "AHCCCSCoveredBHServicesManual.pdf"),
    "ncci_rissnet":      ("Medicaid NCCI edit files from CMS's secure RISSNET portal - CMS 2026 TGM: states 'cannot "
                          "use the publicly available files for processing and paying Medicaid claims' (this KB loads "
                          "the public files: NCCI findings are leads until these replace them)", None),
}
# Rule-dense chapters for the MVP. Chapters 1-3, 5-9, 25-28 are process/eligibility
# text and yield few billing rules; run them once the pipeline is trusted.
MVP_CHAPTERS = ["4", "10", "13", "14", "19", "22"]

# ---- where files live: next to this package, wherever it was uploaded -------------------
# No guessed paths. PACKAGE_DIR is the folder that holds config.py (e.g.
# /Workspace/Users/<you>/Projects/policy_intelligence when the zip is unpacked there), and
# every file this pipeline writes goes under PACKAGE_DIR/data. Workspace files are readable
# and writable from Serverless GPU (hf_token.txt lives in one); Unity Catalog Volumes and
# Delta tables are not reliably reachable from it, which is why the pipeline is split into
# GPU-writes-files / CPU-writes-tables (mirrors llm_summarization).
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
# SB's package folder (confirmed 2026-09-21). Falls back to <wherever config.py is>/data if it
# is ever run from a copy elsewhere.
_SB_PROJECT = "/Workspace/Users/sedo.senou@azahcccs.gov/Projects/policy_intelligence"
WORKSPACE_DATA_DIR = os.environ.get(
    "PKB_WORKSPACE_DATA_DIR",
    f"{_SB_PROJECT}/data" if os.path.isdir(_SB_PROJECT) else os.path.join(PACKAGE_DIR, "data"))
STAGE_DIR = f"{WORKSPACE_DATA_DIR}"                 # 03_stage_inputs writes policy_docs/ and snapshots/ here
STAGE_PDF_DIR = f"{WORKSPACE_DATA_DIR}/policy_docs"  # PDFs the GPU notebook reads (download=False)
RUN_ROOT = f"{WORKSPACE_DATA_DIR}/extraction_runs"  # 04_extract_chapters_gpu writes <run_id>/ here

# PDF_DIR is where policy_docs.acquire() puts/reads PDFs by default. It is the staged
# Workspace folder above - NOT a Unity Catalog Volume. Set PKB_PDF_DIR only if you
# deliberately want a Volume (e.g. /Volumes/<catalog>/<schema>/<volume>); nothing in the
# pipeline creates a Volume any more.
PDF_DIR = os.environ.get("PKB_PDF_DIR", STAGE_PDF_DIR)

# NCCI acquisition (acquire_ncci.py / notebooks/acquire_ncci). Raw CMS zips are archived
# here forever, one folder per quarter (<YYYY>q<N>/). CMS lists only the current and previous
# quarter, so this archive is the only history. With no internet egress, drop the zips here by
# hand and run the notebook with DOWNLOAD = False - everything after the download is automatic.
NCCI_RAW_DIR = os.environ.get("PKB_NCCI_RAW_DIR", f"{WORKSPACE_DATA_DIR}/ncci_raw")
NCCI_ACQUISITION_LOG = f"{CATALOG}.{SCHEMA}.ncci_acquisition_log"

# ------------------------------------------------------- AHCCCS rule tables (v5.2, 2026-10-04)
# AHCCCS publishes some billing rules as DATA on its Medical Coding Resources page. They are loaded the way the NCCI
# files are - by a deterministic reader (ahcccs_tables.py, notebooks/00b_load_ahcccs_tables), never by the model - and
# every rule cites the file, sheet and cell it comes from. Drop each downloaded xlsx in AHCCCS_TABLES_DIR (any name; the
# reader recognises the layout) and run 00b; every file is a VERSION, judging claims from its own date until the next
# version's date (SB 2026-10-04: older claims are judged only by the version in force then - load AHCCCS's earlier
# versions to judge them). SB's readings, 2026-10-04 (reference/ahcccs_table_readings.csv; signed by a reviewer before
# anything compiles while AHCCCS_TABLES_REQUIRE_SIGNED_READINGS is on):
#   Same Day Disallow   D  = the two codes may not be billed for the same member on the same date of service, by any
#                            provider; A* = not by the same provider (AHCCCS_SAME_PROVIDER_SCOPE); A = allowed. The ROW
#                            code's line is the finding, the per-diem / once-a-day COLUMN code's line is its evidence.
#   Daily limits        "Procedure Maximum Occurrence" = the most UNITS of the code for one member from one provider
#                            on one date of service (AHCCCS_DAILY_LIMIT_SCOPE); anesthesia and all-nines maxima are
#                            recorded only (below). The weekly / monthly / yearly / lifetime limits in the same file are
#                            recorded, not compiled yet.
#   B2 Matrix           for a behavioral-health-only code (AHCCCS_B2_COMPILE_CODES: HCPCS H0xxx / H2xxx) the matrix's
#                            provider types are the complete list of provider types that may bill it - a group billing
#                            (type 01) is judged on the rendering provider's type (AHCCCS_B2_PROVIDER_ROLE); its other
#                            codes (CPT, S, T, A, J, G - also billed outside behavioral health), places of service and
#                            modifiers are recorded for reference and conflict checks, not compiled.
AHCCCS_TABLES_DIR = os.environ.get("PKB_AHCCCS_TABLES_DIR", f"{WORKSPACE_DATA_DIR}/ahcccs_tables")
AHCCCS_TABLES = {
    "same_day_disallow": {"title": "AHCCCS Same Day Disallow Table", "url": _MCR + "SameDayDisallowTable.xlsx",
                          "table": f"{CATALOG}.{SCHEMA}.ahcccs_same_day_disallow"},
    "daily_limits":      {"title": "AHCCCS HCPCS CPT Procedures with Daily Limits",
                          "url": _MCR + "HCPCSCPTProcedureswithDailyLimits.xlsx",
                          "table": f"{CATALOG}.{SCHEMA}.ahcccs_daily_limits"},
    "b2_matrix":         {"title": "AHCCCS Behavioral Health Services Matrix (B2 Matrix)", "url": _MCR + "B2Matrix.xlsx",
                          "table": f"{CATALOG}.{SCHEMA}.ahcccs_b2_matrix"},
}
AHCCCS_TABLES_LOG = f"{CATALOG}.{SCHEMA}.ahcccs_table_log"
AHCCCS_TABLE_READINGS = os.environ.get("PKB_AHCCCS_TABLE_READINGS") or os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "reference", "ahcccs_table_readings.csv")
# 2026-10-18 (v6.2): the 852-rule manual inventory (sheet 'rules'), read by v05 as UNREVIEWED recall gold (a measure,
# never the gate). One reading of the 36 chapters made 2026-10-15; it ships with the package so v05 needs no upload.
MANUAL_RULE_INVENTORY = os.environ.get("PKB_MANUAL_RULE_INVENTORY") or os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "reference", "manual_rule_inventory_2026-10-15.xlsx")
AHCCCS_TABLES_REQUIRE_SIGNED_READINGS = (os.environ.get("PKB_AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", "1").strip().lower()
                                         not in ("0", "false", "no", "off"))
AHCCCS_B2_COMPILE_CODES = r"^H[02][0-9]{3}$"         # behavioral-health-only HCPCS codes
# 2026-10-04 (v5.2, independent critic, verified; each a reading SB signs - reference/ahcccs_table_readings.csv binds
# the values below, so a change here un-signs the reading until it is signed again):
# "Same provider" (A* pairs and daily limits). The A* legend says "cannot be provided/billed by the same provider
# (service site or residential placement)", and AHCCCS corrected its own A* programming on 2/27/2026 (memo 3/16/2026,
# DisallowTableSummary.pdf) without publishing the rule. Until SB settles servicing clinician vs service site, "same
# provider" = the same SERVICING and the same BILLING provider id ("member_servicing_billing_day"): a finding then
# breaks the rule under either reading (never a false finding from the choice; some misses). "member_provider_day" =
# the servicing id only; "member_day" = any provider.
AHCCCS_SAME_PROVIDER_SCOPE = "member_servicing_billing_day"
AHCCCS_DAILY_LIMIT_SCOPE = "member_servicing_billing_day"    # SB 2026-10-04 "member + provider + day", provider as above
# B2: the matrix lists rendering practitioner types (85 LCSW, 86, 87 ...) and no group: a GROUP (provider type 01,
# "Group-Payment ID" - in all_data_C_A only as the billing type) billing a code is judged on the line's RENDERING
# (servicing) type; every other biller on its own type. A line whose judged type is missing is never a finding.
AHCCCS_B2_PROVIDER_ROLE = "billing_or_rendering"
GROUP_BILLING_PROVIDER_TYPES = ("01",)
# Daily limits NOT compiled (recorded; listed for SB in policy_ahcccs_conflicts):
#   anesthesia CPT 00100-01999: AHCCCS bills anesthesia in 15-minute TIME units (FFS Ch10: "Every 15 minutes or any
#   portion thereof is equal to one unit of time for anesthesia services"), yet 272 of the 274 anesthesia codes in the
#   9/14/26 file have a maximum of 1 or 2 - the maximum cannot be units there;
#   an all-nines maximum (999 on 113 codes, 999999 on one): a placeholder for "no practical limit" (per-IU clotting
#   factors, per-mile transport), not a limit to enforce.
AHCCCS_DAILY_RECORD_ONLY_CODES = r"^0[01][0-9]{3}$"
AHCCCS_DAILY_PLACEHOLDER_MAX = r"^9{3,}$"
# A version stays in force until the next one is loaded; past this many days after its date, 01 / 07 warn that claims
# are judged by a table AHCCCS has probably replaced (B2 is published monthly, the daily limits report is a run date).
AHCCCS_TABLE_MAX_AGE_DAYS = {"same_day_disallow": 366, "daily_limits": 62, "b2_matrix": 62}
# Daily caps (state rules, every origin; QUERY_SEMANTICS v2.6): a group whose units are over the cap only because ONE
# line alone is over it may be a multi-day line (the claims table has no service end date) -> verify_span; a group
# with a line carrying one of these modifiers (bilateral / anatomic / repeat / distinct) -> verify_modifier.
DAILY_CAP_VERIFY_MODIFIERS = ("50", "RT", "LT", "E1", "E2", "E3", "E4", "FA", "F1", "F2", "F3", "F4", "F5", "F6",
                              "F7", "F8", "F9", "TA", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "LC", "LD",
                              "RC", "LM", "RI", "76", "77", "91", "59", "XE", "XS", "XP", "XU")

# ------------------------------------------------------------- extraction
# STUB   : deterministic pattern extractor - runs the whole pipeline with no model
#          (tests, smoke runs, and a high-precision floor for known rule shapes).
# HFLOCAL: openai/gpt-oss-120b loaded with transformers ON THE CLUSTER (Serverless GPU),
#          prompts via the tokenizer chat template with reasoning_effort, output parsed
#          with openai-harmony (final channel only). This mirrors SB's working
#          llm_summarization_v3 notebook exactly and is the production path.
# HYBRID : patterns AND the model together, unioned; rules both find are corroborated.
#          Refuses to run without the model unless ALLOW_PATTERNS_ONLY is set.
LLM_BACKEND = os.environ.get("PKB_LLM", "STUB")
HYBRID_MODEL_BACKEND = os.environ.get("PKB_HYBRID_MODEL", "HFLOCAL")

# ---- HFLOCAL (mirrors llm_summarization_v3) ----
HF_MODEL = os.environ.get("PKB_HF_MODEL", "openai/gpt-oss-120b")
# Hugging Face token file, same as the summarization notebook. None = assume already logged in.
HF_TOKEN_PATH = os.environ.get(
    "PKB_HF_TOKEN_PATH",
    "/Workspace/Users/sedo.senou@azahcccs.gov/Projects/all_projects_predictions/data/hf_token.txt")
# gpt-oss reasoning effort. Extraction is a READING task: "low" is the default; raise to
# "medium" only if a real run shows rules being missed on dense sections.
LLM_REASONING = os.environ.get("PKB_REASONING", "low")
# max_new_tokens by reasoning level. The output is JSON that grows with the number of rules
# in a section, PLUS the analysis channel, so these are larger than a summarizer's budgets.
# A truncated answer with no final channel is retried once at RETRY_BUDGET_FACTOR x.
REASONING_TOKEN_BUDGET = {"low": 3000, "medium": 4500, "high": 7000}
RETRY_BUDGET_FACTOR = 1.8
# 2026-10-20 (SB's ch19 reruns): a piece that cannot be split further and still runs out (one sentence listing 21
# partner codes: each pair repeats the sentence as its quote) gets ONE last call at this multiple of the first budget
# (low 12,000, medium 18,000 tokens). Decoding is greedy, so a larger budget only lets the same answer finish; only
# such pieces pay for it. The cache key is unchanged (an answer that completed is the same answer).
LAST_RESORT_BUDGET_FACTOR = 4.0
# Persist the model-output cache to Delta every N model calls so a crash mid-run loses
# at most N calls (SB's FLUSH_EVERY pattern). Drafts are re-derived from cache for free.
CACHE_FLUSH_EVERY = 25
# deterministic post-extraction checks (post_checks.py) after grounding; False only to measure them
POST_CHECKS = True
