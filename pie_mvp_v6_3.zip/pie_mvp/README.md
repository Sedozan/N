# PIE: Policy Intelligence Engine (MVP package)

Turns AHCCCS billing policy into checks you can run: federal NCCI edits, the AHCCCS FFS Provider Billing Manual (its
chapters and rule-bearing exhibits) and three AHCCCS rule tables become one cited, versioned, reviewed rule table
(`policy_rules`). That table compiles to SQL, the SQL runs over paid claims, and every finding traces back to the policy
text, the document version and the person who approved the rule.

**Scope, in words you can repeat.** State rules come from the 36 documents in `config.CHAPTERS` (identified by the
`corpus_version` in the build log) and from the Same Day Disallow Table, the HCPCS/CPT daily limits and the B2
behavioral-health matrix, read cell by cell (`00b`; each loaded file is a dated version; a table's rules compile only
when every reading of it is signed). Not loaded yet (`config.CORPUS_PENDING`): the PA guidelines, the OPFS modifier list,
the CBHSG and the RISSNET state NCCI files. Say "rules extracted from the configured FFS manual corpus (corpus_version
...) and the AHCCCS rule tables loaded (versions ...)", not "the AHCCCS policy rules". The NCCI rules in a build are the
CMS edits executable against this claims population (both codes paid).

**How far to trust it today.** The SQL is tested against a written contract (`docs/QUERY_SEMANTICS.md`) by two
independent oracles and by mutation testing: the queries do what the rules say. Whether the rules say what the policy
says, and whether a rule was missed, is measured by people (v01, v05, v07; v03 sums it up). Until v03 shows GO, use the
engine as a controlled rule-discovery and review workbench, not as a validated, complete extraction of AHCCCS policy.

The model only **proposes** state rules. Deterministic grounding checks each proposal against the PDF, a named reviewer
signs it, and only signed rules compile. No model sits in the detection path.

---

## Run order

Copy the whole `pie_mvp` folder into `.../Projects/policy_intelligence/` (overwrite), then import the notebooks keeping
the folder structure. All notebooks find the package on their own (`PKB_PACKAGE_DIR` only if you move them).

| # | notebook | compute | when | what it does | writes |
|---|---|---|---|---|---|
| 00 | `00_acquire_ncci` | CPU + UC | quarterly | finds the six CMS Medicaid NCCI zips, archives, parses, validates, loads one table per file (no egress: drop the zips in `data/ncci_raw/`, `DOWNLOAD = False`); `ARCHIVE = True` also loads every MUE quarter of CMS's MUE archive from the claims' first date of service (`HISTORY_FROM` to start elsewhere) | `main.sedo.medicaid_ncci_edit_*`, `ncci_acquisition_log` |
| 00b | `00b_load_ahcccs_tables` | CPU + UC | when AHCCCS publishes a table | reads the Same Day Disallow, daily-limits and B2 workbooks from `data/ahcccs_tables/` (recognised by layout); each file is a version dated by its own "Updated / As of" date; refuses what it cannot read exactly; never replaces a loaded version | `main.sedo.ahcccs_*`, `ahcccs_table_log` |
| 01 | `01_preflight_ncci` | CPU + UC | after 00 | read-only checks: NCCI quarters and gaps, which edit file each provider type's lines take, data shape (reversals, $0 lines, PA fill rate), the AHCCCS table versions and the dates each judges. "GO" there means safe to build, not that NCCI will run | none |
| 02 | `02_migrate_state_rules` | CPU + UC | once | upserts the 59 hand-authored rules: a checklist v05 scores extraction runs against, never reviewed or compiled | `main.sedo.state_rules` |
| 03 | `03_stage_inputs` | CPU + UC | each extraction cycle | copies the 36 PDFs and table snapshots into workspace files for the GPU step | `data/policy_docs/`, `data/snapshots/` |
| 04 | `04_extract_chapters_gpu` | Serverless GPU | each extraction cycle | gpt-oss-120b (prompt v3) and the pattern layer propose rules; grounding and post-checks keep or refuse each one. Files only | `data/extraction_runs/<run_id>/` |
| 05 | `05_persist_extraction` | CPU + UC | after 04 | merges drafts into `state_rules`, appends the run's telemetry and every draft it produced, exports the review workbook | `state_rules`, `policy_extraction_*`, `policy_sections`, `policy_document_inventory`, `data/review/policy_rules_review.xlsx` |
| (review) | Excel | | after 05 | the reviewer fills `decision` (Approve / Reject / Fix), `reviewer`, `review_note` | |
| 06 | `06_review_decisions` | CPU + UC | after review | applies signed decisions to pending rows; a decided row changes only with `reopen = yes` and a name | `state_rules`, `policy_review_log` |
| 07 | `07_build_kb` | CPU + UC | after 00, 00b or 06 | the NCCI master table (every edit of every file and window, not scoped); gate; a state pair a Same Day version allows is executable up to the day before that version (D3, only once the Same Day readings are signed); normalise, compile; every query stored with its sha256; AHCCCS table rules (only when every reading is signed); coverage per code; the registers; `build_id` + history | `policy_ncci_edits_master`, `policy_rules`, `policy_detectors`, edit tables, `policy_ahcccs_conflicts`, coverage, registers, `*_history`, `policy_build_log` |
| v06 | `validation/v06_query_validation_pack` | CPU + UC | after 07 | every query in plain English with its SQL and must / must-not-flag scenarios; a validator signs OK / PROBLEM per query, bound to the SQL's sha256 | `policy_query_validation(_tests)` |
| 08 | `08_run_detectors` | CPU + UC | after 07 (and v06) | checks the build and every hash; builds the snapshot; NCCI as two table-driven statements on the lines whose deciding routing row is signed (D1); the AHCCCS tables as three; state rules one statement each; rolling-window signals; never runs a query marked PROBLEM | `policy_findings`, `policy_detector_runs`, `policy_utilization_signals` |

**When AHCCCS revises a chapter:** 03, 04, 05. Approved rules from the old PDF drop to `needs_review` with their
`prior_review` kept, and 07 excludes them until someone re-signs them against the new text. The old PDF is kept in
`data/policy_docs/_versions/`.

## Decisions taken in the 2026-10-14 pass

After SB's real run (build `B20261008T231304`, detector run `20261008T233521`, claims 2024-10-01 to 2026-09-25), in
which NCCI never ran and every finding came from 45 state rules:

| | decision |
|---|---|
| D1 | NCCI is gated per provider type, not all or nothing: a line takes an NCCI edit file only when the routing row that decides it is signed; lines whose deciding row is unsigned take no file, and 01 / 08 report their lines and dollars |
| D2 | A group-billed line (billing type in `config.GROUP_BILLING_PROVIDER_TYPES`, `01`) is routed on its servicing (rendering) type; a group line with no usable servicing type takes no file |
| D3 | When an AHCCCS table version allows (A) a pair a chapter rule forbids, the chapter rule stays executable up to the day before that version's date, labelled; it is not turned into a lead for all dates. Round 4: only while the Same Day readings are signed; until then the chapter rule is left as signed and the overlap is listed in the contradiction register (`table_allows_unsigned_reading`) |
| D4 | "X shall / may / cannot / must not be billed with A, B, C" pairs X with each listed code (X's line is the finding), never two listed codes with each other; a token that is not a valid code (e.g. "S109") is reported to the reviewer, never rewritten |
| D5 | Missed rules are fixed in the extractor (pattern layer and prompt), not entered by hand |
| D6 | Coverage = paid dollars dated inside the window of a compiled rule that RAN in the latest detector run, also shown over procedure-coded lines only |

**Facts about the claims (2026-10-08 run).** 17,484,880 lines, 285,894 members, forms A, C, D, I, L and O (not A and D
only): C/02 hospital 1.5M lines ($569M), I/02 $544M, L/22 nursing home $134M. 4,488,912 lines (25.67%) have no
PROC_CD; 1,587,063 (9.08%) have PMT_AMT <= 0. MUE history starts 2026-04-01 (DME 2026-07-01), so earlier lines get no
MUE check until older quarters are loaded.

**Next:** run 00 with `ARCHIVE = True` (MUE quarters from the claims start); sign the routing rows for the provider
types in the claims (01 lists them, with lines and dollars) and the AHCCCS table readings; load AHCCCS's earlier table versions; re-extract with the fixed pattern layer (03, 04, 05), review,
06, 07, v06, 08; then score: v01 with `STATUSES = ["approved"]` (every compiled rule), v01 with `STATUSES = None`
(recall, fidelity), v02 (findings), v07 (pages).

**The first real v3 extraction (v6.2; v6.3 = v6.2 + the fixes from the chapter 19 runs, same prompt).** The prompt is
frozen for it (a test pins its text). Chapter 19 A/B (2026-10-20): medium chosen. `REUSE_ANSWERS_FROM` in 04 reuses earlier runs' answers (same settings only): list the
earlier run ids to rerun only failed sections or to resume a stopped run.
1. 03; then 04 twice on chapters 19 and 10 only (`CHAPTERS_TO_RUN`): once with `REASONING = "low"`, once with
   `"medium"`.
2. v05 with `RUN_ID` = the low run and `RUN_DIR_B` = the medium run. Keep the level whose `inventory_recall` is higher
   for the kinds that matter (pairs, caps, provider types, modifiers) with DANGER 0; medium only if the gain is real
   (several points, not one), since it costs more GPU time.
3. 04 on all chapters at that level (v6.3: `REASONING = "medium"`, `REUSE_ANSWERS_FROM = ["20261020T181133"]`), 05,
   review, 06, then v05 and v01 (v01's human-scored sample is the recall to
   report; the inventory is one unreviewed reading).
4. Fix by where `inventory_missed` says a rule was lost: `prefilter` in `policy_docs.rule_signal`, `not_located` in
   the PDF reader (check the page in v07), `dropped` in grounding or `post_checks` (`drop_reason`), `extractor` in the
   prompt or the pattern layer, and only after this run is scored (then bump the prompt version).

---

## Demos and validation (`notebooks/demos`, `notebooks/validation`)

Read-only unless noted. Each opens with *What this answers / How to read it / Limits*.

| notebook | answers |
|---|---|
| `d01_code_lookup` | everything that governs one procedure code: federal edits, state rules with quotes, leads, overlaps, exposure, findings; says "No governing authority found" when that is the answer |
| `d02_finding_explainer` | the audit trail of one finding: claim lines, the rule as it was in that build, the policy words, the approver, PA status |
| `d03_provider_review` | providers by distinct flagged dollars, the rules behind them, flag rate against peers billing the same codes |
| `d04_coverage_gap` | share of paid dollars dated inside a compiled rule's window (federal / state / none); biggest unchecked dollars |
| `d05_ambiguity_register` | unclear or unenforceable policy, by category, with quotes; exports an xlsx for AHCCCS |
| `d06_federal_state_overlaps` | where CMS and AHCCCS rules cover the same code, who is stricter, contradiction candidates |
| `d07_policy_change_impact` | document versions, change events, rules waiting for re-sign, stale approvals |
| `d08_ncci_federal_edits` | NCCI quarters loaded or missing, edition disagreements, top-firing edits |
| `d09_policy_text_search` | keyword search over the manual's sections with page references |
| `v01_extraction_scoring` | exports a workbook to score, then ingests it. `STATUSES = None`: a stratified sample of the latest run's own drafts (rejected ones included) for precision, fidelity, recall (real rules found / (found + missed)) and filter loss, with 95% intervals; each number carries its population, `corpus_version` and `sample_runs`. `STATUSES = ["approved"]`: every approved rule (a census) for the precision pass mark |
| `v02_detector_precision` | exports a findings sample; after investigator dispositions, precision per rule type |
| `v03_pipeline_health` | the measurement bar, GO / NOT YET per item. Executable-rule precision 1.0 during the pilot: every state rule that compiles scored real AND faithful (a census), and every one explained (in the latest review, or decided earlier and not reproduced; no near-duplicate pair; no sentence with two approved readings from different runs unless the later decision's review_note starts with `keep both` - readings of one run are decided together and never listed); recall >= 0.90 and fidelity >= 0.95 on the lower 95% bound; coverage of the rules that ran; contradictions of every kind; sign-off, routing, corpus. Nothing says GO without a number |
| `v04_chapter_profile` | what the current grammar can see per chapter (code families, rule cues) |
| `v05_extraction_regression` | an extraction run against the reviewed answers: recall, exact match, DANGER (a rule that would compile but should not). Gate: DANGER = 0 and no unadjudicated executable draft; `RUN_DIR_B` compares two runs. Also each run against the shipped 852-rule inventory (unreviewed, never the gate): recall per kind, with and without the rules the prompt's examples come from, and one row per missed rule saying where it was lost (`dropped`, `prefilter`, `failed`, `extractor`, `not_located`) |
| `v06_query_validation_pack` | see the run order |
| `v07_page_fidelity` | what a person sees on a PDF page against what reaches the extractor; a page-fidelity rate on a scored sample |

---

## Package

```
config.py              every table name, claims column, switch and path
reference/             ncci_provider_type_routing.csv (provider type code -> CMS Table 2 row; sign it),
                       ahcccs_table_readings.csv (how each AHCCCS table is read; sign it)
schema.py              Rule + closed predicate grammar + content-derived ids (NCCI- / EXT- / MAN- / TBL-)
acquire_ncci.py        CMS page -> archived zips -> validated quarter tables
ingest_ncci_tables.py  NCCI tables -> rules
ncci_routing.py        which NCCI edit file a line takes (provider type x claim form), Python + SQL twins
ahcccs_tables.py       the AHCCCS rule tables: reader, versions, readings gate, rules, conflicts with state rules
policy_docs.py         PDF -> sections; corpus_version
extract_rules.py       sections -> proposals (STUB patterns / HFLOCAL model / HYBRID both) -> grounding -> drafts
post_checks.py         deterministic checks after grounding
extract_io.py          GPU <-> CPU hand-off files
state_rules.py         the reviewed rule table: merge, re-sign on a new document version, review workbook
state_seed.py          59 hand-authored rules with verbatim quotes (a v05 checklist, never compiled)
regress.py             extraction regression against the reviewed answers (v05)
validate_gate.py       gate: clean / patched / downgraded / needs_review / rejected
rule_normalize.py      stable ids, planes, NCCI edition collapse, state duplicate collapse
detector_gen.py        rules -> SQL; the detection snapshot; table-driven NCCI and AHCCCS statements; signals
query_pack.py          the query validation pack (v06)
run_guard.py           what 08 checks before it runs anything
preflight_sql.py       the read-only checks of 01
gap.py                 coverage per code and claim form
registers.py           ambiguity register; federal/state overlaps
quality.py             sampling, intervals, extraction and detector metrics, v03's verdicts
page_fidelity.py       v07's page checks; chapter_profile.py: v04
policy_changes.py      what changed between document versions
kb_io.py               pandas -> Delta with explicit types
tests/                 offline tests; Spark 4 SQL tests; two independent oracles; e2e_local_spark.py runs every notebook
docs/                  QUERY_SEMANTICS.md (the contract every query meets); V5_CHANGES.md (v5 to v5.2 and upgrade notes)
```

## Tables (`main.policy_kb` unless noted)

| table | one row per |
|---|---|
| `main.sedo.state_rules` | state rule, hand-authored or extracted, with `review_status`, `prior_review`, `extraction_source` |
| `main.sedo.medicaid_ncci_edit_*`, `ncci_acquisition_log` | CMS edit row per quarter; acquisition event |
| `policy_ncci_edits_master` | every NCCI edit of every loaded edit file and window, not scoped to the claims, with its status (in force, deleted, refused) |
| `main.sedo.ahcccs_same_day_disallow`, `ahcccs_daily_limits`, `ahcccs_b2_matrix`, `ahcccs_table_log` | table cell / row per version; load event (row count, rows hash) |
| `policy_document_inventory`, `policy_sections` | document x fetch (doc_hash, revision date); section |
| `policy_extraction_outcomes` | section x run: `skipped_prefilter` / `no_rules` / `proposals` / `failed_retryable` (the recall ledger) |
| `policy_extraction_log`, `_drafts`, `_dropped`, `_cache`, `policy_change_log` | run telemetry, every draft a run produced, refused proposals, model cache, change events |
| `policy_review_log` | reviewer decision, the doc_hash it was made against, whether it was applied |
| `policy_rules`, `policy_rules_history` | rule in the current build / every build (`build_id`, reviewer, quote, jurisdiction) |
| `policy_detectors`, `_history`, `policy_batch_detectors` | rule -> SQL or lead reason; the batch statements |
| `policy_ncci_ptp_edits`, `policy_ncci_mue_limits`, `policy_ahcccs_pair_edits`, `policy_ahcccs_daily_limits`, `policy_ahcccs_provider_types` | edits as data for the batch statements |
| `policy_ahcccs_conflicts` | the contradiction register: an AHCCCS table against a state rule or itself, a state rule against a federal edit, a lead that conflicts with another source (both sources quoted, the dates both apply to, a suggested resolution); plus the table rows recorded but not compiled (`not_compiled_*`) |
| `policy_coverage`, `policy_coverage_summary`, `policy_gap` | paid code x form x edit file (lines with a procedure code), with the dollars inside a rule's window; shares; dollars no state rule judges |
| `policy_ambiguity_register`, `policy_rule_overlaps` | unclear policy entry; federal/state rule pair on a code |
| `policy_build_log` | build: counts, stale approvals excluded, register sizes, NCCI quarters and history gaps, corpus_version |
| `policy_claims_snapshot` | the normalised claims every query reads, rebuilt by 08 (Delta version logged per run) |
| `policy_findings`, `policy_detector_runs` | flagged line or member-day; statement run (`sql_sha256`, `skipped`, `error`; the `RUN:snapshot` row: the run's numbers, the coverage of what ran `pct_paid_ran_*`) |
| `policy_utilization_signals` | member over a period limit inside a rolling window (a signal, never a finding) |
| `policy_query_validation`, `_tests` | validator decision per query (bound to the SQL's sha256); scenario results |
| `policy_quality_metrics`, `policy_extraction_scores`, `policy_finding_reviews` | measured numbers (with `population`, `corpus_version`, `sample_runs`, `unscored`) and the raw scores behind them |

A finding reaches its rule text with `policy_findings JOIN policy_rules_history USING (build_id, rule_id)`. One claim
line can be flagged by more than one rule, so count distinct `(claim_id, line_no)` when adding up dollars.

## Decisions that are yours (config.py)

| switch | default | meaning |
|---|---|---|
| `NCCI_REQUIRE_SIGNED_ROUTING` | `True` | each line takes the edit file CMS Table 2 gives its billing provider type (BProv_Type) and claim form; a group (01) line is routed on its servicing type (D2); a missing or unmapped billing type falls back to the servicing type; a line no row decides takes no file (never routed by claim form). `True`: only when the routing row that decides it is signed (D1). `False` (env `PKB_NCCI_REQUIRE_SIGNED_ROUTING=0`) = a preview on the proposed rows, stamped unsigned |
| `NCCI_OPTIONAL_CATEGORIES_ON` | `()` | CMS's optional Table 2 rows (`"testing_facility"`, `"other_outpatient"`: FQHCs, clinics, BH outpatient). Off = their lines take no NCCI file |
| `NCCI_PROVIDER_TYPE_TABLE` | `reference/ncci_provider_type_routing.csv` | the routing table (env `PKB_NCCI_PROVIDER_TYPE_TABLE`) |
| `LLM_REASONING` | `"low"` | the model's reasoning effort (env `PKB_REASONING`); part of the answer-cache key |
| `RUN_ONLY_VALIDATED_QUERIES` | `False` | `True` = 08 runs only queries signed OK; a PROBLEM never runs either way |
| `STATE_RULES_CLAIMS_SCOPE` | `False` | every signed state rule compiles, paid in this extract or not |
| `COMPILE_HAND_AUTHORED` | `False` | hand-authored rules are a v05 checklist: not exported for review, never compiled (`True`: exported, and compiled once signed) |
| `KB_PROMPT_VERSIONS` | `("v2", "v3")` | one engine in the KB: an extracted rule compiles only when the last run that produced it used one of these prompt versions |
| `DOB_FORMAT` | `None` | the layout of date_of_birth if it is text a plain cast cannot read |
| `AHCCCS_TABLES_REQUIRE_SIGNED_READINGS` | `True` | a table's rules compile only when every reading of it is signed and every config value a reading binds is unchanged |
| `AHCCCS_SAME_PROVIDER_SCOPE`, `AHCCCS_DAILY_LIMIT_SCOPE` | `"member_servicing_billing_day"` | "same provider" for an A* pair and a daily limit = same servicing AND billing id, until AHCCCS says which one it means |
| `AHCCCS_B2_PROVIDER_ROLE`, `GROUP_BILLING_PROVIDER_TYPES` | `"billing_or_rendering"`, `("01",)` | B2 judges the billing type, except a group's line (01), judged on its rendering type |
| `AHCCCS_B2_COMPILE_CODES`, `AHCCCS_DAILY_RECORD_ONLY_CODES`, `AHCCCS_DAILY_PLACEHOLDER_MAX` | | which B2 codes compile (H0xxx / H2xxx); daily-limit rows recorded, not compiled (anesthesia time units; all-nines placeholders) |
| `AHCCCS_TABLE_MAX_AGE_DAYS` | B2 / daily 62, Same Day 366 | 01 and 07 warn when the claims outrun a table's newest version by more than this |
| `DAILY_CAP_VERIFY_MODIFIERS` | bilateral / anatomic / repeat / distinct | a daily-cap finding with one of these modifiers is `verify_modifier` (one line alone over the cap: `verify_span`) |
| `NCCI_DELETION_DATE_INCLUSIVE`, `NCCI_STRICT`, `NCCI_ALLOW_EMPTY`, `NCCI_ALLOW_MUE_GAPS` | `True`, `True`, `False`, `True` | an edit is in force on its deletion date (TGM App. B, verified); bad NCCI rows or no NCCI tables stop the build; a missing MUE quarter closes the MUE run (claims in that quarter get no MUE check, nothing is inferred; 01, 07, v03 and d08 list it), `False` = it stops the build |

## How the rules stay honest

| stage | guarantee |
|---|---|
| propose | closed grammar; the model must quote the source; unclear -> `not_checkable`, never a guess |
| ground | the quote must be in the section; every code in the section; threshold in the quoted sentence; negation and number drift refused; a quote that drops an "unless / except" clause is flagged. The stored quote is the source text |
| outcomes | every section gets an outcome row, so recall can be measured |
| merge | keyed by meaning; a new document version sends approvals back for re-sign |
| review | a decision needs a named reviewer, the document version it was made on, and a pending row |
| build | only approved rules of the current document version and the current engine compile; what was left out, and why, is in the build log |
| validate | every query's plain English, SQL and scenarios go to a validator (v06), bound to the SQL's sha256 |
| detect | deterministic SQL; 08 refuses edited or unhashed SQL; NCCI ignores PA (CMS: not a bypass); state findings with a PA number are `verify_pa`, never suppressed |

**NCCI routing.** CMS decides which edit file applies by provider type and claim form (2026 Medicaid NCCI Technical
Guidance Manual s6.0 Table 2) and applies the edits to claims "from" a type of provider (s5.3). Each line takes ONE file
(practitioner, outpatient hospital or DME) from its type codes and FORM_TYP through
`reference/ncci_provider_type_routing.csv`, or none: dental, pharmacy, inpatient and long-term-care claims take none
(s5.2). The table ships proposed and is signed row by row (D1). Findings follow the CMS public edit set; Arizona's
RISSNET deactivations are not applied (`config.CORPUS_PENDING`): an NCCI finding is a **CMS Medicaid NCCI reference
finding**, never an AHCCCS-authoritative violation; read NCCI findings as leads. Every NCCI window ends at the latest
with the newest loaded quarter of its edit file, deleted or not: claims after it get no NCCI check until the next quarter
is loaded (01, 07, v03 and d08 give those lines and dollars). **Upgrade note (2026-10-17):** an NCCI rule id no longer
contains the end date, so NCCI rules that had one (deleted edits, closed MUE runs) have new ids once; earlier findings
still join `policy_rules_history` on (build_id, rule_id).

**AHCCCS rule tables.** Same Day Disallow: D = the two codes never on one member-day (any provider), A* = not from the
same provider, A = allowed; the row code's line is the finding (`verify_exception`: table note 2). Daily limits: units
per member, provider and day. Each loaded file judges claims from its own date to the day before the next version;
claims before the oldest loaded version are not judged by the table (load AHCCCS's earlier versions).

## Testing

```
python -m pytest tests -q --ignore=tests/test_sql_spark.py --ignore=tests/test_sql_oracle.py --ignore=tests/test_sql_oracle_tables.py
python -m pytest tests/test_sql_spark.py -q                # the SQL on Spark 4, ANSI on
python -m pytest tests/test_sql_oracle.py -q               # independent oracle vs the SQL on random claims
python -m pytest tests/test_sql_oracle_tables.py -q        # independent oracle for the AHCCCS table statements
python tests/e2e_local_spark.py --demos                    # every notebook, in order, on a local Spark
```
The oracles were written from `docs/QUERY_SEMANTICS.md` alone and must agree with the SQL on every finding, label,
unit, evidence line and dollar. The end-to-end run uses synthetic claims with the real column names and planted
violations and false-positive traps.

## Not verified yet (needs your workspace)

* That a filled EVENT_PA_NO means an approved PA (findings with one are `verify_pa`).
* LN_NO's and date_of_birth's column types (both handled; 08 warns when most birth dates do not read).
* The exact layout inside CMS's NCCI text files (the parser finds the header itself and stops if it cannot).
* Cluster egress to cms.gov and azahcccs.gov (drop-zone and upload fallbacks exist).

Upgrade notes for v5 to v5.2 are in `docs/V5_CHANGES.md`.
