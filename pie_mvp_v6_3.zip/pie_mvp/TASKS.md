# PIE: checklist

Earlier work logs (2026-09-28 to 2026-10-04, v5 to v5.2) are in `docs/V5_CHANGES.md` and the git history.

## 2026-10-14: after SB's real run (build B20261008T231304, detector run 20261008T233521)

Decisions taken in this pass (README, "Decisions taken"):
- [x] D1 NCCI gated per provider type: a line takes an edit file only when its deciding routing row is signed; 01 / 08 report the rest
- [x] D2 group-billed lines (01) routed on the servicing (rendering) type; none when it is missing
- [x] D3 a table version that allows a pair a chapter rule forbids dates the conflict: the rule stays executable up to the day before
- [x] D4 hub lists pair X with each listed code, never two listed codes; an invalid token (e.g. "S109") is reported, not rewritten
- [x] D5 missed rules fixed in the extractor (pattern layer + prompt); no manual-entry path
- [x] D6 coverage = paid dollars inside the window of a compiled rule that ran in the latest detector run (also over procedure-coded lines)

Measurement (v01 / v03 / quality.py):
- [x] One corpus id: v03 printed the documents plus the loaded AHCCCS tables' hashes (corpus-38bdddc2efe69681) while v01 stamps the documents only (corpus-7134c61e71b11ea5); v03 now shows only the id v01 stamps
- [x] Precision pass mark on the rules that compile: every compiled state rule scored (a census, exact rate); v01 `STATUSES = ["approved"]` exports every approved rule; the raw drafts' number is shown without a pass mark
- [x] Coverage row = 08's run log (`RUN:snapshot` `pct_paid_ran_*`, computed once by `gap.ran_coverage`), over every paid line and over procedure-coded lines
- [x] Contradiction row = the build log's count over the one register (`policy_ahcccs_conflicts`), by relationship
- [x] Routing row says what share of the CMS-1500 / UB-04 paid dollars NCCI will check (D1)
- [x] Per-chapter model calls / failures (the log held running totals: 6, 15, 39 ... 198)
- [x] Reviewers counted case-insensitively and named ("2 reviewers" for a review signed "ss")
- [x] Removed: the "Nothing compiles without version-bound sign-off" row (GO from a config switch, even with no build; folded into the sign-off row), the `detector_cannot_tell_share` metric (its count is in the precision notes), `config.py`'s legacy aliases, history-only docs (PHASE1 / PHASE15 changes, the early review brief, GAP_TO_DONE); then (2026-10-16) `COMPILE_LEGACY_SEEDS`, the DBFM backend, about 20 names nothing read, 02's PoC-module path, and the notebook source-text tests that behaviour tests cover

## 2026-10-18: v6.2 (prompt reviews; docs/V6_CHANGES.md section 8)

- [x] Prompt: return every obligation (not_checkable when the grammar cannot hold it); every field from the TEXT, never an example; rule 3 = post_checks' exempting vs narrowing reading; one reread (rule 14)
- [x] Three grammar examples corrected (98960 combined cap, T2029 lifetime cap, H0035's four provider types); prompt frozen (test pins its sha)
- [x] v05: inventory shipped and read by default for both runs; recall without the 19 prompt-example rules; each miss says where it was lost
- [x] Review workbook ordered by the checks, not by the model's confidence
- [x] Critic: a threshold the text never writes is a lead; "both codes" is a pair's own trigger; inventory matching adds hub codes, is typed and best-only
- [x] 00_acquire_ncci: three code cells sat inside Markdown cells (never ran on Databricks); split, and a test checks every notebook
- [x] Hub lists run into the next line (H2015, H2020, H0037: about 55 pairs) are pairs, not leads; a reused HYBRID answer gets the current pattern rules (2026-10-21)
- [x] v6.3 (2026-10-21): package version and extraction-code sha in every run manifest, shown by 04 and v05 (prompt still v3)
- [ ] First real v3 run: 04 low and medium on chapters 19 and 10, v05 A/B, then all chapters at the chosen level (README)

## Open (needs SB, the boss or AHCCCS)

- [ ] Sign the routing rows for the provider types on the claims (0 of 140 signed on 2026-10-08; NCCI never ran)
- [ ] Sign the AHCCCS table readings (14 unsigned); which line AHCCCS denies in a both-ways pair; servicing vs billing for "same provider" (A* guidance of 2/27/2026); H0035 B2 vs B6
- [ ] Get AHCCCS's earlier versions of the three tables: Same Day 10/1/2026 and B2 10/1/2026 judge 0 claim lines of 2024-10-01 to 2026-09-25; daily limits 9/14/2026 judges 0.4%
- [x] CMS MUE quarters from the claims start loaded (00 with ARCHIVE, 2026-10-18): 2024Q4 to 2026Q4 for all three files; gaps left: 2025-01-01 to 2025-01-28 (the r1 file applies from Jan 29) and DME 2025Q2 (not in the CMS archive). 14 tables of 2026Q2 to 2026Q4 were loaded earlier without acquisition provenance (findings say hand_loaded; rule ids do not depend on it)
- [ ] Ask AHCCCS for the RISSNET state NCCI files (Arizona's deactivations are not applied)
- [ ] Decide CMS's optional NCCI Table 2 rows (testing facilities; other outpatient incl. FQHCs, clinics); the ASC row (43)
- [ ] Validate the queries in v06 (a sample first is fine)
- [ ] Score: v01 `STATUSES = ["approved"]` (every compiled rule), v01 `STATUSES = None` (recall, fidelity), v02, v07
- [ ] all_data_C_A has columns the grammar treats as absent (Svc_End_Dt, DIAG_CD_1..4, NDC_CD, COS_CODE, Revenue_Cd_Desc, line_of_business): measure their fill rate; after the first scored run, decide which leads they make checkable (the reason meanings in the frozen prompt say NDC and diagnosis are not on the claim)
- [ ] Confirm: EVENT_PA_NO = an approved PA; all_data_C_A is FFS only; LN_NO's type; paid units <= billed units
- [ ] SME: E0618 / E0619 RR on every line (Ch13 p.5) vs "NU, LL, and RR are all permitted" (Ch8 p.5): reject or fix the approved RR rule (it flags nothing today: modifier_required does not compile)
- [ ] SME: Ch19 effective dates; 99070 (Ch10 p.47); A0110's provider type list; S5150 48/day, T1015, W2404 to W2406
- [ ] Form O (UB-04 outpatient, 1,776,938 lines, $1.36B paid, 2026-10-18 01 run) has NO PROC_CD on any line: the outpatient NCCI file and every coded state rule cannot fire there even once its routing rows are signed. Find where its HCPCS lives (PROC_KEY? another table) or ask the data owner
- [ ] Form C is mapped as pharmacy (config.FORM_TYPE_MAP) but 1.55M of its lines ($581M) are billed by type 02 Hospital: confirm with FORM_TYP_DESC
- [ ] Not in the claims: a reversal adjustment key; a revenue CODE (only Revenue_Cd_Desc). Service end date, diagnosis, NDC, category of service and line of business ARE columns (schema seen 2026-10-18; fill rate unknown)
