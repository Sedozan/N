"""regress.py after critic M51 (2026-10-04): DANGER and the unreviewed-draft count of the v05 ship gate.

M51-5  a REVERSED code pair (draft 97110 -> 97530 where the signed rule is 97530 -> 97110) puts the finding on the
       other line (detector_gen.compile_code_pair: the finding sits on code_b), so it flags lines the signed rule does
       not: DANGER, never a mere label difference. A second same-type draft on an already-matched signed rule is a
       harmless 'duplicate' only when its comparable predicate is the signed one; a different reading that is not
       wider is an executable rule nobody reviewed (unmatched_compiled), and a wider one stays DANGER (counted once).
M51-4  compare_runs reports each run's OWN ship gate when v05 passes it (the A/B numbers are a comparison only).
Run: cd pie_mvp && python -m pytest tests/test_regress_v51.py -q
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import regress  # noqa: E402

Q = "Procedure code 97110 may not be billed on the same date of service as code 97530 by the same provider."
PAIR = {"type": "code_pair_prohibited", "code_a": "97530", "code_b": "97110", "modifier_indicator": "0"}
REVERSED = dict(PAIR, code_a="97110", code_b="97530")
CAP = {"type": "max_units_per_day", "code": "97110", "threshold": 4}
QC = "Procedure code 97110 is limited to four units per day for any member."


def _gold(gid, kind, pred, quote=Q, key=None):
    return regress._gold_row(gid, kind, "14", pred, quote, doc_hash="H14", key=key, reviewer="SB", source="test")


def _draft(rid, pred, key=None, quote=Q, pop="all"):
    return {"rule_id": rid, "extraction_key": key, "chapter": "14", "verbatim_quote": quote, "population": pop,
            "predicate": json.dumps(pred)}


# ------------------------------------------------------------------ M51-5: a reversed pair flags the other line
def test_a_reversed_code_pair_is_danger_not_a_label_difference():
    summ, det = regress.compare([_gold("G1", "positive", PAIR, key="k1")], [_draft("D1", REVERSED, key="k1")])
    row = det[0]
    assert row["danger"] and "reversed" in row["danger_reasons"]
    assert "97530" in row["danger_reasons"] and "97110" in row["danger_reasons"]
    assert row["exact"] is False and row["result"] == "changed"            # not the signed predicate
    assert not (row["label_diffs"] or "").count("direction")               # no longer filed as a label
    assert summ["total"]["danger"] == 1 and not regress.ship_gate(summ)[0]
    # the same direction is still exact and safe
    summ, det = regress.compare([_gold("G1", "positive", PAIR, key="k1")], [_draft("D1", dict(PAIR), key="k1")])
    assert det[0]["exact"] and not det[0]["danger"] and regress.ship_gate(summ)[0]
    assert regress.canon(PAIR) != regress.canon(REVERSED)
    assert regress.wider_reasons(_draft("D", REVERSED), _gold("G", "positive", PAIR)) != []


def test_a_reversed_copy_of_a_matched_pair_is_danger():
    summ, det = regress.compare([_gold("G1", "positive", PAIR, key="k1")],
                                [_draft("D1", PAIR, key="k1"), _draft("D2", REVERSED, key="k2")])
    by = {r["rule_id"]: r for r in det}
    assert by["D1"]["result"] == "exact" and by["D2"]["danger"] and "reversed" in by["D2"]["danger_reasons"]
    assert summ["total"]["danger"] == 1 and not regress.ship_gate(summ)[0]


def test_a_rejected_reversal_of_a_kept_pair_stays_a_negative():
    """_finish drops a rejection that is the SAME rule as a kept one (rejected as a duplicate). A reversed pair is not
    the same rule - its finding sits on the other line - so the reviewer's rejection of it is a real negative."""
    import pandas as pd
    book = {"review": pd.DataFrame([
        {"rule_id": "EXT-keep", "chapter": "14", "decision": "Approve", "reviewer": "SB", "extraction_key": "k",
         "predicate": json.dumps(PAIR), "verbatim_quote": Q},
        {"rule_id": "EXT-rev", "chapter": "14", "decision": "Reject", "reviewer": "SB", "extraction_key": "r",
         "predicate": json.dumps(REVERSED), "verbatim_quote": Q}])}
    rep = {}
    gold = regress.gold_from_workbook(book, report=rep)
    assert [(g["gold_id"], g["kind"]) for g in gold] == [("EXT-keep", "positive"), ("EXT-rev", "negative")]
    assert "reject_same_as_a_kept_rule" not in rep["excluded"]


# ------------------------------------------------------------------ M51-5: a different extra reading nobody reviewed
def test_a_narrower_different_extra_draft_is_an_unreviewed_executable_rule():
    cap8 = dict(CAP, threshold=8)
    summ, det = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                                [_draft("D2", CAP, key="k2", quote=QC), _draft("D3", cap8, key="k3", quote=QC)])
    by = {r["rule_id"]: r for r in det}
    assert by["D2"]["result"] == "exact"
    assert by["D3"]["result"] == "unreviewed_variant" and not by["D3"]["danger"] and by["D3"]["gold_id"] == "G2"
    t = summ["total"]
    assert (t["unmatched_compiled"], t["duplicate"], t["danger"]) == (1, 0, 0)
    ok, why = regress.ship_gate(summ)
    assert not ok and "1 new executable draft(s) have no reviewed decision" in why and "unreviewed_variant" in why


def test_an_identical_extra_draft_is_a_harmless_duplicate_and_a_wider_one_is_danger_once():
    summ, det = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                                [_draft("D2", CAP, key="k2", quote=QC), _draft("D3", dict(CAP), key="k3", quote=QC)])
    t = summ["total"]
    assert [r["result"] for r in det if r["rule_id"] == "D3"] == ["duplicate"]
    assert (t["duplicate"], t["unmatched_compiled"], t["danger"]) == (1, 0, 0) and regress.ship_gate(summ)[0]
    wide = dict(CAP, threshold=2)                                              # flags more: DANGER, counted once
    summ, det = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                                [_draft("D2", CAP, key="k2", quote=QC), _draft("D3", wide, key="k3", quote=QC)])
    t = summ["total"]
    d3 = [r for r in det if r["rule_id"] == "D3"][0]
    assert d3["result"] == "duplicate" and d3["danger"] and "threshold 2 < signed 4" in d3["danger_reasons"]
    assert (t["danger"], t["unmatched_compiled"]) == (1, 0)


def test_a_different_extra_lead_does_not_block():
    lead = {"type": "not_checkable", "reason": "requires_medical_record"}
    other = {"type": "not_checkable", "reason": "process_obligation"}
    summ, det = regress.compare([_gold("G4", "positive", lead, quote=QC, key="k4")],
                                [_draft("D4", lead, key="k4", quote=QC), _draft("D5", other, key="k5", quote=QC)])
    assert [r["result"] for r in det if r["rule_id"] == "D5"] == ["unreviewed_variant"]
    assert summ["total"]["unmatched_compiled"] == 0 and regress.ship_gate(summ)[0]
    # an age-scoped rule without an age condition stays a lead (regress.compiles): no block either
    cap8 = dict(CAP, threshold=8)
    summ, _ = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                              [_draft("D2", CAP, key="k2", quote=QC),
                               _draft("D3", cap8, key="k3", quote=QC, pop="members under 21")])
    assert summ["total"]["unmatched_compiled"] == 0


# ------------------------------------------------------------------ M51-4: compare_runs carries each run's own gate
def test_compare_runs_reports_the_gate_it_is_given():
    gold = [_gold("G2", "positive", CAP, quote=QC, key="k2")]
    a = [_draft("D2", CAP, key="k2", quote=QC)]
    blocked = (False, "BLOCKED: 1 new executable draft(s) have no reviewed decision (chapter 4)")
    rows = regress.compare_runs(gold, a, a, labels=("A", "B"), gates=[blocked, (True, "OK: all chapters")])
    assert [r["ship_gate"] for r in rows] == ["BLOCKED", "OK"]
    assert rows[0]["ship_gate_reason"] == blocked[1] and rows[0]["unmatched_compiled"] == 0
    # without gates: the gate of the compared drafts, as before
    assert [r["ship_gate"] for r in regress.compare_runs(gold, a, None)] == ["OK"]


# ------------------------------------------------------------------ 2026-10-17 (external review B3): inventory recall
def test_v05_reads_the_manual_inventory_as_unreviewed_recall_gold_per_kind():
    """The 852-rule manual inventory measured only the pattern layer; v05 (INVENTORY_PATH) now scores a run's drafts
    against it per kind: same chapter, overlapping quote, compatible codes. Recall only, labelled unreviewed."""
    import pandas as pd
    inv = regress.gold_from_inventory(pd.DataFrame([
        {"chapter": "14", "kind": "pair_prohibited", "codes": "97110, 97530", "quote": Q, "checkable": "yes"},
        {"chapter": "14", "kind": "max_units_per_day", "codes": "97110", "quote": QC, "checkable": "yes"},
        {"chapter": "14", "kind": "max_units_per_day", "codes": "97112", "quote": "Code 97112 is limited to two units "
         "per day.", "checkable": "no: units"},
        {"chapter": "15", "kind": "other", "codes": None, "quote": Q, "checkable": "no"}]))
    assert [g["codes"] for g in inv] == [["97110", "97530"], ["97110"], ["97112"], []]
    drafts = [_draft("D1", PAIR), _draft("D2", {"type": "not_checkable", "reason": "ambiguous_source"}, quote=QC),
              _draft("D3", dict(CAP, code="97112"), quote="Code 97112 requires a therapy plan of care on file.")]
    rows = {r["kind"]: r for r in regress.inventory_recall(inv, drafts)}
    assert (rows["pair_prohibited"]["found"], rows["pair_prohibited"]["found_executable"]) == (1, 1)
    assert (rows["max_units_per_day"]["rules"], rows["max_units_per_day"]["found"]) == (2, 1)  # D3: another sentence
    assert rows["max_units_per_day"]["found_executable"] == 0 and rows["other"]["found"] == 0   # chapter 15: no draft
    assert (rows["TOTAL"]["rules"], rows["TOTAL"]["found"], rows["TOTAL"]["recall"]) == (4, 2, 0.5)
    # review of 1beb482: the inventory kind names the predicate type the matcher prefers (a pair draft of a sentence
    # that also states two caps is the pair's, not the first cap's); a code range in the codes column is no code
    chw = ("Claims can be submitted for a maximum of four units per day, up to 24 units per month per member (total units "
           "allowable is inclusive of all 3 billable codes; codes cannot be billed together on the same day).")
    inv = regress.gold_from_inventory(pd.DataFrame([{"chapter": "10", "kind": k, "codes": "98960, 98961", "quote": chw}
                                                    for k in ("max_units_per_day", "max_units_per_period",
                                                              "pair_prohibited")]
                                                   + [{"chapter": "21", "kind": "other", "codes": "97001-97546",
                                                       "quote": "Service limits apply to codes 97001-97546."}]))
    pair = dict(_draft("D9", dict(PAIR, code_a="98960", code_b="98961"), quote=chw), chapter="10")
    lim = dict(_draft("D8", {"type": "not_checkable", "reason": "predicate_not_in_grammar"},
                      quote="Service limits apply to codes 97001-97546."), chapter="21")
    rows = {r["kind"]: r for r in regress.inventory_recall(inv, [pair, lim])}
    assert (rows["pair_prohibited"]["found"], rows["max_units_per_day"]["found"], rows["other"]["found"]) == (1, 0, 1)
    assert inv[-1]["codes"] == []
    src = open(os.path.join(os.path.dirname(HERE), "notebooks", "validation", "v05_extraction_regression.py")).read()
    assert "INVENTORY_PATH       = config.MANUAL_RULE_INVENTORY" in src and "regress.inventory_recall(" in src
    assert "UNREVIEWED inventory" in src


# ------------------------------------------------------------------ 2026-10-18 (v6.2, prompt reviews)
def test_inventory_recall_without_prompt_examples_and_where_each_miss_was_lost():
    """Recall on the rules the prompt's worked examples come from partly measures the examples: inventory_recall also
    reports recall without them. Each miss says where it was lost (dropped / prefilter / failed / extractor /
    not_located), which says what to fix: grounding or post_checks, the pre-filter, a rerun, the prompt, the reader."""
    import pandas as pd
    a0888 = "Code A0888 may only be billed for AHCCCS members who also are covered by Medicare."
    pre = "Code 97140 is limited to two units per day."
    dropped_q = "Code 97150 is not covered."
    failed_q = "Code 97161 is limited to one unit per day."
    lost = "Code 97530 must be billed with modifier GP."
    rows = [{"chapter": "14", "kind": "pair_prohibited", "codes": "97110, 97530", "quote": Q},
            {"chapter": "14", "kind": "population_limit", "codes": "A0888", "quote": a0888},
            {"chapter": "14", "kind": "max_units_per_day", "codes": "97140", "quote": pre},
            {"chapter": "14", "kind": "not_covered", "codes": "97150", "quote": dropped_q},
            {"chapter": "14", "kind": "max_units_per_day", "codes": "97161", "quote": failed_q},
            {"chapter": "14", "kind": "modifier_required", "codes": "97530", "quote": lost},
            {"chapter": "14", "kind": "other", "codes": None, "quote": "Text the reader never produced at all here."}]
    inv = regress.gold_from_inventory(pd.DataFrame(rows))
    assert [g["prompt_example"] for g in inv] == [False, True, False, False, False, False, False]
    sections = [{"chapter": "14", "section_id": "s1", "heading": "Therapy", "text": Q + " " + lost + " " + a0888},
                {"chapter": "14", "section_id": "s2", "heading": "Manual", "text": "Intro. " + pre},
                {"chapter": "14", "section_id": "s3", "heading": "Other", "text": dropped_q},
                {"chapter": "14", "section_id": "s4", "heading": "Eval", "text": failed_q.replace(".", ",") + " x."}]
    outcomes = [{"chapter": "14", "section_id": "s1", "outcome": "proposals"},
                {"chapter": "14", "section_id": "s2", "outcome": "skipped_prefilter"},
                {"chapter": "14", "section_id": "s3", "outcome": "proposals"},
                {"chapter": "14", "section_id": "s4", "outcome": "failed_retryable"}]
    dropped = [{"chapter": "14", "verbatim_quote": dropped_q, "codes": json.dumps(["97150"]),
                "predicate": json.dumps({"type": "code_not_covered", "code": "97150"}), "drop_reason": "quote not found"}]
    drafts = [_draft("D1", PAIR), _draft("D2", {"type": "not_checkable", "reason": "requires_member_attribute"},
                                         quote=a0888)]
    misses = regress.inventory_misses(inv, drafts, sections, outcomes, dropped)
    by = {m["codes"] or "-": m for m in misses}
    assert {k: m["lost_at"] for k, m in by.items()} == {"97140": "prefilter", "97150": "dropped", "97161": "failed",
                                                         "97530": "extractor", "-": "not_located"}
    assert by["97150"]["drop_reason"] == "quote not found" and by["97530"]["heading"] == "Therapy"
    tot = {r["kind"]: r for r in regress.inventory_recall(inv, drafts, misses)}["TOTAL"]
    assert (tot["rules"], tot["found"], tot["prompt_examples"], tot["prompt_examples_found"]) == (7, 2, 1, 1)
    assert (tot["recall"], tot["recall_wo_prompt_examples"]) == (round(2 / 7, 3), round(1 / 6, 3))
    assert [tot[f"lost_{w}"] for w in regress._LOST] == [1, 1, 1, 1, 1, 0]
    # no section texts (an older run): unknown, never not_located
    assert {m["lost_at"] for m in regress.inventory_misses(inv, drafts, [], outcomes)} == {"unknown"}
    assert "lost_dropped" not in regress.inventory_recall(inv, drafts)[0]         # without misses: no loss columns


def test_shipped_inventory_holds_every_prompt_example_source():
    """The inventory ships in reference/ (v05 reads it by default); each manual sentence the prompt's examples come
    from is in it, so recall_wo_prompt_examples leaves out what it should."""
    import config
    import pandas as pd
    assert os.path.exists(config.MANUAL_RULE_INVENTORY)
    df = pd.read_excel(config.MANUAL_RULE_INVENTORY, sheet_name="rules", engine="openpyxl")
    assert len(df) == 852
    qs = [regress.pc.norm(str(q)) for q in df["quote"]]
    for f, _ in regress.PROMPT_EXAMPLE_SOURCES:
        assert any(f in q for q in qs), f
    tagged = {i for i, r in df.iterrows() if regress.prompt_example(r["quote"], r["kind"])}
    assert len(tagged) == 19 and {134, 167, 168, 379} <= tagged and not {169, 461} & tagged   # (critic, v6.2)


def test_inventory_matching_hub_rows_typed_and_best_only_on_the_real_rows():
    """v6.2 (critic), on the shipped inventory's own rows: a hub row names the hub in parameters.hub, so the 14 pairs
    of the H2012 list never found it; the same pairs also 'found' three OTHER hub lists (quote ratio >= 0.85) and the
    pair reading of the CHW sentence 'found' its two caps. Now: the hub's row is found, the others are not."""
    import config
    import pandas as pd
    df = pd.read_excel(config.MANUAL_RULE_INVENTORY, sheet_name="rules", engine="openpyxl")
    inv = regress.gold_from_inventory(df)
    by_q = {g["gold_id"]: g for g in inv}
    h2012 = next(g for g in inv if g["quote"].startswith("H2012 shall not be billed with"))
    assert "H2012" in h2012["codes"]
    pairs = [{"rule_id": f"P{c}", "chapter": "19", "verbatim_quote": h2012["quote"], "population": "all",
              "predicate": json.dumps(dict(PAIR, code_a=c, code_b="H2012"))} for c in h2012["codes"] if c != "H2012"]
    ch19 = [g for g in inv if g["chapter"] == "19"]
    rows = {r["kind"]: r for r in regress.inventory_recall(ch19, pairs)}
    assert rows["pair_prohibited"]["found"] == 1                       # the H2012 row only
    found = regress._found(regress.inventory_match(ch19, pairs))
    assert [ch19[i]["gold_id"] for i in found] == [h2012["gold_id"]] and h2012["gold_id"] in by_q
    chw = [g for g in inv if g["chapter"] == "10" and g["quote"].startswith("Claims can be submitted for a maximum")]
    assert sorted(g["inventory_kind"] for g in chw) == ["max_units_per_day", "max_units_per_period", "pair_prohibited"]
    pair_drafts = [{"rule_id": f"C{i}", "chapter": "10", "verbatim_quote": chw[0]["quote"], "population": "all",
                    "predicate": json.dumps(dict(PAIR, code_a=a, code_b=b))}
                   for i, (a, b) in enumerate([("98960", "98961"), ("98960", "98962"), ("98961", "98962")])]
    rows = {r["kind"]: r for r in regress.inventory_recall(chw, pair_drafts)}
    assert (rows["pair_prohibited"]["found"], rows["max_units_per_day"]["found"],
            rows["max_units_per_period"]["found"]) == (1, 0, 0)


def test_a_per_provider_daily_cap_finds_its_daily_cap_row():
    """(critic re-check) post_checks rescopes a per-provider daily cap to max_units_per_dos; the typed inventory match
    must still credit the row whose kind is max_units_per_day."""
    import pandas as pd
    q = "T1015 may be billed once per day, per MSIC."
    inv = regress.gold_from_inventory(pd.DataFrame([{"chapter": "10", "kind": "max_units_per_day", "codes": "T1015",
                                                     "quote": q}]))
    d = dict(_draft("D1", {"type": "max_units_per_dos", "code": "T1015", "threshold": 1}, quote=q), chapter="10")
    assert regress.inventory_recall(inv, [d])[-1]["found"] == 1


def test_a_duplicate_drop_is_not_a_dropped_rule_and_a_page_picks_the_section():
    import pandas as pd
    a0888 = "Code A0888 may only be billed for AHCCCS members who also are covered by Medicare."
    inv = regress.gold_from_inventory(pd.DataFrame([
        {"chapter": "14", "page": 4, "kind": "population_limit", "codes": "A0888", "quote": a0888},
        {"chapter": "14", "page": 5, "kind": "population_limit", "codes": "A0888", "quote": a0888},
        {"chapter": "14", "page": 6, "kind": "pair_prohibited", "codes": "97110, 97530", "quote": Q}]))
    sections = [{"chapter": "14", "section_id": "p4", "page_start": 4, "page_end": 4, "text": a0888},
                {"chapter": "14", "section_id": "p5", "page_start": 5, "page_end": 5, "text": a0888},
                {"chapter": "14", "section_id": "p6", "page_start": 6, "page_end": 6, "text": Q + " " + QC}]
    outcomes = [{"chapter": "14", "section_id": "p4", "outcome": "proposals"},
                {"chapter": "14", "section_id": "p5", "outcome": "skipped_prefilter"},
                {"chapter": "14", "section_id": "p6", "outcome": "proposals"}]
    lead = {"type": "not_checkable", "reason": "requires_member_attribute"}
    drafts = [dict(_draft("D1", lead, quote=a0888)), _draft("D2", CAP, quote=QC)]
    dropped = [{"chapter": "14", "verbatim_quote": Q, "codes": json.dumps(["97110", "97530"]),
                "predicate": json.dumps(PAIR), "drop_reason": "duplicate (post-check): same as k2"}]
    m = {x["page"]: x for x in regress.inventory_misses(inv, drafts, sections, outcomes, dropped)}
    assert m["5"]["lost_at"] == "prefilter" and m["5"]["section_id"] == "p5"      # not the p4 section
    assert m["6"]["lost_at"] == "extractor" and m["6"]["drop_reason"] is None     # a duplicate drop is no refusal
    assert regress.inventory_misses(inv, drafts, sections, [])[0]["lost_at"] == "unknown"     # no outcomes
    src = open(os.path.join(os.path.dirname(HERE), "notebooks", "04_extract_chapters_gpu.py")).read()
    assert '"prompt_sha": extract_rules.PROMPT_SHA' in src
