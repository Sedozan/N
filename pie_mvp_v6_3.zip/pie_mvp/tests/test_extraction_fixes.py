"""Extraction defects D1 / D2 / D2b / D11, each pinned by a test that failed on the
code before the fix. Offline, no Spark, no model.
Run: cd pie_mvp && python -m pytest tests -q
"""
import copy
import json
import os
import sys

import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import extract_io
import extract_rules as ex

PKG = os.path.dirname(HERE)
INV = {"chapter": "19", "title": "T", "url": "u", "doc_hash": "h19", "revision_date": None}


class _Raw(ex.Backend):
    """A model backend that returns a fixed raw string (or raises)."""
    name, model = "FAKE", "fake"

    def __init__(self, raw=None, exc=None):
        self.raw, self.exc, self.calls = raw, exc, 0

    def complete(self, s, u):
        self.calls += 1
        if self.exc:
            raise self.exc
        return self.raw


class _Fixed(ex.Backend):
    name, model = "FAKE", "fake"

    def __init__(self, rules):
        self.rules = rules

    def complete(self, s, u):
        return json.dumps({"rules": copy.deepcopy(self.rules), "no_rule_reason": None})


def _sec(text, sid="s1", candidate=True, text_hash=None):
    return {"text": text, "text_hash": text_hash or f"th-{sid}", "section_id": sid, "heading": f"H {sid}",
            "page_start": 3, "page_end": 4, "has_rule_signal": candidate, "rule_signal": 1 if candidate else 0}


def _user(text):
    return ex.USER_TEMPLATE.format(chapter="19", title="T", heading="H", page_start=1, page_end=1,
                                   revision="r", text=text)


RULE_98960 = {"statement": "98960 max 4/day", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
              "codes": ["98960"], "verbatim_quote": "A maximum of four units per day applies to 98960.",
              "confidence": 0.8}


# ===================================================================== D1
def test_d1_fenced_model_reply_is_parsed_not_silently_empty():
    """A ```json fenced reply used to become 'no model rules' and the section was cached."""
    fenced = "```json\n" + json.dumps({"rules": [RULE_98960], "no_rule_reason": None}) + "\n```"
    hy = ex.HybridBackend(_Raw(fenced), _Fixed([]))
    obj = json.loads(hy.complete(ex.SYSTEM_PROMPT, _user("x")))
    assert [r["source"] for r in obj["rules"]] == ["model"]
    assert obj["rules"][0]["predicate"]["code"] == "98960"
    assert ex.model_health(hy)["model_unparseable"] == 0


def test_d1_unparseable_model_half_is_retryable_never_cached():
    text = "A maximum of four units per day applies to 98960."
    # require_model=True (default): an unparseable model half is a failure, not "no rules"
    hy = ex.HybridBackend(_Raw("Sorry, I can't help with that."), ex.StubBackend())
    cache = {}
    drafts, _, st = ex.extract_chapter([_sec(text)], INV, hy, "r", cache=cache, log_fn=lambda x: None)
    assert cache == {} and drafts == []
    assert st["unparseable"] == 1 and st["retryable_sections"][0]["why"].startswith("unparseable")
    mh = ex.model_health(hy)
    assert mh["model_unparseable"] == 1 and mh["model_failures"] == 1 and "unparseable" in mh["last_model_error"]
    # require_model=False: degraded patterns-only output, flagged and still not cached
    hy2 = ex.HybridBackend(_Raw("no json here"), ex.StubBackend(), require_model=False)
    cache = {}
    drafts, _, st = ex.extract_chapter([_sec(text)], INV, hy2, "r", cache=cache, log_fn=lambda x: None)
    assert cache == {} and st["degraded_patterns_only"] == 1 and len(drafts) == 1
    assert ex.model_health(hy2)["model_unparseable"] == 1


def test_d1_pattern_half_still_parses_strictly():
    """The pattern half is our own code: bad JSON there is a bug and must not read as 'no rules'."""
    hy = ex.HybridBackend(_Fixed([RULE_98960]), _Raw("not json"))
    with pytest.raises(ValueError):
        hy.complete(ex.SYSTEM_PROMPT, _user("x"))


# ===================================================================== D2
def test_d2a_short_quote_does_not_evidence_a_rule():
    sec = _sec("Do not bill 11975 unless prior authorization is obtained.")
    lead = {"statement": "PA", "predicate": {"type": "not_checkable", "reason": "requires_medical_record"},
            "codes": [], "verbatim_quote": "is obtained", "confidence": 0.9}
    g = ex.ground(lead, sec)
    assert not g["keep"] and g["drop_reason"] == "quote too short to evidence the rule"
    # a short quote that names every predicate code is still acceptable evidence
    short_coded = {"statement": "s", "predicate": {"type": "code_not_covered", "code": "11975"},
                   "codes": ["11975"], "verbatim_quote": "Do not bill 11975", "confidence": 0.9}
    assert ex.ground(short_coded, sec)["keep"]


def test_d2b_codes_far_from_quote_are_flagged_and_capped():
    sec = _sec("Codes covered by this section: 98960 and 98961. Services must be delivered by a registered "
               "worker. Claims are submitted on the CMS 1500 form. Providers must keep records for six years. "
               "A maximum of four units per day applies to these services.")
    pr = {"statement": "98960 max 4/day", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
          "codes": ["98960"], "verbatim_quote": "A maximum of four units per day applies to these services.",
          "confidence": 0.9}
    g = ex.ground(pr, sec)
    assert g["keep"] and g["codes_found"] == "all"            # section-level gate unchanged (recall)
    assert g["codes_in_quote_window"] is False
    row = ex.to_draft_row(pr, g, sec, INV, ex.StubBackend(), "r")
    assert row["extraction_confidence"] <= 0.5
    assert "codes not stated near the quoted sentence" in row["ambiguity_note"]
    # a code in the NEIGHBOURING sentence is inside the window
    sec2 = _sec("Codes 98960 and 98961 are CHW codes. A maximum of four units per day applies to these services.")
    assert ex.ground(pr, sec2)["codes_in_quote_window"] is True


def test_d2c_quote_that_drops_an_unless_clause_is_not_a_clean_rule():
    sec = _sec("Do not bill 11975 unless prior authorization is obtained.")
    pr = {"statement": "11975 not covered", "predicate": {"type": "code_not_covered", "code": "11975"},
          "codes": ["11975"], "verbatim_quote": "Do not bill 11975", "confidence": 0.9}
    g = ex.ground(pr, sec)
    assert g["keep"] and g["quote_truncates_condition"] is True
    row = ex.to_draft_row(pr, g, sec, INV, _Fixed([]), "r")
    assert row["ambiguity_flag"] is True and row["extraction_confidence"] <= 0.5
    assert ("source sentence carries a condition the quote omits: "
            "Do not bill 11975 unless prior authorization is obtained.") in row["ambiguity_note"]
    # the full sentence as the quote is not truncated
    full = dict(pr, verbatim_quote="Do not bill 11975 unless prior authorization is obtained.")
    assert ex.ground(full, sec)["quote_truncates_condition"] is False


def test_d2d_verbatim_quote_is_the_source_text_not_the_model_text():
    src = "A maximum of four units per day applies to code 98960."
    sec = _sec("Community health workers are covered. " + src)
    # fuzzy: model paraphrased one non-meaning word
    fuzzy = {"statement": "s", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
             "codes": ["98960"], "verbatim_quote": "A maximum of four units per day is applied to code 98960.",
             "confidence": 0.8}
    g = ex.ground(fuzzy, sec)
    assert g["keep"] and g["quote_found"] == "fuzzy" and g["source_quote"] == src
    row = ex.to_draft_row(fuzzy, g, sec, INV, _Fixed([]), "r")
    assert row["verbatim_quote"] == src and row["model_quote"] == fuzzy["verbatim_quote"]
    assert f'Verbatim: "{src}"' in row["notes"]
    # exact (after normalisation): original casing from the source, no model_quote
    exact = dict(fuzzy, verbatim_quote="a MAXIMUM of four units  per day applies to code 98960")
    g = ex.ground(exact, sec)
    row = ex.to_draft_row(exact, g, sec, INV, _Fixed([]), "r")
    assert g["quote_found"] == "exact"
    assert row["verbatim_quote"] == src and row["model_quote"] is None


def test_d2e_dropped_word_number_is_drift_not_fuzzy():
    sec = _sec("Providers may bill a maximum of four units per day for code 98960.")
    pr = {"statement": "s", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
          "codes": ["98960"], "verbatim_quote": "Providers may bill a maximum of units per day for code 98960.",
          "confidence": 0.8}
    g = ex.ground(pr, sec)
    assert not g["keep"] and g["quote_found"] == "drift"


def test_d2f_hybrid_merge_keeps_the_pattern_quote():
    pat = dict(RULE_98960, verbatim_quote="A maximum of four units per day applies to 98960.")
    mdl = dict(RULE_98960, verbatim_quote="Per the manual, a maximum of four units per day applies to 98960 "
                                          "for all community health worker services.")
    out = json.loads(ex.HybridBackend(_Fixed([mdl]), _Fixed([pat])).complete("", ""))["rules"]
    assert len(out) == 1 and out[0]["source"] == "pattern+model"
    assert out[0]["verbatim_quote"] == pat["verbatim_quote"] and out[0]["alt_quote"] == mdl["verbatim_quote"]
    # end to end: the corroborated rule still grounds (the longer model quote would not)
    sec = _sec("A maximum of four units per day applies to 98960.")
    hy = ex.HybridBackend(_Fixed([mdl]), _Fixed([pat]))
    drafts, dropped, _ = ex.extract_chapter([sec], INV, hy, "r", cache={}, log_fn=lambda x: None)
    assert len(drafts) == 1 and dropped == [] and drafts[0]["extraction_source"] == "pattern+model"


def test_hybrid_merges_only_the_same_full_predicate_and_shows_a_disagreement():
    """External review 2026-10-17 (B2): the merge key left out provider_types / provider_role (and age, exception,
    dates...), so a pattern H0035 'B2, B5 billing' and a model H0035 '02, 71 servicing' became ONE rule marked
    pattern+model at 0.97. Two readings stay two rules, each naming the other's value, with no confidence bump; a true
    agreement (the same list in another order, '8' vs '08', code vs code_set) is still corroboration."""
    q = "Code H0035 must be billed only by provider types B2 and B5."
    base = {"statement": q, "verbatim_quote": q, "codes": ["H0035"], "population": "all", "confidence": 0.8}
    pat = dict(base, predicate={"type": "provider_type_allowed", "code_set": ["H0035"], "provider_types": ["B2", "B5"],
                                "provider_role": "billing"})
    mdl = dict(base, predicate={"type": "provider_type_allowed", "code_set": ["H0035"], "provider_types": ["02", "71"],
                                "provider_role": "servicing"})
    out = json.loads(ex.HybridBackend(_Fixed([mdl]), _Fixed([pat])).complete("", ""))["rules"]
    assert sorted(r["source"] for r in out) == ["model", "pattern"] and {r["confidence"] for r in out} == {0.8}
    by = {r["source"]: r for r in out}
    assert "pattern and model disagree on provider_role: 'servicing'; provider_types: ['02', '71'] (the model's value)" \
        in by["pattern"]["ambiguity_note"] and by["pattern"]["ambiguous"]
    assert "provider_role: 'billing'; provider_types: ['B2', 'B5'] (the pattern's value)" in by["model"]["ambiguity_note"]
    # one field is enough: an age, an exception or a date makes another rule
    for extra in ({"age": {"below": 21}}, {"exception": "unless authorized"}):
        m2 = dict(pat, predicate=dict(pat["predicate"], **extra))
        assert len(json.loads(ex.HybridBackend(_Fixed([m2]), _Fixed([pat])).complete("", ""))["rules"]) == 2
    assert len(json.loads(ex.HybridBackend(_Fixed([dict(pat, effective_date="2024-10-01")]),
                                           _Fixed([pat])).complete("", ""))["rules"]) == 2
    # a true agreement: same list in another order, the role left to its default, code instead of code_set
    same = dict(base, predicate={"type": "provider_type_allowed", "code": "H0035", "provider_types": ["B5", "B2"]})
    out = json.loads(ex.HybridBackend(_Fixed([same]), _Fixed([pat])).complete("", ""))["rules"]
    assert len(out) == 1 and out[0]["source"] == "pattern+model" and out[0]["confidence"] == 0.9
    assert not out[0].get("ambiguity_note")
    # review of 1beb482: identity is what the compiler reads - a field it never reads (service_category of a state
    # code_not_covered, a cap's unit) never splits an agreement; a field one side leaves out reads "(absent)"
    nc = dict(base, codes=["11975"], predicate={"type": "code_not_covered", "code": "11975"})
    for extra in ({"service_category": "family_planning"}, {"unit": "units"}):
        m2 = dict(nc, predicate=dict(nc["predicate"], **extra))
        assert [r["source"] for r in json.loads(ex.HybridBackend(_Fixed([m2]), _Fixed([nc])).complete("", ""))["rules"]] \
            == ["pattern+model"]
    exc = dict(pat, predicate=dict(pat["predicate"], exception="unless authorized"))
    by = {r["source"]: r for r in json.loads(ex.HybridBackend(_Fixed([exc]), _Fixed([pat])).complete("", ""))["rules"]}
    assert "disagree on exception: 'unless authorized' (the model's value)" in by["pattern"]["ambiguity_note"]
    assert "disagree on exception: (absent) (the pattern's value)" in by["model"]["ambiguity_note"]


# ==================================================================== D2b
def test_d2b_extraction_source_is_recorded_for_every_backend():
    sec = _sec("A maximum of four units per day applies to 98960.")
    pr = dict(RULE_98960)
    g = ex.ground(pr, sec)
    assert ex.to_draft_row(pr, g, sec, INV, ex.StubBackend(), "r")["extraction_source"] == "pattern"
    row = ex.to_draft_row(pr, g, sec, INV, ex.HFLocalBackend(), "r")
    assert row["extraction_source"] == "model" and "Found by: model" in row["notes"]
    hy_pr = dict(pr, source="pattern+model")
    assert ex.to_draft_row(hy_pr, g, sec, INV, ex.StubBackend(), "r")["extraction_source"] == "pattern+model"


def test_gpu_notebook_tallies_by_extraction_source_and_runs_one_chapter():
    src = open(os.path.join(PKG, "notebooks", "04_extract_chapters_gpu.py")).read()
    assert 'CHAPTERS_TO_RUN = ["19"]' in src and 'LLM_BACKEND     = "HYBRID"' in src
    assert 'd.get("extraction_source")' in src
    assert "outcomes=outcome_rows" in src and "outcome_rows=outcome_rows" in src
    per = open(os.path.join(PKG, "notebooks", "05_persist_extraction.py")).read()
    assert "policy_extraction_outcomes" in per and 'run["outcomes"]' in per


# ===================================================================== D11
def test_d11_every_section_gets_an_outcome_and_cache_keeps_the_reason():
    class _Scripted(ex.Backend):
        name, model = "SCRIPT", "s"

        def __init__(self): self.calls = 0

        def complete(self, s, u):
            self.calls += 1
            if "BOOM" in u:
                raise TimeoutError("endpoint")
            if "98960" in u:
                return json.dumps({"rules": [RULE_98960], "no_rule_reason": None})
            if "99999" in u:
                return json.dumps({"rules": [dict(RULE_98960, verbatim_quote="invented text that is nowhere")],
                                   "no_rule_reason": None})
            return json.dumps({"rules": [], "no_rule_reason": "section describes enrollment only"})

    secs = [_sec("Narrative only.", "skip", candidate=False),
            _sec("Enrollment is handled by the plan.", "none"),
            _sec("A maximum of four units per day applies to 98960.", "rule"),
            _sec("Code 99999 text.", "drop"),
            _sec("BOOM", "fail")]
    # 150 non-candidates: the old 100-heading cap lost the tail
    secs += [_sec(f"Narrative {i}.", f"n{i}", candidate=False) for i in range(150)]
    b, cache, outcomes = _Scripted(), {}, []
    drafts, dropped, st = ex.extract_chapter(secs, INV, b, "r1", cache=cache, log_fn=lambda x: None,
                                             outcomes=outcomes)
    assert len(outcomes) == len(secs) and st["sections_skipped_noncandidate"] == 151
    by = {o["section_id"]: o for o in outcomes}
    assert by["skip"]["outcome"] == "skipped_prefilter" and by["n149"]["outcome"] == "skipped_prefilter"
    assert by["none"]["outcome"] == "no_rules" and by["none"]["reason"] == "section describes enrollment only"
    assert by["rule"]["outcome"] == "proposals" and by["rule"]["n_grounded"] == 1 and by["rule"]["n_dropped"] == 0
    assert by["drop"]["outcome"] == "proposals" and by["drop"]["n_dropped"] == 1
    assert by["fail"]["outcome"] == "failed_retryable" and by["fail"]["reason"].startswith("backend error")
    o = by["rule"]
    assert (o["chapter"], o["doc_hash"], o["run_id"], o["page_start"], o["page_end"], o["from_cache"]) == \
           ("19", "h19", "r1", 3, 4, False)
    assert set(o) >= {"heading", "n_proposals"}
    # a cache hit keeps the model's no-rule reason
    outcomes2 = []
    ex.extract_chapter(secs, INV, b, "r2", cache=cache, log_fn=lambda x: None, outcomes=outcomes2)
    by2 = {o["section_id"]: o for o in outcomes2}
    assert by2["none"]["from_cache"] is True and by2["none"]["reason"] == "section describes enrollment only"
    assert by2["rule"]["from_cache"] is True and by2["rule"]["n_grounded"] == 1
    assert by2["fail"]["from_cache"] is False                              # never cached, retried
    # dropped rows are traceable to chapter / codes / doc / pages
    d = dropped[0]
    assert (d["chapter"], d["doc_hash"], d["page_start"], d["page_end"]) == ("19", "h19", 3, 4)
    assert json.loads(d["codes"]) == ["98960"]


def test_d11_old_plain_list_cache_entries_still_read():
    sec = _sec("A maximum of four units per day applies to 98960.")
    b = ex.StubBackend()
    ck = ex.cache_key(sec, b)                          # C3-08: one helper builds the key everywhere
    assert ck == f"{sec['text_hash']}|{ex.PROMPT_VERSION}|{b.name}|{b.model}"   # STUB keys keep their shape
    cache = {ck: [dict(RULE_98960)], "other": []}
    outcomes = []
    drafts, _, st = ex.extract_chapter([sec], INV, b, "r", cache=cache, log_fn=lambda x: None, outcomes=outcomes)
    assert st["sections_from_cache"] == 1 and len(drafts) == 1
    assert outcomes[0]["from_cache"] is True and outcomes[0]["outcome"] == "proposals"


def test_d11_outcomes_file_round_trips(tmp_path):
    assert extract_io.RUN_FILES["outcomes"] == "outcomes.jsonl"
    run_dir = extract_io.new_run_dir(str(tmp_path), "r1")
    rows = [{"chapter": "19", "section_id": "s", "outcome": "no_rules", "reason": "x", "from_cache": False}]
    counts = extract_io.write_run(run_dir, inventory_rows=[], section_rows=[], log_rows=[], dropped_rows=[],
                                  change_rows=[], drafts=[], cache={}, manifest={"finished": True},
                                  outcome_rows=rows)
    assert counts["outcomes"] == 1 and extract_io.read_run(run_dir)["outcomes"] == rows


def test_daily_cap_accepts_code_set_and_ingest_requires_known_reason():
    from extract_rules import predicate_valid
    ok, _ = predicate_valid({"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4})
    assert ok
    ok, why = predicate_valid({"type": "max_units_per_line", "code_set": ["98960"], "threshold": 4})
    assert not ok and "missing code" in why          # the per-line compiler reads p["code"] only
    assert predicate_valid({"type": "not_checkable", "reason": "requires_provider_attribute"})[0]
    ok, why = predicate_valid({"type": "not_checkable", "reason": "requires_provider_attribute"}, strict_reason=True)
    assert not ok and "unknown not_checkable reason" in why


# ===================================================================== 2026-10-19 (SB's ch19 runs)
HUB = ("H2012 shall not be billed with H0036, H2015, H0018, H0014 or H0035.\n\n"
       "H2015 shall not be billed with H2012, H2016, H0036 or H0018.\n\n"
       "H2019 shall not be billed with H2020, H2015 or H2012.\n\n"
       "H0036 may not be billed with H0037, H2015 or H2012.")


class _Capacity(ex.Backend):
    """A model that runs out of budget (or GPU memory) on any text longer than `limit` characters."""
    name, model = "FAKE", "fake"

    def __init__(self, limit, exc):
        self.limit, self.exc, self.calls = limit, exc, 0

    def complete(self, s, u):
        self.calls += 1
        text = u.split('"""')[1]
        if len(text) > self.limit:
            raise self.exc
        return json.dumps({"rules": [], "no_rule_reason": "fake: nothing"})


def test_a_capacity_failure_keeps_the_sections_pattern_rules_and_stays_retryable():
    """Low lost the S5151 respite list (21 signed pairs) and medium the six hub lists of the day-program section: the
    model was truncated even after two splits, and the HYBRID run dropped the deterministic pattern pairs with it."""
    hy = ex.HybridBackend(_Capacity(10, ex.ModelOutputTruncated("final channel truncated")), ex.StubBackend())
    sec = dict(_sec(HUB), heading="BEHAVIORAL HEALTH DAY PROGRAM")
    cache, outcomes = {}, []
    drafts, _, st = ex.extract_chapter([sec], INV, hy, "r", cache=cache, log_fn=lambda x: None, outcomes=outcomes)
    assert drafts and {d["extraction_source"] for d in drafts} == {"pattern"}
    assert any(json.loads(d["predicate"])["type"] == "code_pair_prohibited" for d in drafts)
    assert all("the model failed on this section" in (d.get("ambiguity_note") or "") for d in drafts)
    assert cache == {} and outcomes[0]["outcome"] == "failed_retryable"          # retried next run, never cached
    assert st["model_failed"] == 1 and st["sections_pattern_fallback"] == 1
    # a transient failure is only retried (D1: never silently patterns-only)
    hy = ex.HybridBackend(_Raw("Sorry, no JSON."), ex.StubBackend())
    drafts, _, st = ex.extract_chapter([sec], INV, hy, "r", cache={}, log_fn=lambda x: None)
    assert drafts == [] and "sections_pattern_fallback" not in st


def test_out_of_gpu_memory_splits_the_section_like_a_truncated_answer():
    class OutOfMemoryError(RuntimeError):
        pass
    long_text = "\n\n".join([HUB] * 4)                          # ~1,000 characters: two splits to fit 300
    model = _Capacity(300, OutOfMemoryError("CUDA out of memory. Tried to allocate 4.36 GiB"))
    hy = ex.HybridBackend(model, ex.StubBackend())
    info = {}
    props, why = ex.propose(dict(_sec(long_text)), INV, hy, info=info)
    assert why is None or not ex._retryable(why), why          # the pieces fit: no failure
    assert info["split_depth"] >= 2 and model.calls > 3
    assert ex.SPLIT_MAX_DEPTH == 4


def test_a_reason_written_as_the_type_is_a_lead_not_a_drop():
    import post_checks as pc
    prop, acts = pc.repair({"statement": "PA", "verbatim_quote": "All admissions to a BHRF require prior authorization.",
                            "predicate": {"type": "process_obligation"}, "codes": ["H0018"]})
    assert prop["predicate"] == {"type": "not_checkable", "reason": "process_obligation"}
    assert [a["check"] for a in acts] == ["reason_as_type"]


def test_claim_form_sentences_reach_the_model():
    import policy_docs as pdx
    for t in ("Inpatient services are billed on the UB-04 claim form and are reimbursed on a per diem basis.",
              "All outpatient and professional services are billed on a CMS 1500 Claim Form.",
              "All other BH counseling and therapy services should be billed using the applicable HCPCS codes."):
        assert pdx.rule_signal(t)["score"] > 0, t
    assert pdx.rule_signal("The provider may be directed to the customer service unit.")["score"] == 0


# ===================================================================== 2026-10-20 (SB's ch19 reruns)
class _BigAnswer(ex.Backend):
    """An HFLOCAL-like model whose answer for one long hub sentence needs more than its normal budget: it answers
    only when propose() sets budget_override (the last-resort call)."""
    name, model = "HFLOCAL", "fake"

    def __init__(self):
        self.budget_override, self.calls, self.overrides = None, 0, []

    def budget(self):
        return 3000

    def complete(self, s, u):
        self.calls += 1
        self.overrides.append(self.budget_override)
        if not self.budget_override:
            raise ex.ModelOutputTruncated("final channel truncated (incomplete JSON) after 5400/5400 tokens")
        q = "H2012 shall not be billed with H0036, H2015, H0018, H0014 or H0035."
        return json.dumps({"rules": [{"statement": "H2012 / H0036", "verbatim_quote": q, "codes": ["H0036", "H2012"],
                                      "predicate": {"type": "code_pair_prohibited", "code_a": "H0036",
                                                    "code_b": "H2012", "scope": "member_provider_day",
                                                    "modifier_indicator": "0"}, "confidence": 0.8}],
                           "no_rule_reason": None})


def test_an_unsplittable_piece_gets_one_last_call_at_a_larger_budget():
    """Each ch19 run lost the same section on every run: one sentence listing 21 partner codes needs more output than
    the budget, and a sentence cannot be split. One last call at LAST_RESORT_BUDGET_FACTOR x the budget finishes it."""
    model = _BigAnswer()
    hy = ex.HybridBackend(model, ex.StubBackend())
    sec = _sec("H2012 shall not be billed with H0036, H2015, H0018, H0014 or H0035.")      # one short sentence
    cache, outcomes = {}, []
    drafts, _, st = ex.extract_chapter([sec], INV, hy, "r", cache=cache, log_fn=lambda x: None, outcomes=outcomes)
    assert model.overrides == [None, 12000] and model.budget_override is None              # reset after the call
    assert outcomes[0]["outcome"] == "proposals" and len(cache) == 1 and st["last_resort_calls"] == 1
    assert any(d["extraction_source"] in ("model", "pattern+model") for d in drafts)
    # out of GPU memory never gets the larger budget (it would need more memory, not less)
    class OutOfMemoryError(RuntimeError):
        pass

    class _Oom(_BigAnswer):
        def complete(self, s, u):
            self.calls += 1
            self.overrides.append(self.budget_override)
            raise OutOfMemoryError("CUDA out of memory")
    m2 = _Oom()
    props, why = ex.propose(sec, INV, ex.HybridBackend(m2, ex.StubBackend()), info={})
    assert 12000 not in m2.overrides and ex._retryable(why)


def test_a_rerun_reuses_earlier_answers_and_asks_only_for_the_rest(tmp_path):
    a = extract_io.new_run_dir(str(tmp_path), "A")
    extract_io.write_cache(a, {"k1": {"proposals": [], "no_rule_reason": "x"}, "k2": {"proposals": []}})
    cache = {"k2": {"proposals": ["mine"]}}
    assert extract_io.reuse_answers(str(tmp_path), ["A"], cache) == {"A": 1}
    assert cache["k2"] == {"proposals": ["mine"]} and "k1" in cache            # answers already present win
    with pytest.raises(FileNotFoundError):
        extract_io.reuse_answers(str(tmp_path), ["missing"], {})
    src = open(os.path.join(PKG, "notebooks", "04_extract_chapters_gpu.py")).read()
    assert "REUSE_ANSWERS_FROM = []" in src and "extract_io.reuse_answers(RUN_ROOT, REUSE_ANSWERS_FROM, cache)" in src


def test_a_hub_list_run_into_the_next_block_still_gives_its_pairs():
    """Both ch19 runs produced no pair for the H2015, H2020 and H0037 lists (about 55 pairs): the PDF runs the list into
    the next line without a period ("... or H0015 Therapeutic H2019 -", "... or H0030 NOTE: ...", "... or H0030 Refer
    to AMPM ..."), which read as words after the list. A capitalised condition or a lower-case tail still makes a lead."""
    cases = {
        "H2015": ("Billing Unit: 15 minutes • H2015 shall not be billed with H2012, H2016, H0036, H0018, H0014, H0035, "
                  "H2020, H2018, H2016, H2026, H0037, S109, T1020, S5151, S9480, or H0015 Therapeutic H2019 – "
                  "Therapeutic Behavioral Services: See general definition above.", 14),
        "H2020": ("Billing Unit: Per Diem • H2020 shall not be billed with H2015, H0036, H0001, H0002, H0004, H0006, "
                  "H0025, H0034, H0036, H2012, H2014, H2015, H2017, H2019, H2025, H2027, H2033, S5150. T1019. H0031, "
                  "H0038, or H0030 NOTE: A professional who supervises therapeutic BH services and day programs using "
                  "the per diem codes may not bill this function separately.", 20),
        "H0037": ("H0037 may not be billed with H0036, H2015, H0001, H0002, H0004, H0006, H0025, H0034, H0036, H2012, "
                  "H2014, H2015, H2017, H2019, H2025, H2027, H2033, S5150. T1019. H0031, H0038, or H0030 Refer to AMPM "
                  "310-B – Title XIX XXI BH Service Benefit for more information.", 20),
        "condition": ("H2012 shall not be billed with H0036, H2015 or H0018 For members enrolled in ALTCS.", 0),
        "lower": ("H2012 shall not be billed with H0036, H2015 or H0018 in a residential setting.", 0),
    }
    for name, (text, n) in cases.items():
        drafts, _, _ = ex.extract_chapter([_sec(text, sid=name)], INV, ex.StubBackend(), "r", cache={},
                                          log_fn=lambda x: None)
        pairs = [json.loads(d["predicate"]) for d in drafts
                 if json.loads(d["predicate"])["type"] == "code_pair_prohibited"]
        assert len(pairs) == n, (name, len(pairs))
        assert all(p["code_b"] == name for p in pairs) if n else True


def test_a_reused_hybrid_answer_gets_the_current_pattern_rules():
    """2026-10-21: the cache holds the merged pattern + model answer and its key has no pattern version, so a pattern
    fix (the hub-list reader) never reached a reused answer (REUSE_ANSWERS_FROM). The pattern half is rerun on every
    cache read and merged with the cached model half; unchanged patterns give back the cached answer exactly."""
    text = ("H2015 shall not be billed with H2012, H0036 or H0018. A maximum of four units per day applies to 98960.")
    mdl = [dict(RULE_98960, confidence=0.8), {"statement": "a lead", "predicate": {"type": "not_checkable",
           "reason": "predicate_not_in_grammar"}, "codes": ["H2015"], "confidence": 0.6,
           "verbatim_quote": "H2015 shall not be billed with H2012, H0036 or H0018."}]
    hy = ex.HybridBackend(_Fixed(mdl), ex.StubBackend())
    sec, cache = _sec(text), {}
    first, _, st1 = ex.extract_chapter([sec], INV, hy, "r1", cache=cache, log_fn=lambda x: None)
    again, _, st2 = ex.extract_chapter([sec], INV, hy, "r2", cache=copy.deepcopy(cache), log_fn=lambda x: None)
    assert st2["sections_from_cache"] == 1 and not st2.get("cache_patterns_changed")

    def view(ds):
        return sorted((d["predicate"], d["extraction_confidence"], d["verbatim_quote"], d["extraction_source"],
                       d["ambiguity_note"] or "", d["model_quote"] or "") for d in ds)
    assert view(first) == view(again)

    # an answer cached by older pattern code that missed the hub pairs: they come back, the model's rules stay
    (ck, entry), = cache.items()
    old = copy.deepcopy(cache)
    old[ck]["proposals"] = [p for p in entry["proposals"] if p["source"] != "pattern"]
    assert len(old[ck]["proposals"]) < len(entry["proposals"])
    redo, _, st3 = ex.extract_chapter([sec], INV, hy, "r3", cache=old, log_fn=lambda x: None)
    assert st3["cache_patterns_changed"] == 1
    assert view(redo) == view(first)
    pairs = [json.loads(d["predicate"]) for d in redo if json.loads(d["predicate"])["type"] == "code_pair_prohibited"]
    assert {p["code_a"] for p in pairs} == {"H2012", "H0036", "H0018"}


def test_model_half_undoes_the_corroboration_and_the_old_pattern_notes():
    pat = dict(RULE_98960, confidence=0.9, verbatim_quote="A maximum of four units per day applies to 98960.")
    mdl = dict(RULE_98960, confidence=0.7, verbatim_quote="maximum of four units per day applies to 98960 code")
    hy = ex.HybridBackend(_Fixed([mdl]), _Fixed([pat]))
    merged = json.loads(hy.complete("", ""))["rules"]
    assert merged[0]["source"] == "pattern+model" and merged[0]["confidence"] == 0.97
    back = ex.HybridBackend.model_half(merged)
    assert back[0]["source"] == "model" and back[0]["verbatim_quote"] == mdl["verbatim_quote"]
    assert "alt_quote" not in back[0]
    fresh = [dict(copy.deepcopy(pat), source="pattern")]
    assert json.loads(hy.merge(fresh, back))["rules"] == merged
    note = {"source": "model", "predicate": {"type": "x"}, "ambiguous": True,
            "ambiguity_note": "pattern and model disagree on threshold: 4 (the pattern's value)."}
    b = ex.HybridBackend.model_half([note])[0]
    assert b["ambiguous"] is False and not b["ambiguity_note"]
    keep = dict(note, ambiguity_note="the sentence names two limits. pattern and model disagree on threshold: 4 "
                                     "(the pattern's value).")
    b = ex.HybridBackend.model_half([keep])[0]
    assert b["ambiguous"] is True and b["ambiguity_note"] == "the sentence names two limits."


def test_every_run_records_the_package_version_and_the_extraction_code():
    """v6.3: a run folder recorded the prompt but not the code that turned answers into drafts; two runs of the same
    prompt with other code could not be told apart."""
    import config
    import hashlib
    assert config.PIE_VERSION == "6.3" and len(ex.CODE_SHA) == 12
    h = hashlib.sha256()
    for f in ex.EXTRACTION_CODE_FILES:
        h.update(f.encode() + b"\0" + open(os.path.join(PKG, f), "rb").read())
    assert ex.CODE_SHA == h.hexdigest()[:12]
    nb = open(os.path.join(PKG, "notebooks", "04_extract_chapters_gpu.py")).read()
    assert '"code_sha": extract_rules.CODE_SHA' in nb and '"pie_version"' in nb
    assert ex.PROMPT_VERSION == "v3"           # the prompt did not change: answers stay reusable
