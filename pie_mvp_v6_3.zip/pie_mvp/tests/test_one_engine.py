"""One extraction engine in the KB (SB, 2026-10-04: "I want to fresh and to keep rules that are extracted using the
same version of extraction"). The hand-written rules are a checklist v05 scores runs against, not KB rules; a rule an
older engine produced stays out until the current engine produces it again.

  config.COMPILE_HAND_AUTHORED  False (default): hand-authored rules (origin 'manual') are never exported for review
                                and never compiled
  config.KB_PROMPT_VERSIONS     ("v2", "v3"): an extracted rule compiles only when the LAST run that produced it
                                (extraction_run_id) used one of these prompt versions (policy_extraction_log)
  state_rules.merge_drafts      a DECIDED row the new run produced again names that run (its decision untouched)
Run: cd pie_mvp && python -m pytest tests/test_one_engine.py -q
"""
import json
import os
import sys

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import state_rules as sr  # noqa: E402

PRED = {"type": "code_not_covered", "code": "11975"}


def _row(key, origin="extracted", status="approved", run="R2", **kw):
    r = {c: None for c in sr.STATE_RULE_COLUMNS}
    r.update(rule_id=("EXT-" if origin == "extracted" else "MAN-") + key, extraction_key=key if origin == "extracted"
             else None, origin=origin, chapter="10", doc_hash="D10" if origin == "extracted" else None,
             statement=f"rule {key}", predicate=json.dumps(PRED), codes=json.dumps(["11975"]), population="all",
             review_status=status, reviewer="SB" if status == "approved" else None, plane="coverage_scope",
             binding_status="state_policy", machine_checkable=True, extraction_run_id=run if origin == "extracted"
             else None, source_doc="Chapter 10", source_locator="page 3", source_url="https://x")
    r.update(kw)
    return r


RUNS = {"R1": "v1", "R2": "v2"}


def _ids(rules):
    """The rows a list of Rule objects came from (row_to_rule leaves the content id to 07's normaliser)."""
    return sorted(("MAN-" if r.origin == "manual" else "EXT-") + r.statement.split()[-1] for r in rules)


def test_only_rules_of_the_current_engine_compile(monkeypatch):
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", False)
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ("v2",))
    df = pd.DataFrame([_row("new", run="R2"), _row("old", run="R1"), _row("lost", run="R9"),
                       _row("seed", origin="manual", status="approved")])
    rep = {}
    got = sr.rules_from_frame(df, current_doc_hash={"10": "D10"}, report=rep, run_prompt=RUNS)
    assert _ids(got) == ["EXT-new"]
    why = {r["rule_id"]: r["reason"] for r in rep["engine_excluded"]}
    assert why == {"EXT-old": "other_engine", "EXT-lost": "engine_unknown", "MAN-seed": "hand_authored"}
    # the switches, one at a time
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ())                      # any engine
    assert _ids(sr.rules_from_frame(df, current_doc_hash={"10": "D10"}, run_prompt=RUNS)) == [
        "EXT-lost", "EXT-new", "EXT-old"]
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", True)                 # hand-authored once signed
    assert "MAN-seed" in _ids(sr.rules_from_frame(df, current_doc_hash={"10": "D10"}, run_prompt=RUNS))
    # run_prompt None (a caller that does not apply the rule): unchanged behaviour
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", False)
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ("v2",))
    assert len(sr.rules_from_frame(df, current_doc_hash={"10": "D10"})) == 4


def test_decided_readings_of_one_sentence_all_compile_duplicates_once_and_differences_block_done(monkeypatch):
    """Second review 2026-10-17 (finding 4) and the final critic: 07 never drops a signed rule because another signed
    rule reads the same sentence (automatic grouping dropped correct rules and let wrong ones through). Rules that
    compile to the same SQL (schema.compiled_identity: 4 = 4.0, scope omitted = its default, indicator 0 = "0",
    service_category not read) compile ONCE (rule_normalize.collapse_state_duplicates); readings of one sentence that
    differ all compile. Readings of one run were decided side by side: never listed. Readings of different runs are
    listed in the build log and keep v03's explained bar NOT YET until the later decision says "keep both"."""
    import quality
    import rule_normalize as rn
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ())
    m = "Code 98960 is limited to 4 units per month."
    per = lambda k, n, pd_: _row(k, verbatim_quote=m, codes=json.dumps(["98960"]), predicate=json.dumps(  # noqa: E731
        {"type": "max_units_per_period", "code_set": ["98960"], "threshold": n, "period": pd_}))
    s1 = "Service codes H2025, H2026, and H2027 cannot be billed on the same day."
    pair = lambda k, a_, b_, **x: _row(k, verbatim_quote=s1, codes=json.dumps(sorted([a_, b_])),  # noqa: E731
                                       predicate=json.dumps({"type": "code_pair_prohibited", "code_a": a_, "code_b": b_,
                                                             **x}))
    s3 = "Code 98960 is limited to 4 units per day for members under 21 and 2 units per day for members 21 and older."
    age = lambda k, n, ag: _row(k, verbatim_quote=s3, codes=json.dumps(["98960"]), predicate=json.dumps(  # noqa: E731
        {"type": "max_units_per_day", "code": "98960", "threshold": n, "age": ag}))
    d = "Code 98960 is limited to 4 units per day."
    day = lambda k, **x: _row(k, verbatim_quote=d, codes=json.dumps(["98960"]), predicate=json.dumps(  # noqa: E731
        {"type": "max_units_per_day", "code": "98960", "threshold": 4, **x}))
    rows = [per("m4", 4, "month"), per("y4", 4, "year"),                                    # two readings, one sentence
            pair("p1", "H2025", "H2026", modifier_indicator="0"), pair("p2", "H2026", "H2025", modifier_indicator="0"),
            age("g1", 4, {"below": 21}), age("g2", 2, {"min": 21}),
            day("t1"), day("t2", threshold=4.0)]                                             # the same reading twice
    rep = {}
    got = sr.rules_from_frame(pd.DataFrame(rows), current_doc_hash={"10": "D10"}, report=rep)
    assert _ids(got) == ["EXT-g1", "EXT-g2", "EXT-m4", "EXT-p1", "EXT-p2", "EXT-t1", "EXT-t2", "EXT-y4"]  # all signed
    assert rep["stale"] == [] and rep["same_sentence_readings"] == []          # one run (R2): decided side by side
    # different runs: listed (4 vs 4.0 is one reading), until the later decision's note says "keep both"
    rows2 = [dict(r, extraction_run_id="R1", reviewed_at="2026-10-05") if r["extraction_key"] in ("m4", "p1", "t1")
             else dict(r, reviewed_at="2026-10-06") for r in rows]
    rep = {}
    sr.rules_from_frame(pd.DataFrame(rows2), current_doc_hash={"10": "D10"}, report=rep)
    assert [x["rule_ids"] for x in rep["same_sentence_readings"]] == [["EXT-m4", "EXT-y4"], ["EXT-p1", "EXT-p2"]]
    rows3 = [dict(r, review_note="Keep both: the cap per month and the cap per year") if r["extraction_key"] == "y4"
             else r for r in rows2]
    rep3 = {}
    sr.rules_from_frame(pd.DataFrame(rows3), current_doc_hash={"10": "D10"}, report=rep3)
    assert [x["rule_ids"] for x in rep3["same_sentence_readings"]] == [["EXT-p1", "EXT-p2"]]
    for note in ("do NOT keep both: reject m4", "should we keep both?"):          # only a note that STARTS with it
        r4 = [dict(r, review_note=note) if r["extraction_key"] == "y4" else r for r in rows2]
        assert ["EXT-m4", "EXT-y4"] in [x["rule_ids"] for x in sr.same_sentence_readings(pd.DataFrame(r4))]
    # one sentence, overlapping codes: a combined code_set cap vs one code's own cap, a daily cap vs a per-provider one
    two = "H2014 and H2017 are limited to 4 units per day."
    cap = lambda k, run, **p_: dict(_row(k, verbatim_quote=two, codes=json.dumps(sorted(p_.get("code_set") or  # noqa
                                                                                       [p_["code"]])),
                                         predicate=json.dumps(dict({"type": "max_units_per_day", "threshold": 4}, **p_))),
                                    extraction_run_id=run, reviewed_at=run)
    lst = sr.same_sentence_readings(pd.DataFrame([cap("c1", "R1", code_set=["H2014", "H2017"]),
                                                  cap("c2", "R2", code="H2014"), cap("c3", "R2", code="H2017")]))
    assert [x["rule_ids"] for x in lst] == [["EXT-c1", "EXT-c2", "EXT-c3"]]
    dos = lambda k, run: dict(cap(k, run, code="H2014"), predicate=json.dumps(  # noqa: E731
        {"type": "max_units_per_dos", "code": "H2014", "threshold": 4}))
    lst = sr.same_sentence_readings(pd.DataFrame([cap("d1", "R1", code="H2014"), dos("d2", "R2")]))
    assert [x["rule_ids"] for x in lst] == [["EXT-d1", "EXT-d2"]]                   # any provider vs one provider
    mpd = [cap("d3", "R1", code="H2014", scope="member_provider_day"), dos("d4", "R2")]
    assert sr.same_sentence_readings(pd.DataFrame(mpd)) == []                        # the same SQL ...
    loaded = sr.rules_from_frame(pd.DataFrame(mpd), current_doc_hash={"10": "D10"})
    assert len(rn.collapse_state_duplicates([r.to_dict() for r in loaded])[0]) == 1  # ... compiles once
    # equal compiler-read predicates compile once
    eq = [(day("e1"), day("e2", threshold=4.0)),
          (pair("f1", "H2025", "H2026", modifier_indicator=0), pair("f2", "H2025", "H2026", modifier_indicator="0",
                                                                      scope="member_provider_day")),
          (pair("s1", "H2025", "H2026", modifier_indicator="0"), pair("s2", "H2025", "H2026", modifier_indicator="0",
                                                                       service_category="state")),
          (age("a1", 4, {"min": 21}), age("a2", 4, {"min": 21.0}))]
    for x, y in eq:
        loaded = sr.rules_from_frame(pd.DataFrame([x, y]), current_doc_hash={"10": "D10"})
        assert len(loaded) == 2 and len(rn.collapse_state_duplicates([r.to_dict() for r in loaded])[0]) == 1
    # the build log's list keeps v03's explained bar NOT YET
    ex = pd.DataFrame([{"rule_id": r, "category": "in_latest_review", "near_duplicate_of": None}
                       for r in ("EXT-m4", "EXT-y4")], columns=quality.EXPLANATION_COLUMNS)
    assert quality.explained_bar(ex)[0]
    ok, why = quality.explained_bar(ex, rep["same_sentence_readings"])
    assert not ok and "two decided readings of one sentence: EXT-m4 / EXT-y4: confirm both or reject one" in why


def test_a_decided_rule_the_new_engine_reproduces_names_the_new_run():
    """The merge keeps a decided row (never downgraded) but records that the new run produced it again - otherwise the
    one-engine rule would drop an approved rule the current engine DID reproduce."""
    approved = _row("k1", status="approved", run="R1", approved_predicate_sha256="abc")
    rejected = _row("k2", status="rejected", run="R1")
    gone = _row("k3", status="approved", run="R1")                                # the new run does not produce it
    new = [_row("k1", status="draft", run="R2", extraction_backend="HYBRID:gpt-oss-120b"),
           _row("k2", status="draft", run="R2")]
    merged, counts = sr.merge_drafts(pd.DataFrame([approved, rejected, gone]), new, run_id="R2")
    m = {r["extraction_key"]: r for r in merged.to_dict("records")}
    assert counts["reproduced_decided"] == 2 and counts["kept_reviewed"] == 1 and counts["kept_rejected"] == 1
    assert m["k1"]["extraction_run_id"] == "R2" and m["k1"]["review_status"] == "approved"
    assert m["k1"]["reviewer"] == "SB" and m["k1"]["approved_predicate_sha256"] == "abc"
    assert m["k1"]["extraction_backend"] == "HYBRID:gpt-oss-120b"
    assert m["k2"]["extraction_run_id"] == "R2" and m["k2"]["review_status"] == "rejected"
    assert m["k3"]["extraction_run_id"] == "R1"                                    # only an older engine produced it
    # the same merge again changes nothing more
    _, again = sr.merge_drafts(merged, new, run_id="R2")
    assert again["reproduced_decided"] == 0


class _Spark:
    def __init__(self, rows):
        self.rows = rows

    def table(self, name):
        rows = self.rows
        return type("T", (), {"toPandas": lambda self: pd.DataFrame(rows)})()


def test_a_decided_rule_the_same_engine_does_not_reproduce_stays_decided(monkeypatch):
    """Run-to-run instability (Ch.19: a second run of the same engine on the same PDF did not reproduce 21 of 84 drafts
    the reviewers had decided). The run that superseded those drafts landed before the workbook was ingested, and 06
    ignored every decision on them ('row is superseded'). A decision on such a draft now applies, and the rule compiles
    under the one-engine gate; a NEW document version still sends an unreproduced approval back for re-sign."""
    import kb_io
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ("v2",))
    runs = {"R2": "v2", "R3": "v2"}
    draft = _row("k1", status="draft", run="R2", reviewer=None, section_id="S1")
    merged, counts = sr.merge_drafts(pd.DataFrame([draft]), [], rerun={"10": "D10"}, run_id="R3",
                                     completed_sections={"S1"})
    assert counts["superseded"] == 1                                    # R3 (same engine, same PDF) did not produce it
    workbook = sr.review_frame(pd.DataFrame([draft])).assign(decision="Approve", reviewer="SS")
    monkeypatch.setattr(sr, "_xlsx_read", lambda p: workbook)
    written = {}
    monkeypatch.setattr(sr, "write_state_rules", lambda s, t, rows: written.update(rows=rows))
    monkeypatch.setattr(kb_io, "write_table", lambda *a, **k: 0)
    res = sr.ingest_review_decisions(_Spark(merged.to_dict("records")), "t", "wb.xlsx", "log")
    assert res["outcomes"] == ["approved"]
    after = pd.DataFrame(written["rows"])
    assert _ids(sr.rules_from_frame(after, current_doc_hash={"10": "D10"}, run_prompt=runs)) == ["EXT-k1"]
    # the next run of the same engine on the same PDF does not reproduce it either: it stays approved and compiles
    again, _ = sr.merge_drafts(after, [], rerun={"10": "D10"}, run_id="R4", completed_sections={"S1"})
    assert _ids(sr.rules_from_frame(again, current_doc_hash={"10": "D10"}, run_prompt=dict(runs, R4="v2"))) == ["EXT-k1"]
    # a new version of the PDF whose run does not reproduce it: back to needs_review with the decision kept
    new_doc, c2 = sr.merge_drafts(again, [], rerun={"10": "D11"}, run_id="R5")
    r = new_doc.to_dict("records")[0]
    assert c2["resign_not_reproduced"] == 1 and r["review_status"] == "needs_review" and r["doc_hash"] == "D11"
    assert json.loads(r["prior_review"])["reviewer"] == "SS" and "source document changed" in r["review_note"]
    assert sr.rules_from_frame(new_doc, current_doc_hash={"10": "D11"}, run_prompt=runs) == []


def test_an_unreproduced_approval_on_a_new_version_says_whether_its_quote_is_still_there(monkeypatch):
    """Review 2026-10-16: the approval sent back for re-sign on a new document version kept its OLD quote and the
    reviewer was asked to check by hand. The merge now grounds that quote against the new version's sections and says
    so; 06 refuses a plain Approve when the quote is gone (the rule needs a Fix carrying the new sentence)."""
    import kb_io
    quote = "Codes 11975 and 11977 are not covered."
    old = _row("k1", status="approved", run="R2", verbatim_quote=quote, reviewer="SB")
    keeps = [{"chapter": "10", "doc_hash": "D11", "text": "Intro.\n" + quote + "\nOther text."},
             {"chapter": "10", "doc_hash": "D10", "text": "the old version is not read"}]
    drops = [{"chapter": "10", "doc_hash": "D11", "text": "Codes 11975 and 11977 are covered with prior authorization."}]
    notes = {}
    for name, secs in (("kept", keeps), ("gone", drops), ("unknown", None)):
        merged, _ = sr.merge_drafts(pd.DataFrame([old]), [], rerun={"10": "D11"}, run_id="R5", sections=secs)
        notes[name] = merged.to_dict("records")[0]
    assert "- quote found in the new version" in notes["kept"]["review_note"]
    assert "- quote NOT found in the new version" in notes["gone"]["review_note"]
    assert "confirm its sentence is in the new text" in notes["unknown"]["review_note"]
    assert {r["review_status"] for r in notes.values()} == {"needs_review"}
    assert notes["gone"]["verbatim_quote"] == quote and notes["gone"]["doc_hash"] == "D11"
    monkeypatch.setattr(kb_io, "write_table", lambda *a, **k: 0)
    written = {}
    monkeypatch.setattr(sr, "write_state_rules", lambda s, t, rows: written.update(rows=rows))
    outcomes = {}
    for name, decision, fix in (("kept", "Approve", ""), ("gone", "Approve", ""), ("gone", "Fix", ""),
                                ("gone", "Fix", "Codes 11975 and 11977 are covered with prior authorization.")):
        row = notes[name]
        wb = sr.review_frame(pd.DataFrame([row])).assign(decision=decision, reviewer="SS", corrected_rule=fix,
                                                         corrected_predicate=json.dumps(PRED) if decision == "Fix" else "")
        monkeypatch.setattr(sr, "_xlsx_read", lambda p, wb=wb: wb)
        res = sr.ingest_review_decisions(_Spark([row]), "t", "wb.xlsx", "log")
        outcomes[(name, decision, bool(fix))] = (res["outcomes"][0], written["rows"][0]["review_status"])
        if res["outcomes"][0] == "quote_not_in_new_version":
            assert "quote NOT found in the new version" in written["rows"][0]["review_note"]
            assert sr.parked_reason(written["rows"][0]["review_note"]).startswith("quote_not_in_new_version")
    assert outcomes == {("kept", "Approve", False): ("approved", "approved"),
                        ("gone", "Approve", False): ("quote_not_in_new_version", "needs_review"),
                        ("gone", "Fix", False): ("quote_not_in_new_version", "needs_review"),
                        ("gone", "Fix", True): ("fixed", "approved")}


def test_hand_authored_rules_are_not_sent_for_review_by_default(tmp_path, monkeypatch):
    rows = [_row("d1", status="draft"), _row("seed", origin="manual", status="legacy_hand_authored")]
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", False)
    p = sr.export_review_workbook(_Spark(rows), "t", str(tmp_path / "wb.xlsx"))
    assert list(pd.read_excel(p)["origin"]) == ["extracted"]
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", True)
    p = sr.export_review_workbook(_Spark(rows), "t", str(tmp_path / "wb2.xlsx"))
    assert sorted(pd.read_excel(p)["origin"]) == ["extracted", "manual"]


def test_the_switches_read_their_environment(monkeypatch):
    import importlib
    try:
        monkeypatch.setenv("PKB_COMPILE_HAND_AUTHORED", "1")
        monkeypatch.setenv("PKB_KB_PROMPT_VERSIONS", "any")
        importlib.reload(config)
        assert config.COMPILE_HAND_AUTHORED is True and config.KB_PROMPT_VERSIONS == ()
        monkeypatch.setenv("PKB_COMPILE_HAND_AUTHORED", "off")
        monkeypatch.setenv("PKB_KB_PROMPT_VERSIONS", "v2, v3")
        importlib.reload(config)
        assert config.COMPILE_HAND_AUTHORED is False and config.KB_PROMPT_VERSIONS == ("v2", "v3")
    finally:
        monkeypatch.delenv("PKB_COMPILE_HAND_AUTHORED", raising=False)
        monkeypatch.delenv("PKB_KB_PROMPT_VERSIONS", raising=False)
        importlib.reload(config)
    assert config.COMPILE_HAND_AUTHORED is False and config.KB_PROMPT_VERSIONS == ("v2", "v3")
