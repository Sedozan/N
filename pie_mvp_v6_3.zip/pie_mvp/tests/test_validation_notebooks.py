"""Validation notebooks v01 / v03 (2026-10-04, external review of the measurement). They run only on Databricks and in
the Spark e2e. Their behaviour is tested by RUNNING them from source against an in-memory catalog
(tests/test_m51_measurement.py) and the arithmetic in tests/test_quality.py; this file keeps only what no behaviour test
guards: the Databricks cell format, the pass marks, the scoring instructions and the sign-off query (2026-10-16: the
source-text copies of tested behaviour were removed).
Run: cd pie_mvp && python -m pytest tests -q
"""
import ast
import os

HERE = os.path.dirname(__file__)
PKG = os.path.dirname(HERE)


def _src(name):
    return open(os.path.join(PKG, "notebooks", "validation", name)).read()


def _consts(src, *names):
    """Module-level literal assignments of a notebook (column lists, parameters), read without running it."""
    out = {}
    for node in ast.parse(src).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) \
                and node.targets[0].id in names:
            out[node.targets[0].id] = ast.literal_eval(node.value)
    return out


def test_changed_validation_notebooks_compile_and_keep_the_databricks_format():
    for nb in ("v01_extraction_scoring.py", "v03_pipeline_health.py", "v05_extraction_regression.py"):
        src = _src(nb)
        compile(src, nb, "exec")
        assert src.startswith("# Databricks notebook source\n# MAGIC %md"), nb
        assert "\n# COMMAND ----------\n" in src and "PKB_PACKAGE_DIR" in src, nb
        assert "write_table" not in src or nb == "v01_extraction_scoring.py", nb      # v03 / v05 stay read-only


def test_no_notebook_has_code_inside_a_markdown_cell():
    """2026-10-18 (SB's screenshot of 00): a cell that starts with '# MAGIC %md' is a Markdown cell in Databricks; code
    after the heading in the same cell (no '# COMMAND ----------' between them) is shown as text and never runs. Three
    cells of 00_acquire_ncci were like that since v5.2. The local runners execute the code anyway, so only this
    check sees it."""
    import glob
    bad = []
    for f in sorted(glob.glob(os.path.join(PKG, "notebooks", "**", "*.py"), recursive=True)):
        src = open(f).read()
        if not src.startswith("# Databricks notebook source"):
            continue
        for i, cell in enumerate(src.split("\n# COMMAND ----------\n")):
            lines = [ln for ln in cell.split("\n") if ln.strip() and ln != "# Databricks notebook source"]
            if lines and lines[0].startswith("# MAGIC") and any(not ln.startswith("# MAGIC") for ln in lines):
                bad.append(f"{os.path.relpath(f, PKG)} cell {i}: {lines[0][:60]}")
    assert not bad, bad


def test_the_gpu_notebook_does_not_install_an_unpinned_kernels():
    """2026-10-18 (SB's runs): `kernels` >= 0.15 refuses the unversioned kernel lookup transformers makes, so an
    unpinned `kernels` in 04's %pip cell breaks the model load; the validated runs used none."""
    src = open(os.path.join(PKG, "notebooks", "04_extract_chapters_gpu.py")).read()
    pip = next(ln for ln in src.splitlines() if ln.startswith("# MAGIC %pip install"))
    assert "kernels" not in pip and "openai-harmony" in pip


def test_pass_marks_and_their_parameters():
    """The pass marks themselves (no behaviour test fails if one is lowered) and the default population."""
    for nb in ("v01_extraction_scoring.py", "v03_pipeline_health.py"):
        c = _consts(_src(nb), "EXEC_PRECISION_TARGET", "RECALL_TARGET", "FIDELITY_TARGET")
        assert (c["EXEC_PRECISION_TARGET"], c["RECALL_TARGET"], c["FIDELITY_TARGET"]) == (1.0, 0.90, 0.95), nb
    assert _consts(_src("v03_pipeline_health.py"), "MAX_UNSCORED_SHARE")["MAX_UNSCORED_SHARE"] == 0.10
    assert _consts(_src("v01_extraction_scoring.py"), "STATUSES")["STATUSES"] is None


def test_v01_tells_the_scorer_what_each_count_means():
    """The scoring instructions define the measurement (2026-10-04, external review: recall on REAL rules found)."""
    src = _src("v01_extraction_scoring.py")
    assert "real_rules_found: how many of the rules in rules_extracted_text are REAL, DISTINCT rules" in src
    assert "Fill both on a row, or neither" in src and "DROPPED sheet - one candidate" in src


def test_v03_signoff_reads_the_compiled_state_rules_only():
    """The sign-off and precision rows stand on this query (the offline harness does not model it; e2e reports no
    verdict on it)."""
    src = _src("v03_pipeline_health.py")
    assert "where(\"compiled AND (origin IS NULL OR origin <> 'ncci')\")" in src
    assert "quality.signoff_bar(compiled_state)" in src and "quality.compiled_precision_bar(" in src
