"""The tolerant reader (extract/repair.py, run.Extractor(tolerant=True)): format slips found in the refusals of run
narr-20261122T183841Z-5c2e are repaired and grounded again; kept proposals, their records and the extraction id do not
move; content errors stay refused."""
import json
import os

from pie_kb import config
from pie_kb.extract import run as XR
from pie_kb.extract.backends import CacheOnly, ReplayBackend
from pie_kb.extract.repair import repair
from pie_kb.io.store import SCHEMAS, LocalStore
from pie_kb.sources import registry

from test_extract import synthetic

TEXT = ("Respite services cannot be billed for members who are receiving services in an ADHS Facility, ADES group "
        "home or nursing home. H2019 shall not be billed with H2020, H0036 or School attendance and education hours. "
        "H2014 must be paired with the HQ modifier when providers are serving two or more members at the same time. "
        "Providers are prohibited from voiding and replacing claims with new codes. "
        "For case management utilized when assisting members in applying for Social Security benefits the modifier HK "
        "is required.")


def p(kind, subject, params, quote, conditions=()):
    return {"kind": kind, "subject": subject, "params": params, "conditions": list(conditions), "exceptions": [],
            "quote": quote, "effective": None, "end": None, "discretionary": False, "note": None}


GOOD = p("modifier_rule", {"codes": ["H2014"]}, {"mode": "required", "modifiers": ["HQ"], "match": "any",
                                                  "complete_list": False},
         "H2014 must be paired with the HQ modifier when providers are serving two or more members at the same time",
         [{"type": "service_context", "text": "when providers are serving two or more members at the same time"}])
# the same rule with its condition under 'include' (the slip): recovered, then merged into GOOD, which stays
GOOD_SLIP = {**GOOD, "conditions": [{"type": "service_context",
                                     "include": ["when providers are serving two or more members at the same time"]}]}
SETTING_SLIP = p("not_covered", {"category": "Respite services"}, {},
                 "Respite services cannot be billed for members who are receiving services in an ADHS Facility, ADES "
                 "group home or nursing home",
                 [{"type": "place_of_service", "include": "ADHS Facility"}])          # one string, and words
PARTNER_SLIP = p("pair_prohibited", {"codes": ["H2019"]},
                 {"partners": ["School attendance and education hours"], "partner_category": None,
                  "scope": "member_day", "modifier_bypass": "unstated", "both_ways": False},
                 "H2019 shall not be billed with H2020, H0036 or School attendance and education hours")
DUTY_SLIP = p("obligation", {"category": "providers"}, {},
              "Providers are prohibited from voiding and replacing claims with new codes")
CONTENT_ERROR = p("modifier_rule", {"codes": ["T1016"]}, {"mode": "required", "modifiers": ["HK"]},
                  "the modifier HK is required")                 # T1016 is not in the quote: content, never repaired


def run_section(props, tolerant):
    sec = synthetic(TEXT)
    answer = json.dumps({"records": props, "none_reason": None})
    ex = XR.Extractor(ReplayBackend(fn=lambda s, u, b: answer, model="replay"), registry.load(), log=lambda m: None,
                      tolerant=tolerant)
    ex.generate([sec])
    return ex.ground_section(sec)


def test_the_extraction_id_does_not_change():
    assert "extract/repair.py" not in XR.CODE_FILES
    assert XR.config_id("openai/gpt-oss-120b", "medium") == "narr-v7.1-dced7019-a0bfe24c06-gpt-oss-120b-medium"


def test_repairs_on_the_shapes_seen_in_run_5c2e():
    r, t = repair({"kind": "x", "conditions": [{"type": "setting", "include": ["in a BHRF", "in a hospital"]}]})
    assert t == ["text_condition_key"] and r["conditions"] == [{"type": "setting", "text": "in a BHRF; in a hospital"}]
    r, t = repair({"kind": "x", "conditions": [{"type": "service_context", "service_context": "full intake"}]})
    assert r["conditions"] == [{"type": "service_context", "text": "full intake"}]
    r, t = repair({"kind": "x", "conditions": [{"type": "setting", "exclude": "co-located providers"}]})
    assert t == []                                         # a text condition cannot say "not"
    r, t = repair({"kind": "x", "conditions": [{"type": "category", "text": "Family Counseling"}]})
    assert r["conditions"] == [{"type": "service_context", "text": "Family Counseling"}] and t == ["condition_type"]
    r, t = repair({"kind": "x", "conditions": [{"type": "modifier", "present": "HK"},
                                               {"type": "program", "include": "IHS/638"}]})
    assert r["conditions"] == [{"type": "modifier", "present": ["HK"]}, {"type": "program", "include": ["IHS/638"]}]
    r, t = repair({"kind": "x", "conditions": [{"type": "place_of_service", "include": "home"}]})
    assert r["conditions"] == [{"type": "setting", "text": "home"}] and t == ["pos_words_to_setting"]
    r, t = repair({"kind": "x", "conditions": [{"type": "place_of_service", "exclude": "licensed health care "
                                                                                       "institution"}]})
    assert r["conditions"][0]["exclude"] == ["licensed health care institution"]   # list, still checked: refused
    r, t = repair({"kind": "x", "conditions": [{"type": "place_of_service", "include": ["11", "12"]}]})
    assert t == []
    r, t = repair({"kind": "obligation", "params": {"requirement": "keep records"}, "quote": "q"})
    assert r["params"] == {"duty": "keep records"} and t == ["duty_key"]
    r, t = repair({"kind": "obligation", "params": {}, "quote": ["Providers shall", "keep records"]})
    assert r["params"]["duty"] == "Providers shall ... keep records" and t == ["duty_from_quote"]
    r, t = repair({"kind": "not_covered", "subject": {"term": "DSM-IV codes"}})
    assert r["subject"] == {"category": "DSM-IV codes"}
    r, t = repair({"kind": "definition", "subject": {"term": "BHT"}})
    assert t == []                                         # a definition takes a term
    r, t = repair({"kind": "units_limit", "params": {"max": 15, "per": "session", "unit_basis": "member"}})
    assert t == []                                         # a group size, not a units limit: content
    r, t = repair({"kind": "units_limit", "params": {"max": 1, "per": "day", "unit_basis": "dose"}})
    assert t == []                                         # a dose is not a unit: content
    r, t = repair({"kind": "pair_prohibited", "params": {"partners": [], "partner_category": None}})
    assert t == []                                         # no partners at all: content
    r, t = repair({"kind": "pair_prohibited", "params": {"partners": ["[L1]", "H0004"]}})
    assert t == []                                         # a list token is a code list


def test_kept_records_do_not_move_and_slips_are_recovered_after_them():
    props = [GOOD_SLIP, GOOD, SETTING_SLIP, PARTNER_SLIP, DUTY_SLIP, CONTENT_ERROR]
    off, on = run_section(props, False), run_section(props, True)
    kept_off = {r.record_id: r.content_sha for r in off["records"]}
    kept_on = {r.record_id: r.content_sha for r in on["records"]}
    assert kept_off.items() <= kept_on.items()             # every record kept without the reader, unchanged
    good = next(r for r in off["records"] if r.kind == "modifier_rule")
    assert kept_on[good.record_id] == good.content_sha and "repaired" not in [f["code"] for f in
                                                                              next(r for r in on["records"]
                                                                                   if r.record_id == good.record_id).flags]
    new = [r for r in on["records"] if r.record_id not in kept_off]
    assert sorted(r.kind for r in new) == ["not_covered", "obligation", "pair_prohibited"]
    assert all(r.status == "needs_review" and r.flags[-1]["code"] == "repaired" and r.origin == "model" for r in new)
    pair = next(r for r in new if r.kind == "pair_prohibited")
    assert pair.params.get("partners") in (None, []) and \
        pair.params["partner_category"] == "School attendance and education hours"
    nc = next(r for r in new if r.kind == "not_covered")
    assert nc.conditions == [{"type": "setting", "text": "ADHS Facility"}]
    # proposal rows: the model's own answer stays in raw; the repaired one and the old reason in grounding
    rows = on["proposals"]
    slip = rows[0]                                         # GOOD_SLIP: recovered, then merged into GOOD
    assert slip["kept"] and slip["raw"] == GOOD_SLIP and slip["record_id"] == good.record_id
    assert slip["grounding"]["repairs"] == ["text_condition_key"]     # same id as GOOD: one record, GOOD's object
    assert len([r for r in on["records"] if r.record_id == good.record_id]) == 1
    assert rows[5]["kept"] is False and rows[5]["drop_reason"].startswith("codes not in the quote")
    assert "repairs_tried" not in rows[5]["grounding"]     # nothing to repair in a content error
    assert sum(1 for x in rows if x["kept"]) == sum(1 for x in off["proposals"] if x["kept"]) + 4


def test_without_the_switch_nothing_changes():
    props = [GOOD_SLIP, SETTING_SLIP, PARTNER_SLIP, DUTY_SLIP]
    out = run_section(props, False)
    assert [x["kept"] for x in out["proposals"]] == [False] * 4
    assert all("repairs" not in x["grounding"] for x in out["proposals"])


def _store_with_versions(tmp_path):
    """A local store holding two parsed versions of one document, without the PDFs (sections written directly)."""
    st = LocalStore(str(tmp_path / "store"))
    cols = [c for c, _ in SCHEMAS["source_versions"]]
    vrows, srows = [], []
    for svid, day in (("A7@2025-10-01#11111111", "2025-10-01"), ("A7@2026-10-01#22222222", "2026-10-01")):
        v = {c: None for c in cols}
        v.update(source_version_id=svid, source_id="A7", document_key="main", version_date=day, status="active")
        vrows.append(v)
        s = synthetic(TEXT)
        s.update(source_version_id=svid, section_id=f"S-{day}", source_id="A7")
        srows.append(s)
    st.write("source_versions", vrows)
    st.write("sections", srows)
    return st


def test_a_cache_only_recovery_run_touches_only_the_versions_asked_for(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RUNS_DIR", str(tmp_path / "runs"))
    reg, st = registry.load(), _store_with_versions(tmp_path)
    stage = str(tmp_path / "stage")
    answer = json.dumps({"records": [GOOD, SETTING_SLIP, DUTY_SLIP], "none_reason": None})
    be = ReplayBackend(fn=lambda s, u, b: answer, model="replay", reasoning="medium")
    XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium", log=lambda m: None)
    first = XR.extract(stage, be, reg, log=lambda m: None)
    XR.persist(st, reg, first["run_dir"], log=lambda m: None)
    before = {r["record_id"]: r["content_sha"] for r in st.read("records")}
    assert len(before) == 2                                # GOOD in each version; the two slips refused

    # recovery: the newest version only, from the cache, with the reader on, into a folder of its own
    target = {"A7@2026-10-01#22222222"}
    s = XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium", force=True, version_ids=target,
                  log=lambda m: None)
    assert s["versions"] == 1
    out = XR.extract(stage, CacheOnly.like(be), reg, run_dir=str(tmp_path / "recovery" / "r1"),
                     seeds=[os.path.join(first["run_dir"], "answers.jsonl")], log=lambda m: None, tolerant=True)
    assert out["model_calls"] == 0 and "needs_model" not in out["outcomes"]
    XR.persist(st, reg, out["run_dir"], log=lambda m: None)
    after = {r["record_id"]: r for r in st.read("records")}
    assert all(after[k]["content_sha"] == v for k, v in before.items())          # nothing kept moved
    new = [r for k, r in after.items() if k not in before]
    assert len(new) == 2 and {r["source_version_id"] for r in new} == target
    assert all(r["status"] == "needs_review" and r["origin"] == "model" for r in new)
    other = [r for r in after.values() if r["source_version_id"] == "A7@2025-10-01#11111111"]
    assert len(other) == 1                                 # the version not asked for is untouched
    ledger = [x for x in st.read("processing_ledger") if x["run_id"] == out["run_id"]]
    assert [x["status"] for x in ledger] == ["ok"]


def test_a_recovered_record_holds_nothing_back_until_a_person_approves_it():
    from pie_kb.core.record import Record, finalize
    from pie_kb.kb import conflicts as CF
    from pie_kb.review import decisions as DC

    def limit(mx, flags=()):
        return finalize(Record(kind="units_limit", subject={"codes": ["H0038"]},
                               params={"max": mx, "per": "day", "unit_basis": "unit"},
                               citation={"source_id": "A7", "document_key": "main", "source_version_id": "A7@x#1",
                                         "locator": f"p.{mx}", "quote": f"H0038 at most {mx} units per day"},
                               flags=list(flags), origin="model"))
    approved, recovered = limit(16), limit(4, [{"code": "repaired", "text": "read after repairing"}])
    views = lambda st: {approved.record_id: {"record": approved, "status": "approved", "window": ("2025-01-01", None),
                                             "codes": ["H0038"]},
                        recovered.record_id: {"record": recovered, "status": st, "window": ("2025-01-01", None),
                                              "codes": ["H0038"]}}
    assert CF.find(views("needs_review"), {}, [], DC.Log([]), "b") == []     # the approved rule is not held back
    assert len(CF.find(views("approved"), {}, [], DC.Log([]), "b")) == 1     # once approved, compared as any other


def test_a_recovered_exception_overlays_nothing_until_approved():
    from pie_kb.core.record import Record, finalize
    from pie_kb.kb import overlays as OV

    def rec(kind, params, flags=()):
        return finalize(Record(kind=kind, subject={"codes": ["H0004"]}, params=params,
                               citation={"source_id": "A7", "document_key": "main", "source_version_id": "A7@x#1",
                                         "locator": f"p.{kind}", "quote": f"H0004 {kind} words here"},
                               flags=list(flags), origin="model"))
    rule = rec("modifier_rule", {"mode": "required", "modifiers": ["HQ"], "match": "any"})
    exc = rec("exception", {"effect": "waives", "applies_to": "members under 21", "target_kinds": ["modifier_rule"]},
              [{"code": "repaired", "text": "read after repairing"}])
    view = lambda st: {rule.record_id: {"record": rule, "status": "approved", "window": ("2025-01-01", None),
                                        "codes": ["H0004"]},
                       exc.record_id: {"record": exc, "status": st, "window": ("2025-01-01", None), "codes": ["H0004"]}}
    assert OV.find(view("needs_review")) == {}                         # the approved rule stays as it was
    assert rule.record_id in OV.find(view("approved"))                 # once approved, it overlays as any other


def test_recover_a_run_on_a_store_then_prove_nothing_kept_moved(tmp_path, monkeypatch):
    """What notebook r01 does, on a local store: build, recover the run's versions from the cache, build, compare."""
    from datetime import date

    from pie_kb.extract import recover as RC
    from pie_kb.kb import build as KB
    monkeypatch.setattr(config, "RUNS_DIR", str(tmp_path / "runs"))
    monkeypatch.setattr(config, "DATA_DIR", str(tmp_path))
    reg, st = registry.load(), _store_with_versions(tmp_path)
    answer = json.dumps({"records": [GOOD, SETTING_SLIP, DUTY_SLIP, PARTNER_SLIP], "none_reason": None})
    be = CacheOnly(reasoning=config.REASONING)
    real = ReplayBackend(fn=lambda s, u, b: answer, model=be.model, reasoning=be.reasoning, budget=be.budget())
    real.name = be.name                                   # answers cached under the hf_local tag, as on Databricks
    stage = str(tmp_path / "stage")
    XR.export(st, reg, out_dir=stage, log=lambda m: None)
    first = XR.extract(stage, real, reg, log=lambda m: None)
    XR.persist(st, reg, first["run_dir"], log=lambda m: None)
    kept = {r["record_id"]: r["content_sha"] for r in XR._read_jsonl(os.path.join(first["run_dir"], "records.jsonl"))}
    day = date(2026, 11, 22)
    before = RC.snapshot(st, KB.build(st, reg, today=day, log=lambda m: None))
    res = RC.recover(st, reg, first["run_id"], log=lambda m: None)
    assert res["recovered"] == 6 and res["persisted"]["partial"] == []        # 3 slips in each of 2 versions
    after = RC.snapshot(st, KB.build(st, reg, today=day, log=lambda m: None))
    chk = RC.compare(before, after, res["versions"], kept)
    assert chk["problems"] == [] and len(chk["new_records"]) == 6 and chk["build_rows_checked"] >= 2
    # the run folder is outside RUNS_DIR: 06 never persists it again by itself
    assert os.path.dirname(os.path.dirname(res["run_dir"])) != os.path.abspath(config.RUNS_DIR)
    assert res["run_id"] not in {r["run_id"] for r in __import__("pie_kb.stages", fromlist=["runs"]).runs()}


def test_the_table_prefix_redirects_every_read_and_write(tmp_path, monkeypatch):
    st = LocalStore(str(tmp_path / "s"))
    st.write("review_log", [])
    st.write("source_versions", [{c: None for c, _ in SCHEMAS["source_versions"]} | {"source_version_id": "x"}])
    monkeypatch.setattr(config, "TABLE_PREFIX", "kbtr_")
    assert st.read("source_versions") == []               # r01 in test mode never sees or writes the kb_ tables


# ------------------------------------------------------------------ 7.1.5: codes the section lists (extract/listed.py)
PHP = ("H0035 Mental health partial hospitalization, treatment, less than 24 hours. "
       "Partial Hospitalization services may only be provided by the following Provider Types: B5, B6, 02, and 71. "
       "RN/LPN services are included in the per diem rate. All codes must meet scope of practice guidelines.")
PHP_RULE = p("provider_type_rule", {"codes": ["H0035"]},
             {"mode": "allowed", "provider_types": ["B5", "B6", "02", "71"], "role": "billing", "complete_list": True},
             "Partial Hospitalization services may only be provided by the following Provider Types: B5, B6, 02, and 71")
PHP_ELSEWHERE = {**PHP_RULE, "subject": {"codes": ["T1016"]}}             # T1016 is written nowhere in the section
PHP_DUTY = p("obligation", {"codes": ["H0035"]}, {"duty": "meet scope of practice guidelines"},
             "All codes must meet scope of practice guidelines")          # not a rule kind: left refused


def run_php(props, tolerant=True):
    sec = synthetic(PHP, path="PARTIAL HOSPITALIZATION > BILLING LIMITATIONS")
    answer = json.dumps({"records": props, "none_reason": None})
    ex = XR.Extractor(ReplayBackend(fn=lambda s, u, b: answer, model="replay"), registry.load(), log=lambda m: None,
                      tolerant=tolerant)
    ex.generate([sec])
    return ex.ground_section(sec)


def test_listed_codes_are_not_in_the_extraction_id():
    assert "extract/listed.py" not in XR.CODE_FILES and not any("listed" in f for f in XR.CODE_FILES)


def test_a_rule_about_the_code_its_section_names_elsewhere_is_recovered_and_flagged():
    out = run_php([PHP_RULE])
    assert len(out["records"]) == 1
    r = out["records"][0]
    assert r.kind == "provider_type_rule" and r.subject["codes"] == ["H0035"]
    assert r.params["provider_types"] == ["02", "71", "B5", "B6"] or sorted(r.params["provider_types"]) == \
        ["02", "71", "B5", "B6"]
    codes = {f["code"] for f in r.flags}
    assert {"codes_from_section", "repaired"} <= codes and r.status == "needs_review"
    assert "section_codes" in r.extraction["repairs"]
    assert r.citation["quote"].startswith("Partial Hospitalization services may only")
    row = out["proposals"][0]
    assert row["kept"] and row["grounding"]["refused_before_repair"].startswith("codes not in the quote")
    assert row["raw"]["subject"]["codes"] == ["H0035"]                     # the model's answer is kept as it was


def test_a_code_the_section_never_names_and_a_non_rule_kind_stay_refused():
    out = run_php([PHP_ELSEWHERE, PHP_DUTY])
    assert out["records"] == []
    a, b = out["proposals"]
    assert not a["kept"] and a["drop_reason"].startswith("codes not in the quote")
    assert "not written in the section" in a["grounding"]["section_codes"]
    assert not b["kept"] and b["drop_reason"].startswith("codes not in the quote")


def test_without_the_switch_listed_codes_stay_refused():
    out = run_php([PHP_RULE], tolerant=False)
    assert out["records"] == [] and out["proposals"][0]["drop_reason"].startswith("codes not in the quote")


def test_the_rest_of_the_proposal_is_still_checked_with_the_codes_set_aside():
    wrong_number = {**PHP_RULE, "kind": "units_limit", "params": {"max": 7, "per": "day"},
                    "quote": "RN/LPN services are included in the per diem rate"}
    out = run_php([wrong_number])
    assert out["records"] == [] and "numbers not in the quote" in out["proposals"][0]["grounding"]["after_repair"]
