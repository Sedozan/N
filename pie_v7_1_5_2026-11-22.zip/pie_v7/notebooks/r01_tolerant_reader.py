# Databricks notebook source
# MAGIC %md
# MAGIC # r01 · Tolerant reader: recover the format slips of one run (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Reads again, from the answer cache (no model, no GPU), the versions of one finished extraction run, this time
# MAGIC repairing the format slips of the proposals grounding refused (pie_kb/extract/repair.py) and, from 7.1.5, reading
# MAGIC rules about the codes their own section lists (pie_kb/extract/listed.py, flag codes_from_section). Kept proposals are not
# MAGIC repaired, so their records and every decision bound to them stay as they are. A recovered record is flagged
# MAGIC "repaired", waits for review, and holds nothing back (no conflict, no exception overlay) until a person approves it.
# MAGIC
# MAGIC TARGET "test" first: the kb tables are deep-cloned to kbtr_ tables in the same schema and everything runs there;
# MAGIC the real tables are only read. The last cells list the checks (every one must pass) and the recovered records.
# MAGIC TARGET "apply" runs the same on the real tables; run it only after the test passed, then 07 for the workbook.
# MAGIC
# MAGIC Run folders go to data/runs_tolerant (not data/runs), so 06 never picks them up by itself.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import json
import os
from datetime import date

import pandas as pd

from pie_kb.extract import recover as RC
from pie_kb.extract import run as XR
from pie_kb.io.store import open_store

RUN_ID = "narr-20261122T183841Z-5c2e"     # the run whose refused proposals are read again
TARGET = "test"                           # "test": kbtr_ clones of the tables; "apply": the real kb_ tables
AS_OF = date(2026, 11, 22)                # the build date compared before and after (same as the last 07)
TEST_PREFIX = "kbtr_"

assert TARGET in ("test", "apply")
assert os.path.exists(os.path.join(config.RUNS_DIR, RUN_ID, "manifest.json")), f"{RUN_ID} is not in {config.RUNS_DIR}"
print(f"PIE {config.PIE_VERSION}; extraction id {XR.config_id(reasoning=REASONING)} (must equal the run's)")
with open(os.path.join(config.RUNS_DIR, RUN_ID, "manifest.json"), encoding="utf-8") as f:
    RUN = json.load(f)
assert RUN["config_id"] == XR.config_id(reasoning=REASONING), "the package's extraction id differs from the run's"
print(f"{RUN_ID}: {len(RUN['versions'])} version(s): {sorted(RUN['versions'])}")

# COMMAND ----------

# Test only: deep clones of every kb_ table, then point the package at them (the real tables are not written).
if TARGET == "test":
    names = [r.tableName for r in spark.sql(f"SHOW TABLES IN {config.CATALOG}.{config.SCHEMA}").collect()  # noqa: F821
             if r.tableName.startswith(config.TABLE_PREFIX)]
    for t in names:
        dst = TEST_PREFIX + t[len(config.TABLE_PREFIX):]
        spark.sql(f"CREATE OR REPLACE TABLE {config.CATALOG}.{config.SCHEMA}.{dst} "  # noqa: F821
                  f"DEEP CLONE {config.CATALOG}.{config.SCHEMA}.{t}")
    config.TABLE_PREFIX = TEST_PREFIX
    print(f"cloned {len(names)} table(s); writing to {config.CATALOG}.{config.SCHEMA}.{TEST_PREFIX}*")
store = open_store(spark)  # noqa: F821
print("tables:", config.table("records"))

# COMMAND ----------

# Before: a build as of AS_OF on the tables in use, and a snapshot of what must not move.
b0 = stages.build(store, reg, today=AS_OF)
before = RC.snapshot(store, b0)
print(f"before: {len(before['records']):,} records, {len(before['current']):,} build rows, "
      f"{before['review_log']:,} decisions, conflicts {dict(before['conflicts'])}")

# COMMAND ----------

# Recover: export the run's versions, re-ground them from the cache with the tolerant reader, persist.
res = RC.recover(store, reg, RUN_ID, out_root=os.path.join(config.DATA_DIR, "runs_tolerant", TARGET),
                 reasoning=REASONING)
print({k: v for k, v in res.items() if k != "persisted"})

# COMMAND ----------

# After: the same build, and the checks. Every check must pass before TARGET = "apply".
b1 = stages.build(store, reg, today=AS_OF)
after = RC.snapshot(store, b1)
kept = {r["record_id"]: r["content_sha"] for r in XR._read_jsonl(os.path.join(config.RUNS_DIR, RUN_ID, "records.jsonl"))}
chk = RC.compare(before, after, res["versions"], kept)
print(f"records {chk['records_before']:,} -> {chk['records_after']:,} ({len(chk['new_records'])} recovered); "
      f"build rows checked {chk['build_rows_checked']:,}, moved {chk['build_rows_moved']}")
for p in chk["problems"]:
    print("PROBLEM:", p)
print("ALL CHECKS PASSED" if not chk["problems"] else "CHECKS FAILED: do not apply; send this output")

# COMMAND ----------

# The recovered records, for review (they appear in the next 07 workbook, flagged "repaired").
new = set(chk["new_records"])
rows = [r for r in store.read("records_current") if r["record_id"] in new]
df = pd.DataFrame([{"version": r["source_version_id"], "page": (r.get("citation") or {}).get("page_start"),
                    "kind": r["kind"], "class": r["execution_class"], "status": r["status"],
                    "statement": r["statement"], "quote": (r.get("citation") or {}).get("quote"),
                    "repairs": next((f["text"] for f in r.get("flags") or [] if f.get("code") == "repaired"), ""),
                    "record_id": r["record_id"]} for r in rows])
if len(df):
    display(df.groupby(["kind", "class"]).size().rename("records").reset_index())  # noqa: F821
    display(df.sort_values(["class", "kind", "version"]))  # noqa: F821
    out = os.path.join(config.REVIEW_OUT_DIR, f"tolerant_recovered_{TARGET}_{RUN_ID}.csv")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    df.to_csv(out, index=False)
    print("saved", out)

# COMMAND ----------

# Test only, when done: drop the clones (leave commented to keep them for a look).
# for t in [r.tableName for r in spark.sql(f"SHOW TABLES IN {config.CATALOG}.{config.SCHEMA}").collect()
#           if r.tableName.startswith(TEST_PREFIX)]:
#     spark.sql(f"DROP TABLE {config.CATALOG}.{config.SCHEMA}.{t}")
