"""Tolerant reader: repair known format slips in a model proposal that grounding refused, then ground it again.

Built from the 712 refusals of run narr-20261122T183841Z-5c2e (11/22/2026). Rules:
  - only a proposal the unchanged check refused is repaired (run.py tries it after the refusal), so a kept proposal,
    its record and every decision bound to it cannot move;
  - a repair fixes shape only: it moves words the model wrote to the field that takes them, and adds no word;
  - the repaired proposal goes through the same grounding as any other (quote, codes, numbers, values, sense);
  - a recovered record carries the flag 'repaired' (status needs_review) and the repairs in its extraction metadata;
    the proposal row keeps the model's original answer, and the repaired one in its grounding;
  - until a person approves it (or the same meaning approved elsewhere carries over, as for any record) it holds
    nothing back: it opens no conflict and lays no exception overlay (kb/conflicts._held_out).

Repairs:
  text_condition_key    a setting, service_context, member_attribute or other condition whose words sit under
                        'include', 'value' or the type's own name instead of 'text' (an 'exclude' is left alone: a text
                        condition cannot say "not")
  condition_type        condition type 'category' (not a condition type) with words: service_context
  string_as_list        a list-valued condition key (include, exclude, present, absent, codes) given one string, which
                        the check would read letter by letter
  pos_words_to_setting  place_of_service values that are words, not POS codes ('home', 'inpatient hospital'): a setting
                        condition with those words (an exclude in words is left alone)
  partner_words         pair_prohibited partners that are words, not codes, with no partner_category: the words become
                        the partner_category, the codes stay partners
  duty_key              an obligation's duty under 'requirement' or 'description' (dropped as unknown keys)
  duty_from_quote       an obligation with no duty at all: the duty is the quote, verbatim
  subject_term          a subject given as 'term' for a kind that takes codes or a category

Not repaired, because they are content, not format: codes the quote does not name, a period the quote contradicts
(including '3 in 7 days'), a dose read as a unit, credentials given as provider types, places of service or provider
types given as words in params, numbers not in the quote, quotes not found, programs outside all/acute/ltc, two claim
forms at once, a pair with no partners at all, unit_basis 'member' (on the real refusals it was a group size, "groups
of at most 15 members", which as a units limit would read "at most 15 units per session").

This file is not in the extraction configuration id (run.CODE_FILES): using it makes no version due again. Add it there
when the tolerant reader becomes the default for every run (one replay from the cache, no model time).
"""
from __future__ import annotations

import copy
import re

from ..core.kinds import KINDS

TEXT_TYPES = ("setting", "service_context", "member_attribute", "other")
LIST_KEYS = ("include", "exclude", "present", "absent", "codes")
PROCEDURE = re.compile(r"^(?:\d{4}[0-9A-Z]|[A-Z]\d{4})$")
POS_CODE = re.compile(r"^\d{1,2}$")

REPAIRS = ("text_condition_key", "condition_type", "string_as_list", "pos_words_to_setting", "partner_words",
           "duty_key", "duty_from_quote", "subject_term")


def _words(v) -> str:
    if isinstance(v, (list, tuple)):
        return "; ".join(str(x).strip() for x in v if str(x).strip())
    return str(v).strip() if v is not None else ""


def _quote_text(q) -> str:
    if isinstance(q, (list, tuple)):
        return " ... ".join(str(x).strip() for x in q if str(x).strip())
    return str(q or "").strip()


def _condition(c, tags: list):
    if not isinstance(c, dict):
        return c
    c = dict(c)
    t = c.get("type")
    if t == "category" and c.get("text"):
        c["type"] = t = "service_context"
        tags.append("condition_type")
    if t in TEXT_TYPES:
        if not c.get("text"):
            for k in ("include", "value", t):
                if c.get(k) not in (None, "", []):
                    c["text"] = _words(c.pop(k))
                    tags.append("text_condition_key")
                    break
        return c
    if t == "place_of_service":
        inc = c.get("include")
        vals = [inc] if isinstance(inc, str) else list(inc or [])
        if vals and set(c) <= {"type", "include"} and any(not POS_CODE.match(str(x).strip()) for x in vals):
            tags.append("pos_words_to_setting")
            return {"type": "setting", "text": _words(vals)}
    for k in LIST_KEYS:
        if isinstance(c.get(k), str) and c[k].strip():
            c[k] = [c[k]]
            tags.append("string_as_list")
    return c


def repair(raw: dict) -> tuple[dict, list]:
    """(a repaired copy of the proposal, the repairs made). No repairs: the copy equals the input."""
    if not isinstance(raw, dict):
        return raw, []
    r = copy.deepcopy(raw)
    tags: list = []
    kind = str(r.get("kind") or "").strip()
    if isinstance(r.get("conditions"), list):
        r["conditions"] = [_condition(c, tags) for c in r["conditions"]]
    params = r.get("params") if isinstance(r.get("params"), dict) else None
    subject = r.get("subject") if isinstance(r.get("subject"), dict) else None

    if kind == "pair_prohibited" and params is not None and not params.get("partner_category"):
        partners = params.get("partners") if isinstance(params.get("partners"), list) else []
        words = [p for p in partners if not PROCEDURE.match(str(p).strip().upper()) and not str(p).startswith("[L")]
        if words:
            params["partners"] = [p for p in partners if p not in words]
            params["partner_category"] = _words(words)
            tags.append("partner_words")

    if kind == "obligation":
        params = params if params is not None else {}
        if not params.get("duty"):
            for k in ("requirement", "description"):
                if isinstance(params.get(k), str) and params[k].strip():
                    params["duty"] = params.pop(k)
                    tags.append("duty_key")
                    break
            else:
                q = _quote_text(r.get("quote"))
                if q:
                    params["duty"] = q
                    tags.append("duty_from_quote")
        r["params"] = params

    if subject is not None and kind in KINDS and KINDS[kind].subject == "codes_or_category" \
            and subject.get("term") and not subject.get("codes") and not subject.get("category"):
        subject["category"] = subject.pop("term")
        tags.append("subject_term")

    return r, sorted(set(tags))
