"""Tolerant reader, second step: a rule about the codes its section lists, when the sentence itself names none.

The AHCCCS guides state a service's codes once (a 'CPT Codes' or 'HCPCS Codes' list, or the code in the service's
own lines) and then its rules in sentences that do not repeat them: "CPT Codes may only be used by independently
licensed qualified clinicians ...", "Partial Hospitalization services may only be provided by the following Provider
Types: B5, B6, 02, and 71." The model attaches the section's codes; grounding refuses them ("codes not in the
quote"), because a code must be written in the quote. On run narr-20261122T183841Z-5c2e that was the largest refusal
(328 of 712), and 290 of them named codes that their own section names elsewhere.

Rules:
  - only a model proposal grounding refused with "codes not in the quote" (after the format repairs of repair.py);
  - only the rule kinds (subject codes or a category: limits, pairs, provider types, modifiers, places of service,
    coverage, authorization ...); not obligations, scope notes, exceptions, pointers or definitions, which never judge
    a claim and would only add rows to review;
  - every code the quote does not name must be written elsewhere in the same section; a code written nowhere in the
    section (a revenue code read as a CPT code, a provider type read as a code) stays refused;
  - the rest of the proposal must pass the same grounding: the codes are set aside, the proposal is grounded with the
    words the model wrote (quote, numbers, values, periods, negation), and the codes are put back on the record;
  - the record carries the flag 'codes_from_section' naming the codes and where they are written, besides the flag
    'repaired' (run.py), so it waits for review and holds nothing back until a person approves it.

Not in the extraction configuration id (run.CODE_FILES), like repair.py: using it makes no version due again.
"""
from __future__ import annotations

import copy
import re

from ..core import codes as C
from ..core.kinds import KINDS
from ..core.record import finalize
from .ground import CODE_LIST_PARAMS, Outcome, _allowed_codes, _expand_codes, find_quote, ground

REFUSAL = "codes not in the quote"
FLAG = "codes_from_section"
PLACEHOLDER = "the codes this section lists"
CATEGORY_PARAM = {"partners": "partner_category", "parent_codes": "parent_category"}


def eligible(prop) -> bool:
    return isinstance(prop, dict) and KINDS.get(str(prop.get("kind") or "").strip()) is not None and \
        KINDS[str(prop.get("kind")).strip()].subject == "codes_or_category"


def _section_codes(text: str, tk, universe) -> set:
    found = {c for c, *_ in C.procedure_codes_in(text)}
    for lo, hi, *_ in C.ranges_in(text):
        found |= set(C.expand_range(lo, hi, universe))
    for cl in tk.lists.values():
        found |= set(cl.codes)
    return found


def recover(prop: dict, section: dict, tk, ctx: dict) -> tuple[Outcome | None, dict]:
    """(outcome, details) for a proposal refused for codes not in its quote; (None, details) when it does not apply."""
    if not eligible(prop):
        return None, {"section_codes": "not a rule kind"}
    text = section["text"]
    mq = str(prop.get("quote") or "")
    lo, hi = ctx.get("span") or (0, len(text))
    span = find_quote(text[lo:hi], tk.expand(mq))
    span = (span[0] + lo, span[1] + lo) if span else find_quote(text, tk.expand(mq))
    if span is None:
        return None, {"section_codes": "quote not found"}
    q0, q1 = span
    quote = re.sub(r"\s+", " ", text[q0:q1]).strip()
    anchor = lo if any(a <= q0 and q1 <= b for a, b in ctx.get("context") or ()) else q1
    universe = ctx.get("universe") or set()

    subj = prop.get("subject") if isinstance(prop.get("subject"), dict) else {}
    raw_subject = subj.get("codes")
    sub_codes, tokens, _ = _expand_codes(raw_subject if isinstance(raw_subject, list) else
                                         ([raw_subject] if raw_subject else []), tk)
    params = dict(prop.get("params") or {}) if isinstance(prop.get("params"), dict) else {}
    lists = {}
    for name in CODE_LIST_PARAMS:
        if name in params:
            v = params[name]
            codes, tks, _ = _expand_codes(v if isinstance(v, list) else [v], tk)
            lists[name], tokens = codes, tokens + tks
    allowed = _allowed_codes(quote, mq, tk, tokens, anchor, universe)
    named = sub_codes + [c for v in lists.values() for c in v]
    missing = sorted({c for c in named if c not in allowed})
    if not missing:
        return None, {"section_codes": "no code missing from the quote"}
    elsewhere = _section_codes(text[:q0] + " " + text[q1:], tk, universe)
    absent = [c for c in missing if c not in elsewhere]
    if absent:
        return None, {"section_codes": f"not written in the section: {absent[:8]}"}

    # ground the proposal with the missing codes set aside, then put them back on the record
    standin = copy.deepcopy(prop)
    s_subj = dict(standin.get("subject") or {}) if isinstance(standin.get("subject"), dict) else {}
    kept_subject = [c for c in sub_codes if c not in missing]
    s_subj["codes"] = kept_subject
    if not kept_subject and not s_subj.get("category"):
        s_subj["category"] = PLACEHOLDER
    standin["subject"] = s_subj
    s_params = dict(standin.get("params") or {}) if isinstance(standin.get("params"), dict) else {}
    placeholders = []
    for name, codes in lists.items():
        s_params[name] = [c for c in codes if c not in missing]
        cat = CATEGORY_PARAM[name]
        if not s_params[name] and not s_params.get(cat):
            s_params[cat] = PLACEHOLDER
            placeholders.append(cat)
    standin["params"] = s_params
    g = ground(standin, section, tk, ctx)
    if not g.kept:
        return Outcome(None, False, g.reason, g.checks), {"section_codes": f"refused with the codes set aside: "
                                                                          f"{g.reason[:200]}"}
    rec = g.record
    subject = dict(rec.subject)
    if sub_codes:
        subject["codes"] = sub_codes
    if subject.get("category") == PLACEHOLDER:
        subject.pop("category")
    rec.subject = subject
    p = dict(rec.params)
    for name, codes in lists.items():                 # as ground() does: a lone subject code is not its own partner
        if codes:
            p[name] = [c for c in codes if c not in sub_codes] if len(sub_codes) == 1 else codes
    for cat in placeholders:
        if p.get(cat) == PLACEHOLDER:
            p.pop(cat)
    rec.params = p
    rec.flags = list(rec.flags) + [{"code": FLAG, "text": f"the quote does not name {', '.join(missing[:12])}"
                                                          f"{' ...' if len(missing) > 12 else ''}; the section names "
                                                          f"them elsewhere: check that the sentence applies to each"}]
    rec.status = "needs_review"
    rec.statement = ""
    rec = finalize(rec)
    problems = rec.problems()
    if problems:
        return Outcome(None, False, "; ".join(problems), g.checks), {"section_codes": "; ".join(problems)[:200]}
    return Outcome(rec, True, "", {**g.checks, "codes": "from the section"}), {"section_codes": missing}
