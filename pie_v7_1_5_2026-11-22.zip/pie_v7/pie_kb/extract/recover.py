"""Read again, with the tolerant reader, the versions of one finished extraction run, and prove nothing kept moved.

Used by notebook r01 (first on a clone of the tables, then on the real ones). No model time: every answer comes from
the cache of the earlier runs (a cache-only backend), and the run stops before persisting if any piece needed the model.

  snapshot(store)                    what the checks compare: records, the current build's rows, decisions, conflicts
  recover(store, reg, run_id, ...)   export the run's versions (forced), re-ground them with tolerant=True from the
                                     cache into a run folder of its own, persist it
  compare(before, after, ...)        the checks; problems is empty when nothing kept moved
"""
from __future__ import annotations

import json
import os
from collections import Counter

from .. import config
from . import run as XR
from .backends import CacheOnly

CURRENT_FIELDS = ("status", "status_basis", "execution_class", "executable_now", "effective_start", "effective_end",
                  "presumed_from", "in_force_today", "conflicts", "overlays", "content_sha")


def _repaired(r: dict) -> bool:
    return any(isinstance(f, dict) and f.get("code") == XR.REPAIRED for f in r.get("flags") or [])


def snapshot(store, build: dict | None = None) -> dict:
    recs = store.read("records")
    current = store.read("records_current")
    bid = (build or {}).get("build_id") or (current[0]["build_id"] if current else None)
    conflicts = [c for c in store.read("conflicts") if c.get("build_id") == bid] if bid else []
    return {"build_id": bid,
            "records": {r["record_id"]: {"sha": r["content_sha"], "svid": r.get("source_version_id"),
                                         "origin": r.get("origin"), "repaired": _repaired(r)} for r in recs},
            "current": {(c["record_id"], c.get("part_of") or c["record_id"], c.get("presumed_from") or ""):
                        {k: c.get(k) for k in CURRENT_FIELDS} for c in current},
            "review_log": len(store.read("review_log")),
            "conflicts": Counter(str(c.get("status") or "").split(":")[0] for c in conflicts)}


def recover(store, reg, run_id: str, out_root: str | None = None, reasoning: str | None = None, log=print) -> dict:
    """The versions of run `run_id`, read again from the cache with the tolerant reader, persisted."""
    src = os.path.join(config.RUNS_DIR, run_id, "manifest.json")
    with open(src, encoding="utf-8") as f:
        manifest = json.load(f)
    version_ids = set(manifest["versions"])
    out_root = out_root or os.path.join(config.DATA_DIR, "runs_tolerant")
    stage_dir = os.path.join(out_root, f"stage_{run_id}")
    summary = XR.export(store, reg, out_dir=stage_dir, force=True, version_ids=version_ids, reasoning=reasoning,
                        log=log)
    if summary["versions"] != len(version_ids):
        raise ValueError(f"exported {summary['versions']} version(s), the run had {len(version_ids)}")
    be = CacheOnly(reasoning=reasoning)
    run_dir = os.path.join(out_root, f"recovery_of_{run_id}")
    out = XR.extract(stage_dir, be, reg, run_dir=run_dir, log=log, tolerant=True)
    open_ = {k: v for k, v in (out.get("outcomes") or {}).items() if k in XR.OPEN}
    if out.get("model_calls") or open_:
        raise RuntimeError(f"not persisted: the cache did not answer every piece ({open_}, model calls "
                           f"{out.get('model_calls')}); the run folder is {out['run_dir']}")
    persisted = XR.persist(store, reg, out["run_dir"], log=log)
    return {"run_id": out["run_id"], "run_dir": out["run_dir"], "versions": sorted(version_ids),
            "recovered": out.get("recovered_by_tolerant_reader", 0), "records": out.get("records"),
            "persisted": persisted}


def compare(before: dict, after: dict, version_ids, kept_run_records: dict | None = None) -> dict:
    """Checks that nothing kept moved. kept_run_records: {record_id: content_sha} of the earlier run's records."""
    vids = set(version_ids)
    problems = []
    b, a = before["records"], after["records"]
    gone = sorted(k for k in b if k not in a)
    changed = sorted(k for k in b if k in a and a[k]["sha"] != b[k]["sha"])
    if gone:
        problems.append(f"{len(gone)} record(s) present before are gone: {gone[:5]}")
    if changed:
        problems.append(f"{len(changed)} record(s) changed content: {changed[:5]}")
    new = sorted(k for k in a if k not in b)
    outside = [k for k in new if a[k]["svid"] not in vids]
    if outside:
        problems.append(f"{len(outside)} new record(s) outside the run's versions: {outside[:5]}")
    unflagged = [k for k in new if not a[k]["repaired"]]
    if unflagged:
        problems.append(f"{len(unflagged)} new record(s) without the 'repaired' flag: {unflagged[:5]}")
    if kept_run_records:
        lost = [k for k, sha in kept_run_records.items() if a.get(k, {}).get("sha") != sha]
        if lost:
            problems.append(f"{len(lost)} record(s) of the earlier run missing or changed: {lost[:5]}")
    moved = []
    for key, row in before["current"].items():
        now = after["current"].get(key)
        if now is None:
            moved.append((key, "row gone"))
            continue
        diff = {f: (row[f], now[f]) for f in CURRENT_FIELDS if row[f] != now[f]}
        if diff:
            moved.append((key, diff))
    if moved:
        problems.append(f"{len(moved)} build row(s) of existing records changed: {moved[:3]}")
    if after["review_log"] != before["review_log"]:
        problems.append(f"review log rows {before['review_log']} -> {after['review_log']}")
    if after["conflicts"].get("open", 0) != before["conflicts"].get("open", 0):
        problems.append(f"open conflicts {before['conflicts'].get('open', 0)} -> {after['conflicts'].get('open', 0)}")
    return {"problems": problems, "new_records": new, "records_before": len(b), "records_after": len(a),
            "build_rows_checked": len(before["current"]), "build_rows_moved": len(moved)}
