# PIE v7: the AHCCCS behavioral health policy knowledge base

PIE reads the AHCCCS behavioral health policy sources (the CBHSG, AMPM policies, the FFS and IHS/Tribal billing
manuals, A.A.C. Title 9 Chapter 22, Claims Clues, the B2 matrix, the PA guidelines, the telehealth code set and the
other approved tables) and turns them into a knowledge base of records. A record is one thing a source says: its kind
(a units limit, a same-day pair, a prior authorization rule, a definition, a pointer, and 16 more), its codes and
conditions, its date window, and the source's own words it was read from (document, version, page, section, quote).
People sign what the records mean before any of them can judge a claim.

Version 7.0 is a clean start. Nothing from v6.3 (rules, seeds, table loads) is read or carried over.

Version 7.1 (2026-11-19) adds what loading earlier versions of the sources needs. Nothing in it changes the parser or
the extraction, so no version already extracted is due again; the table stage runs again (CPU) because its code changed.
- Intake dates the CBHSG by its EFFECTIVE DATE (the January 2025 edition was posted 12/23/2024 and takes effect
  1/1/2025), reads titles wrapped in bidirectional control characters, quarantines a PDF that may be cut off or damaged
  (no end-of-file marker, data after its last marker as when an update was cut off, or it opens only after repair;
  padding after the marker is fine) and quarantines a second file that states the same version date as one held.
- The Same Day spec reads the 2025 tables (no notes above the grid; changed cells marked 'A*(1)'); the daily limits
  spec reads the June 2024 report ('Frequnecy' header). A table without notes takes the medical necessity exception
  from the CBHSG (page 5 of every edition held) under its own reading, SD-NOTE2-CBHSG, which needs a signature.
- A version is HELD only while no other edition can have been in force: up to the day before a release known to exist
  whose file is not held (reference/known_releases.csv: CBHSG 5/18/2026, Same Day 11/12/2025, 2/11/2026, 5/12/2026,
  Chapter 19 10/22/2026, ...), no longer than its publication cadence (B2 one month; daily limits and Same Day three
  months, reference/release_cadence.csv), and, for the newest edition, only to the latest date a check found it still
  to be the edition on the AHCCCS site (reference/current_checks.csv), or its own date when there is no check.
- Past the held end, a record is PRESUMED when the next edition held repeats it (an approved record with the same
  meaning) or no later edition is held; otherwise it ends there. The presumed dates are a row of their own, named by
  its first date (record_id~2026-05-18) with presumed_from set: an executable record is conditional there and never
  executable now, so a consumer that reads only class and window cannot treat a presumed date as executable. Every
  row's part_of names its record (kb_records.record_id): group or join on part_of, not record_id, to see one record.
  kb_code_index and kb_records_history carry part_of and presumed_from too.
- A pair rule another source states (Chapter 19, the CBHSG, Claims Clues) is conditional where the Same Day table in
  force marks the pair A, or A* while the rule says any provider: it would flag what the code-level table allows. Its
  reasons name the pairs; a Fix to its scope or partners clears it.
- Review decisions carry back from a newer version to an older one loaded later where the section reads the same, and
  an older copy that reads the same as a newer copy still waiting is decided with it (one workbook row, which lists
  the windows it also serves). A claim-checkable record also needs the same quoted words.
- A signed conflict resolution applies to the same two statements met again in other versions, until someone defers
  either conflict; the workbook lists those carried resolutions for confirmation. A general limit stricter than a
  specific one inside it is listed as a build warning.
- Revised on 11/19 after two independent reviews (code and design, two rounds each): bridging replaced by held and
  presumed dates, presumed dates written as their own rows, newest editions held only as far as a check goes,
  corrections presumed across a release not held, carry-over independent of row order, a later Defer withdraws a
  carried resolution, a same-text decision later on beats a differing one earlier, and a partial re-run no longer
  stops decisions carrying into a version whose complete run's records it kept.
- reference/claim_fields.csv records what a01 measured on the claims table (POS and diagnosis usable; EVENT_PA_NO too
  sparse to show a missing authorization); the build classes records with it.
- a01 judges each claim line by the B2 version in force on its service date and shows the results by version, and the
  field fill rates by quarter from 10/1/2024.

## The notebooks, in order

| notebook | compute | what it does | writes |
|---|---|---|---|
| 00_setup | CPU, Unity Catalog | creates the schema and the folders; checks the registry and readings | |
| 01_sources | CPU, Unity Catalog | files what is new in the inbox (or fetched): recognised by content, dated from its own words, archived once | kb_source_registry, kb_source_versions |
| 02_parse | CPU, Unity Catalog | PDFs into located sections | kb_sections |
| 03_tables | CPU, Unity Catalog | tables into rows, records and value sets, under readings | kb_table_rows, kb_records, kb_value_sets, kb_readings |
| 04_export_narrative | CPU, Unity Catalog | stages the due sections as files; plans the model work | files |
| 05_extract_gpu | Serverless GPU (environment 5), no Spark | the model reads the pieces the cache does not hold; grounding keeps what the text says | a run folder |
| 06_persist_narrative | CPU, Unity Catalog | finished runs into the tables | kb_records, kb_proposals, kb_extraction_outcomes |
| 07_build_and_review | CPU, Unity Catalog | builds the knowledge base as of a date; exports the review workbook | kb_records_current and the build tables; a workbook |
| v01_review_ingest | CPU, Unity Catalog | reads a filled workbook into the review log; rebuilds | kb_review_log |
| v02_kb_report | CPU, Unity Catalog | where the knowledge base stands | |
| d01_code_lookup | CPU, Unity Catalog | everything the knowledge base says about one code | |
| a01_claims_checks | CPU, Unity Catalog | claim field fill rates, and how often paid lines fall outside B2's modifier, POS and provider type lists (each line against the B2 version in force on its service date): the evidence the B2-MOD, B2-POS and B2-PT readings wait on | |

Every notebook first runs `_settings`, the one place for the file folder, the schema, the model backend and the
reasoning level.

## Getting it into Databricks

The folder layout matters: `notebooks/` must sit next to `pie_kb/` (the notebooks find the package in their parent
folder). Either:
- push this folder to your Git provider and clone it as a Databricks Git folder, or
- unzip it on your PC and import the whole folder with the Databricks CLI:
  `databricks workspace import-dir pie_v7 /Workspace/Users/<you>/pie_v7`
  The notebooks (files whose first line is `# Databricks notebook source`) arrive as notebooks, everything else as
  workspace files. Uploading the notebooks one by one, without `pie_kb/` beside them, does not work.

## First run

1. Open `notebooks/_settings` and check DATA_DIR (where PIE keeps its files; the default is the `data` folder
   inside the project folder, whatever the folder is called) and SCHEMA. Run 00. Drop the source files in the inbox folder it prints (any file names,
   any subfolders).
2. Run 01, 02 and 03. 01 lists what it filed, what it recognised as a duplicate, and what it quarantined (with why).
3. Run 04. Its plan says how many pieces the model must read and about how long that takes.
4. Run 05 with DRY_RUN True: three sections. Read what the model proposed and what grounding kept or refused, with the
   reason. Then run it with DRY_RUN False. MAX_MINUTES caps a run; the next run continues where it stopped.
5. Run 06, then 07. Download the workbook from review/out, fill Decision and Reviewer, put it in review/in, run v01.

## Running again: only what is new or changed

- A file is identified by its bytes. Dropping the same file again changes nothing. A new version of a document is
  filed with the date written in it and goes through the stages.
- Each stage keeps a processing ledger. A version is due for a stage until a run finishes it under the stage's current
  configuration: parser code; table code and readings; prompt, extraction code, model and reasoning level, plus the
  version's own text. A code or prompt change makes versions due again only for that stage.
- Model answers are cached by message (prompt, section text, model, reasoning, budget). A section that did not change
  costs no model time, even in a new version of its document. A run stopped early loses nothing.
- A partial run (a piece failed or was not reached) leaves its versions due, and never replaces the records of a
  version that already had a complete run.
- A version runs from its own date to the day before the next version held, but is held only up to the day before a
  release in reference/known_releases.csv whose file is not held (content_change 'no', a layout-only release, does
  not count) and no longer than its cadence (B2: one month, so load each month's B2 to keep its rules executable now;
  daily limits and Same Day: three months). Past that, a record is presumed (a row of its own, conditional) when the
  next edition held repeats it with an approved record, and ends otherwise. Add a row when you learn of a release;
  when its file arrives the row is moot if the edition is dated, or says it was posted, on that date.
- The newest edition of a document is held only to the latest date someone found it still to be the edition on the
  AHCCCS site. To record that, download the file (or open its page) and, when it is the same edition, add a row to
  reference/current_checks.csv: source, document, the date checked, its sha256 (or, without one, its edition date)
  and how. Prefer the sha256: an edition date cannot tell a re-issue under the same date. The build warns with the
  newest editions that have no check (their rules are presumed after their own dates). Five rows wait to be completed
  (checked_on and where): the telehealth code set, IHS/Tribal Chapter 12, AMPM Exhibit 300-2A, A.A.C. R9-22 and the
  CBHSG FAQ, the unchecked editions whose rules check claims. Documents published once
  (Claims Clues issues) and files that state their own end are exempt. Nothing is executable now (on the build
  date) unless its edition is held on that date; to see what can run on the claims in hand, build as of their last
  service date (07: AS_OF).
- Two different files with one version date (AHCCCS edited the 7/8/2024 Chapter 19 without changing its revision
  date): the second is quarantined with the name of the first. Keep one.

## Review: people sign what records mean

- Every decision is bound to a hash of what the reviewer saw. If the record, reading, statement or conflict changes
  later, the decision is shown as stale and not applied.
- Table records are approved when every reading they rest on is signed (reference/table_readings.csv lists 27
  readings, each with its evidence).
- A Fix becomes a new record that must still match the section's words, and someone other than its author approves it.
  An SME can add a record the extraction missed; the same rule applies.
- Decisions carry between versions of a document only when the record means the same (same record key), its section
  reads the same (ignoring case, spacing, commas, quotes, apostrophes and brackets; words, numbers, . ; : and list
  levels count), no term it quotes is defined differently or in one edition only, and, for a record that can judge a
  claim (executable, conditional, signal), its quoted words are the same too. They carry forward to a newer version
  and back to an older version loaded later, only into versions whose extraction finished; a same-text decision later
  on beats a differing one earlier. Otherwise the record goes back for review, and its Status says which words differ.
  An older copy that reads the same as a newer copy still waiting is decided with it: the workbook lists the newer copy
  once with the windows its decision also serves. Each build's kb_records_history keeps where a carried status came
  from (review.carried_from or review.follows, with the original decision). An approval keeps judging its own
  version's window; a correction runs over the versions where its original was superseded.
- Conflicts (two records about the same code that cannot both hold) are listed with a suggested prevailing record: a
  source's own precedence statement first, then authority, then specificity, then date. The suggestion is never
  applied unsigned; records in an open conflict cannot run. A signed resolution also settles the same two statements
  met again in other versions (listed in the workbook to confirm; a Defer on either conflict withdraws it); two records
  read from one table row are never a conflict (their reading settles it).

## Execution classes

| class | meaning |
|---|---|
| executable | checkable on the claim lines as stated |
| conditional | checkable, but a condition, an exception or a field needs a person per finding |
| signal | ranks providers for review; never a violation (the Claims Clues documentation thresholds) |
| knowledge | definitions, pointers, duties a claim cannot show |
| unresolved | names a service no code set resolves yet, or flagged by grounding |

A record is executable now only when it is executable, approved, in force on the build date, held (not presumed) on
that date and in no open conflict. Presumed dates are separate rows whose class is at most conditional: the edition in
force then is not held, or this one is not confirmed current, so a person confirms each finding against it.
The claim fields a class needs are judged with reference/claim_fields.csv (what a01 measured); update it when a01 is
run on a changed claims table.

## Model time

At the rate v6.3 measured on chapter 19 (Serverless GPU, one piece at a time), the 423 pieces of the sources in hand
take about 44 hours at reasoning medium (18 at low). Ways to shorten it: run in windows (MAX_MINUTES; P1 sources go
first), try BATCH above 1 on the GPU, or set MODEL_BACKEND to "serving" to use the Databricks endpoint
databricks-gpt-oss-120b with parallel requests, if the workspace allows it.

## Package layout

| module | what it holds |
|---|---|
| config.py | every name, path and switch (environment variables PIE_<NAME> override) |
| reference/ | sources.csv (the registry), table_readings.csv, precedence.csv, programs.csv, known_releases.csv, release_cadence.csv, current_checks.csv, claim_fields.csv |
| core/ | text, hashing, dates, code systems, the 21 record kinds, the record, execution classes per claim type |
| sources/ | the registry (reference/sources.csv), intake, version dating, ledgers, the fetcher |
| parse/ | PDF lines, document profiles, sections |
| tables/ | one spec per table family, readings |
| extract/ | list tokens, pieces, the prompt, answer reading, grounding, patterns, backends, the answer cache, the stage |
| review/ | decisions and the review workbook |
| kb/ | the code spine, status, category resolution, conflicts, overlays, diffs, measured claim fields, the build |
| stages.py | one call per pipeline step (what the notebooks run) |

## Tests

`python -m pytest -q` from the repository root (165 tests); `python tools/local_e2e.py --compare` runs the whole
pipeline on local Spark and on Parquet files and compares the two. Tests that read the real source files look in
/home/claude/sources_raw/AHCCCS_BH_Files or in the folder PIE_TEST_SOURCES names, and are skipped when it is absent.

## Known limits

- Coverage of the claims (October 2024 to September 2026) depends on the earlier versions held. Not held as of
  2026-11-18: the CBHSG before 1/1/2025 (9/30 and 10/04/2024) and of 5/18/2026; the Same Day tables before 1/21/2025
  and of 11/12/2025, 2/11/2026 and 5/12/2026; the B2 before 1/1/2025 and between 8/1/2025 and 10/1/2026.
- NCCI files are not in hand; their spec was built to the documented layout and tested on synthetic files.
- AHCCCS edited the 7/8/2024 Chapter 19 on 11/21/2024 without a new revision date (it added a 42 CFR Part 2 section,
  no billing rule). PIE holds one file per version date, so that section is dated from 7/8/2024.
- EVENT_PA_NO was measured on FFS and managed care lines together (the PA file is FFS only). FORM_TYP_DESC marks FFS
  versus managed care lines: a01 now splits the fill rates and the PA check by it; update claim_fields.csv from the FFS
  lines.
- A limit with conditions inside a general one's is a specific rule, not a conflict, so both stay executable; when the
  general one is stricter, it flags what the specific one allows where its conditions hold. The build lists such
  pairs as warnings.
- A.A.C. rules are dated from the supplement held (12/31/2025), not from each section's own effective date.
- The Same Day overlay judges a pair rule as a whole: when the table allows one of its pairs on any of its dates, the
  rule is conditional on all of them (three approved Chapter 19 rules of 9/15/2026 are conditional from 9/15 because
  the 10/1/2026 table allows some of their pairs).
- A notice published once (Claims Clues) has no later edition, so its rules run until a person ends them; only the
  Same Day overlay (a later table allowing the pair) makes one conditional by itself.
- Intake quarantines a complete PDF that has text appended after its last end-of-file marker (none received has);
  a file cut exactly at an earlier end-of-file marker reads as the earlier revision and cannot be told apart.
- A code range expands only over codes the knowledge base knows (the code spine).
- Checkmark tables inside narrative PDFs (AMPM 610) come through as rows of cells without their column headers.
- Managed care sources are deferred; records carry applicability (FFS, MC) so shared sources need no re-extraction.
- Four-eyes compares names without case or spacing, but cannot tell that "J. Doe" is "Jane Doe": the workbook shows
  each record's author next to the Reviewer column.
- On Delta, a stage replaces a version's rows with a delete and then an append (two transactions). A failure between
  them leaves that version's rows missing until the stage runs again, which it does on its next run.
