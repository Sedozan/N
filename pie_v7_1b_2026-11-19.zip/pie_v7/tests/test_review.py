"""Review and build: decisions bound to content, readings, carry-forward across versions, windows, service categories,
conflicts with precedence suggestions, version diffs, and the review workbook out and back."""
import dataclasses
from datetime import date

import pytest

from pie_kb.core.hashing import short_hash, text_hash
from pie_kb.core.record import Record, finalize, store_row
from pie_kb.extract import ground as G
from pie_kb.extract import lists as LS
from pie_kb.io.store import LocalStore
from pie_kb.kb import build as KB
from pie_kb.kb import conflicts as CF
from pie_kb.kb import resolve as RS
from pie_kb.review import decisions as DC
from pie_kb.review import workbook as WB
from pie_kb.sources import ledger, registry
from pie_kb.tables import readings as RD

REG = registry.load()
V1, V2 = "A7@2025-10-01#11111111", "A7@2026-10-01#22222222"
AAC, CH19 = "A20@2025-12-31#33333333", "A8@2026-09-15#44444444"
RESPITE = "Support Services > Unskilled Respite Care > Billing Limitations"


def version(svid: str, day: str) -> dict:
    sid, rest = svid.split("@")
    return {"source_version_id": svid, "source_id": sid, "document_key": "main", "version_date": day,
            "version_label": rest.split("#")[0], "version_basis": "stated", "version_evidence": "test",
            "sha256": rest.split("#")[1] * 8, "status": "active", "first_seen_at": "2026-11-01T00:00:00+00:00",
            "file_kind": "pdf"}


def section(svid: str, path: str, text: str, page: int = 3) -> dict:
    sid = svid.split("@")[0]
    return {"section_id": "S-" + short_hash(svid, path), "section_key": "SK-" + short_hash(sid, path),
            "source_version_id": svid, "source_id": sid, "document_key": "main", "path": path.split(" > "),
            "path_text": path, "heading": path.split(" > ")[-1], "level": 2, "page_start": page, "page_end": page,
            "text": text, "text_hash": text_hash(text), "n_chars": len(text),
            "blocks": [{"kind": "para", "page": page, "item": "", "start": 0, "end": len(text)}],
            "codes": {"procedure": []}, "signal": 1, "role": "body", "applicability": {"delivery_systems": ["FFS"]},
            "defined_terms": [], "stated_dates": [], "ordinal": 1}


def record(sec: dict, prop: dict, origin: str = "model") -> Record:
    doc = REG.get(sec["source_id"], "main")
    g = G.ground(prop, sec, LS.tokenize(sec["text"], set()), {"doc": doc, "source_version_id": sec["source_version_id"],
                                                                "universe": set(), "extraction": {}, "origin": origin})
    assert g.kept, g.reason
    return g.record


def limit(code_or_cat, n, quote, per="day"):
    subject = {"codes": [code_or_cat]} if code_or_cat[0].isupper() and code_or_cat[1:].isdigit() else \
        {"category": code_or_cat}
    return {"kind": "units_limit", "subject": subject, "params": {"max": n, "per": per, "scope": "member"},
            "quote": quote}


def b2_record() -> Record:
    return finalize(Record(kind="provider_type_rule", subject={"codes": ["H0004"]},
                           params={"mode": "allowed", "provider_types": ["77"], "complete_list": True,
                                   "role": "billing_or_rendering"},
                           citation={"source_id": "A1", "document_key": "main",
                                     "source_version_id": "A1@2026-10-01#55555555", "locator": "sheet 'B2' rows 7-8",
                                     "quote": "H0004 | provider types: 77", "row_key": "H0004"},
                           applicability={"delivery_systems": ["FFS", "MC"]}, origin="table", authority_level=5,
                           extraction={"spec": "b2", "readings": ["B2-PT", "B2-VER"]}))


@pytest.fixture()
def world(tmp_path, monkeypatch):
    """Two CBHSG versions, the A.A.C. and Ch19, with records whose decisions the tests make. No known releases, no
    cadence caps and no currency checks: the newest editions stay open (a test that needs these sets its own)."""
    monkeypatch.setattr(ledger, "known_releases", lambda path=None: {})
    monkeypatch.setattr(ledger, "release_cadence", lambda path=None: {})
    monkeypatch.setattr(ledger, "current_checks", lambda path=None: None)
    st = LocalStore(str(tmp_path / "store"))
    secs = {
        "respite1": section(V1, RESPITE, "Respite services are limited to 600 hours per benefit year per member."),
        "respite2": section(V2, RESPITE, "Respite services are limited to 600 hours per benefit year per member."),
        "couns1": section(V1, "Counseling > Billing Limitations", "H0004 is limited to 24 units per day per member."),
        "couns2": section(V2, "Counseling > Billing Limitations", "H0004 is limited to 24 units per day per member. "
                                                                  "Documentation is required for every session."),
        "pa2": section(V2, "Crisis > Billing Limitations", "Prior authorization is required for H2011 crisis care."),
        "aac": section(AAC, "R9-22-1205", "H0004 is limited to 16 units per day per member under this rule."),
        "ch19": section(CH19, "CRISIS SERVICES", "Prior authorization is not required for H2011 in a crisis."),
    }
    hours = {"kind": "units_limit", "subject": {"category": "Respite services"},
             "params": {"max": 600, "per": "benefit_year", "scope": "member", "unit_basis": "hour"},
             "quote": "Respite services are limited to 600 hours per benefit year per member."}
    recs = {
        "respite1": record(secs["respite1"], hours), "respite2": record(secs["respite2"], hours),
        "couns1": record(secs["couns1"], limit("H0004", 24, "H0004 is limited to 24 units per day per member.")),
        "couns2": record(secs["couns2"], limit("H0004", 24, "H0004 is limited to 24 units per day per member.")),
        "pa2": record(secs["pa2"], {"kind": "prior_auth_rule", "subject": {"codes": ["H2011"]},
                                    "params": {"requirement": "required"},
                                    "quote": "Prior authorization is required for H2011 crisis care."}),
        "aac": record(secs["aac"], limit("H0004", 16, "H0004 is limited to 16 units per day per member under this "
                                                      "rule.")),
        "ch19": record(secs["ch19"], {"kind": "prior_auth_rule", "subject": {"codes": ["H2011"]},
                                      "params": {"requirement": "not_required"},
                                      "quote": "Prior authorization is not required for H2011 in a crisis."}),
        "b2": b2_record(),
    }
    st.write("source_versions", [version(V1, "2025-10-01"), version(V2, "2026-10-01"), version(AAC, "2025-12-31"),
                                 version(CH19, "2026-09-15"), version("A1@2026-10-01#55555555", "2026-10-01")])
    st.write("sections", list(secs.values()))
    st.write("records", [store_row(r) for r in recs.values()])
    vs = [{"value_set_id": "SVC:A7:Support Services > Unskilled Respite Care", "source_version_id": v, "code": c,
           "code_system": "HCPCS", "description": "", "attributes": {}, "origin": "pattern"}
          for v in (V1, V2) for c in ("S5150", "S5151")]
    st.write("value_sets", vs)
    # every narrative version's extraction finished: decisions carry only into such versions
    st.write("processing_ledger", [ledger.processing_row(v, "extract_narrative", "cfg", "run-1", "ok")
                                   for v in (V1, V2, AAC, CH19)])
    return st, secs, recs


def decide(st, subject_type, sid, decision, sha, who="Reviewer One", **kw):
    st.write("review_log", [DC.row(subject_type, sid, decision, who, sha, **kw)], mode="append")


def current(st) -> dict:
    return {c["record_id"]: c for c in st.read("records_current")}


# ------------------------------------------------------------------ status, windows, carry-forward
def test_decisions_bind_to_content_and_carry_forward_only_over_unchanged_text(world):
    st, secs, recs = world
    decide(st, "record", recs["respite1"].record_id, "approve", recs["respite1"].content_sha)
    decide(st, "record", recs["couns1"].record_id, "approve", recs["couns1"].content_sha)
    decide(st, "record", recs["aac"].record_id, "approve", "not-the-content")              # stale: never applied
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["respite1"].record_id]["status"] == "approved"
    r2 = cur[recs["respite2"].record_id]
    assert r2["status"] == "approved" and r2["status_basis"] == f"carried forward from {recs['respite1'].record_id}"
    assert any(f["code"] == "carried_forward" for f in r2["flags"])
    c2 = cur[recs["couns2"].record_id]
    assert c2["status"] == "needs_review"
    assert "its section differs (added 'documentation is required for every session.')" in c2["status_basis"]
    a = cur[recs["aac"].record_id]
    assert a["status"] == "proposed" and any(f["code"] == "stale_decision" for f in a["flags"])


def test_decisions_carry_back_to_an_older_version_loaded_later(world):
    """The newest edition was reviewed; an older edition loaded afterwards needs review only where its words differ."""
    st, secs, recs = world
    decide(st, "record", recs["respite2"].record_id, "approve", recs["respite2"].content_sha)
    decide(st, "record", recs["couns2"].record_id, "reject", recs["couns2"].content_sha)
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    r1 = cur[recs["respite1"].record_id]
    assert r1["status"] == "approved" and r1["status_basis"] == f"carried back from {recs['respite2'].record_id}"
    assert any(f["code"] == "carried_back" for f in r1["flags"])
    c1 = cur[recs["couns1"].record_id]                       # the older section lacks the documentation sentence
    assert c1["status"] == "needs_review" and c1["status_basis"].startswith(f"was rejected in {V2}")
    assert "added 'documentation is required for every session.'" in c1["status_basis"]


def test_an_older_copy_follows_a_later_copy_still_waiting_then_takes_its_decision(world):
    st, secs, recs = world
    v0 = "A7@2025-04-15#00000000"
    sec0 = section(v0, "Counseling > Billing Limitations", secs["couns1"]["text"])
    couns0 = record(sec0, limit("H0004", 24, "H0004 is limited to 24 units per day per member."))
    st.write("source_versions", [version(v0, "2025-04-15")], mode="append")
    st.write("sections", [sec0], mode="append")
    st.write("records", [store_row(couns0)], mode="append")
    st.write("processing_ledger", [ledger.processing_row(v0, "extract_narrative", "cfg", "run-1", "ok")], mode="append")
    decide(st, "record", recs["couns2"].record_id, "approve", recs["couns2"].content_sha)
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["couns1"].record_id]["status"] == "needs_review"          # its words differ from 2026
    c0 = cur[couns0.record_id]
    assert c0["status_basis"].startswith(f"follows {recs['couns1'].record_id}")
    assert couns0.record_id not in {r["record_id"] for r in WB.rows_for(st, REG)["Records"]}
    decide(st, "record", recs["couns1"].record_id, "approve", recs["couns1"].content_sha)
    KB.build(st, REG, log=lambda m: None)
    c0 = current(st)[couns0.record_id]
    assert c0["status"] == "approved" and c0["status_basis"] == f"carried back from {recs['couns1'].record_id}"


def test_reading_form_ignores_glyphs_case_and_punctuation_but_not_words():
    from pie_kb.kb import status as ST
    a = "Claims with T1016 must not be billed\n\uf0b7\uf020Medical supplies ; 15 minute units (See the B2 Matrix ."
    b = "Claims with T1016 must not be billed\n• Medical supplies; 15 minute units See the b2 matrix."
    assert ST.reading_form(a) == ST.reading_form(b)
    assert ST.reading_form("limited to 1.5 hours") != ST.reading_form("limited to 15 hours")
    assert ST.reading_form("core billing limitation #25") != ST.reading_form("core billing limitation #24")
    assert ST.word_changes("T1016 must not be billed", "T1016 shall not be billed") == "'must' → 'shall'"
    # list levels: a glyph of the same shape reads the same, a sub-item under another glyph does not
    assert ST.reading_form("\u25cb item \u25aa NOTE: G2214") == ST.reading_form("\u25e6 item \u25a0 NOTE: G2214")
    assert ST.reading_form("\u25cb NOTE: G2214") != ST.reading_form("\u25a0 NOTE: G2214")


def test_a_term_defined_twice_in_one_edition_compares_the_same_in_any_order():
    from pie_kb.kb import status as ST

    def d(text):
        return Record(kind="definition", subject={"term": "Unit"}, params={"definition": text},
                      citation={"source_version_id": V1})
    one, two = d("15 minutes."), d("one day.")
    assert ST.definitions([one, two]) == ST.definitions([two, one]) == {V1: {"unit": ("15 minutes.", "one day.")}}


def test_a_known_missing_release_makes_later_dates_presumed_and_conditional(world, monkeypatch):
    """CBHSG 10/1/2025 and 10/1/2026 are held; the 5/18/2026 edition is known but missing. Past 5/17/2026 a rule the
    10/1/2026 edition repeats (approved) is only presumed: findings on those dates are conditional. A rule the next
    edition does not repeat ends on 5/17/2026."""
    st, secs, recs = world
    gone = section(V1, "Crisis > Billing Limitations", "H2011 is limited to 3 units per day per member.")
    only_old = record(gone, limit("H2011", 3, "H2011 is limited to 3 units per day per member."))
    st.write("sections", [gone], mode="append")
    st.write("records", [store_row(only_old)], mode="append")
    monkeypatch.setattr(ledger, "known_releases",
                        lambda path=None: {("A7", "main"): [{"date": "2026-05-18", "content_change": True}]})
    for r in ("respite2", "couns2"):
        decide(st, "record", recs[r].record_id, "approve", recs[r].content_sha)
    decide(st, "record", recs["couns1"].record_id, "approve", recs["couns1"].content_sha)
    decide(st, "record", only_old.record_id, "approve", only_old.content_sha)
    KB.build(st, REG, today=date(2026, 6, 1), log=lambda m: None)
    cur = current(st)
    same = cur[recs["respite1"].record_id]                 # carried back from respite2 (same words)
    part = cur[recs["respite1"].record_id + "~2026-05-18"]   # its presumed dates are a row of their own
    assert (same["effective_start"], same["effective_end"], same["presumed_from"]) == \
        ("2025-10-01", "2026-05-17", None)
    assert (part["effective_start"], part["effective_end"], part["presumed_from"]) == \
        ("2026-05-18", "2026-09-30", "2026-05-18")
    assert part["review"]["part_of"] == recs["respite1"].record_id and part["status"] == "approved"
    assert same["execution_class"] == "executable" and part["execution_class"] == "conditional"
    assert "the release of 2026-05-18 is not held" in same["window_basis"]
    assert any(w.startswith("from 2026-05-18 this edition is not known to be the one in force")
               for w in part["execution_reasons"])
    assert not part["executable_now"]                      # built on 6/1/2026: inside the presumed part
    assert part["part_of"] == same["part_of"] == recs["respite1"].record_id
    assert part["record_id"] not in {r["record_id"] for r in WB.rows_for(st, REG)["Records"]}
    old = cur[only_old.record_id]
    assert (old["effective_end"], old["presumed_from"]) == ("2026-05-17", None)
    assert "does not repeat it" in old["window_basis"]
    assert cur[recs["respite2"].record_id]["presumed_from"] is None


def test_a_rejected_copy_in_the_next_edition_does_not_count_as_repeating(world, monkeypatch):
    st, secs, recs = world
    monkeypatch.setattr(ledger, "known_releases",
                        lambda path=None: {("A7", "main"): [{"date": "2026-05-18", "content_change": True}]})
    decide(st, "record", recs["respite1"].record_id, "approve", recs["respite1"].content_sha)
    decide(st, "record", recs["respite2"].record_id, "reject", recs["respite2"].content_sha)
    KB.build(st, REG, today=date(2026, 6, 1), log=lambda m: None)
    r1 = current(st)[recs["respite1"].record_id]
    assert (r1["effective_end"], r1["presumed_from"]) == ("2026-05-17", None)


def test_measured_claim_fields_class_records(world):
    """a01 measured the claims: EVENT_PA_NO cannot show a missing authorization, so a PA rule is knowledge, and the
    reason quotes the measurement (reference/claim_fields.csv)."""
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    pa = current(st)[recs["pa2"].record_id]
    assert pa["execution_class"] == "knowledge"
    assert any(w.startswith("pa_number: a01") and "EVENT_PA_NO" in w for w in pa["execution_reasons"])
    from pie_kb.core import checkability as CK
    assert CK.CLAIM_TYPES["professional"].status("pos") == CK.UNVERIFIED     # the module's defaults are untouched


def test_windows_follow_versions_and_old_approvals_keep_their_window(world):
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    old, new = cur[recs["respite1"].record_id], cur[recs["respite2"].record_id]
    assert (old["effective_start"], old["effective_end"]) == ("2025-10-01", "2026-09-30")
    assert (new["effective_start"], new["effective_end"]) == ("2026-10-01", None)
    assert not old["in_force_today"] and new["in_force_today"]


def test_table_records_follow_their_readings(world):
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    b2 = current(st)[recs["b2"].record_id]
    assert b2["status"] == "proposed" and "B2-PT" in b2["status_basis"]
    rd = RD.load()
    for rid in ("B2-PT", "B2-VER"):
        decide(st, "reading", rid, "sign", DC.reading_sha(rd[rid]))
    KB.build(st, REG, today=date(2026, 10, 15), log=lambda m: None)
    b2 = current(st)[recs["b2"].record_id]
    assert b2["status"] == "approved" and b2["execution_class"] == "executable" and b2["executable_now"]
    # B2 is published monthly: the October matrix is held for October; built in November with no newer matrix, its
    # rules are presumed from November 1 (conditional on those dates) and not executable now
    KB.build(st, REG, today=date(2026, 11, 19), log=lambda m: None)
    cur = current(st)
    b2, later = cur[recs["b2"].record_id], cur[recs["b2"].record_id + "~2026-11-01"]
    assert (b2["effective_end"], b2["presumed_from"], b2["executable_now"]) == ("2026-10-31", None, False)
    assert (later["effective_start"], later["effective_end"], later["presumed_from"]) == ("2026-11-01", None,
                                                                                         "2026-11-01")
    assert later["execution_class"] == "conditional" and not later["executable_now"]
    assert "published about every 1 month(s)" in b2["window_basis"]
    index = [i for i in st.read("code_index") if i["code"] == "H0004" and i["record_id"].startswith(b2["record_id"])]
    assert {(i["record_id"], i["effective_start"], i["execution_class"], i["presumed_from"]) for i in index} == {
        (b2["record_id"], "2026-10-01", "executable", None), (later["record_id"], "2026-11-01", "conditional",
                                                              "2026-11-01")}
    hist = {h["record_id"]: h for h in st.read("records_history") if h["build_id"] == later["build_id"]}
    assert hist[later["record_id"]]["presumed_from"] == "2026-11-01" and hist[b2["record_id"]]["window_basis"]
    decide(st, "reading", "B2-PT", "reject", DC.reading_sha(rd["B2-PT"]), who="Reviewer Two")
    KB.build(st, REG, log=lambda m: None)
    assert current(st)[recs["b2"].record_id]["status"] == "rejected"


def test_a_service_named_without_codes_resolves_to_its_section_code_set(world):
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    r = current(st)[recs["respite2"].record_id]
    assert r["resolved_codes"] == ["S5150", "S5151"] and r["resolution"].startswith("section: SVC:A7:")
    assert r["execution_class"] in ("executable", "conditional")
    key, sha = DC.category_key("A7", "Respite services"), DC.category_sha("A7", "Respite services")
    decide(st, "category", key, "none", sha)
    KB.build(st, REG, log=lambda m: None)
    r = current(st)[recs["respite2"].record_id]
    assert r["resolved_codes"] == [] and r["execution_class"] == "unresolved"
    assert RS.suggestions("unskilled respite", st.read("value_sets"))[0][0] == \
        "SVC:A7:Support Services > Unskilled Respite Care"


# ------------------------------------------------------------------ conflicts
def test_conflicts_are_listed_with_a_suggestion_and_hold_records_until_signed(world):
    st, _, recs = world
    for k in ("couns2", "aac", "pa2", "ch19"):
        decide(st, "record", recs[k].record_id, "approve", recs[k].content_sha)
    KB.build(st, REG, log=lambda m: None)
    rows = st.read("conflicts")
    by = {frozenset((c["record_a"], c["record_b"])): c for c in rows}
    lim = by[frozenset((recs["couns2"].record_id, recs["aac"].record_id))]
    assert lim["relationship"] == "different_limit" and lim["suggested_prevailing"] == recs["aac"].record_id
    assert lim["basis"].startswith("higher authority") and lim["status"] == "open"
    pa = by[frozenset((recs["pa2"].record_id, recs["ch19"].record_id))]
    assert pa["relationship"] == "contradiction" and pa["suggested_prevailing"] == recs["ch19"].record_id
    assert frozenset((recs["couns1"].record_id, recs["aac"].record_id)) in by           # windows overlap in 2026
    cur = current(st)
    assert not cur[recs["aac"].record_id]["executable_now"]
    assert any("open conflict" in w for w in cur[recs["aac"].record_id]["execution_reasons"])
    a, b = (recs["aac"], recs["couns2"]) if lim["record_a"] == recs["aac"].record_id else (recs["couns2"], recs["aac"])
    decide(st, "conflict", lim["conflict_id"], "a" if a is recs["aac"] else "b",
           DC.conflict_sha(a.content_sha, b.content_sha))
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["aac"].record_id]["executable_now"] or cur[recs["aac"].record_id]["conflicts"]
    assert any("does not prevail" in w for w in cur[recs["couns2"].record_id]["execution_reasons"])
    # the same two statements meet again through the 2025 edition (couns1 reads as couns2): the resolution carries
    rows = [c for c in st.read("conflicts") if c["build_id"] == cur[recs["aac"].record_id]["build_id"]]
    old = [c for c in rows if {c["record_a"], c["record_b"]} == {recs["couns1"].record_id, recs["aac"].record_id}][0]
    assert old["status"].startswith("resolved:") and f"carried from {lim['conflict_id']}" in old["detail"]
    assert any("does not prevail" in w for w in cur[recs["couns1"].record_id]["execution_reasons"])


def test_two_records_of_one_table_row_are_not_a_conflict():
    from pie_kb.kb import conflicts as CF2
    def dl(max_, per, rk):
        return finalize(Record(kind="units_limit", subject={"codes": ["J2310"]},
                               params={"max": max_, "per": per, "scope": "member_provider", "unit_basis": "unit"},
                               citation={"source_id": "A3", "document_key": "main", "source_version_id": "A3@x#1",
                                         "locator": "row 9", "quote": "J2310 | 000010 | 4 | 1 | D", "row_key": rk},
                               origin="table", extraction={"readings": ["DL-MAX"]}))
    a, b = dl(10, "day", "J2310"), dl(4, "day", "J2310|limit1")
    views = {r.record_id: {"record": r, "status": "proposed", "window": ("2026-01-01", None), "codes": ["J2310"]}
             for r in (a, b)}
    assert CF2.find(views, {}, [], DC.Log([]), "b") == []


def test_relation_needs_the_same_conditions_and_period(world):
    _, secs, recs = world
    a, b = recs["couns2"], recs["aac"]
    assert CF.relation(a, b)[0] == "different_limit"
    wsec = section(AAC, "R9-22-1206", "H0004 is limited to 16 units per week per member under this rule.")
    weekly = record(wsec, limit("H0004", 16, "H0004 is limited to 16 units per week per member under this rule.",
                                per="week"))
    assert CF.relation(a, weekly) is None


# ------------------------------------------------------------------ diffs
def test_diffs_list_added_removed_and_changed(world):
    st, secs, recs = world
    changed = record(secs["couns2"], {"kind": "documentation_required", "subject": {"category": "counseling"},
                                      "params": {"requirement": "documentation for every session"},
                                      "quote": "Documentation is required for every session."})
    st.write("records", [store_row(changed)], mode="append")
    KB.build(st, REG, log=lambda m: None)
    d = [x for x in st.read("record_diffs") if x["source_id"] == "A7"]
    assert {x["change"] for x in d} == {"added"} and d[0]["record_id_to"] == changed.record_id


# ------------------------------------------------------------------ the workbook
def _fill(path, sheet, match, values):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = wb[sheet]
    head = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        cells = dict(zip(head, row))
        if all(str(cells[k].value or "").startswith(v) for k, v in match.items()):
            for k, v in values.items():
                cells[k].value = v
            wb.save(path)
            return
    raise AssertionError(f"no row in {sheet} matching {match}")


def _append_new(path, values):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = wb["New records"]
    head = [c.value for c in ws[1]]
    ws.append([values.get(h, "") for h in head])
    wb.save(path)


def test_workbook_round_trip(world, tmp_path):
    st, secs, recs = world
    KB.build(st, REG, log=lambda m: None)
    path = str(tmp_path / "review.xlsx")
    out = WB.export(st, REG, path)
    # respite1 (2025) reads the same as respite2 (2026), both waiting: one row decides both
    assert out["Records"] == 6 and out["Readings"] == len(RD.load()) and out["Precedence"] == 3
    rows = {r["record_id"]: r for r in WB.rows_for(st, REG)["Records"]}
    assert recs["respite1"].record_id not in rows
    assert f"also serves 1 older version(s) that read the same, with their windows: {V1} (2025-10-01 to " \
           f"2026-09-30)" in rows[recs["respite2"].record_id]["Status"]
    _fill(path, "Records", {"record_id": recs["aac"].record_id}, {"Decision": "Approve", "Reviewer": "Ann"})
    _fill(path, "Records", {"record_id": recs["couns2"].record_id},
          {"Decision": "Fix", "Reviewer": "Ann", "Fix: params": '{"max": 24, "per": "day", "scope": "member", '
                                                               '"unit_basis": "unit"}'})
    _fill(path, "Records", {"record_id": recs["pa2"].record_id},
          {"Decision": "Fix", "Reviewer": "Ann", "Fix: params": '{"requirement": "not_required"}'})  # contradicts text
    _fill(path, "Readings", {"reading_id": "B2-PT"}, {"Decision": "Sign", "Reviewer": "Ann"})
    _fill(path, "Precedence", {"precedence_id": "P1"}, {"Decision": "Sign", "Reviewer": "Ann"})
    _append_new(path, {"Source version id": V2, "Section id": secs["pa2"]["section_id"], "Kind": "obligation",
                       "Subject": '{"codes": ["H2011"]}', "Params": '{"duty": "obtain prior authorization"}',
                       "Quote": "Prior authorization is required for H2011 crisis care.", "Author": "Ann"})
    _append_new(path, {"Source version id": V2, "Section id": secs["pa2"]["section_id"], "Kind": "obligation",
                       "Subject": '{"codes": ["H2011"]}', "Params": '{"duty": "x"}', "Quote": "Not in the text at all",
                       "Author": "Ann"})
    res = WB.ingest(st, REG, path, log=lambda m: None)
    assert res["decisions"] == 5 and res["new_records"] == 3, res["errors"]
    assert len(res["errors"]) == 1 and "quote not found" in res["errors"][0]
    assert WB.ingest(st, REG, path, log=lambda m: None)["decisions"] == 0                  # idempotent
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["aac"].record_id]["status"] == "approved"
    assert cur[recs["couns2"].record_id]["status"] == "superseded"
    assert cur[recs["pa2"].record_id]["status"] == "superseded"
    sme = [c for c in cur.values() if c["origin"] == "sme"]
    assert len(sme) == 3 and {c["status"] for c in sme} == {"needs_review"}
    fixed = next(c for c in sme if c["kind"] == "units_limit")
    assert fixed["params"]["unit_basis"] == "unit" and fixed["review"]["author"] == "Ann"
    flipped = next(c for c in sme if c["kind"] == "prior_auth_rule")       # a fix against the words is flagged
    assert flipped["params"]["requirement"] == "not_required" and any(f["code"] == "negation" for f in flipped["flags"])

    # the author cannot approve her own record; someone else can; a changed record makes its row stale
    path2 = str(tmp_path / "review2.xlsx")
    WB.export(st, REG, path2)
    _fill(path2, "Records", {"record_id": fixed["record_id"]}, {"Decision": "Approve", "Reviewer": "Ann"})
    res = WB.ingest(st, REG, path2, log=lambda m: None)
    assert res["decisions"] == 0 and "another person approves it" in res["errors"][0]
    _fill(path2, "Records", {"record_id": fixed["record_id"]}, {"Decision": "Approve", "Reviewer": "Ben"})
    assert WB.ingest(st, REG, path2, log=lambda m: None)["decisions"] == 1
    KB.build(st, REG, log=lambda m: None)
    assert current(st)[fixed["record_id"]]["status"] == "approved"
    rows = st.read("records")
    for r in rows:
        if r["record_id"] == recs["respite2"].record_id:
            r["content_sha"] = "edited"
    st.write("records", rows)
    _fill(path2, "Records", {"record_id": recs["respite2"].record_id}, {"Decision": "Reject", "Reviewer": "Ben"})
    res = WB.ingest(st, REG, path2, log=lambda m: None)
    assert any("stale" in e for e in res["errors"])


def test_an_exception_in_another_source_makes_a_rule_conditional(world):
    st, secs, recs = world
    sec = section(CH19, "EPSDT", "For members under 21, H0004 limits may be exceeded when medically necessary.")
    x = record(sec, {"kind": "exception", "subject": {"codes": ["H0004"]},
                     "params": {"effect": "waives", "applies_to": "H0004 limits", "target_kinds": ["units_limit"]},
                     "conditions": [{"type": "age", "below_age": 21}],
                     "quote": "For members under 21, H0004 limits may be exceeded when medically necessary."})
    st.write("sections", [sec], mode="append")
    st.write("records", [store_row(x)], mode="append")
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    a = cur[recs["aac"].record_id]
    assert a["overlays"] == [x.record_id] and a["execution_class"] == "conditional"
    assert any("exception in A8" in w for w in a["execution_reasons"])
    assert cur[recs["pa2"].record_id]["overlays"] == []                    # another code and kind


def test_a_guide_rule_meets_a_b2_row_for_one_provider_type(world):
    st, secs, recs = world
    b2 = finalize(Record(kind="modifier_rule", subject={"codes": ["H0004"]},
                         params={"mode": "allowed", "modifiers": ["HQ"], "complete_list": True},
                         conditions=[{"type": "provider_type", "include": ["77"]}],
                         citation={"source_id": "A1", "document_key": "main",
                                   "source_version_id": "A1@2026-10-01#55555555", "locator": "rows 9-10",
                                   "quote": "H0004 | 77 | HQ", "row_key": "H0004|77"},
                         applicability={"delivery_systems": ["FFS"]}, origin="table", authority_level=5,
                         extraction={"spec": "b2", "readings": ["B2-MOD"]}))
    sec = section(V2, "Counseling > Modifiers", "H0004 is never billed with modifier HQ by any provider.")
    guide = record(sec, {"kind": "modifier_rule", "subject": {"codes": ["H0004"]},
                         "params": {"mode": "not_allowed", "modifiers": ["HQ"]},
                         "quote": "H0004 is never billed with modifier HQ by any provider."})
    st.write("sections", [sec], mode="append")
    st.write("records", [store_row(b2), store_row(guide)], mode="append")
    KB.build(st, REG, log=lambda m: None)
    c = [x for x in st.read("conflicts") if {x["record_a"], x["record_b"]} == {b2.record_id, guide.record_id}]
    assert c and c[0]["relationship"] == "contradiction" and "narrower" in c[0]["detail"]
    assert c[0]["suggested_prevailing"] == b2.record_id and c[0]["precedence_id"] == "P1"


def test_four_eyes_ignores_case_and_spacing():
    assert DC.same_person("Jane Doe", "jane  doe") and not DC.same_person("Jane Doe", "John Doe")
    assert not DC.same_person("", "")


# ---- 7.1 review fixes ----------------------------------------------------------------------------------------------

def test_a_later_defer_withdraws_a_carried_resolution(world):
    """A resolution carries to the same two statements in another version, until someone defers either conflict."""
    st, secs, recs = world
    for r in ("couns1", "couns2", "aac"):
        decide(st, "record", recs[r].record_id, "approve", recs[r].content_sha)
    KB.build(st, REG, log=lambda m: None)
    rows = {frozenset((c["record_a"], c["record_b"])): c for c in st.read("conflicts")}
    c2 = rows[frozenset((recs["couns2"].record_id, recs["aac"].record_id))]
    decide(st, "conflict", c2["conflict_id"], "both", DC.conflict_sha(recs["couns2"].content_sha,
                                                                      recs["aac"].content_sha))
    KB.build(st, REG, log=lambda m: None)
    bid = current(st)[recs["aac"].record_id]["build_id"]
    now = {frozenset((c["record_a"], c["record_b"])): c for c in st.read("conflicts") if c["build_id"] == bid}
    c1 = now[frozenset((recs["couns1"].record_id, recs["aac"].record_id))]
    assert c1["status"] == "resolved:both" and "carried from" in c1["detail"]
    rows_wb = {r["conflict_id"]: r for r in WB.rows_for(st, REG)["Conflicts"]}
    assert c1["conflict_id"] in rows_wb and rows_wb[c1["conflict_id"]]["Suggested"] == "Both"   # listed to confirm
    decide(st, "conflict", c2["conflict_id"], "defer", DC.conflict_sha(recs["couns2"].content_sha,
                                                                       recs["aac"].content_sha), who="Reviewer Two")
    KB.build(st, REG, log=lambda m: None)
    bid = current(st)[recs["aac"].record_id]["build_id"]
    now = {frozenset((c["record_a"], c["record_b"])): c for c in st.read("conflicts") if c["build_id"] == bid}
    assert now[frozenset((recs["couns1"].record_id, recs["aac"].record_id))]["status"] == "open"


def test_two_b2_rows_sharing_a_row_key_can_still_conflict():
    from pie_kb.kb import conflicts as CF2

    def pos(rows, places):
        return finalize(Record(kind="pos_rule", subject={"codes": ["H0004"]},
                               params={"mode": "allowed", "pos": places, "complete_list": True},
                               citation={"source_id": "A1", "document_key": "main", "source_version_id": "A1@x#1",
                                         "locator": f"sheet 'B2' rows {rows}", "quote": f"H0004 | {places}",
                                         "row_key": "H0004"}, origin="table", extraction={"readings": ["B2-POS"]}))
    a, b = pos("7-8", ["11"]), pos("9-10", ["11", "12"])
    views = {r.record_id: {"record": r, "status": "approved", "window": ("2026-01-01", None), "codes": ["H0004"]}
             for r in (a, b)}
    assert len(CF2.find(views, {}, [], DC.Log([]), "b")) == 1


def test_carry_over_does_not_depend_on_the_order_records_are_read(world):
    import random
    st, secs, recs = world
    extra = record(secs["couns2"], limit("H0004", 24, "H0004 is limited to 24 units per day per member."))
    dup = section(V2, "Counseling > Other", "H0004 is limited to 24 units per day per member.")
    dup_rec = record(dup, limit("H0004", 24, "H0004 is limited to 24 units per day per member."))
    st.write("sections", [dup], mode="append")
    st.write("records", [store_row(dup_rec)], mode="append")
    decide(st, "record", recs["couns2"].record_id, "reject", recs["couns2"].content_sha)
    decide(st, "record", dup_rec.record_id, "approve", dup_rec.content_sha)
    assert extra.record_id == recs["couns2"].record_id
    seen = set()
    rows = st.read("records")
    for seed in range(4):
        random.Random(seed).shuffle(rows)
        st.write("records", rows)
        KB.build(st, REG, log=lambda m: None)
        seen.add(current(st)[recs["couns1"].record_id]["status_basis"])
    assert len(seen) == 1, seen
    assert "couns" not in seen.pop()                    # matched by its own section first: couns2, which differs


def test_a_same_text_decision_later_on_beats_a_differing_one_earlier(world):
    st, secs, recs = world
    v3 = "A7@2027-01-01#77777777"
    sec3 = section(v3, "Counseling > Billing Limitations", secs["couns2"]["text"])
    couns3 = record(sec3, limit("H0004", 24, "H0004 is limited to 24 units per day per member."))
    st.write("source_versions", [version(v3, "2027-01-01")], mode="append")
    st.write("sections", [sec3], mode="append")
    st.write("records", [store_row(couns3)], mode="append")
    st.write("processing_ledger", [ledger.processing_row(v3, "extract_narrative", "cfg", "run-1", "ok")], mode="append")
    decide(st, "record", recs["couns1"].record_id, "approve", recs["couns1"].content_sha)   # differs from couns2
    decide(st, "record", couns3.record_id, "reject", couns3.content_sha)                   # same words as couns2
    KB.build(st, REG, log=lambda m: None)
    c2 = current(st)[recs["couns2"].record_id]
    assert c2["status"] == "rejected" and c2["status_basis"] == f"carried back from {couns3.record_id}"


def test_a_claim_checkable_record_needs_the_same_quoted_words(world):
    st, secs, recs = world
    v0 = "A7@2025-04-15#00000000"
    sec0 = section(v0, "Counseling > Billing Limitations", "H0004 is limited to 24 units per day, per member.")
    c0 = record(sec0, limit("H0004", 24, "H0004 is limited to 24 units per day, per member."))
    st.write("source_versions", [version(v0, "2025-04-15")], mode="append")
    st.write("sections", [sec0], mode="append")
    st.write("records", [store_row(c0)], mode="append")
    st.write("processing_ledger", [ledger.processing_row(v0, "extract_narrative", "cfg", "run-1", "ok")], mode="append")
    decide(st, "record", recs["couns1"].record_id, "approve", recs["couns1"].content_sha)
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["couns1"].record_id]["execution_class"] in ("executable", "conditional")
    c = cur[c0.record_id]                              # the section reads the same (a comma), the quote does not
    assert c["status"] == "needs_review" and "its quoted words differ" in c["status_basis"]


def test_a_term_defined_in_one_edition_only_blocks_the_carry(world):
    st, secs, recs = world
    d2 = section(V2, "Definitions", "Respite services means short-term care for a member.")
    rec = record(d2, {"kind": "definition", "subject": {"term": "Respite services"},
                      "params": {"definition": "short-term care for a member."},
                      "quote": "Respite services means short-term care for a member."}, origin="pattern")
    st.write("sections", [d2], mode="append")
    st.write("records", [store_row(rec)], mode="append")
    decide(st, "record", recs["respite2"].record_id, "approve", recs["respite2"].content_sha)
    KB.build(st, REG, log=lambda m: None)
    r1 = current(st)[recs["respite1"].record_id]
    assert r1["status"] == "needs_review" and "in one of the two editions only" in r1["status_basis"]


def test_no_decision_is_carried_into_a_version_still_being_extracted(world):
    """A version with partial runs only takes no carried decision. A partial re-run after a complete one leaves the
    complete run's records in place (extract/run.persist), so decisions still carry into it."""
    st, secs, recs = world
    decide(st, "record", recs["respite2"].record_id, "approve", recs["respite2"].content_sha)
    st.write("processing_ledger", [ledger.processing_row(V1, "extract_narrative", "cfg", "run-2", "partial")],
             mode="append")
    KB.build(st, REG, log=lambda m: None)
    assert current(st)[recs["respite1"].record_id]["status"] == "approved"
    st.write("processing_ledger", [p for p in st.read("processing_ledger")
                                   if not (p["source_version_id"] == V1 and p["status"] == "ok")])
    KB.build(st, REG, log=lambda m: None)
    r1 = current(st)[recs["respite1"].record_id]
    assert r1["status"] == "proposed" and any(f["code"] == "extraction_incomplete" for f in r1["flags"])


def test_a_correction_runs_over_the_versions_where_its_original_was_superseded(world, monkeypatch):
    """The original's copy in the 2025 edition sits under a renamed heading but reads the same: the fix carries there,
    and the correction's window follows the status, not the section key."""
    st, secs, recs = world
    renamed = section(V1, "Support Services > Respite > Billing Limitations", secs["respite1"]["text"])
    copy = record(renamed, {**{"kind": "units_limit", "subject": {"category": "Respite services"},
                               "params": {"max": 600, "per": "benefit_year", "scope": "member", "unit_basis": "hour"},
                               "quote": secs["respite1"]["text"]}})
    rows = [r for r in st.read("records") if r["record_id"] != recs["respite1"].record_id] + [store_row(copy)]
    st.write("records", rows)
    st.write("sections", [renamed], mode="append")
    fixed = record(secs["respite2"], {"kind": "units_limit", "subject": {"category": "Respite services"},
                                      "params": {"max": 600, "per": "year", "scope": "member",
                                                 "unit_basis": "hour"}, "quote": secs["respite2"]["text"]},
                   origin="sme")
    fixed.review = {"author": "Reviewer One", "corrected_from": recs["respite2"].record_id}
    st.write("records", [store_row(fixed)], mode="append")
    decide(st, "record", recs["respite2"].record_id, "fix", recs["respite2"].content_sha,
           correction={"record_id": fixed.record_id})
    decide(st, "record", fixed.record_id, "approve", fixed.content_sha, who="Reviewer Two")
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[copy.record_id]["status"] == "superseded"
    fx = cur[fixed.record_id]
    assert fx["status"] == "approved" and fx["effective_start"] == "2025-10-01" and fx["effective_end"] is None
    # a release between the two editions is not held: the correction is presumed there, like any record
    monkeypatch.setattr(ledger, "known_releases",
                        lambda path=None: {("A7", "main"): [{"date": "2026-05-18", "content_change": True}]})
    KB.build(st, REG, today=date(2026, 11, 19), log=lambda m: None)
    cur = current(st)
    rows = sorted((r for r in cur.values() if r["record_id"].split("~")[0] == fixed.record_id),
                  key=lambda r: r["effective_start"])
    assert [(r["effective_start"], r["effective_end"], r["presumed_from"]) for r in rows] == [
        ("2025-10-01", "2026-05-17", None), ("2026-05-18", "2026-09-30", "2026-05-18"), ("2026-10-01", None, None)]
    assert [r["record_id"] for r in rows] == [fixed.record_id, fixed.record_id + "~2026-05-18",
                                              fixed.record_id + "~2026-10-01"]
    assert rows[1]["execution_class"] == "conditional" and rows[2]["executable_now"]


def test_an_unchecked_newest_edition_is_presumed_after_its_own_date(world, monkeypatch):
    """Nothing shows the 10/1/2026 CBHSG is still the edition on the AHCCCS site: its rules are held on its own date
    and presumed after it, and the build names it. A check that found it current holds them to that date."""
    st, secs, recs = world
    monkeypatch.setattr(ledger, "current_checks", lambda path=None: {})
    decide(st, "record", recs["respite2"].record_id, "approve", recs["respite2"].content_sha)
    out = KB.build(st, REG, today=date(2026, 11, 19), log=lambda m: None)
    cur = current(st)
    r2, part = cur[recs["respite2"].record_id], cur[recs["respite2"].record_id + "~2026-10-02"]
    assert (r2["effective_start"], r2["effective_end"], r2["executable_now"]) == ("2026-10-01", "2026-10-01", False)
    assert (part["effective_start"], part["effective_end"], part["presumed_from"]) == ("2026-10-02", None,
                                                                                       "2026-10-02")
    assert part["execution_class"] == "conditional" and "not confirmed current" in part["window_basis"]
    assert any("never checked against the AHCCCS site" in w and "A7 main (2026-10-01)" in w for w in out["warnings"])
    assert cur[recs["respite1"].record_id]["effective_end"] == "2026-09-30"      # ended by the next edition held
    monkeypatch.setattr(ledger, "current_checks", lambda path=None: {("A7", "main"): [
        {"checked_on": "2026-11-19", "sha256": "", "version_date": "2026-10-01", "evidence": "test"}]})
    KB.build(st, REG, today=date(2026, 11, 19), log=lambda m: None)
    r2 = current(st)[recs["respite2"].record_id]
    assert (r2["effective_end"], r2["executable_now"]) == ("2026-11-19", True)


def test_a_general_limit_stricter_than_a_specific_one_inside_it_is_a_warning(world):
    _, secs, recs = world
    general = recs["aac"]                                  # 16 units a day, for everyone
    text = "In a school (place of service 03) H0004 is limited to 24 units per day per member."
    specific = record(section(V2, "Counseling > School", text),
                      {**limit("H0004", 24, text), "conditions": [{"type": "place_of_service", "include": ["03"]}]})
    assert specific.conditions and not general.conditions
    views = {r.record_id: {"record": r, "status": "approved", "window": ("2026-10-01", None), "codes": ["H0004"]}
             for r in (general, specific)}
    warnings: list = []
    assert CF.find(views, {}, [], DC.Log([]), "b", warnings=warnings) == []
    assert len(warnings) == 1 and "stricter than the specific" in warnings[0] and "(at most 16)" in warnings[0]


def test_a_pair_rule_the_same_day_table_allows_is_conditional(world):
    """Chapter 19 prohibits T1016 with H0018 for any provider; the Same Day table in force marks the pair A*
    (allowed when a different provider bills) and T1016 with S9480 A: the rule would flag what the table allows."""
    from pie_kb.kb import overlays as OV
    st, _, _ = world
    text = "T1016 must not be billed on the same day as H0018 or S9480."
    rule = record(section(CH19, "CASE MANAGEMENT", text),
                  {"kind": "pair_prohibited", "subject": {"codes": ["T1016"]},
                   "params": {"partners": ["H0018", "S9480"], "scope": "member_day", "modifier_bypass": "none"},
                   "quote": text})
    sd = "A2@2026-04-01#66666666"
    wins = {sd: {"effective_start": "2026-04-01", "effective_end": None}}
    rows = [{"source_version_id": sd, "spec": "same_day", "data": {"row_code": "T1016", "col_code": c,
                                                                     "indicator": i}}
            for c, i in (("H0018", "A*"), ("S9480", "A"), ("H0004", "D"))]
    view = {rule.record_id: {"record": rule, "status": "approved", "window": ("2026-09-15", None),
                             "codes": ["T1016"]}}
    found = OV.table_allows(view, rows, wins)[rule.record_id]
    assert len(found) == 1 and found[0][0] == sd
    assert "T1016 with H0018 A*" in found[0][1] and "T1016 with S9480 A" in found[0][1]
    same_provider = dataclasses.replace(rule, params={**rule.params, "scope": "member_provider_day"})
    view[rule.record_id]["record"] = same_provider          # fixed to the same provider: only the A cell is left
    found = OV.table_allows(view, rows, wins)[rule.record_id]
    assert "S9480 A" in found[0][1] and "H0018" not in found[0][1]
    view[rule.record_id]["window"] = ("2026-01-01", "2026-03-31")   # dates before the table: nothing to compare
    assert OV.table_allows(view, rows, wins) == {}
    # through the build: the table's rows make the approved rule conditional, with the reason and a warning
    st.write("source_versions", [version(sd, "2026-04-01")], mode="append")
    st.write("table_rows", [{**r, "source_id": "A2", "row_key": f"T1016|{r['data']['col_code']}", "locator": "x"}
                            for r in rows])
    st.write("sections", [section(CH19, "CASE MANAGEMENT", text)], mode="append")
    st.write("records", [store_row(rule)], mode="append")
    decide(st, "record", rule.record_id, "approve", rule.content_sha)
    out = KB.build(st, REG, today=date(2026, 9, 20), log=lambda m: None)
    row = current(st)[rule.record_id]
    assert row["execution_class"] == "conditional" and row["overlays"] == [sd] and not row["executable_now"]
    assert any("pair rule(s) from other sources" in w for w in out["warnings"])
