"""Registry, intake, version dates and the ledgers, on the files SB downloaded."""
import csv
import os

import pytest

from conftest import real_path
from pie_kb import config
from pie_kb.sources import intake, ledger, registry, versions


def test_registry_is_consistent(reg):
    assert registry.validate(reg) == []
    with open(os.path.join(config.REFERENCE_DIR, "sources.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    assert all(None not in r for r in rows), "a field with a comma is not quoted"
    assert reg.get("A24").status == "obsolete"
    assert {d.source_id for d in reg.docs if d.status == "deferred"} == {"M1", "M2", "M3", "M4", "M5", "M6"}


PDFS = [("01_CBHSG/AHCCCS_CBHSG.pdf", "A7", "2026-10-01"),
        ("02_AMPM/AMPM_1620-G.pdf", "A18", "2021-06-01"),
        ("02_AMPM/AMPM_310-B.pdf", "A10", "2025-07-22"),
        ("02_AMPM/AMPM_320-I.pdf", "A13", "2023-10-01"),
        ("02_AMPM/AMPM_320-O.pdf", "A12", "2026-05-21"),
        ("02_AMPM/AMPM_320-V.pdf", "A11", "2026-10-01"),
        ("02_AMPM/AMPM_590.pdf", "A14", "2024-09-27"),
        ("02_AMPM/AMPM_610.pdf", "A15", "2024-12-09"),
        ("02_AMPM/AMPM_660.pdf", "A16", "2026-10-01"),
        ("02_AMPM/AMPM_963.pdf", "A17", "2026-10-01"),
        ("02_AMPM/AMPM_Exhibit_300-2A.pdf", "A19", "2023-07-20"),
        ("03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf", "A8", "2026-09-15"),
        ("03_Billing_Manuals/IHS_Tribal_Chapter12_BehavioralHealth.pdf", "A9", "2023-02-11"),
        ("04_Arizona_Rules/AAC_Title9_Ch22_includes_Article12.pdf", "A20", "2025-12-31"),
        ("05_Claims_Clues/ClaimsClues_Feb_2024.pdf", "A23/cc_2024_02", "2024-02-01"),
        ("05_Claims_Clues/ClaimsClues_July_2023.pdf", "A23/cc_2023_07", "2023-07-01"),
        ("05_Claims_Clues/ClaimsClues_May_2023.pdf", "A23/cc_2023_05", "2023-05-01"),
        ("08_Additional_BH_References/CBHSG_FAQ.pdf", "A28", "2024-10-01"),
        ("08_Additional_BH_References/ClaimsClues_Feb2024_BH_Per_Diem_Clarification.pdf",
         "A23/bh_per_diem_2024_02", "2024-02-06"),
        ("08_Additional_BH_References/ClaimsClues_May2023_BH_Billing_Clarification.pdf",
         "A23/bh_clarification_2023_05", "2023-05-03"),
        ("09_BH_Diagnosis_Lists/AHCCCS_2026_BH_SDOH_Diagnosis_List.pdf", "A6", "2025-10-01"),
        ("09_BH_Diagnosis_Lists/AHCCCS_2027_BH_Diagnosis_List.pdf", "A6", "2026-10-01")]


@pytest.mark.parametrize("rel,doc_id,version", PDFS)
def test_real_pdf_is_recognised_and_dated(reg, rel, doc_id, version):
    p = real_path(rel)
    ident = intake.identify(p, reg)
    assert ident.doc is not None, ident.reason
    assert ident.doc.doc_id == doc_id
    assert ident.how.startswith("title"), "recognised by its content, not its file name"
    assert intake.version_of(p, ident.doc).date == version


def test_renamed_file_is_still_recognised(reg, tmp_path):
    import shutil
    p = tmp_path / "download (3).pdf"
    shutil.copyfile(real_path("02_AMPM/AMPM_320-V.pdf"), p)
    assert intake.identify(str(p), reg).doc.doc_id == "A11"


def test_fiscal_year_list_states_its_end(reg):
    p = real_path("09_BH_Diagnosis_Lists/AHCCCS_2027_BH_Diagnosis_List.pdf")
    vi = intake.version_of(p, reg.get("A6"))                 # the list states its own period: preferred
    assert (vi.date, vi.period_end, vi.basis) == ("2026-10-01", "2027-09-30", "stated")
    assert "EFFECTIVE 10/01/2026 TO 09/30/2027" in vi.evidence
    old = versions.from_pdf_text("dx_list_fy", versions.pdf_head_text(p))   # the title rule agrees
    assert (old.date, old.period_end) == (vi.date, vi.period_end)


def test_applicability_read_from_the_purpose_statement(reg):
    text = versions.pdf_head_text(real_path("02_AMPM/AMPM_320-V.pdf"))
    a = registry.applicability_from_purpose(text, reg)
    assert set(a["programs_include"]) >= {"ACC", "ACC_RBHA", "ALTCS_EPD", "DCS_CHP", "DES_DDD", "AIHP", "DDD_THP",
                                          "TRIBAL_ALTCS", "TRBHA", "FFS_ALL"}
    assert a["programs_exclude"] == ["FESP"]
    assert a["delivery_systems"] == ["FFS", "MC"]
    t963 = versions.pdf_head_text(real_path("02_AMPM/AMPM_963.pdf"))
    a963 = registry.applicability_from_purpose(t963, reg)
    assert "FFS" in a963["delivery_systems"] and "AIHP" in a963["programs_include"]     # SME question 4


def test_accession_archives_once_and_flags_duplicates(reg, tmp_path):
    src = real_path("02_AMPM/AMPM_660.pdf")
    arch, quar = str(tmp_path / "archive"), str(tmp_path / "quarantine")
    row = intake.accession(src, reg, [], archive_dir=arch, quarantine_dir=quar)
    assert row["status"] == "active" and row["source_version_id"].startswith("A16@2026-10-01#")
    assert os.path.exists(row["archive_path"]) and row["archive_path"].startswith(arch)
    again = intake.accession(src, reg, [row], archive_dir=arch, quarantine_dir=quar)
    assert again["status"] == "duplicate" and again["duplicate_of"] == row["source_version_id"]
    junk = tmp_path / "notes.pdf"
    junk.write_bytes(b"%PDF-1.4 not a policy")
    q = intake.accession(str(junk), reg, [], archive_dir=arch, quarantine_dir=quar)
    assert q["status"] == "quarantined"


def test_cbhsg_is_dated_by_its_effective_date():
    """The January 2025 edition was posted 12/23/2024 and takes effect 1/1/2025; a superscript footnote number can run
    into the year ('APRIL 15, 20251')."""
    jan = ("Updated: 12/23/2024, 10/04/2024, 09/30/2024 1 of 79 The footnotes in the CBHSG indicate areas of revision "
           "COVERED BEHAVIORAL HEALTH SERVICES GUIDE (CBHSG) EFFECTIVE DATE: JANUARY 1, 2025")
    vi = versions.from_pdf_text("cbhsg_updated", jan)
    assert vi.date == "2025-01-01" and "posted 12/23/2024" in vi.evidence
    assert versions.from_pdf_text("cbhsg_updated", "Updated: 04/15/2025\nEFFECTIVE DATE: APRIL 15, 20251").date == \
        "2025-04-15"
    assert versions.from_pdf_text("cbhsg_updated", "Updated: 10/04/2024, 09/30/2024\nGUIDE").date == "2024-10-04"


def test_cut_off_pdf_and_a_second_file_for_one_date_are_quarantined(reg, tmp_path):
    src = real_path("02_AMPM/AMPM_660.pdf")
    arch, quar = str(tmp_path / "archive"), str(tmp_path / "quarantine")
    data = open(src, "rb").read()
    cut = tmp_path / "cut.pdf"
    cut.write_bytes(data[: len(data) // 2])
    q = intake.accession(str(cut), reg, [], archive_dir=arch, quarantine_dir=quar)
    assert q["status"] == "quarantined" and "cut off" in q["notes"]
    padded = tmp_path / "padded.pdf"                     # complete, with padding after its end marker: not cut off
    padded.write_bytes(data + b"\0" * 5000)
    assert intake.accession(str(padded), reg, [], archive_dir=str(tmp_path / "a2"),
                            quarantine_dir=quar)["status"] == "active"
    update = tmp_path / "update.pdf"                     # an incremental update cut off after the original's marker
    update.write_bytes(data + b"\n12 0 obj\n<< /Type /Page /Parent 2 0 R >>\nendobj\n13 0 obj\n<< /Len")
    q3 = intake.accession(str(update), reg, [], archive_dir=str(tmp_path / "a3"), quarantine_dir=quar)
    assert q3["status"] == "quarantined" and "data after its last end-of-file marker" in q3["notes"]
    row = intake.accession(src, reg, [], archive_dir=arch, quarantine_dir=quar)
    edited = tmp_path / "edited.pdf"                     # same document and date, different bytes
    edited.write_bytes(data + b"\0" * 16)
    q2 = intake.accession(str(edited), reg, [row], archive_dir=arch, quarantine_dir=quar)
    assert q2["status"] == "quarantined" and "two files for one version date" in q2["notes"]
    assert row["source_version_id"] in q2["notes"]


def test_held_and_presumed_parts_of_a_version_window():
    from datetime import date
    vs = [{"source_version_id": f"A2@{d}#x", "source_id": "A2", "document_key": "main", "status": "active",
           "version_date": d, "first_seen_at": "x", "period_end": None, "version_evidence": ev}
          for d, ev in (("2025-04-01", ""), ("2026-10-01", "EFFECTIVE DATE: OCTOBER 1, 2026 (posted 09/20/2026)"))]
    known = {("A2", "main"): [{"date": "2025-11-12", "content_change": True},
                              {"date": "2026-02-11", "content_change": True},
                              {"date": "2025-06-01", "content_change": False},       # layout only: not a cut
                              {"date": "2026-09-20", "content_change": True}]}      # posted date of a held edition
    w = {v["source_version_id"]: v for v in ledger.windows(vs, today=date(2026, 11, 18), known=known)}
    old, new = w["A2@2025-04-01#x"], w["A2@2026-10-01#x"]
    assert (old["effective_end"], old["held_end"], old["next_version_id"]) == ("2026-09-30", "2025-11-11",
                                                                               "A2@2026-10-01#x")
    assert old["missing_releases"] == ["2025-11-12", "2026-02-11"] and "2025-11-12" in old["held_basis"]
    assert new["effective_end"] is None and new["held_end"] is None and new["in_force_today"]
    # cadence: a quarterly report is held three months
    w = {v["source_version_id"]: v for v in ledger.windows(vs, today=date(2026, 11, 18), cadence={("A2", "main"): 3})}
    assert w["A2@2025-04-01#x"]["held_end"] == "2025-06-30" and w["A2@2026-10-01#x"]["held_end"] == "2026-12-31"
    k = ledger.known_releases()
    assert {r["date"] for r in k[("A7", "main")]} >= {"2024-10-04", "2026-05-18"}
    assert [(r["date"], r["content_change"]) for r in k[("A8", "main")]] == [("2026-05-01", False),
                                                                             ("2026-10-22", True)]
    assert ledger.release_cadence()[("A3", "main")] == 3


def test_the_newest_edition_is_held_only_as_far_as_a_check_confirms_it():
    from datetime import date

    def v(sid, day, sha, end=None):
        return {"source_version_id": f"{sid}@{day}", "source_id": sid, "document_key": "main", "status": "active",
                "version_date": day, "first_seen_at": "x", "period_end": end, "version_evidence": "", "sha256": sha}
    vs = [v("A9", "2023-02-11", "a" * 64), v("A7", "2025-10-01", "b" * 64), v("A7", "2026-10-01", "c" * 64),
          v("A23", "2023-05-01", "d" * 64), v("A6", "2026-10-01", "e" * 64, end="2027-09-30"),
          v("A1", "2026-10-01", "f" * 64)]
    checks = {("A7", "main"): [{"checked_on": "2026-11-08", "sha256": "c" * 12, "version_date": ""},
                               {"checked_on": "2026-12-01", "sha256": "b" * 64, "version_date": ""}],
              ("A1", "main"): [{"checked_on": "2026-12-15", "sha256": "", "version_date": "2026-10-01"}]}
    w = {x["source_version_id"]: x for x in ledger.windows(vs, today=date(2026, 11, 19), monthly_cadence={"A1"},
                                                           checks=checks, single={("A23", "main")})}
    assert (w["A9@2023-02-11"]["held_end"], w["A9@2023-02-11"]["confirmed_on"]) == ("2023-02-11", None)
    assert w["A9@2023-02-11"]["held_basis"].startswith("not confirmed current")
    assert (w["A7@2026-10-01"]["held_end"], w["A7@2026-10-01"]["confirmed_on"]) == ("2026-11-08", "2026-11-08")
    assert w["A7@2025-10-01"]["held_end"] is None          # the next edition held ends it
    assert w["A23@2023-05-01"]["held_end"] is None         # a notice is published once
    assert w["A6@2026-10-01"]["held_end"] is None          # its file states its own end
    assert w["A1@2026-10-01"]["held_end"] == "2026-12-15"  # a check later than the cadence period is evidence
    assert ledger.windows(vs, today=date(2026, 11, 19), checks=None)[0]["held_end"] is None
    c = ledger.current_checks()
    assert c[("A7", "main")][0]["sha256"].startswith("d5da6d5a") and c[("A8", "main")]


def test_windows_and_gaps():
    vs = [{"source_version_id": "A1@2025-08-01#a", "source_id": "A1", "document_key": "main", "status": "active",
           "version_date": "2025-08-01", "first_seen_at": "x", "period_end": None},
          {"source_version_id": "A1@2026-10-01#b", "source_id": "A1", "document_key": "main", "status": "active",
           "version_date": "2026-10-01", "first_seen_at": "x", "period_end": None},
          {"source_version_id": "A6@2026-10-01#c", "source_id": "A6", "document_key": "main", "status": "active",
           "version_date": "2026-10-01", "first_seen_at": "x", "period_end": "2027-09-30"}]
    from datetime import date
    w = {v["source_version_id"]: v for v in ledger.windows(vs, today=date(2026, 11, 2), monthly_cadence={"A1"})}
    old, new, dx = w["A1@2025-08-01#a"], w["A1@2026-10-01#b"], w["A6@2026-10-01#c"]
    assert (old["effective_start"], old["effective_end"], old["window_basis"]) == ("2025-08-01", "2026-09-30",
                                                                                   "next_version")
    assert len(old["gap_months"]) == 13 and old["gap_months"][0] == "2025-09-01"
    assert new["effective_end"] is None and new["in_force_today"]
    assert (dx["effective_end"], dx["window_basis"]) == ("2027-09-30", "stated")


def test_due_is_per_configuration():
    vs = [{"source_version_id": "A11@x#1", "source_id": "A11", "status": "active"},
          {"source_version_id": "A12@x#2", "source_id": "A12", "status": "active"}]
    done = [ledger.processing_row("A11@x#1", "parse", "cfg1", "run1", "ok")]
    assert [v["source_version_id"] for v in ledger.due(vs, done, "parse", "cfg1")] == ["A12@x#2"]
    assert len(ledger.due(vs, done, "parse", "cfg2")) == 2          # a new parser makes both due again


def test_quotes_in_the_precedence_file_are_real(reg):
    """Every precedence statement quotes its source word for word (checked against the PDF text)."""
    from pie_kb.core.text import match_form
    files = {"A7": "01_CBHSG/AHCCCS_CBHSG.pdf", "A8": "03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf",
             "A9": "03_Billing_Manuals/IHS_Tribal_Chapter12_BehavioralHealth.pdf"}
    import pymupdf
    for pr in reg.precedence:
        with pymupdf.open(real_path(files[pr.stated_in])) as doc:
            page = doc[pr.page - 1].get_text()
        assert match_form(pr.quote) in match_form(page), pr.precedence_id
