"""The ledgers: every file version PIE holds (kb_source_versions) and every processing step run on it
(kb_processing_ledger). Pure Python over lists of dicts; io/store.py writes them to Delta.

"Already processed" holds per configuration: a version is due for a stage until a run with the CURRENT config id
finished that stage on it. A parser or prompt change gives a new config id, so the versions become due again, but
only when a run asks for that stage.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from ..core import dates as D

VERSION_COLUMNS = ("source_version_id", "source_id", "document_key", "version_date", "version_label",
                   "version_basis", "version_evidence", "period_end", "sha256", "bytes", "file_kind",
                   "archive_path", "original_name", "origin", "origin_url", "http_last_modified", "first_seen_at",
                   "status", "duplicate_of", "notes")
PROCESSING_COLUMNS = ("source_version_id", "stage", "config_id", "run_id", "status", "started_at", "finished_at",
                      "counts", "message")
STAGES = ("parse", "extract_tables", "extract_narrative", "review", "build")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def version_id(doc_id: str, label: str, sha256: str) -> str:
    """A11@2026-10-01#4bec407f: the document, its version date and the first 8 characters of the file's sha256."""
    return f"{doc_id}@{label}#{sha256[:8]}"


def _add_months(d: date, months: int) -> date:
    y, m = divmod(d.month - 1 + months, 12)
    y, m = d.year + y, m + 1
    last = (date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)).day
    return date(y, m, min(d.day, last))


def _posted(v: dict) -> set:
    """ISO dates a version says it was posted on ('EFFECTIVE DATE: JANUARY 1, 2025 (posted 12/23/2024)'): a known
    release listed by its posting date is held when a version posted that day is."""
    import re
    out = set()
    for m in re.finditer(r"posted (\d{1,2})/(\d{1,2})/(\d{4})", v.get("version_evidence") or ""):
        try:
            out.add(date(int(m.group(3)), int(m.group(1)), int(m.group(2))).isoformat())
        except ValueError:
            pass
    return out


def _confirmed(v: dict, checks: list) -> date | None:
    """The latest date a check found this version to be the edition on the publisher's site: the same bytes (sha256,
    or its first 12 or more characters) or, when the check gives no hash, the same edition date."""
    out = None
    for c in checks:
        sha, vd = (c.get("sha256") or "").strip().lower(), c.get("version_date")
        same = (len(sha) >= 12 and (v.get("sha256") or "").lower().startswith(sha)) if sha else \
            bool(vd) and str(vd) == str(v.get("version_date"))
        d = D.to_date(c.get("checked_on"))
        if same and d and (out is None or d > out):
            out = d
    return out


def windows(versions: list[dict], today: date | None = None, monthly_cadence: set | None = None,
            known: dict | None = None, cadence: dict | None = None, checks: dict | None = None,
            single: set | None = None) -> list[dict]:
    """Effective window of every active version: from its own date to the day before the next version of the same
    document starts (or to the end the version states, whichever is first). The newest is open-ended.

    Within that window, the version is HELD only as long as no other edition can have been in force: up to the day
    before the first release known to exist whose file is not held and that changed content (known: reference/
    known_releases.csv), and no longer than the source's publication cadence (cadence: {(source_id, document_key):
    months}, reference/release_cadence.csv and the registry's monthly sources). After held_end, the version is only
    PRESUMED in force: kb/build.py keeps a record there only when the next edition held states the same rule, and
    judges it conditional on those dates (the edition in force is not held, so a person confirms against it).

    The newest version of a document has no next one to end it, so it is held only as far as evidence goes: to the
    latest date a check found it still to be the edition on the publisher's site (checks: reference/current_checks.csv),
    or, with no check, its own date; a source published on a cadence is held for one cadence period at least. A
    document published once (single: a notice) and a version whose file states its own end are exempt. checks=None
    leaves the newest versions open (tests only).

    known: {(source_id, document_key): [{"date": ISO, "content_change": bool}]}; checks: {(source_id, document_key):
    [{"checked_on", "sha256", "version_date"}]}; single: {(source_id, document_key)}.

    Adds: effective_start, effective_end, window_basis (next_version, stated, open, undated), in_force_today, future,
    gap_months (monthly sources: months with no version between this one and the next), held_end (None when the whole
    window is held), held_basis, missing_releases (content-changing releases not held between this version and the
    next one held), confirmed_on (the latest check that found it current) and next_version_id."""
    today = today or date.today()
    monthly_cadence = monthly_cadence or set()
    known, cadence, single = known or {}, dict(cadence or {}), single or set()
    out, by_doc = [], {}
    for v in versions:
        if v.get("status") != "active":
            continue
        by_doc.setdefault((v["source_id"], v["document_key"]), []).append(v)
    for (sid, dk), vs in by_doc.items():
        dated = sorted([v for v in vs if v.get("version_date")], key=lambda v: (v["version_date"], v["first_seen_at"]))
        held_dates = {v["version_date"] for v in dated} | {d for v in dated for d in _posted(v)}
        releases = sorted({D.to_date(k["date"]) for k in known.get((sid, dk), [])
                           if k.get("content_change", True) and k.get("date") and k["date"] not in held_dates} - {None})
        months = cadence.get((sid, dk)) or (1 if sid in monthly_cadence else None)
        for i, v in enumerate(dated):
            start = D.to_date(v["version_date"])
            nxt = D.to_date(dated[i + 1]["version_date"]) if i + 1 < len(dated) else None
            stated_end = D.to_date(v.get("period_end"))
            ends = [e for e in (D.day_before(nxt) if nxt else None, stated_end) if e]
            end = min(ends) if ends else None
            basis = "next_version" if nxt and (not stated_end or D.day_before(nxt) <= stated_end) else \
                "stated" if stated_end else "open"
            missing = [k for k in releases if k > start and (nxt is None or k < nxt)]
            seen = _confirmed(v, (checks or {}).get((sid, dk), []))
            seen = seen if seen and seen >= start else None
            cut = []                                       # (date, rank: a known release first on a tie, why)
            if missing:
                cut.append((D.day_before(missing[0]), 0, f"the release of {missing[0].isoformat()} is not held"))
            if months:
                cap = D.day_before(_add_months(start, months))
                if seen and seen > cap:                    # a check is evidence; the cadence only a presumption
                    cut.append((seen, 2, f"confirmed current on {seen.isoformat()}, not since"))
                else:
                    cut.append((cap, 1, f"published about every {months} month(s): the edition due after "
                                        f"{cap.isoformat()} is not held"))
            elif checks is not None and nxt is None and end is None and (sid, dk) not in single:
                cut.append((seen, 2, f"confirmed current on {seen.isoformat()}, not since") if seen else
                           (start, 2, "not confirmed current after its own date (no check in "
                                      "reference/current_checks.csv)"))
            cut = [c for c in cut if end is None or c[0] < end]
            held_end, _, held_basis = min(cut) if cut else (None, 0, "")
            gaps = [m.isoformat() for m in D.months_between(start, nxt)] if (nxt and sid in monthly_cadence) else []
            out.append({**v, "effective_start": start.isoformat(), "effective_end": D.iso(end),
                        "window_basis": basis, "future": start > today,
                        "in_force_today": start <= today and (end is None or end >= today), "gap_months": gaps,
                        "held_end": D.iso(held_end), "held_basis": held_basis,
                        "missing_releases": [k.isoformat() for k in missing], "confirmed_on": D.iso(seen),
                        "next_version_id": dated[i + 1]["source_version_id"] if i + 1 < len(dated) else None})
        for v in vs:
            if not v.get("version_date"):
                out.append({**v, "effective_start": None, "effective_end": None, "window_basis": "undated",
                            "future": False, "in_force_today": False, "gap_months": [], "held_end": None,
                            "held_basis": "", "missing_releases": [], "confirmed_on": None, "next_version_id": None})
    return out


def _reference(name: str, path: str | None):
    import csv
    import os

    from .. import config
    path = path or os.path.join(config.REFERENCE_DIR, name)
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def known_releases(path: str | None = None) -> dict:
    """{(source_id, document_key): [{"date", "content_change"}]} from reference/known_releases.csv: releases known
    to exist whose files are not held. content_change 'no' (a revision history that says the release only changed
    layout) does not end the held period; 'yes' and 'unknown' do. A missing file means none."""
    out: dict = {}
    for row in _reference("known_releases.csv", path):
        d = D.to_date(row.get("release_date"))
        if row.get("source_id") and d:
            change = (row.get("content_change") or "unknown").strip().lower() != "no"
            out.setdefault((row["source_id"].strip(), (row.get("document_key") or "main").strip()), []).append(
                {"date": d.isoformat(), "content_change": change})
    return out


def release_cadence(path: str | None = None) -> dict:
    """{(source_id, document_key): months} from reference/release_cadence.csv: how often a source is published, as
    observed from the editions held. A version is held no longer than that without a newer edition."""
    out: dict = {}
    for row in _reference("release_cadence.csv", path):
        try:
            m = int(str(row.get("months") or "").strip())
        except ValueError:
            continue
        if row.get("source_id") and m > 0:
            out[(row["source_id"].strip(), (row.get("document_key") or "main").strip())] = m
    return out


def current_checks(path: str | None = None) -> dict:
    """{(source_id, document_key): [{"checked_on", "sha256", "version_date", "evidence"}]} from
    reference/current_checks.csv: dates a person (or a download) found an edition still to be the one on the
    publisher's site. A missing file means none, so every newest edition is held to its own date only."""
    out: dict = {}
    for row in _reference("current_checks.csv", path):
        d = D.to_date(row.get("checked_on"))
        if row.get("source_id") and d:
            vd = D.to_date(row.get("version_date"))
            out.setdefault((row["source_id"].strip(), (row.get("document_key") or "main").strip()), []).append(
                {"checked_on": d.isoformat(), "sha256": (row.get("sha256") or "").strip(),
                 "version_date": vd.isoformat() if vd else "", "evidence": row.get("evidence") or ""})
    return out


def due(versions: list[dict], processing: list[dict], stage: str, config_id: str,
        only: set | None = None) -> list[dict]:
    """Active versions with no successful `stage` run under `config_id` (optionally limited to some source ids)."""
    done = {(p["source_version_id"]) for p in processing
            if p["stage"] == stage and p["config_id"] == config_id and p["status"] == "ok"}
    return [v for v in versions if v.get("status") == "active" and v["source_version_id"] not in done
            and (only is None or v["source_id"] in only)]


def processing_row(source_version_id: str, stage: str, config_id: str, run_id: str, status: str,
                   counts: dict | None = None, message: str = "", started_at: str | None = None) -> dict:
    import json
    return {"source_version_id": source_version_id, "stage": stage, "config_id": config_id, "run_id": run_id,
            "status": status, "started_at": started_at or now_iso(), "finished_at": now_iso(),
            "counts": json.dumps(counts or {}, sort_keys=True), "message": message[:2000]}
