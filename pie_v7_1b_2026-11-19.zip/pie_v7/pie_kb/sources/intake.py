"""Intake: every file dropped in the inbox (or downloaded) is recognised, dated, archived once and recorded.

  recognise  a workbook by its table layout (tables/ specs), a PDF by its title text and file name (registry), a ZIP by
             its members (NCCI). No match, or two matches, sends the file to quarantine with the reason.
  date       sources/versions.py (documents) or the table spec (workbooks); never the download date
  archive    ARCHIVE_DIR/<source>/<document>/<version>_<sha12>.<ext>, written once, never overwritten
  record     one kb_source_versions row; a file whose bytes are already held is recorded as a duplicate of it
"""
from __future__ import annotations

import io
import os
import shutil
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone

from .. import config
from ..core.hashing import sha256_bytes
from . import ledger, versions
from .registry import Registry, SourceDoc


@dataclass
class Identification:
    doc: SourceDoc | None
    how: str                       # title | filename | layout | members | none | ambiguous
    candidates: tuple = ()
    reason: str = ""


def file_kind(data: bytes) -> str:
    if data[:1024].lstrip().startswith(b"%PDF-"):
        return "pdf"
    if zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
        if "xl/workbook.xml" in names:
            return "xlsx"
        return "zip"
    head = data[:2048].lower()
    if b"<html" in head or b"<!doctype html" in head:
        return "html"
    return "other"


def identify(path: str, reg: Registry, data: bytes | None = None) -> Identification:
    """Which registry document a file is. Content first (title, layout), the file name only breaks ties or names
    documents whose content says too little."""
    data = data if data is not None else open(path, "rb").read()
    kind = file_kind(data)
    name = os.path.basename(path)
    if kind == "xlsx":
        from ..tables import detect_xlsx            # the table specs (M3) recognise their own layouts
        parsers = detect_xlsx(path)
        docs = [d for p in parsers for d in reg.by_parser(p)]
        if len(docs) == 1:
            return Identification(docs[0], "layout")
        if not docs:
            return Identification(None, "none", reason="no table spec recognises this workbook's layout")
        return Identification(None, "ambiguous", tuple(d.doc_id for d in docs), "two table layouts match")
    if kind == "zip":
        from ..tables import detect_zip
        parsers = detect_zip(path)
        docs = [d for p in parsers for d in reg.by_parser(p)]
        if len(docs) == 1:
            return Identification(docs[0], "members")
        return Identification(None, "none" if not docs else "ambiguous", tuple(d.doc_id for d in docs),
                              "no NCCI file recognised in the archive" if not docs else "several NCCI files in one zip")
    if kind != "pdf":
        return Identification(None, "none", reason=f"not a PDF, workbook or zip ({kind})")
    try:
        text = versions.pdf_head_text(path, pages=2)
    except Exception as e:                       # noqa: BLE001 - a damaged or encrypted PDF is quarantined
        return Identification(None, "none", reason=f"the PDF cannot be read ({type(e).__name__})")
    from ..tables import file_kind_of
    docs = [d for d in reg.docs if d.status in ("active", "pending") and file_kind_of(d.parser) == "pdf"]
    by_title = [d for d in docs if d.title_matches(text)]
    by_name = [d for d in docs if d.filename_matches(name)]
    if len(by_title) == 1:
        return Identification(by_title[0], "title")
    if len(by_title) > 1:
        both = [d for d in by_title if d in by_name]
        if len(both) == 1:
            return Identification(both[0], "title+filename")
        return Identification(None, "ambiguous", tuple(d.doc_id for d in by_title),
                              f"{len(by_title)} registry documents match by title")
    # no title match: the file name decides only for documents whose registry row has no title pattern
    named = [d for d in by_name if not d.match_title]
    if len(named) == 1:
        return Identification(named[0], "filename")
    if len(named) > 1:
        return Identification(None, "ambiguous", tuple(d.doc_id for d in named), "several file name matches")
    return Identification(None, "none", reason="no registry document's title matches the first two pages")


def version_of(path: str, doc: SourceDoc, http_last_modified: str | None = None) -> versions.VersionInfo:
    from ..tables import SPECS, version_of_file
    if doc.parser in SPECS:
        return version_of_file(path, doc.parser, http_last_modified)
    from ..core import dates as D
    server = D.any_date(http_last_modified) if http_last_modified else None
    return versions.from_pdf_text(doc.version_rule, versions.pdf_head_text(path, pages=2), server_date=server)


def archive_path(doc: SourceDoc, label: str, sha: str, ext: str, archive_dir: str | None = None) -> str:
    base = archive_dir or config.ARCHIVE_DIR
    return os.path.join(base, doc.source_id, doc.document_key, f"{label}_{sha[:12]}{ext}")


def _repaired(data: bytes) -> bool:
    """True when the PDF opens only after pymupdf rebuilt it: a truncated file does (none of the complete AHCCCS PDFs
    received did)."""
    try:
        import pymupdf
        with pymupdf.open(stream=data, filetype="pdf") as d:
            return bool(d.is_repaired)
    except Exception:
        return True


def _damaged(data: bytes) -> str:
    """Why a PDF may be cut off or damaged, or '' when it is not. Bytes after the last end-of-file marker other than
    padding (NUL or white space) are part of an update that was cut off: a reader would show the edition before it
    without complaint. A file that opens only after repair, its padding aside, is damaged. None of the complete AHCCCS
    PDFs received has either; the truncated CBHSG_2024_09.pdf has both."""
    i = data.rfind(b"%%EOF")
    if i < 0:
        return "no end-of-file marker"
    if data[i + 5:].strip(b"\0 \t\r\n\f"):
        return "data after its last end-of-file marker, as when an update was cut off"
    if _repaired(data[: i + 5]):
        return "it opens only after repair"
    return ""


def accession(path: str, reg: Registry, held: list[dict], *, origin: str = "drop", origin_url: str = "",
              http_last_modified: str | None = None, archive_dir: str | None = None,
              quarantine_dir: str | None = None) -> dict:
    """Recognise, date and archive one file; return its kb_source_versions row (status active, duplicate or
    quarantined). `held` is the current version ledger; it is not modified."""
    data = open(path, "rb").read()
    sha = sha256_bytes(data)
    kind = file_kind(data)
    # a duplicate always names the active version it repeats; a quarantined file is identified again on every run,
    # so a registry row added later picks it up
    seen = {h["sha256"]: h for h in held if h.get("status") == "active"}
    base = {"sha256": sha, "bytes": len(data), "file_kind": kind, "original_name": os.path.basename(path),
            "origin": origin, "origin_url": origin_url, "http_last_modified": http_last_modified or "",
            "first_seen_at": ledger.now_iso(), "duplicate_of": "", "notes": ""}
    if sha in seen:
        h = seen[sha]
        return {**{c: h.get(c) for c in ledger.VERSION_COLUMNS}, **base, "status": "duplicate",
                "duplicate_of": h["source_version_id"], "archive_path": h["archive_path"],
                "source_version_id": h["source_version_id"] + "~dup",
                "notes": f"same bytes as {h['source_version_id']}"}
    def quarantine(reason: str) -> dict:
        qdir = quarantine_dir or config.QUARANTINE_DIR
        os.makedirs(qdir, exist_ok=True)
        qpath = os.path.join(qdir, f"{sha[:12]}_{os.path.basename(path)}")
        if not os.path.exists(qpath):
            shutil.copyfile(path, qpath)
        return {**{c: "" for c in ledger.VERSION_COLUMNS}, **base, "source_version_id": f"Q@{sha[:12]}",
                "status": "quarantined", "archive_path": qpath, "notes": reason[:2000]}

    # one unreadable or undatable file is quarantined with the reason; it never stops the rest of the inbox
    damage = _damaged(data) if kind == "pdf" else ""
    if damage:
        return quarantine(f"the PDF may be cut off or damaged: {damage} ({len(data):,} bytes; a download that stops "
                          f"at exactly 1,048,576 bytes was truncated). Get a fresh copy, or re-save it if it is "
                          f"complete")
    try:
        ident = identify(path, reg, data)
    except Exception as e:                       # noqa: BLE001
        return quarantine(f"could not be read: {type(e).__name__}: {e}")
    if ident.doc is None:
        return quarantine(f"{ident.how}: {ident.reason} {list(ident.candidates) or ''}".strip())
    doc = ident.doc
    try:
        vi = version_of(path, doc, http_last_modified)
    except Exception as e:                       # noqa: BLE001
        return quarantine(f"recognised as {doc.doc_id} ({doc.title}), but its version could not be dated: "
                          f"{type(e).__name__}: {e}")
    # two different files can state one version date (AHCCCS edited the 7/8/2024 Chapter 19 without changing its
    # revision date); the version order would then be arbitrary, so the second waits for a person to keep one
    if vi.date:
        same_day = [h for h in held if h.get("status") == "active" and h.get("source_id") == doc.source_id
                    and h.get("document_key") == doc.document_key and h.get("version_date") == vi.date]
        if same_day:
            return quarantine(f"recognised as {doc.doc_id} ({doc.title}) dated {vi.date}, but "
                              f"{same_day[0]['source_version_id']} ({same_day[0].get('original_name') or ''}) already "
                              f"holds that date with different bytes: two files for one version date. Keep one: "
                              f"remove this file from the inbox, or compare the two first.")
    ext = os.path.splitext(path)[1].lower() or {"pdf": ".pdf", "xlsx": ".xlsx", "zip": ".zip"}.get(kind, "")
    dest = archive_path(doc, vi.label, sha, ext, archive_dir)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    if not os.path.exists(dest):
        with open(dest, "wb") as f:
            f.write(data)
    return {**base, "source_version_id": ledger.version_id(doc.doc_id, vi.label, sha), "source_id": doc.source_id,
            "document_key": doc.document_key, "version_date": vi.date, "version_label": vi.label,
            "version_basis": vi.basis, "version_evidence": vi.evidence, "period_end": vi.period_end,
            "archive_path": dest, "status": "active",
            "notes": f"recognised by {ident.how}" + ("" if doc.status == "active" else
                                                      f"; registry status {doc.status}")}


def scan(inbox_dir: str | None = None) -> list[str]:
    """Every file under the inbox, in a stable order (hidden files and Office lock files skipped)."""
    root = inbox_dir or config.INBOX_DIR
    out = []
    for dirpath, _, files in os.walk(root):
        for f in files:
            if f.startswith((".", "~$")):
                continue
            out.append(os.path.join(dirpath, f))
    return sorted(out)


def intake_all(reg: Registry, held: list[dict], inbox_dir: str | None = None, **kw) -> list[dict]:
    """Accession every inbox file; files later in the same batch see the earlier ones (duplicates inside a batch)."""
    rows, known = [], list(held)
    for path in scan(inbox_dir):
        row = accession(path, reg, known, **kw)
        rows.append(row)
        if row["status"] == "active":
            known.append(row)
    return rows


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def new_run_id(prefix: str) -> str:
    """parse-20261102T181034Z-3fa9: the time and four random hex digits, so two runs in one second never share an id
    (or a run folder)."""
    import secrets
    return f"{prefix}-{stamp()}-{secrets.token_hex(2)}"
