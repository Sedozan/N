"""Exception overlays: an exception one source states against rules another source holds (EPSDT for members under 21
against AHCCCS service limits; emergency services without prior authorization against the PA guidelines).

An exception record (kind "exception") overlays the records that share a code with it, are of a kind it targets
(params.target_kinds; any kind checked on claims when it names none), overlap it in time and in applicability, and
are neither rejected nor superseded. An overlaid executable record becomes conditional: a person confirms, finding by
finding, whether the exception applies. Overlays never delete or change the record they touch.

The Same Day table overlays pair rules other sources state (table_allows): where the table in force marks a pair A
(allowed on the same day) or A* (allowed when a different provider bills) and a narrative rule prohibits it for any
provider (or does not say), the rule would flag what the code-level table allows (precedence P1 and P2; Chapter 19
points to the table). An A cell builds no record, so this is not a conflict between two records: the rule becomes
conditional and its reasons name the pairs; a Fix to its scope or partners clears it.
"""
from __future__ import annotations

from collections import defaultdict

from ..core.kinds import KINDS
from .conflicts import _applies_together, _overlap


def find(views: dict) -> dict:
    """{record_id: [(exception record_id, reason)]}. views as in kb/conflicts.find."""
    by_code: dict = defaultdict(list)
    for rid, v in views.items():
        if v["status"] in ("rejected", "superseded"):
            continue
        for c in v["codes"]:
            by_code[c].append(rid)
    out: dict = defaultdict(list)
    for xid, xv in views.items():
        x = xv["record"]
        if x.kind != "exception" or xv["status"] in ("rejected", "superseded"):
            continue
        targets = set((x.params or {}).get("target_kinds") or [])
        for c in xv["codes"]:
            for rid in by_code.get(c, []):
                if rid == xid:
                    continue
                r = views[rid]["record"]
                if r.kind == "exception" or not getattr(KINDS.get(r.kind), "checkable", False):
                    continue
                if targets and r.kind not in targets:
                    continue
                if _overlap(xv["window"], views[rid]["window"]) is None or not _applies_together(x, r):
                    continue
                effect = (x.params or {}).get("effect") or "changes"
                reason = (f"an exception in {x.citation.get('source_id')} p.{x.citation.get('page_start') or '?'} "
                          f"{effect} it ({xid}): a person confirms per finding whether it applies")
                if (xid, reason) not in out[rid]:
                    out[rid].append((xid, reason))
    return dict(out)


def table_allows(views: dict, rows: list, wins: dict) -> dict:
    """{record_id: [(table version id, reason)]} for pair rules of other sources against the Same Day table rows
    (kb_table_rows, spec same_day) of the versions whose windows overlap the rule's. wins: version windows."""
    allowed: dict = defaultdict(list)            # (row code, column code) -> [(version, indicator, window)]
    for t in rows:
        d, w = t.get("data") or {}, wins.get(t.get("source_version_id"))
        if t.get("spec") == "same_day" and w and d.get("indicator") in ("A", "A*"):
            allowed[(d.get("row_code"), d.get("col_code"))].append(
                (t["source_version_id"], d["indicator"], (w["effective_start"], w["effective_end"])))
    out: dict = {}
    for rid, v in views.items():
        r = v["record"]
        if r.kind != "pair_prohibited" or r.origin == "table" or v["status"] in ("rejected", "superseded"):
            continue
        p = r.params or {}
        any_provider = p.get("scope") != "member_provider_day"
        pairs = {(s, q) for s in v["codes"] for q in p.get("partners") or []}
        if p.get("both_ways"):
            pairs |= {(q, s) for s, q in pairs}
        found: dict = defaultdict(list)
        for pair in sorted(pairs):
            for svid, ind, win in allowed.get(pair, []):
                if (ind == "A" or any_provider) and _overlap(win, v["window"]) is not None:
                    found[svid].append(f"{pair[0]} with {pair[1]} {ind}")
        if found:
            out[rid] = [(svid, f"the Same Day table {svid} marks {', '.join(cells)} (A: allowed on the same day; A*: "
                               f"allowed when a different provider bills), which this rule prohibits"
                               f"{' for any provider' if any_provider else ''}: the table is the code-level source "
                               f"(P1, P2), so a person confirms per finding or fixes the rule's scope or partners")
                        for svid, cells in sorted(found.items())]
    return out
