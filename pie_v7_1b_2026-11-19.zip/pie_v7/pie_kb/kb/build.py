"""The knowledge base build: every record with its effective status, window, codes, class and conflicts, as of a date.

  window          a version runs from its own date to the day before the next version of its document
                  (sources/ledger.windows); a record's window is its version's, narrowed by dates its text or table
                  row states. A corrected record (a fix, origin sme) runs through the earlier and later versions
                  where its original was superseded by carrying the fix (kb/status.py); a record a person added runs
                  over its own version only.
  presumed        a version is HELD only while no other edition can have been in force: up to the day before a
                  release known to exist whose file is not held (reference/known_releases.csv) and no longer than its
                  publication cadence (reference/release_cadence.csv; monthly sources one month); the newest edition
                  only to the latest date it was confirmed current (reference/current_checks.csv), or its own date.
                  Past that, a record is kept only when the next edition held repeats it (an approved record with the
                  same record_key; the newest edition has no next one), and only as PRESUMED: that part of its window is
                  written as its own row (record_id~2; presumed_from = its start; executable becomes conditional,
                  with the reason), so a consumer reading only class and window never judges a presumed date as
                  executable. A record the next edition does not repeat ends at the held end: when it changed is
                  unknown. A correction carried through several versions gets a presumed part for each gap.
  status          decisions bound to content, signed readings, carried over between versions (kb/status.py)
  codes           a record that names a service gets the service's code set (kb/resolve.py)
  class           executable, conditional, signal, knowledge or unresolved, for the claim type (core/checkability.py,
                  with the claim fields measured on the claims table: reference/claim_fields.csv, kb/fields.py)
  conflicts       kb/conflicts.py; an open conflict holds both records back
  overlays        kb/overlays.py; an exception another record states makes an executable record conditional
  executable_now  executable, approved, in force on the build date, and not held back by a conflict (a
                  presumed part is never executable)
Writes kb_records_current (the projection detection reads), kb_records_history, kb_conflicts, kb_record_diffs,
kb_code_index and kb_build_log. It reads the records and decisions and changes neither.
"""
from __future__ import annotations

import dataclasses
import glob
import os
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone

from .. import config
from ..core.checkability import execution_class
from ..core.hashing import files_hash
from ..core.record import Record
from ..review import decisions as DC
from ..sources import ledger
from ..sources.intake import new_run_id
from ..tables import readings as RD
from . import conflicts as CF
from . import diff as DF
from . import fields as FL
from . import overlays as OV
from . import resolve as RS
from . import status as ST


def package_sha() -> str:
    files = sorted(glob.glob(os.path.join(config.PACKAGE_DIR, "**", "*.py"), recursive=True) +
                   glob.glob(os.path.join(config.REFERENCE_DIR, "*.csv")))
    return files_hash(*files, n=12)


def version_order(wins: dict) -> dict:
    """{(source_id, document_key): [source_version_id oldest first]}; undated versions last."""
    out: dict = defaultdict(list)
    for w in sorted(wins.values(), key=lambda w: (w["effective_start"] or "9999-12-31", w.get("first_seen_at") or "",
                                                  w["source_version_id"])):
        out[(w["source_id"], w["document_key"])].append(w["source_version_id"])
    return dict(out)


def _day_after(d: str) -> str:
    return (date.fromisoformat(d) + timedelta(days=1)).isoformat()


def _version_parts(w: dict, key: str, repeated: dict, continues: bool) -> list:
    """[(start, end, 'held' | 'presumed', why)] of one version's window for a record with this key. Past the held end,
    the record goes on as presumed when `continues` (a correction's chain goes on to the next version), when no
    later edition is held, or when the next edition held repeats it with an approved record; otherwise it ends."""
    vs, ve, he = w["effective_start"], w["effective_end"], w.get("held_end")
    if not vs or not he or (ve is not None and he >= ve):
        return [(vs, ve, "held", "")]
    nxt = w.get("next_version_id")
    parts = [(vs, he, "held", "")]
    if continues or nxt is None or key in repeated.get(nxt, set()):
        missing = w.get("missing_releases") or []
        why = w.get("held_basis") or "the edition in force is not held"
        if len(missing) > 1:
            why += f" (releases not held: {', '.join(missing)})"
        why += f"; {nxt} repeats it" if nxt else "; no later edition is held"
        parts.append((_day_after(he), ve, "presumed", why))
    return parts


def _window(r: Record, wins: dict, order: dict, covers: dict, repeated: dict) -> tuple:
    """(start, end, basis, parts) of a record. parts: [(start, end, 'held' | 'presumed', why)] in date order; the
    build writes one row per part, so a consumer that reads only class and window never treats a presumed date as
    executable. covers: {original record_id: versions where a copy of it was superseded by carrying the fix};
    repeated: {source_version_id: record_keys of its approved records}."""
    svid = r.citation.get("source_version_id")
    w = wins[svid]
    basis = f"version ({w['window_basis']})"
    chain = [svid]
    original = (r.review or {}).get("corrected_from") if r.origin == "sme" else None
    if original:
        # a correction runs over exactly the versions where its original was superseded (kb/status.py carried the
        # fix there: same meaning, section reading the same, no term defined differently), when they adjoin its own
        doc_order = order.get((r.citation.get("source_id"), r.citation.get("document_key")), [])
        mine = covers.get(original, set())
        if svid in doc_order:
            i = doc_order.index(svid)
            later = []
            for nxt in doc_order[i + 1:]:
                if nxt not in mine:
                    break
                later.append(nxt)
            earlier = []
            for prv in reversed(doc_order[:i]):
                if prv not in mine:
                    break
                earlier.insert(0, prv)
            chain = earlier + [svid] + later
            if len(chain) > 1:
                basis = f"version ({w['window_basis']}) carried through {', '.join(v for v in chain if v != svid)}: " \
                        f"the original was superseded there too"
    parts = []
    for k, v in enumerate(chain):
        parts += _version_parts(wins[v], r.record_key, repeated, continues=k + 1 < len(chain))
    merged: list = []
    for p in parts:                                # adjoining parts of one kind are one part
        if merged and merged[-1][2] == p[2] and merged[-1][1] and p[0] and _day_after(merged[-1][1]) == p[0]:
            merged[-1] = (merged[-1][0], p[1], p[2], merged[-1][3] or p[3])
        else:
            merged.append(p)
    rs, re_ = r.effective_start, r.effective_end
    clipped = []
    for ps, pe, kind, why in merged:               # dates the record's own text or row states narrow every part
        s_ = max([x for x in (ps, rs) if x]) if (ps or rs) else None
        e_ = min([x for x in (pe, re_) if x]) if (pe or re_) else None
        if not (s_ and e_ and s_ > e_):
            clipped.append((s_, e_, kind, why))
    if r.window_basis not in ("version", "", None):
        basis += f" + {r.window_basis}"
    last = wins[chain[-1]]
    if not clipped:
        vs, ve = merged[0][0], merged[-1][1]
        start = max([x for x in (vs, rs) if x]) if (vs or rs) else None
        end = min([x for x in (ve, re_) if x]) if (ve or re_) else None
        full_end = last["effective_end"]
        if (rs and full_end and rs > full_end) or (re_ and vs and re_ < vs):
            why = "its stated dates fall outside its version"
        else:
            why = (f"its stated dates fall after its version's held end {ve} ({last.get('held_basis')}), and "
                   f"{last.get('next_version_id')} does not repeat it")
        return start, end, f"{basis}; empty: {why}", []
    if any(k == "presumed" for _, _, k, _ in clipped):
        basis += "; " + "; ".join(f"{k} {a or '?'} to {b or 'open'}" + (f" ({why})" if why else "")
                                  for a, b, k, why in clipped)
    if last.get("held_end") and (last["effective_end"] is None or last["held_end"] < last["effective_end"]) \
            and clipped[-1][2] == "held" and clipped[-1][1] == last["held_end"]:
        basis += f"; ends {last['held_end']}: {last['held_basis']}, and {last.get('next_version_id')} does not " \
                 f"repeat it"
    return clipped[0][0], clipped[-1][1], basis, clipped


def _root(record_id: str, status: dict) -> str:
    """The record whose own decision a carried status comes from."""
    seen = set()
    while record_id not in seen:
        seen.add(record_id)
        nxt = ((status.get(record_id) or {}).get("review") or {}).get("carried_from")
        if not nxt:
            break
        record_id = nxt
    return record_id


def _extracted(store) -> set:
    """Versions whose records come from a complete narrative extraction (decisions are carried only into those). Once
    a version has a complete run, a later partial run never replaces its records (extract/run.persist), so any
    complete run counts."""
    return {p["source_version_id"] for p in store.read("processing_ledger")
            if p["stage"] == "extract_narrative" and p["status"] == "ok"}


def build(store, reg, today: date | None = None, claim_type: str | None = None, log=print) -> dict:
    today = today or date.today()
    day = today.isoformat()
    ct = claim_type or config.CLAIM_TYPE
    build_id = new_run_id("build")
    warnings: list = []
    monthly = {d.source_id for d in reg.docs if d.cadence == "monthly"}
    single = {(d.source_id, d.document_key) for d in reg.docs if d.cadence == "once"}
    wins = {w["source_version_id"]: w for w in ledger.windows(store.read("source_versions"), today, monthly,
                                                               ledger.known_releases(), ledger.release_cadence(),
                                                               ledger.current_checks(), single)}
    unconfirmed = sorted(f"{w['source_id']} {w['document_key']} ({w['effective_start']})" for w in wins.values()
                         if w["held_basis"].startswith("not confirmed current"))
    if unconfirmed:
        warnings.append(f"{len(unconfirmed)} newest edition(s) never checked against the AHCCCS site, so their rules "
                        f"are presumed after their own dates: {', '.join(unconfirmed)}. Record a check in "
                        f"reference/current_checks.csv")
    order = version_order(wins)
    records = [Record.from_row(r) for r in store.read("records")]
    live = [r for r in records if r.citation.get("source_version_id") in wins]
    if len(live) < len(records):
        warnings.append(f"{len(records) - len(live)} record(s) belong to versions that are not active; left out")
    sections = {s["section_id"]: s for s in store.read("sections")}
    rlog = DC.Log(store.read("review_log"))
    readings = RD.load()
    value_sets = store.read("value_sets")
    measured = FL.load()

    resolved = RS.resolve(live, value_sets, rlog)
    classes = {}                                   # class does not depend on status: computed once, before it
    with FL.applied(measured):
        for r in live:
            codes = resolved.get(r.record_id, (None, ""))[0]
            judged = dataclasses.replace(r, subject={**r.subject, "codes": codes}) if codes else r
            cls, why = execution_class(judged, ct)
            classes[r.record_id] = (cls, FL.explain(why, judged, ct, measured))
    strict = {rid for rid, (cls, _) in classes.items() if cls in ("executable", "conditional", "signal")}
    status = ST.resolve(live, order, sections, rlog, readings, strict=strict, complete=_extracted(store))
    repeated: dict = defaultdict(set)              # record keys each version states with an approved record
    covers: dict = defaultdict(set)                # original record -> versions where it was superseded
    for r in live:
        st = status[r.record_id]
        if st["status"] == "approved":
            repeated[r.citation.get("source_version_id")].add(r.record_key)
        elif st["status"] == "superseded":
            covers[_root(r.record_id, status)].add(r.citation.get("source_version_id"))
    windows = {r.record_id: _window(r, wins, order, covers, repeated) for r in live}
    docs = {}
    for r in live:
        try:
            docs[r.record_id] = reg.get(r.citation.get("source_id"), r.citation.get("document_key") or "main")
        except KeyError:
            warnings.append(f"{r.record_id}: source {r.citation.get('source_id')} is not in the registry")
    views = {r.record_id: {"record": r, "status": status[r.record_id]["status"], "window": windows[r.record_id][:2],
                           "codes": list(r.subject.get("codes") or []) or resolved.get(r.record_id, ([], ""))[0]}
             for r in live}
    statements = [(p, DC.precedence_status(p, rlog)[0]) for p in reg.precedence]
    carried = CF.resolutions(rlog, store.read("conflicts"), {r.record_id: r.content_sha for r in records})
    conflict_rows = CF.find(views, docs, statements, rlog, build_id, carried, warnings)
    held = CF.effects(conflict_rows)
    overlays = OV.find(views)
    pairs_allowed = OV.table_allows(views, store.read("table_rows", where={"spec": "same_day"}), wins)
    for rid, found in pairs_allowed.items():
        overlays.setdefault(rid, []).extend(found)
    if pairs_allowed:
        warnings.append(f"{len(pairs_allowed)} pair rule(s) from other sources prohibit pairs the Same Day table in "
                        f"force allows (A, or A* for a different provider): conditional until a person fixes them "
                        f"({', '.join(sorted(pairs_allowed)[:5])}{' ...' if len(pairs_allowed) > 5 else ''})")
    in_conflicts: dict = defaultdict(list)
    for c in conflict_rows:
        in_conflicts[c["record_a"]].append(c["conflict_id"])
        in_conflicts[c["record_b"]].append(c["conflict_id"])

    current, history, index, classes_after = [], [], [], {}
    for r in live:
        st = status[r.record_id]
        start, end, wbasis, parts = windows[r.record_id]
        codes, rbasis = resolved.get(r.record_id, (None, ""))
        cls, why = classes[r.record_id]
        ov = overlays.get(r.record_id, [])
        if ov:
            why = list(why) + [reason for _, reason in ov]
            cls = "conditional" if cls == "executable" else cls
        classes_after[r.record_id] = cls
        held_back = [held[r.record_id]] if r.record_id in held else []
        base = {"build_id": build_id, "record_key": r.record_key,
                "content_sha": r.content_sha, "kind": r.kind, "subject": r.subject, "params": r.params,
                "conditions": r.conditions, "exceptions": r.exceptions, "applicability": r.applicability,
                "statement": r.statement, "citation": r.citation, "source_id": r.citation.get("source_id"),
                "document_key": r.citation.get("document_key"),
                "source_version_id": r.citation.get("source_version_id"), "authority_level": r.authority_level,
                "origin": r.origin, "status": st["status"], "status_basis": st["basis"], "window_basis": wbasis,
                "resolved_codes": codes or [], "resolution": rbasis, "conflicts": in_conflicts.get(r.record_id, []),
                "overlays": [x for x, _ in ov], "flags": list(r.flags or []) + st["flags"]}
        # one row per part: a presumed part is its own row, conditional, so a consumer that reads only the class and
        # the window never judges a presumed date as executable
        for i, (ps, pe, kind, pwhy) in enumerate(parts or [(start, end, "held", "")]):
            presumed = kind == "presumed"
            pcls = "conditional" if presumed and cls == "executable" else cls
            reasons = list(why) + ([f"from {ps} this edition is not known to be the one in force ({pwhy}): hold "
                                    f"findings on these dates until the edition in force is obtained or this one is "
                                    f"confirmed current, or record the source used to confirm them"]
                                   if presumed else []) + held_back
            in_force = bool(ps) and ps <= day and (pe is None or pe >= day)
            now = pcls == "executable" and st["status"] == "approved" and in_force and r.record_id not in held
            rid = r.record_id if i == 0 else f"{r.record_id}~{ps}"     # a later part is named by its first date
            row = {**base, "record_id": rid, "part_of": r.record_id,
                   "review": st["review"] if i == 0 else {**st["review"], "part_of": r.record_id},
                   "effective_start": ps, "effective_end": pe, "presumed_from": ps if presumed else None,
                   "in_force_today": in_force, "execution_class": pcls, "execution_reasons": reasons,
                   "executable_now": now}
            current.append(row)
            history.append({k: row[k] for k in ("build_id", "record_id", "part_of", "record_key", "content_sha", "kind",
                                                 "status", "execution_class", "statement", "citation",
                                                 "effective_start", "effective_end", "review", "presumed_from",
                                                 "window_basis", "executable_now")})
            p = r.params or {}
            for role, cs in (("subject", r.subject.get("codes") or []), ("subject_resolved", codes or []),
                             ("partner", p.get("partners") or []), ("parent", p.get("parent_codes") or [])):
                for c in cs:
                    index.append({"build_id": build_id, "code": c, "record_id": rid, "part_of": r.record_id,
                                  "kind": r.kind, "role": role,
                                  "source_id": r.citation.get("source_id"), "effective_start": ps,
                                  "effective_end": pe, "status": st["status"], "execution_class": pcls,
                                  "presumed_from": row["presumed_from"]})
    by_version: dict = defaultdict(list)
    for r in live:
        by_version[r.citation.get("source_version_id")].append(r)
    diff_rows, diff_counts = DF.diffs(by_version, order, build_id)

    first = [c for c in current if c["record_id"] == c["part_of"]]     # one row per record: its first part
    counts = {"records": len(live), "rows": len(current),
              "presumed_rows": sum(1 for c in current if c["presumed_from"]),
              "status": dict(Counter(c["status"] for c in first)),
              "class": dict(Counter(classes_after[c["part_of"]] for c in first)),
              "executable_now": sum(1 for c in current if c["executable_now"]),
              "in_force_today": sum(1 for c in current if c["in_force_today"]),
              "conflicts": dict(Counter(c["status"].split(":")[0] for c in conflict_rows)),
              "overlaid": sum(1 for c in first if c["overlays"]),
              "diffs": diff_counts, "codes_indexed": len({i["code"] for i in index}),
              "categories": dict(Counter(c["resolution"].split(":")[0] for c in current if c["resolution"]))}
    sources = sorted({(w["source_id"], w["document_key"], w["source_version_id"], w["effective_start"] or "",
                       w["effective_end"] or "") for w in wins.values()})
    store.write("records_current", current)
    store.write("records_history", history, mode="append")
    store.write("conflicts", conflict_rows, mode="append")
    store.write("record_diffs", diff_rows, mode="append")
    store.write("code_index", index)
    built_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
    store.write("build_log", [{"build_id": build_id, "built_at": built_at, "pie_version": config.PIE_VERSION,
                               "package_sha": package_sha(), "counts": counts,
                               "sources": [list(s) for s in sources], "warnings": warnings}], mode="append")
    log(f"build {build_id} as of {day}: {counts['records']:,} records; status {counts['status']}; class "
        f"{counts['class']}; executable now {counts['executable_now']:,}; conflicts {counts['conflicts']}")
    for w in warnings[:10]:
        log(f"  warning: {w}")
    return {"build_id": build_id, "as_of": day, **counts, "warnings": warnings}
