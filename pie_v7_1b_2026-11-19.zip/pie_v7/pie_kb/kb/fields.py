"""Claim fields measured on the claims table (reference/claim_fields.csv), applied when the build classes records.

core/checkability.py holds what PIE assumed before anyone measured the claims (most fields 'unverified'). What a01
measured is data, not code: it lives in the reference file, so recording a measurement never changes the code the
extraction is keyed to. A field marked available there moves every record that needs it up by itself; one marked
unavailable (EVENT_PA_NO, too sparse to show a missing authorization) moves such records down to knowledge, and the
record's reasons quote the measurement.
"""
from __future__ import annotations

import csv
import dataclasses
import os
from contextlib import contextmanager

from .. import config
from ..core import checkability as CK

STATUSES = (CK.AVAILABLE, CK.UNVERIFIED, CK.UNAVAILABLE)


def load(path: str | None = None) -> dict:
    """{(claim_type, field): row}."""
    path = path or os.path.join(config.REFERENCE_DIR, "claim_fields.csv")
    if not os.path.exists(path):
        return {}
    out = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            ct, fld, st = (row.get("claim_type") or "").strip(), (row.get("field") or "").strip(), \
                (row.get("status") or "").strip()
            if ct in CK.CLAIM_TYPES and fld and st in STATUSES:
                out[(ct, fld)] = {**row, "status": st}
    return out


def claim_types(measured: dict) -> dict:
    """Copies of the checkability claim types with the measured statuses."""
    out = {}
    for name, ct in CK.CLAIM_TYPES.items():
        upd = {f: row["status"] for (c, f), row in measured.items() if c == name}
        out[name] = dataclasses.replace(ct, fields={**ct.fields, **upd}) if upd else ct
    return out


@contextmanager
def applied(measured: dict):
    """Classes computed inside the block use the measured fields; the module's own defaults come back after."""
    saved = dict(CK.CLAIM_TYPES)
    CK.CLAIM_TYPES.update(claim_types(measured))
    try:
        yield
    finally:
        CK.CLAIM_TYPES.clear()
        CK.CLAIM_TYPES.update(saved)


def explain(why: list, rec, claim_type: str, measured: dict) -> list:
    """The reasons, plus the measurement behind every field the record needs that is not available."""
    base, cond = CK.required_fields(rec)
    notes = [f"{f}: {measured[(claim_type, f)]['evidence']}" for f in sorted(base | cond)
             if (claim_type, f) in measured and measured[(claim_type, f)]["status"] != CK.AVAILABLE]
    return list(why) + notes
