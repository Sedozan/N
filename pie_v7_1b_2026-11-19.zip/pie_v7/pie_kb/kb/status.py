"""A record's effective review status at build time.

  table records      approved when every reading they rest on is signed; rejected when one of them is rejected
  other records      the latest decision on the record's current content. With none, the decision on the same meaning
                     (record_key) in another version of the document carries over when the record's section reads the
                     same in both and no term it uses was defined differently: forward from the latest earlier version,
                     and back from the nearest later version that decided it (a person reviewed the newest edition; an
                     older edition loaded afterwards needs review only where its words differ). When the section
                     differs, the record goes back for review, with the words that changed. An older copy that reads
                     the same as a later copy still waiting follows it: one decision serves both, so the review
                     workbook lists the later copy only.
                     Otherwise the extraction status (proposed, or needs_review when grounding flagged something).
  fixed records      a fix supersedes the original; the corrected record (origin sme) waits for a second reviewer.
                     A supersession carries over like an approval, and the corrected record's window runs through the
                     other versions whose section reads the same (kb/build.py)
An approval never moves a record outside its own window: the window comes from the version (kb/build.py), so an
approved record of an old version keeps judging the dates its version was in force.

"Reads the same": equal after glyph, case, spacing and punctuation clean-up (reading_form). An editorial comma or a
bullet glyph does not send a record back to review; a changed word or number does.
"""
from __future__ import annotations

import difflib
import re
from collections import defaultdict

from ..core.text import clean, match_form
from ..review import decisions as DC

DECIDED = {"approve": "approved", "reject": "rejected", "fix": "superseded", "defer": "needs_review"}
CARRIES = ("approved", "rejected", "superseded")
NOT_REVIEWED = "not reviewed"

# list markers keep their level: a bullet glyph swap (• in one edition, the Symbol-font U+F0B7 in the next) reads the
# same, a sub-item turned into an item does not
_LEVELS = {**{ord(c): " xlistdisc " for c in "•●∙\uf0b7"},       # the glyphs AHCCCS uses for a level, by shape
           **{ord(c): " xlistcircle " for c in "○◦"},
           **{ord(c): " xlistsquare " for c in "■▪\uf0a7"},
           **{ord(c): " xlistarrow " for c in "‣⁃➢"},
           ord("\uf020"): " "}                             # U+F020: the Symbol-font space
_DROP = re.compile(r"[,\"()\[\]!?]")                      # commas, quotes, brackets: editorial
_BEFORE = re.compile(r"\s+([.;:])")                         # 'Matrix .' reads as 'Matrix.'
_WS = re.compile(r"\s+")


def reading_form(text: str | None) -> str:
    """A section's words for comparing two versions: case, spacing, commas, quotes, apostrophes and brackets are
    ignored; words, numbers, the sentence and clause marks . ; : and list levels count. Private-use glyphs other
    than the Symbol-font bullet and space (a Wingdings check mark, a Symbol ≥) are kept, so changing one counts."""
    s = match_form((text or "").translate(_LEVELS)).replace("'", "")    # member's, members' and members alike
    s = _DROP.sub(" ", s)
    s = _BEFORE.sub(r"\1", s)
    return _WS.sub(" ", s).strip()


def word_changes(old: str | None, new: str | None, limit: int = 3, form=None) -> str:
    """The words that differ between two texts, briefly: "'member' → 'members'; added 'G2214 ...'". form: the
    normalisation compared in (reading_form by default; clean for quotes, where case and punctuation count)."""
    form = form or reading_form
    a, b = form(old).split(), form(new).split()
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == "equal":
            continue
        x, y = " ".join(a[i1:i2])[:60], " ".join(b[j1:j2])[:60]
        out.append(f"'{x}' → '{y}'" if x and y else f"added '{y}'" if y else f"removed '{x}'")
    if not out:
        return "no word differs"
    return "; ".join(out[:limit]) + (f"; {len(out) - limit} more" if len(out) > limit else "")


def _doc(r) -> tuple:
    return r.citation.get("source_id"), r.citation.get("document_key")


def definitions(records: list) -> dict:
    """{source_version_id: {term: (definition, ...)}} in match form, from definition records. A term one version
    defines twice keeps both definitions, so the comparison does not depend on which row came last."""
    out: dict = defaultdict(lambda: defaultdict(set))
    for r in records:
        if r.kind == "definition" and r.subject.get("term"):
            out[r.citation.get("source_version_id")][match_form(r.subject["term"])].add(
                match_form(str(r.params.get("definition") or "")))
    return {v: {t: tuple(sorted(d)) for t, d in terms.items()} for v, terms in out.items()}


def _uses(quote: str, term: str) -> bool:
    return bool(term) and re.search(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])", match_form(quote)) is not None


class _Sections:
    """Section texts in reading form, computed once."""

    def __init__(self, sections: dict):
        self.sections, self._form = sections, {}

    def text(self, r) -> str | None:
        s = self.sections.get(r.citation.get("section_id"))
        return s.get("text") if s else None

    def form(self, r) -> str | None:
        sid = r.citation.get("section_id")
        if sid not in self._form:
            t = self.text(r)
            self._form[sid] = reading_form(t) if t is not None else None
        return self._form[sid]

    def same(self, a, b) -> bool:
        fa = self.form(a)
        return fa is not None and fa == self.form(b)

    def key(self, r) -> str | None:
        s = self.sections.get(r.citation.get("section_id"))
        return (s or {}).get("section_key") or r.citation.get("section_key")


class _Copies:
    """Copies of each meaning in other versions: the same record_key in the same section first (one version can state
    one meaning in several sections), then the same record_key anywhere. Built in record_id order, so the result does
    not depend on how the store returned the rows."""

    def __init__(self):
        self.by_section, self.by_key = {}, {}

    def get(self, r, secs):
        return self.by_section.get((r.record_key, secs.key(r))) or self.by_key.get(r.record_key)

    def merge(self, here: list, secs) -> None:
        for r, value in here:
            self.by_section[(r.record_key, secs.key(r))] = value
            self.by_key[r.record_key] = value


class _Ctx:
    """What carrying a decision between versions checks: sections, definitions, which records are claim-checkable
    (their quoted words must match too) and which versions are fully extracted (decisions go only into those)."""

    def __init__(self, records: list, sections: dict, strict: set | None, complete: set | None):
        self.secs, self.defs = _Sections(sections), definitions(records)
        self.strict, self.complete = strict or set(), complete

    def terms(self, r, a: str, b: str) -> list:
        """Terms r quotes that the two versions define differently, or that only one of them defines."""
        old, new = self.defs.get(a, {}), self.defs.get(b, {})
        changed = {t for t in old.keys() | new.keys() if old.get(t) != new.get(t)}
        return sorted(t for t in changed if _uses(r.citation.get("quote") or "", t))

    def quote_differs(self, r, o) -> bool:
        return r.record_id in self.strict and clean(r.citation.get("quote")) != clean(o.citation.get("quote"))

    def open(self, r) -> bool:
        return self.complete is None or r.citation.get("source_version_id") in self.complete


def resolve(records: list, version_order: dict, sections: dict, log: DC.Log, readings: dict,
            strict: set | None = None, complete: set | None = None) -> dict:
    """{record_id: {"status", "basis", "review", "flags"}} for every record.

    version_order: {(source_id, document_key): [source_version_id oldest first]}; sections: {section_id: row};
    strict: record ids that can judge a claim (executable, conditional or signal): a decision carries to them only
    when the quoted words are the same too (case and punctuation counting); complete: versions whose narrative
    extraction finished (None: not checked): decisions carry only into those."""
    reading_state = {rid: DC.reading_status(r, log) for rid, r in readings.items()}
    ctx = _Ctx(records, sections, strict, complete)
    by_version: dict = defaultdict(list)
    for r in sorted(records, key=lambda x: (x.record_id, x.citation.get("section_id") or "")):
        by_version[r.citation.get("source_version_id")].append(r)
    out: dict = {}
    secs = ctx.secs
    for doc, svids in version_order.items():
        prior = _Copies()                        # the latest earlier version holding each meaning
        for svid in svids:
            here = []
            for r in by_version.get(svid, []):
                st = _one(r, reading_state, log, prior.get(r, secs), ctx)
                out[r.record_id] = st
                here.append((r, (r, st)))
            prior.merge(here, secs)
        later = _Copies()                        # (record, state, representative) in the nearest later version
        decided = _Copies()                      # (record, state) in the nearest later version that decided it
        for svid in reversed(svids):
            here, here_decided = [], []
            for r in by_version.get(svid, []):
                st, rep = out[r.record_id], r
                forward_differs = st["basis"].startswith("was ") and any(
                    f["code"] == "back_to_review" for f in st["flags"])
                if r.origin != "table" and ctx.open(r) and (st["basis"] == NOT_REVIEWED or forward_differs):
                    nxt = later.get(r, secs)
                    if nxt and nxt[1]["status"] not in CARRIES and secs.same(nxt[0], r) \
                            and not ctx.quote_differs(r, nxt[0]) \
                            and not ctx.terms(r, svid, nxt[0].citation.get("source_version_id")):
                        if not forward_differs:      # same words as a later copy still waiting: decided with it
                            rep = nxt[2]
                            st = _follow(r, rep, out[rep.record_id], st)
                    else:
                        back = _carry(r, decided.get(r, secs), ctx, "back", st if not forward_differs else
                                      {"flags": [f for f in st["flags"] if f["code"] != "back_to_review"]})
                        if back and (not forward_differs or back["status"] in CARRIES):
                            st = back                # a same-text decision later on beats a differing one earlier
                    out[r.record_id] = st
                here.append((r, (r, st, rep)))
                if st["status"] in CARRIES:
                    here_decided.append((r, (r, st)))
            later.merge(here, secs)
            decided.merge(here_decided, secs)
    for r in records:                              # versions missing from the ledger: extraction status only
        out.setdefault(r.record_id, {"status": r.status, "basis": "version not in the ledger", "review": {},
                                     "flags": [{"code": "no_version", "text": "its version is not in the ledger"}]})
    return out


def _follow(r, rep, rep_state: dict, fallback: dict) -> dict:
    """An older copy whose section reads the same as a later copy still waiting for review: one decision, on the later
    copy (the representative), serves both; the next build carries it back here. The workbook lists only the
    representative, with the windows of the copies its decision serves."""
    flags = list(fallback.get("flags") or []) + [
        {"code": "follows", "text": f"reads the same as {rep.record_id} in {rep.citation.get('source_version_id')}, "
                                    f"which is waiting ({rep_state['status']}); decided with it"}]
    return {"status": fallback["status"],
            "basis": f"follows {rep.record_id}: same section and meaning, decided with it",
            "review": {"follows": rep.record_id}, "flags": flags}


def _carry(r, other, ctx: _Ctx, direction: str, fallback: dict | None = None) -> dict | None:
    """The status a record takes from the same meaning in another version (other = (record, state)), or None when
    that record was not decided. direction: 'forward' (other is earlier) or 'back' (other is later)."""
    if not other or other[1]["status"] not in CARRIES:
        return None
    o, ost = other
    flags = list((fallback or {}).get("flags") or [])
    svid, osvid = r.citation.get("source_version_id"), o.citation.get("source_version_id")
    terms = ctx.terms(r, svid, osvid)
    same, quote_differs = ctx.secs.same(o, r), ctx.quote_differs(r, o)
    verb = "carried forward" if direction == "forward" else "carried back"
    if same and not terms and not quote_differs:
        flags.append({"code": "carried_forward" if direction == "forward" else "carried_back",
                      "text": f"{ost['status']} in {osvid} ({ost['basis']}); its section reads the same"})
        return {"status": ost["status"], "basis": f"{verb} from {o.record_id}",
                "review": {**ost["review"], "carried_from": o.record_id}, "flags": flags}
    older, newer = (o, r) if direction == "forward" else (r, o)
    if terms:
        why = f"the term(s) {', '.join(terms)} are defined differently, or in one of the two editions only"
    elif quote_differs:
        quoted = word_changes(older.citation.get("quote"), newer.citation.get("quote"), form=clean)
        why = f"its quoted words differ ({quoted})"
    elif ctx.secs.form(o) is None or ctx.secs.form(r) is None:
        why = "its section could not be compared"
    else:
        why = f"its section differs ({word_changes(ctx.secs.text(older), ctx.secs.text(newer))})"
    flags.append({"code": "back_to_review", "text": f"{ost['status']} in {osvid}; {why}"})
    return {"status": "needs_review", "basis": f"was {ost['status']} in {osvid}; {why}",
            "review": {"previous": o.record_id}, "flags": flags}


def _one(r, reading_state: dict, log: DC.Log, earlier, ctx: _Ctx) -> dict:
    """earlier: (record, state) of the same meaning in the latest earlier version, or None."""
    flags: list = []
    if r.origin == "table":
        used = list((r.extraction or {}).get("readings") or [])
        states = {rid: reading_state.get(rid, ("proposed", "reading not in table_readings.csv")) for rid in used}
        rejected = [rid for rid, (s, _) in states.items() if s == "rejected"]
        pending = [rid for rid, (s, _) in states.items() if s != "signed"]
        if rejected:
            return {"status": "rejected", "basis": f"reading {', '.join(rejected)} rejected", "review": {},
                    "flags": flags}
        if pending:
            return {"status": "proposed", "basis": f"readings not signed: {', '.join(pending)}", "review": {},
                    "flags": flags}
        return {"status": "approved", "basis": "readings signed: " + ", ".join(used), "review": {
            "readings": {rid: b for rid, (_, b) in states.items()}}, "flags": flags}
    d, stale = log.current("record", r.record_id, r.content_sha)
    if stale and not d:
        flags.append({"code": "stale_decision", "text": f"{len(stale)} earlier decision(s) were made on other "
                                                        f"content; the record changed since"})
    if d:
        if d["decision"] == "approve" and r.origin == "sme" and DC.same_person(d["reviewer"],
                                                                                (r.review or {}).get("author")):
            return {"status": "needs_review", "basis": "approved by its own author: needs a second reviewer",
                    "review": _review(d), "flags": flags}
        return {"status": DECIDED[d["decision"]], "basis": f"{d['decision']} by {d['reviewer']} on "
                                                           f"{d['decided_at'][:10]}", "review": _review(d),
                "flags": flags}
    if r.origin == "sme" and (r.review or {}).get("author"):
        return {"status": "needs_review", "basis": f"authored by {r.review['author']}: needs a second reviewer",
                "review": dict(r.review), "flags": flags}
    if not ctx.open(r):
        flags.append({"code": "extraction_incomplete", "text": "its version's extraction has not finished: no "
                                                               "decision is carried into it yet"})
    else:
        carried = _carry(r, earlier, ctx, "forward", {"flags": flags})
        if carried:
            return carried
    base = r.status if r.status in ("proposed", "needs_review") else "proposed"
    return {"status": base, "basis": NOT_REVIEWED, "review": {}, "flags": flags}


def _review(d: dict) -> dict:
    return {"decision_id": d["decision_id"], "decision": d["decision"], "reviewer": d["reviewer"],
            "decided_at": d["decided_at"], "note": d.get("note") or ""}
