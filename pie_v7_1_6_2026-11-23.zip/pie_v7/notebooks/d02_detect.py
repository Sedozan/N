# Databricks notebook source
# MAGIC %md
# MAGIC # d02 · Detection: approved rules run over paid claim lines (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Every approved record of the latest build (07) judges the claim lines whose service date falls in its window, so
# MAGIC each line is judged by the edition in force on its date. Run 07 first; set the dates below; run all.
# MAGIC
# MAGIC **How to read a finding.**
# MAGIC - **violation**: the record is executable on that date (its edition is held, nothing in it needs a person).
# MAGIC - **lead**: a person confirms first. The reasons say what: an exception (Same Day note 2: an approved medical
# MAGIC   necessity exception), a parameter the source leaves open, a presumed date (the edition in force then is not
# MAGIC   held), a "may", or a rule for FFS lines when FFS_WHERE is not set.
# MAGIC - Dollars are the amounts paid on the flagged lines, each line counted once in the totals. They are not an
# MAGIC   overpayment estimate: a pair finding puts one line at issue, a limit finding a group of lines.
# MAGIC
# MAGIC **What does not run** (section 1): a record with a condition the claim cannot show (setting, member attribute,
# MAGIC service context), a limit in hours (it needs the code's billing unit), a period other than a day or a line, a
# MAGIC category no code set resolves, a record in an open conflict. Nothing is guessed.
# MAGIC
# MAGIC Lines: one row per claim line (ClaimID, LN_NO; rows of a line, such as an original and its reversal, are summed),
# MAGIC professional form A, net units and net paid above zero. The claims write -1 in an empty modifier slot.

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import uuid
from datetime import datetime, timezone

import pandas as pd

from pie_kb import detect as DT
from pie_kb.io.store import open_store

CLAIMS = "main.prod_input.all_data_C_A"
SINCE = "2026-04-01"            # service dates from (ISO): start with recent claims (the state's focus), then
                                # widen once the run time is known; the knowledge base holds editions from 10/1/2024
UNTIL = None                    # service dates to (ISO); None: the last date in the claims
FORMS = ("A",)                  # FORM_TYP: A = professional (CMS-1500)
WHERE = "1 = 1"                 # extra filter on the claims table
FFS_WHERE = None                # e.g. "FORM_TYP_DESC = 'FFS'": the lines that are FFS (a01 section 0 lists the values);
                                # None: rules written for FFS only (Chapter 19) run on every line, as leads
WRITE = True                    # append the findings to kb_findings (with this run's id)
TOP = 25

store = open_store(spark)  # noqa: F821
current = store.read("records_current")
build_id = current[0]["build_id"] if current else None
open_conflicts = {x for c in store.read("conflicts") if c.get("build_id") == build_id
                  and not str(c.get("status") or "").startswith("resolved") for x in (c["record_a"], c["record_b"])}
rules, skipped = DT.prepare(current, open_conflicts=open_conflicts, ffs_known=FFS_WHERE is not None)
run_id = f"detect-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:4]}"
print(f"PIE {config.PIE_VERSION} | {run_id} | build {build_id} | {len({r['part_of'] for r in rules}):,} records run "
      f"({len(rules):,} record-code rows); {len({s['part_of'] for s in skipped}):,} approved records do not run")

# COMMAND ----------

# MAGIC %md ## 1 · Which approved records run, and why the others do not

# COMMAND ----------

display(pd.DataFrame(DT.coverage(rules, skipped)))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 2 · Claim lines read

# COMMAND ----------

spark.sql(DT.lines_sql(CLAIMS, where=WHERE, forms=FORMS, since=SINCE, until=UNTIL,  # noqa: F821
                       ffs_where=FFS_WHERE)).createOrReplaceTempView("pie_lines")
display(spark.sql("""SELECT count(*) AS lines, count(DISTINCT member) AS members, min(dos) AS first_dos,
                            max(dos) AS last_dos, round(sum(paid), 2) AS paid, count_if(is_ffs) AS ffs_lines
                     FROM pie_lines"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 3 · Run

# COMMAND ----------

findings = (DT.run(spark, rules).selectExpr(f"'{run_id}' AS run_id", f"'{build_id}' AS build_id", "*")  # noqa: F821
            .cache())
findings.createOrReplaceTempView("pie_findings")
n = findings.count()
print(f"{n:,} findings")
if WRITE and n:
    findings.write.mode("append").option("mergeSchema", "true").saveAsTable(config.table("findings"))
    print("appended to", config.table("findings"))

# COMMAND ----------

# MAGIC %md ## 4 · Summary by source, kind and tier (a line flagged by two rules of one row is counted once)

# COMMAND ----------

display(spark.sql("""
    SELECT source_id, kind, tier, sum(findings) AS findings, count(*) AS lines, count(DISTINCT member) AS members,
           count(DISTINCT bprov) AS billing_providers, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT split(version, '@')[0] AS source_id, kind, tier, line_id, first(member) AS member,
                 first(bprov) AS bprov, first(paid) AS paid, count(*) AS findings
          FROM pie_findings GROUP BY 1, 2, 3, 4)
    GROUP BY 1, 2, 3 ORDER BY paid_on_lines DESC"""))  # noqa: F821
display(spark.sql("""
    SELECT tier, count(*) AS lines, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT line_id, first(paid) AS paid, max(tier) AS tier FROM pie_findings GROUP BY line_id)
    GROUP BY tier"""))  # noqa: F821
display(spark.sql("""
    SELECT count(*) AS lines_flagged, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT line_id, first(paid) AS paid FROM pie_findings GROUP BY line_id)"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 5 · The rules that flag the most dollars

# COMMAND ----------

display(spark.sql(f"""
    SELECT part_of AS record, kind, tier, first(statement) AS statement, first(source) AS source,
           first(locator) AS locator, count(DISTINCT line_id) AS lines, count(DISTINCT bprov) AS billing_providers,
           round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT DISTINCT part_of, kind, tier, statement, source, locator, line_id, bprov, paid FROM pie_findings)
    GROUP BY part_of, kind, tier ORDER BY paid_on_lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 6 · Billing providers with the most flagged dollars (each line once)

# COMMAND ----------

display(spark.sql(f"""
    SELECT bprov, count(DISTINCT line_id) AS lines, count(DISTINCT member) AS members,
           count(DISTINCT CASE WHEN tier = 'violation' THEN line_id END) AS violation_lines,
           count(DISTINCT part_of) AS rules, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT DISTINCT bprov, line_id, member, tier, part_of, paid FROM pie_findings)
    GROUP BY bprov ORDER BY paid_on_lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 7 · Findings with their evidence and the policy words (violations first)

# COMMAND ----------

display(spark.sql(f"""
    SELECT tier, kind, code, dos, member, bprov, sprov, units, paid, evidence, statement, source, version, locator,
           quote, reasons, line_id, record_id
    FROM pie_findings ORDER BY tier DESC, paid DESC LIMIT 500"""))  # noqa: F821
