"""Detection: approved knowledge base rules run over paid claim lines, by service date.

A rule judges a line only on the dates its row in kb_records_current covers (effective_start to effective_end), so
each claim is judged by the edition in force on its date of service. Only approved records run, and only those whose
whole content can be checked on the claim:

  violation   the record is executable on that date (class executable, edition held, no exception to confirm)
  lead        the record is conditional (an exception a person confirms, a parameter the source leaves open, a field
              not yet measured) or the date falls in a presumed part of its window

A record with a condition the claim cannot show (a setting, a member attribute, the service context) does not run:
it is listed in the coverage table with the reason, never guessed. Neither does a kind or period detection does not
check yet. Nothing here decides a payment: a finding is evidence for a person, with the rule's words and citation.

The rules are prepared in Python (prepare); the claims never leave Spark (run). Notebook d02 calls both.
"""
from __future__ import annotations

import json
from collections import Counter

TELEHEALTH_MODIFIERS = ("GT", "GQ", "FQ")       # the code set's telehealth columns (TH-MOD)
CHECKED_CONDITIONS = ("modifier", "place_of_service", "age", "provider_type", "claim_form")
PERIODS = {"units_limit": ("day", "line"), "frequency_limit": ("day",)}
UNIT_BASES = ("unit", "unstated", None, "")      # an hour or session limit needs the code's billing unit (not here)

# claims table columns (main.prod_input.all_data_C_A); the notebook can override any of them
COLUMNS = {"claim": "ClaimID", "line": "LN_NO", "member": "MEMBER_KEY", "billing": "BProv_ID",
           "servicing": "SProv_ID", "billing_type": "BProv_Type", "servicing_type": "SProv_Type",
           "code": "PROC_CD", "mods": ("PROC_MOD_1", "PROC_MOD_2", "PROC_MOD_3", "PROC_MOD_4"), "pos": "POS_CODE",
           "dos": "Svc_Begin_Dt", "units": "QUANTITY_PAID", "paid": "PMT_AMT", "dob": "date_of_birth",
           "form": "FORM_TYP"}

RULE_FIELDS = [  # name, Spark type
    ("rid", "string"), ("part_of", "string"), ("kind", "string"), ("code", "string"), ("start", "string"),
    ("end", "string"), ("tier", "string"), ("reasons", "string"), ("statement", "string"), ("source", "string"),
    ("version", "string"), ("locator", "string"), ("quote", "string"), ("group_key", "string"), ("maxv", "double"),
    ("per", "string"), ("by_provider", "boolean"), ("partners", "array<string>"), ("bypass", "array<string>"),
    ("min_age", "int"), ("below_age", "int"), ("mode", "string"), ("match", "string"), ("mods", "array<string>"),
    ("pos", "array<string>"), ("ptypes", "array<string>"), ("role", "string"), ("parents", "array<string>"),
    ("c_mod_present", "array<string>"), ("c_mod_absent", "array<string>"), ("c_pos_in", "array<string>"),
    ("c_pos_out", "array<string>"), ("c_age_min", "int"), ("c_age_below", "int"), ("c_pt_in", "array<string>"),
    ("c_pt_out", "array<string>"), ("c_pt_role", "string"), ("c_form", "array<string>"), ("ffs_only", "boolean")]


def _j(v, default):
    if v is None or v == "":
        return default
    return json.loads(v) if isinstance(v, str) else v


def _pt(v) -> str:
    s = str(v).strip().upper()
    return s.zfill(2) if s.isdigit() and len(s) == 1 else s


def _conditions(conds: list) -> tuple[dict | None, str]:
    """Flat condition columns, or (None, why) when one cannot be checked on a claim."""
    out = {"c_mod_present": [], "c_mod_absent": [], "c_pos_in": [], "c_pos_out": [], "c_age_min": None,
           "c_age_below": None, "c_pt_in": [], "c_pt_out": [], "c_pt_role": None, "c_form": []}
    seen = Counter(c.get("type") for c in conds)
    for c in conds:
        t = c.get("type")
        if t not in CHECKED_CONDITIONS:
            return None, f"condition needs {t.replace('_', ' ') if t else 'an unknown field'}, not on the claim"
        if seen[t] > 1:
            return None, f"two {t.replace('_', ' ')} conditions"
        if t == "modifier":
            out["c_mod_present"] = [m.upper() for m in c.get("present") or []]
            out["c_mod_absent"] = [m.upper() for m in c.get("absent") or []]
        elif t == "place_of_service":
            out["c_pos_in"] = [str(p).zfill(2) for p in c.get("include") or []]
            out["c_pos_out"] = [str(p).zfill(2) for p in c.get("exclude") or []]
        elif t == "age":
            out["c_age_min"], out["c_age_below"] = c.get("min_age"), c.get("below_age")
        elif t == "provider_type":
            vals = [_pt(x) for x in (c.get("include") or []) + (c.get("exclude") or [])]
            if any(not (len(x) == 2 and x.isalnum()) for x in vals):
                return None, "provider types given as words, not AHCCCS type codes"
            out["c_pt_in"] = [_pt(x) for x in c.get("include") or []]
            out["c_pt_out"] = [_pt(x) for x in c.get("exclude") or []]
            out["c_pt_role"] = c.get("role") or "billing_or_rendering"
        elif t == "claim_form":
            f = c.get("form")
            out["c_form"] = [str(x).upper() for x in (f if isinstance(f, list) else [f]) if x]
    return out, ""


def _kind_params(kind: str, p: dict) -> tuple[dict | None, str]:
    """The kind's check columns, or (None, why) when detection does not check it yet."""
    base = {"maxv": None, "per": None, "by_provider": False, "partners": [], "bypass": [], "min_age": None,
            "below_age": None, "mode": None, "match": None, "mods": [], "pos": [], "ptypes": [], "role": None,
            "parents": []}
    scope = p.get("scope") or "unstated"
    if kind in ("units_limit", "frequency_limit"):
        if p.get("per") not in PERIODS[kind]:
            return None, f"{kind.replace('_', ' ')} per {p.get('per')} is not checked yet"
        if kind == "units_limit" and p.get("unit_basis") not in UNIT_BASES:
            return None, f"a limit in {p.get('unit_basis')}s needs the code's billing unit to compare with units"
        if p.get("max") is None:
            return None, "no maximum"
        # an unstated scope is read per provider: the narrower count, so fewer and surer findings
        return {**base, "maxv": float(p["max"]), "per": p["per"], "by_provider": scope != "member"}, ""
    if kind == "pair_prohibited":
        if not p.get("partners"):
            return None, "partner category not resolved to codes"
        by = p.get("modifier_bypass")
        return {**base, "partners": [x.upper() for x in p["partners"]], "by_provider": scope != "member_day",
                "bypass": [m.upper() for m in by] if isinstance(by, list) else []}, ""
    if kind == "age_limit":
        return {**base, "min_age": p.get("min_age"), "below_age": p.get("below_age")}, ""
    if kind == "modifier_rule":
        mode = p.get("mode")
        if mode == "allowed" and not p.get("complete_list"):
            return None, "an allowed list not stated as complete cannot show a violation"
        if mode not in ("required", "allowed", "not_allowed"):
            return None, f"modifier mode {mode} is not checked"
        return {**base, "mode": mode, "match": p.get("match") or "any",
                "mods": [m.upper() for m in p.get("modifiers") or []]}, ""
    if kind == "pos_rule":
        mode = p.get("mode")
        if mode == "allowed" and not p.get("complete_list"):
            return None, "an allowed list not stated as complete cannot show a violation"
        if mode not in ("allowed", "not_allowed"):
            return None, f"place of service mode {mode} is not checked"
        return {**base, "mode": mode, "pos": [str(x).zfill(2) for x in p.get("pos") or []]}, ""
    if kind == "provider_type_rule":
        mode = p.get("mode")
        if mode == "allowed" and not p.get("complete_list"):
            return None, "an allowed list not stated as complete cannot show a violation"
        if mode not in ("allowed", "not_allowed"):
            return None, f"provider type mode {mode} is not checked"
        return {**base, "mode": mode, "ptypes": [_pt(x) for x in p.get("provider_types") or []],
                "role": p.get("role") or "billing_or_rendering"}, ""
    if kind == "telehealth_rule":
        if not p.get("allowed"):
            return None, "a telehealth prohibition is not checked yet"
        return {**base, "mods": [m.upper() for m in p.get("modifiers") or []],
                "pos": [str(x).zfill(2) for x in p.get("pos") or []]}, ""
    if kind == "included_in":
        if not p.get("parent_codes"):
            return None, "parent category not resolved to codes"
        if scope not in ("same_day",):
            return None, f"included in, scope {scope}, is not checked yet"
        return {**base, "parents": [x.upper() for x in p["parent_codes"]], "by_provider": True}, ""
    if kind == "not_covered":
        return base, ""
    return None, f"{kind.replace('_', ' ')} is not checked on claims"


def prepare(current: list[dict], open_conflicts: set | None = None, ffs_known: bool = False) -> tuple[list, list]:
    """(rule rows, not run). current: kb_records_current rows; a row is one record over one window (a presumed part
    is a row of its own). open_conflicts: record ids in an open conflict (they do not run). ffs_known: whether the
    notebook can tell FFS lines (a record for FFS only then runs on them; else its findings are leads)."""
    rows, skipped = [], []
    open_conflicts = open_conflicts or set()
    for r in current:
        if r.get("status") != "approved" or r.get("execution_class") not in ("executable", "conditional"):
            continue
        rid, kind = r["record_id"], r["kind"]

        def skip(why):
            skipped.append({"rid": rid, "part_of": r.get("part_of") or rid, "kind": kind, "source_id": r.get("source_id"),
                            "statement": r.get("statement"), "why": why})
        if (r.get("part_of") or rid) in open_conflicts or rid in open_conflicts:
            skip("in an open conflict")
            continue
        subject, params = _j(r.get("subject"), {}), _j(r.get("params"), {})
        codes = [c.upper() for c in (subject.get("codes") or _j(r.get("resolved_codes"), []) or [])]
        if not codes:
            skip("names a category no code set resolves")
            continue
        conds, why = _conditions(_j(r.get("conditions"), []))
        if conds is None:
            skip(why)
            continue
        kp, why = _kind_params(kind, params)
        if kp is None:
            skip(why)
            continue
        reasons = list(_j(r.get("execution_reasons"), []))
        tier = "violation" if r.get("execution_class") == "executable" else "lead"
        if r.get("presumed_from"):
            tier = "lead"
            reasons.append(f"presumed from {r['presumed_from']}: the edition in force on these dates is not held")
        flags = [f for f in _j(r.get("flags"), []) if isinstance(f, dict)]
        if any(f.get("code") == "discretionary" for f in flags):
            tier = "lead"
            reasons.append("the text says may: a finding is discretionary")
        systems = (_j(r.get("applicability"), {}) or {}).get("delivery_systems") or []
        ffs_only = bool(systems) and set(systems) == {"FFS"}
        if ffs_only and not ffs_known:
            tier = "lead"
            reasons.append("applies to FFS lines; the run cannot tell FFS lines apart")
        cit = _j(r.get("citation"), {})
        base = {"rid": rid, "part_of": r.get("part_of") or rid, "kind": kind, "start": r.get("effective_start"),
                "end": r.get("effective_end"), "tier": tier, "reasons": "; ".join(reasons),
                "statement": r.get("statement"), "source": cit.get("title") or r.get("source_id"),
                "version": r.get("source_version_id"),
                "locator": cit.get("locator") or " ".join(x for x in (f"p.{cit['page_start']}" if cit.get("page_start")
                                                                         else "", cit.get("section_path") or "") if x)
                or None,
                "quote": cit.get("quote"), "ffs_only": ffs_only and ffs_known, **conds, **kp}
        combined = bool(params.get("combined")) and kind == "units_limit"
        for c in codes:
            rows.append({**base, "code": c, "group_key": rid if combined else f"{rid}|{c}"})
    return rows, skipped


def lines_sql(table: str, where: str = "1 = 1", forms=("A",), since=None, until=None, ffs_where=None,
              columns: dict | None = None) -> str:
    """One row per claim line: rows of a line (an original and its adjustments) summed, payable lines only."""
    c = {**COLUMNS, **(columns or {})}
    s = lambda col: f"trim(CAST({col} AS STRING))"  # noqa: E731

    def mod(col):
        v = f"upper({s(col)})"
        return f"CASE WHEN {v} RLIKE '^[A-Z0-9]{{2}}$' THEN {v} END"

    def ptype(col):
        v = s(col)
        return (f"CASE WHEN {v} IS NULL OR upper({v}) IN ('', 'NONE', 'NAN', 'NULL', '-1') THEN NULL "
                f"WHEN {v} RLIKE '^[0-9]$' THEN lpad({v}, 2, '0') ELSE upper({v}) END")
    forms_sql = ", ".join(f"'{f}'" for f in forms)
    dates = (f" AND to_date({c['dos']}) >= DATE'{since}'" if since else "") + \
            (f" AND to_date({c['dos']}) <= DATE'{until}'" if until else "")
    mods = ", ".join(mod(m) for m in c["mods"])
    return f"""
    SELECT claim_id, ln_no, concat_ws('-', claim_id, ln_no) AS line_id, member, bprov, sprov, btype, rtype, code,
           mods, pos, form, dos, units, paid, is_ffs,
           CAST(floor(months_between(dos, dob) / 12) AS INT) AS age
    FROM (
      SELECT {s(c['claim'])} AS claim_id, {s(c['line'])} AS ln_no, max({s(c['member'])}) AS member,
             max({s(c['billing'])}) AS bprov, max({s(c['servicing'])}) AS sprov,
             max({ptype(c['billing_type'])}) AS btype, max({ptype(c['servicing_type'])}) AS rtype,
             max(upper({s(c['code'])})) AS code,
             max(filter(array({mods}), x -> x IS NOT NULL)) AS mods,
             max(lpad(regexp_replace({s(c['pos'])}, '\\\\.0+$', ''), 2, '0')) AS pos,
             max(upper({s(c['form'])})) AS form, max(to_date({c['dos']})) AS dos, max(to_date({c['dob']})) AS dob,
             sum(CAST({c['units']} AS DOUBLE)) AS units, sum(CAST({c['paid']} AS DOUBLE)) AS paid,
             max({'(' + ffs_where + ')' if ffs_where else 'CAST(NULL AS BOOLEAN)'}) AS is_ffs
      FROM {table}
      WHERE upper({s(c['form'])}) IN ({forms_sql}){dates} AND ({where})
      GROUP BY {s(c['claim'])}, {s(c['line'])})
    WHERE units > 0 AND paid > 0 AND dos IS NOT NULL AND code IS NOT NULL"""


COND_SQL = """
    (size(r.c_mod_present) = 0 OR arrays_overlap(l.mods, r.c_mod_present))
    AND (size(r.c_mod_absent) = 0 OR NOT arrays_overlap(l.mods, r.c_mod_absent))
    AND (size(r.c_pos_in) = 0 OR coalesce(array_contains(r.c_pos_in, l.pos), false))
    AND (size(r.c_pos_out) = 0 OR (l.pos IS NOT NULL AND NOT array_contains(r.c_pos_out, l.pos)))
    AND (r.c_age_min IS NULL OR coalesce(l.age >= r.c_age_min, false))
    AND (r.c_age_below IS NULL OR coalesce(l.age < r.c_age_below, false))
    AND (size(r.c_form) = 0 OR coalesce(array_contains(r.c_form, l.form), false))
    AND (size(r.c_pt_in) = 0 OR CASE r.c_pt_role
           WHEN 'billing' THEN coalesce(array_contains(r.c_pt_in, l.btype), false)
           WHEN 'rendering' THEN coalesce(array_contains(r.c_pt_in, l.rtype), false)
           ELSE coalesce(array_contains(r.c_pt_in, l.btype), false) OR coalesce(array_contains(r.c_pt_in, l.rtype), false) END)
    AND (size(r.c_pt_out) = 0 OR CASE r.c_pt_role
           WHEN 'billing' THEN l.btype IS NOT NULL AND NOT array_contains(r.c_pt_out, l.btype)
           WHEN 'rendering' THEN l.rtype IS NOT NULL AND NOT array_contains(r.c_pt_out, l.rtype)
           ELSE NOT coalesce(array_contains(r.c_pt_out, l.btype), false)
                AND NOT coalesce(array_contains(r.c_pt_out, l.rtype), false) END)
    AND (NOT r.ffs_only OR coalesce(l.is_ffs, false))"""

# the type a provider type rule reads: a group (01) bills for its rendering provider (as reading B2-PT)
BILLING_TYPE = "CASE WHEN l.btype = '01' THEN l.rtype ELSE l.btype END"

SINGLE_LINE = {
    "age_limit": ("l.age IS NOT NULL AND ((r.min_age IS NOT NULL AND l.age < r.min_age) OR "
                  "(r.below_age IS NOT NULL AND l.age >= r.below_age))",
                  "concat('member age ', l.age, ' on the date of service')"),
    "modifier_rule": ("""CASE r.mode
                          WHEN 'required' THEN CASE r.match WHEN 'all' THEN size(array_except(r.mods, l.mods)) > 0
                                                ELSE NOT arrays_overlap(l.mods, r.mods) END
                          WHEN 'allowed' THEN size(array_except(l.mods, r.mods)) > 0
                          ELSE arrays_overlap(l.mods, r.mods) END""",
                      "concat('modifiers on the line: ', coalesce(nullif(array_join(l.mods, ' '), ''), 'none'))"),
    "pos_rule": ("l.pos IS NOT NULL AND CASE r.mode WHEN 'allowed' THEN NOT array_contains(r.pos, l.pos) "
                 "ELSE array_contains(r.pos, l.pos) END",
                 "concat('place of service ', l.pos)"),
    "provider_type_rule": (f"""CASE r.role
                               WHEN 'billing' THEN {BILLING_TYPE} IS NOT NULL AND (array_contains(r.ptypes, {BILLING_TYPE}) = (r.mode = 'not_allowed'))
                               WHEN 'rendering' THEN l.rtype IS NOT NULL AND (array_contains(r.ptypes, l.rtype) = (r.mode = 'not_allowed'))
                               ELSE CASE r.mode WHEN 'allowed' THEN coalesce(l.btype, l.rtype) IS NOT NULL
                                         AND NOT coalesce(array_contains(r.ptypes, l.btype), false)
                                         AND NOT coalesce(array_contains(r.ptypes, l.rtype), false)
                                    ELSE coalesce(array_contains(r.ptypes, l.btype), false)
                                         OR coalesce(array_contains(r.ptypes, l.rtype), false) END END""",
                           "concat('billing type ', coalesce(l.btype, 'blank'), ', servicing type ', coalesce(l.rtype, 'blank'))"),
    "telehealth_rule": (f"""arrays_overlap(l.mods, array({', '.join(f"'{m}'" for m in TELEHEALTH_MODIFIERS)}))
                           AND (size(array_except(array_intersect(l.mods, array({', '.join(f"'{m}'" for m in TELEHEALTH_MODIFIERS)})), r.mods)) > 0
                                OR (l.pos IS NOT NULL AND NOT array_contains(r.pos, l.pos)))""",
                        "concat('telehealth line: modifiers ', array_join(l.mods, ' '), ', place of service ', coalesce(l.pos, 'blank'))"),
    "not_covered": ("true", "'the code is billed'"),
    "units_limit": ("r.per = 'line' AND l.units > r.maxv", "concat(l.units, ' units on the line, most ', r.maxv)"),
}

FINDING_COLS = """r.rid AS record_id, r.part_of, r.kind, r.tier, l.line_id, l.claim_id, l.ln_no, l.member, l.bprov,
                  l.sprov, l.code, l.dos, l.units, l.paid, {evidence} AS evidence, r.statement, r.source, r.version,
                  r.locator, r.quote, r.reasons"""


def run(spark, rules: list[dict], lines_view: str = "pie_lines"):
    """Findings as a Spark DataFrame (one row per flagged line per rule). rules: prepare()'s rule rows."""
    from pyspark.sql.types import StructType, StructField
    from pyspark.sql.types import _parse_datatype_string
    schema = StructType([StructField(n, _parse_datatype_string(t), True) for n, t in RULE_FIELDS])
    norm = [{n: (r.get(n) if r.get(n) is not None or not t.startswith("array") else []) for n, t in RULE_FIELDS}
            for r in rules]
    spark.createDataFrame(norm, schema).createOrReplaceTempView("pie_rules")
    spark.sql(f"""
        CREATE OR REPLACE TEMP VIEW pie_applies AS
        SELECT r.*, l.line_id, l.claim_id, l.ln_no, l.member, l.bprov, l.sprov, l.btype, l.rtype, l.mods AS l_mods,
               l.pos AS l_pos, l.dos, l.units, l.paid,
               CASE WHEN r.by_provider THEN concat_ws('|', coalesce(l.bprov, ''), coalesce(l.sprov, '')) END AS who
        FROM pie_rules r JOIN {lines_view} l
          ON l.code = r.code AND l.dos >= to_date(r.start) AND l.dos <= coalesce(to_date(r.end), DATE'9999-12-31')
        WHERE {COND_SQL}""")
    parts = []
    for kind, (pred, evidence) in SINGLE_LINE.items():
        parts.append(f"""SELECT {FINDING_COLS.format(evidence=evidence)}
            FROM pie_rules r JOIN {lines_view} l
              ON l.code = r.code AND l.dos >= to_date(r.start) AND l.dos <= coalesce(to_date(r.end), DATE'9999-12-31')
            WHERE r.kind = '{kind}' AND {COND_SQL} AND ({pred})""")
    # limits per day: units (units_limit) or services (frequency_limit) per member, or per member and provider
    parts.append("""
        SELECT a.rid AS record_id, a.part_of, a.kind, a.tier, a.line_id, a.claim_id, a.ln_no, a.member, a.bprov,
               a.sprov, a.code, a.dos, a.units, a.paid,
               concat(g.total, CASE a.kind WHEN 'units_limit' THEN ' units' ELSE ' services' END, ' on ', a.dos,
                      CASE WHEN a.by_provider THEN ' from this provider' ELSE ' from all providers' END,
                      ', most ', a.maxv, '; lines ', g.lines) AS evidence,
               a.statement, a.source, a.version, a.locator, a.quote, a.reasons
        FROM pie_applies a JOIN (
          SELECT group_key, member, dos, who,
                 CASE WHEN kind = 'units_limit' THEN sum(units) ELSE count(DISTINCT line_id) END AS total,
                 max(maxv) AS maxv, array_join(sort_array(collect_set(line_id)), ' ') AS lines
          FROM pie_applies WHERE kind IN ('units_limit', 'frequency_limit') AND per = 'day'
          GROUP BY group_key, member, dos, who, kind
          HAVING total > max(maxv)) g
          ON g.group_key = a.group_key AND g.member = a.member AND g.dos = a.dos
             AND (g.who IS NULL AND a.who IS NULL OR g.who = a.who)
        WHERE a.kind IN ('units_limit', 'frequency_limit') AND a.per = 'day'""")
    # pairs: the subject's line is the finding, the partner's line its evidence
    parts.append(f"""
        SELECT a.rid AS record_id, a.part_of, a.kind, a.tier, a.line_id, a.claim_id, a.ln_no, a.member, a.bprov,
               a.sprov, a.code, a.dos, a.units, a.paid,
               concat('billed with ', array_join(sort_array(collect_set(concat(p.code, ' (line ', p.line_id, ')'))), ', '),
                      CASE WHEN first(a.by_provider) THEN ' by the same provider' ELSE '' END) AS evidence,
               a.statement, a.source, a.version, a.locator, a.quote, a.reasons
        FROM pie_applies a JOIN {lines_view} p
          ON p.member = a.member AND p.dos = a.dos AND p.line_id <> a.line_id
             AND array_contains(a.partners, p.code)
             AND (NOT a.by_provider OR (p.bprov = a.bprov AND p.sprov = a.sprov))
             AND NOT arrays_overlap(a.l_mods, a.bypass) AND NOT arrays_overlap(p.mods, a.bypass)
        WHERE a.kind = 'pair_prohibited'
        GROUP BY a.rid, a.part_of, a.kind, a.tier, a.line_id, a.claim_id, a.ln_no, a.member, a.bprov, a.sprov, a.code,
                 a.dos, a.units, a.paid, a.statement, a.source, a.version, a.locator, a.quote, a.reasons""")
    # included in: the bundled line is the finding when its parent is billed the same day by the same billing provider
    parts.append(f"""
        SELECT a.rid AS record_id, a.part_of, a.kind, a.tier, a.line_id, a.claim_id, a.ln_no, a.member, a.bprov,
               a.sprov, a.code, a.dos, a.units, a.paid,
               concat('included in ', array_join(sort_array(collect_set(concat(p.code, ' (line ', p.line_id, ')'))), ', '),
                      ' billed the same day by the same billing provider') AS evidence,
               a.statement, a.source, a.version, a.locator, a.quote, a.reasons
        FROM pie_applies a JOIN {lines_view} p
          ON p.member = a.member AND p.dos = a.dos AND p.line_id <> a.line_id AND array_contains(a.parents, p.code)
             AND p.bprov = a.bprov
        WHERE a.kind = 'included_in'
        GROUP BY a.rid, a.part_of, a.kind, a.tier, a.line_id, a.claim_id, a.ln_no, a.member, a.bprov, a.sprov, a.code,
                 a.dos, a.units, a.paid, a.statement, a.source, a.version, a.locator, a.quote, a.reasons""")
    return spark.sql("\nUNION ALL\n".join(parts))


def coverage(rules: list[dict], skipped: list[dict]) -> list[dict]:
    """Records that ran and records that did not, by kind and reason (one row per record, not per code)."""
    ran = {}
    for r in rules:
        ran.setdefault((r["kind"], r["tier"]), set()).add(r["part_of"])
    out = [{"kind": k, "status": f"runs ({t})", "why": "", "records": len(v)} for (k, t), v in sorted(ran.items())]
    miss = Counter((s["kind"], s["why"]) for s in {s["part_of"]: s for s in skipped}.values())
    out += [{"kind": k, "status": "does not run", "why": w, "records": n} for (k, w), n in sorted(miss.items())]
    return out
