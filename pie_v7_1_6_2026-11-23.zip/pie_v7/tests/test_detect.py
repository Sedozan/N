"""Detection (pie_kb/detect.py) on local Spark with a synthetic claims table: every check has lines it must flag and
lines it must not, written from the rule's words, not from the SQL."""
import json

import pytest

from pie_kb import detect as DT

pyspark = pytest.importorskip("pyspark")


@pytest.fixture(scope="module")
def spark():
    from pyspark.sql import SparkSession
    s = (SparkSession.builder.master("local[2]").appName("pie-detect-test")
         .config("spark.sql.ansi.enabled", "true").config("spark.ui.enabled", "false")
         .config("spark.sql.shuffle.partitions", "2").getOrCreate())
    yield s


def rec(rid, kind, codes, params, start="2025-01-01", end=None, cls="executable", status="approved", conds=(),
        presumed=None, systems=("FFS", "MC"), flags=(), reasons=(), part_of=None):
    return {"record_id": rid, "part_of": part_of or rid, "kind": kind, "subject": json.dumps({"codes": list(codes)}),
            "params": json.dumps(params), "conditions": json.dumps(list(conds)), "status": status,
            "execution_class": cls, "execution_reasons": json.dumps(list(reasons)), "effective_start": start,
            "effective_end": end, "presumed_from": presumed, "applicability": json.dumps({"delivery_systems": list(systems)}),
            "flags": json.dumps(list(flags)), "statement": f"{rid} statement", "source_id": "AX",
            "source_version_id": f"AX@{start}", "resolved_codes": "[]",
            "citation": json.dumps({"title": "Test source", "locator": "row 1", "quote": "the words"})}


# ClaimID, LN_NO, MEMBER_KEY, BProv_ID, SProv_ID, BProv_Type, SProv_Type, PROC_CD, mods, POS, Svc_Begin_Dt, units,
# paid, date_of_birth, FORM_TYP, FORM_TYP_DESC
D = "2025-03-03"
LINES = [
    # daily limit H0004, 2 per member per provider per day
    ("C1", 1, "M1", "P1", "S1", "77", "77", "H0004", [], "11", D, 1, 50, "1990-01-01", "A", "FFS"),
    ("C1", 2, "M1", "P1", "S1", "77", "77", "H0004", [], "11", D, 2, 90, "1990-01-01", "A", "FFS"),
    ("C2", 1, "M1", "P2", "S2", "77", "77", "H0004", [], "11", D, 1, 50, "1990-01-01", "A", "FFS"),
    ("C9", 1, "M9", "P1", "S1", "77", "77", "H0004", [], "11", D, 3, 120, "1990-01-01", "A", "FFS"),   # reversed
    ("C9", 1, "M9", "P1", "S1", "77", "77", "H0004", [], "11", D, -3, -120, "1990-01-01", "A", "FFS"),
    # per diem twice for one member from two providers (frequency 1 per day, any provider)
    ("C3", 1, "M2", "P1", "S1", "B8", "B8", "H0018", [], "55", D, 1, 300, "1980-05-05", "A", "MC"),
    ("C4", 1, "M2", "P2", "S2", "B8", "B8", "H0018", [], "55", D, 1, 300, "1980-05-05", "A", "MC"),
    ("C5", 1, "M3", "P1", "S1", "B8", "B8", "H0018", [], "55", D, 1, 300, "1980-05-05", "A", "MC"),
    # pairs: H0004 not with H0018 (any provider); H2014 not with H0018 by the same provider
    ("C6", 1, "M2", "P3", "S3", "77", "77", "H0004", [], "11", D, 1, 40, "1980-05-05", "A", "MC"),
    ("C7", 1, "M2", "P1", "S1", "B8", "B8", "H2014", [], "55", D, 4, 60, "1980-05-05", "A", "MC"),
    ("C8", 1, "M3", "P2", "S2", "B8", "B8", "H2014", [], "55", D, 4, 60, "1980-05-05", "A", "MC"),
    ("C10", 1, "M3", "P2", "S2", "77", "77", "H0004", ["59"], "11", D, 1, 40, "1980-05-05", "A", "MC"),
    # age 12 through 17
    ("C11", 1, "M4", "P1", "S1", "77", "77", "H2033", [], "11", D, 4, 80, "2005-01-01", "A", "FFS"),
    ("C12", 1, "M5", "P1", "S1", "77", "77", "H2033", [], "11", D, 4, 80, "2011-01-01", "A", "FFS"),
    ("C13", 1, "M6", "P1", "S1", "77", "77", "H2033", [], "11", D, 4, 80, None, "A", "FFS"),
    ("C13b", 1, "M6b", "P1", "S1", "77", "77", "H2033", [], "11", D, 4, 80, "2007-03-03", "A", "FFS"),  # 18 today
    ("C13c", 1, "M6c", "P1", "S1", "77", "77", "H2033", [], "11", D, 4, 80, "2013-03-04", "A", "FFS"),  # 11
    ("C13d", 1, "M6d", "P1", "S1", "77", "77", "H2033", [], "11", D, 4, 80, "2013-03-03", "A", "FFS"),  # 12 today
    # H0020 needs HG and a listed billing provider type
    ("C14", 1, "M7", "P4", "S4", "77", "77", "H0020", ["-1", "HG"], "57", D, 1, 20, "1970-01-01", "A", "FFS"),
    ("C15", 1, "M7", "P5", "S5", "IC", "IC", "H0020", [], "57", D, 1, 20, "1970-01-01", "A", "FFS"),
    ("C16", 1, "M8", "P6", "S6", "01", "08", "H0020", ["HG"], "57", D, 1, 20, "1970-01-01", "A", "FFS"),
    ("C17", 1, "M8", "P7", "S7", "01", "IC", "H0020", ["HG"], "57", D, 1, 20, "1970-01-01", "A", "FFS"),
    ("C18", 1, "M8", "P8", "S8", "2", "2", "H0020", ["HG"], "57", D, 1, 20, "1970-01-01", "A", "FFS"),
    # H0035 places of service
    ("C19", 1, "M10", "P9", "S9", "02", "02", "H0035", [], "52.0", D, 1, 400, "1970-01-01", "A", "FFS"),
    ("C20", 1, "M11", "P9", "S9", "02", "02", "H0035", [], "11", D, 1, 400, "1970-01-01", "A", "FFS"),
    ("C21", 1, "M12", "P9", "S9", "02", "02", "H0035", [], None, D, 1, 400, "1970-01-01", "A", "FFS"),
    # telehealth: 90837 by GT or FQ, originating sites 11 and 12
    ("C22", 1, "M13", "P1", "S1", "08", "08", "90837", ["GT"], "11", D, 1, 100, "1970-01-01", "A", "FFS"),
    ("C23", 1, "M13", "P1", "S1", "08", "08", "90837", ["GT"], "02", "2025-03-04", 1, 100, "1970-01-01", "A", "FFS"),
    ("C24", 1, "M13", "P1", "S1", "08", "08", "90837", ["GQ"], "11", "2025-03-05", 1, 100, "1970-01-01", "A", "FFS"),
    ("C25", 1, "M13", "P1", "S1", "08", "08", "90837", [], "02", "2025-03-06", 1, 100, "1970-01-01", "A", "FFS"),
    # combined crisis hours, 5 per day per member; a line past the window; units per line
    ("C26", 1, "M14", "P1", "S1", "B8", "B8", "S9484", [], "52", D, 3, 90, "1970-01-01", "A", "FFS"),
    ("C27", 1, "M14", "P2", "S2", "B8", "B8", "S9485", [], "52", D, 3, 90, "1970-01-01", "A", "FFS"),
    ("C28", 1, "M15", "P1", "S1", "77", "77", "H0004", [], "11", "2025-07-15", 9, 400, "1990-01-01", "A", "FFS"),
    ("C29", 1, "M16", "P1", "S1", "77", "77", "T1016", [], "11", D, 5, 100, "1990-01-01", "A", "FFS"),
    # included in: H0038 within H0018 by the same billing provider
    ("C30", 1, "M2", "P1", "S9", "B8", "B8", "H0038", [], "55", D, 2, 30, "1980-05-05", "A", "MC"),
    ("C31", 1, "M3", "P9", "S9", "B8", "B8", "H0038", [], "55", D, 2, 30, "1980-05-05", "A", "MC"),
    # a dental line is never read (FORM_TYP D)
    ("C32", 1, "M1", "P1", "S1", "77", "77", "H0004", [], "11", D, 5, 50, "1990-01-01", "D", "FFS"),
]

RULES = [
    rec("R-dl", "units_limit", ["H0004"], {"max": 2, "per": "day", "scope": "member_provider", "unit_basis": "unit"},
        end="2025-06-30"),
    rec("R-self", "frequency_limit", ["H0018"], {"max": 1, "per": "day", "scope": "member"}, cls="conditional",
        reasons=["states an exception a person confirms per finding"]),
    rec("R-d", "pair_prohibited", ["H0004"], {"partners": ["H0018"], "scope": "member_day", "modifier_bypass": ["59"]}),
    rec("R-astar", "pair_prohibited", ["H2014"], {"partners": ["H0018"], "scope": "member_provider_day",
                                                    "modifier_bypass": "none"}),
    rec("R-age", "age_limit", ["H2033"], {"min_age": 12, "below_age": 18}),
    rec("R-hg", "modifier_rule", ["H0020"], {"mode": "required", "match": "all", "modifiers": ["HG"]}),
    rec("R-pt", "provider_type_rule", ["H0020"], {"mode": "allowed", "complete_list": True, "role": "billing",
                                                   "provider_types": ["08", "18", "19", "31", "77"]}, systems=["FFS"]),
    rec("R-pos", "pos_rule", ["H0035"], {"mode": "allowed", "complete_list": True,
                                         "pos": ["06", "08", "19", "22", "52", "62"]}),
    rec("R-th", "telehealth_rule", ["90837"], {"allowed": True, "modifiers": ["FQ", "GT"], "pos": ["11", "12"]},
        presumed="2025-02-01"),
    rec("R-comb", "units_limit", ["S9484", "S9485"], {"max": 5, "per": "day", "scope": "member", "combined": True}),
    rec("R-line", "units_limit", ["T1016"], {"max": 4, "per": "line", "scope": "member_provider"}),
    rec("R-incl", "included_in", ["H0038"], {"parent_codes": ["H0018"], "scope": "same_day"}),
    # do not run
    rec("R-hours", "units_limit", ["H0038"], {"max": 8, "per": "day", "unit_basis": "hour"}),
    rec("R-stay", "frequency_limit", ["H0018"], {"max": 2, "per": "stay", "scope": "member"},
        conds=[{"type": "modifier", "present": ["U9"]}]),
    rec("R-setting", "not_covered", ["T1019"], {}, conds=[{"type": "setting", "text": "nursing facility"}]),
    rec("R-words", "not_covered", ["H2011"], {}, conds=[{"type": "provider_type", "include": ["EMS", "FIRE"]}]),
    rec("R-open", "not_covered", ["T1016"], {}, status="needs_review"),
    rec("R-know", "not_covered", ["T1016"], {}, cls="knowledge"),
    rec("R-conf", "not_covered", ["T1016"], {}),
]


@pytest.fixture(scope="module")
def found(spark):
    from pyspark.sql import Row
    cols = ["ClaimID", "LN_NO", "MEMBER_KEY", "BProv_ID", "SProv_ID", "BProv_Type", "SProv_Type", "PROC_CD",
            "PROC_MOD_1", "PROC_MOD_2", "PROC_MOD_3", "PROC_MOD_4", "POS_CODE", "Svc_Begin_Dt", "QUANTITY_PAID",
            "PMT_AMT", "date_of_birth", "FORM_TYP", "FORM_TYP_DESC"]
    data = []
    for c, ln, m, b, s, bt, st, code, mods, pos, d, u, p, dob, form, deliv in LINES:
        mods = (list(mods) + ["-1"] * 4)[:4]
        data.append(Row(**dict(zip(cols, [c, ln, m, b, s, bt, st, code, *mods, pos, d, u, p, dob, form, deliv]))))
    spark.createDataFrame(data).createOrReplaceTempView("claims")
    spark.sql(DT.lines_sql("claims", ffs_where="FORM_TYP_DESC = 'FFS'")).createOrReplaceTempView("pie_lines")
    rules, skipped = DT.prepare(RULES, open_conflicts={"R-conf"}, ffs_known=True)
    rows = [r.asDict() for r in DT.run(spark, rules).collect()]
    return rows, rules, skipped


def flagged(rows, rid):
    return sorted(r["line_id"] for r in rows if r["record_id"] == rid)


def test_lines_are_net_payable_professional_lines(spark, found):
    lines = {r["line_id"]: r for r in (x.asDict() for x in spark.sql("SELECT * FROM pie_lines").collect())}
    assert "C9-1" not in lines                     # an original and its reversal net to zero
    assert "C32-1" not in lines                    # form D
    assert lines["C14-1"]["mods"] == ["HG"]        # -1 is an empty slot
    assert lines["C18-1"]["btype"] == "02" and lines["C19-1"]["pos"] == "52"
    assert lines["C11-1"]["age"] == 20 and lines["C13-1"]["age"] is None


def test_daily_units_per_member_and_provider_inside_the_window(found):
    rows, _, _ = found
    assert flagged(rows, "R-dl") == ["C1-1", "C1-2"]                # 3 units from P1; P2's 1 unit and July not
    ev = [r["evidence"] for r in rows if r["record_id"] == "R-dl"][0]
    assert "3.0 units" in ev and "from this provider" in ev


def test_per_diem_once_per_member_per_day_from_any_provider_is_a_lead(found):
    rows, _, _ = found
    assert flagged(rows, "R-self") == ["C3-1", "C4-1"]
    assert {r["tier"] for r in rows if r["record_id"] == "R-self"} == {"lead"}


def test_pairs_any_provider_same_provider_and_bypass(found):
    rows, _, _ = found
    assert flagged(rows, "R-d") == ["C6-1"]                         # C10 carries the bypass modifier 59
    assert flagged(rows, "R-astar") == ["C7-1"]                     # C8 is H2014 by P2, H0018 by P1


def test_single_line_checks(found):
    rows, _, _ = found
    assert flagged(rows, "R-age") == ["C11-1", "C13b-1", "C13c-1"]  # 20, 18, 11 flagged; 12, 14, no birth date not
    assert flagged(rows, "R-hg") == ["C15-1"]
    assert flagged(rows, "R-pt") == ["C15-1", "C17-1", "C18-1"]     # IC; a group billing for an IC; 02
    assert flagged(rows, "R-pos") == ["C20-1"]                      # 52.0 reads 52; a blank POS is not a finding
    assert flagged(rows, "R-th") == ["C23-1", "C24-1"]              # POS 02 by GT; GQ not listed; no modifier not
    assert {r["tier"] for r in rows if r["record_id"] == "R-th"} == {"lead"}       # presumed dates
    assert flagged(rows, "R-line") == ["C29-1"]


def test_combined_codes_and_included_in(found):
    rows, _, _ = found
    assert flagged(rows, "R-comb") == ["C26-1", "C27-1"]            # 3 + 3 hours across two codes and providers
    assert flagged(rows, "R-incl") == ["C30-1"]                     # C31's H0018 was billed by another provider


def test_what_does_not_run_says_why(found):
    _, rules, skipped = found
    why = {s["rid"]: s["why"] for s in skipped}
    assert "billing unit" in why["R-hours"]
    assert "per stay" in why["R-stay"]
    assert "setting" in why["R-setting"]
    assert "words" in why["R-words"]
    assert why["R-conf"] == "in an open conflict"
    assert not {r["rid"] for r in rules} & {"R-open", "R-know", "R-hours", "R-conf"}
    cov = DT.coverage(rules, skipped)
    assert any(c["status"] == "does not run" and c["kind"] == "units_limit" for c in cov)


def test_ffs_only_rule_is_a_lead_when_ffs_lines_cannot_be_told(spark):
    rules, _ = DT.prepare([RULES[6]], ffs_known=False)
    assert rules[0]["tier"] == "lead" and "FFS" in rules[0]["reasons"] and not rules[0]["ffs_only"]
    rules, _ = DT.prepare([RULES[6]], ffs_known=True)
    assert rules[0]["tier"] == "violation" and rules[0]["ffs_only"]
