# Databricks notebook source
# MAGIC %md
# MAGIC # 06 · Persist the extraction (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Loads every finished run folder not persisted yet (dry runs are skipped) into kb_records, kb_proposals,
# MAGIC kb_extraction_outcomes and kb_value_sets, and writes one processing-ledger row per version: "ok" when every piece
# MAGIC was read, "partial" when a piece failed, was not reached, or the run had no model. A partial version stays due, so
# MAGIC the next 04 and 05 pick it up; a partial run never replaces the records of a version that already had a complete
# MAGIC run.
# MAGIC
# MAGIC Next: 07.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import pandas as pd

from pie_kb.io.store import open_store

RUN_DIR = None                      # None: every finished run not persisted yet; or one run folder
store = open_store(spark)  # noqa: F821
for res in stages.persist_narrative(store, reg, run_dir=RUN_DIR):
    print(res)

# COMMAND ----------

oc = store.read("extraction_outcomes")
if oc:
    df = pd.DataFrame(oc)
    display(df.groupby(["run_id", "source_version_id", "outcome"]).size().rename("pieces").reset_index())  # noqa: F821
    bad = df[df.outcome.isin(["failed", "not_run", "needs_model"])]
    if len(bad):
        display(bad[["run_id", "section_id", "outcome", "detail"]])  # noqa: F821
