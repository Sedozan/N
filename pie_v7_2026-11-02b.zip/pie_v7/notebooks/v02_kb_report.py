# Databricks notebook source
# MAGIC %md
# MAGIC # v02 · Knowledge base report (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Where the knowledge base stands after the latest build: records by source, status and class; what is executable
# MAGIC now; open conflicts; services still named without codes; what the latest revisions changed; extraction pieces
# MAGIC that did not complete; review progress by reviewer. Read only.

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

def t(name: str) -> str:
    return config.table(name)


display(spark.sql(f"""
    SELECT source_id, origin, status, execution_class, count(*) AS records,
           sum(CASE WHEN executable_now THEN 1 ELSE 0 END) AS executable_now
    FROM {t('records_current')} GROUP BY ALL ORDER BY source_id, origin, status, execution_class"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## Open conflicts of the latest build

# COMMAND ----------

display(spark.sql(f"""
    SELECT c.conflict_id, c.relationship, c.codes, c.detail, c.window_start, c.window_end, c.basis,
           a.statement AS record_a, b.statement AS record_b
    FROM {t('conflicts')} c
    JOIN {t('records_current')} a ON a.record_id = c.record_a
    JOIN {t('records_current')} b ON b.record_id = c.record_b
    WHERE c.status = 'open' AND c.build_id = (SELECT max(build_id) FROM {t('records_current')})"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## Services named without codes, and what the latest revisions changed

# COMMAND ----------

display(spark.sql(f"""
    SELECT source_id, get_json_object(subject, '$.category') AS category, resolution, count(*) AS records
    FROM {t('records_current')} WHERE resolution <> '' GROUP BY ALL ORDER BY records DESC"""))  # noqa: F821
display(spark.sql(f"""
    SELECT source_id, from_version, to_version, change, count(*) AS records FROM {t('record_diffs')}
    WHERE build_id = (SELECT max(build_id) FROM {t('build_log')}) GROUP BY ALL ORDER BY source_id"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## Extraction pieces that did not complete, and review progress

# COMMAND ----------

display(spark.sql(f"""
    SELECT source_version_id, outcome, count(*) AS pieces, max(detail) AS example FROM {t('extraction_outcomes')}
    WHERE outcome IN ('failed', 'not_run', 'needs_model', 'patterns_only') GROUP BY ALL"""))  # noqa: F821
display(spark.sql(f"""
    SELECT subject_type, decision, reviewer, count(*) AS decisions, max(decided_at) AS latest
    FROM {t('review_log')} GROUP BY ALL ORDER BY latest DESC"""))  # noqa: F821
