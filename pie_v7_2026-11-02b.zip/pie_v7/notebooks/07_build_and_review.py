# Databricks notebook source
# MAGIC %md
# MAGIC # 07 · Build the knowledge base and export the review workbook (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC The build gives every record, as of the build date: its window (from its version, narrowed by dates the text
# MAGIC states), its review status (decisions bound to its content; approvals carried forward only where the section
# MAGIC reads the same), its codes (a service named without codes resolved to the service's code set), its execution
# MAGIC class, its conflicts (with a suggested prevailing record, never applied unsigned) and the exceptions that overlay
# MAGIC it. A record is executable now only when it is executable, approved, in force and in no open conflict.
# MAGIC
# MAGIC Writes kb_records_current (what detection reads), kb_records_history, kb_conflicts, kb_record_diffs,
# MAGIC kb_code_index and kb_build_log, then a review workbook in review/out.
# MAGIC
# MAGIC Next: download the workbook, fill Decision and Reviewer on the rows you decide, put it in review/in, and run
# MAGIC v01.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import pandas as pd

from pie_kb.io.store import open_store

AS_OF = None                        # None: today; or a datetime.date to see the knowledge base as of that day
SOURCES = None                      # None: every source in the workbook; or a set such as {"A7", "A8"}

store = open_store(spark)  # noqa: F821
res = stages.build(store, reg, today=AS_OF)
print({k: v for k, v in res.items() if k != "warnings"})

# COMMAND ----------

wb = stages.review_out(store, reg, sources=SOURCES)
print(wb)

# COMMAND ----------

cur = pd.DataFrame(store.read("records_current"))
if len(cur):
    display(cur.groupby(["source_id", "origin", "status", "execution_class"]).size().rename("records")  # noqa: F821
            .reset_index())
