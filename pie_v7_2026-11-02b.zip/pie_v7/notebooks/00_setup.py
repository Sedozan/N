# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Setup (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Run once, and again after changing the settings. It creates the schema and the file folders, and checks the
# MAGIC source registry, the program list, the precedence statements and the table readings shipped with the package.
# MAGIC Nothing is extracted here.
# MAGIC
# MAGIC Next: drop the source files in the inbox folder printed below (any names, any subfolders), then run 01.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import os

from pie_kb.sources import registry as RG
from pie_kb.tables import SPECS
from pie_kb.tables import readings as RD

try:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {config.CATALOG}.{config.SCHEMA}")  # noqa: F821
    print(f"schema {config.CATALOG}.{config.SCHEMA} is ready")
except Exception as e:                                                          # noqa: BLE001
    print(f"could not create {config.CATALOG}.{config.SCHEMA} ({type(e).__name__}): ask for CREATE SCHEMA, or set "
          f"SCHEMA in _settings to one you can write")

for d in (config.INBOX_DIR, config.ARCHIVE_DIR, config.QUARANTINE_DIR, config.STAGE_DIR, config.RUNS_DIR,
          config.REVIEW_OUT_DIR, config.REVIEW_IN_DIR):
    os.makedirs(d, exist_ok=True)
print("folders under", config.DATA_DIR)
print("  drop source files in:", config.INBOX_DIR)

problems = RG.validate(reg) + RD.validate(RD.load(), SPECS)
print(f"registry: {len(reg.docs)} documents ({len(reg.active())} active), {len(reg.programs)} programs, "
      f"{len(reg.precedence)} precedence statements; readings: {len(RD.load())}")
print("problems:", problems or "none")
