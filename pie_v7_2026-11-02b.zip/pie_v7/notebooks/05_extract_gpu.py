# Databricks notebook source
# MAGIC %md
# MAGIC # 05 · Extract with the model (Serverless GPU, environment 5; no Spark)
# MAGIC
# MAGIC Reads the files notebook 04 staged and writes one run folder under the runs folder. Three passes:
# MAGIC 1. Plan: every piece the model must read, and how many the answer cache already holds (from every earlier run).
# MAGIC 2. Generate: the model reads the pieces the cache does not hold. Answers are cached as they come (written every
# MAGIC    20 calls), so a run stopped by the time limit, a GPU failure or a cancel loses nothing: the next run asks only
# MAGIC    for what is still missing. An answer cut off by its token budget is retried once larger, then its piece is
# MAGIC    split in two.
# MAGIC 3. Ground: patterns and answers become records only when their quote, codes, numbers and dates are in the
# MAGIC    section's own words; a refused proposal is kept with its reason.
# MAGIC
# MAGIC Start with DRY_RUN True: a few sections, to read the model's answers and the grounding before a long run. A dry
# MAGIC run is never persisted. Sources run in priority order (P1 first), so a time-limited run reads the most important
# MAGIC ones first.
# MAGIC
# MAGIC Next: 06 on a CPU cluster with Unity Catalog.

# COMMAND ----------

# MAGIC %pip install -q openai-harmony accelerate openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import json
import os

import pandas as pd

from pie_kb.extract import run as XR

DRY_RUN = True                      # first: a few sections only (not persisted); then False for the full run
DRY_RUN_SECTIONS = 3
MAX_MINUTES = 240                   # stop asking the model after this long; the next run continues where this stopped
BATCH = 1                           # pieces per generate() call (local GPU) or parallel requests (serving endpoint)

stage_dir = os.path.join(config.STAGE_DIR, "narrative")
be = stages.backend(MODEL_BACKEND, REASONING)
plan = XR.plan_stage(stage_dir, be, reg)
print(plan)

# COMMAND ----------

if plan.get("to_model", 0) == 0:
    print("the cache answers every piece: no model is loaded; this run only grounds")
else:
    ok, msg = be.healthcheck()       # loads the model on the local GPU (about 65 GB, several minutes)
    print(msg)
    if not ok:
        raise RuntimeError(msg)

# COMMAND ----------

out = stages.extract_narrative(be, reg, stage_dir=stage_dir, max_minutes=MAX_MINUTES, batch=BATCH,
                               limit=DRY_RUN_SECTIONS if DRY_RUN else None)
print(json.dumps({k: out.get(k) for k in ("run_id", "dry_run", "records", "proposals", "outcomes", "model_calls",
                                          "generate")}, indent=1, default=str))

# COMMAND ----------

# MAGIC %md ## What the model proposed and what grounding kept

# COMMAND ----------

props = XR._read_jsonl(os.path.join(out["run_dir"], "proposals.jsonl"))
if props:
    df = pd.DataFrame([{"section": p["section_id"], "origin": p["origin"], "kept": p["kept"],
                        "drop_reason": p["drop_reason"], "kind": (p["raw"] or {}).get("kind"),
                        "quote": str((p["raw"] or {}).get("quote"))[:200]} for p in props])
    display(df)  # noqa: F821
