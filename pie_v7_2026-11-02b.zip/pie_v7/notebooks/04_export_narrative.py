# Databricks notebook source
# MAGIC %md
# MAGIC # 04 · Stage the sections for the model (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Writes the sections of every version not yet extracted under the current configuration (prompt, extraction
# MAGIC code, model, reasoning level, and the version's own text) to files the GPU notebook reads. Nothing is sent to a
# MAGIC model here. The plan below says how many pieces the model must read and how many the answer cache already holds,
# MAGIC with an estimate of the time at the rate v6.3 measured on your GPU (one piece at a time).
# MAGIC
# MAGIC Next: 05 on Serverless GPU (with MODEL_BACKEND "serving", on any compute that can call the endpoint).

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import os

from pie_kb.extract import run as XR
from pie_kb.extract.backends import CacheOnly
from pie_kb.io.store import open_store

FORCE = False                       # True: every version again (unchanged messages still come from the cache)
store = open_store(spark)  # noqa: F821
model = config.SERVING_ENDPOINT if MODEL_BACKEND == "serving" else config.HF_MODEL
stages.export_narrative(store, reg, model=model, reasoning=REASONING, force=FORCE)

# the plan, from the answer cache alone: no model is loaded or called here
probe = CacheOnly(MODEL_BACKEND, model, REASONING)
print(XR.plan_stage(os.path.join(config.STAGE_DIR, "narrative"), probe, reg))
