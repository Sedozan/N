# Databricks notebook source
# MAGIC %md
# MAGIC # v01 · Read a filled review workbook back, then rebuild (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Every filled row becomes a decision in kb_review_log, bound to the content the reviewer saw. Ingest refuses, and
# MAGIC lists: a row whose record, reading, statement or conflict changed since the export (stale: export a new
# MAGIC workbook); a Fix the section's own words do not support; an author approving their own record (someone else
# MAGIC approves it). Ingesting the same workbook twice adds nothing. The rebuild then applies the decisions.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import glob
import os

from pie_kb.io.store import open_store

WORKBOOK = None                     # None: the newest .xlsx in review/in (filled workbooks); or a full path
store = open_store(spark)  # noqa: F821
filled = glob.glob(os.path.join(config.REVIEW_IN_DIR, "*.xlsx"))
if WORKBOOK is None and not filled:
    raise FileNotFoundError(f"no filled workbook in {config.REVIEW_IN_DIR}: put the filled workbook there")
path = WORKBOOK or max(filled, key=os.path.getmtime)
print("reading", path)
res = stages.review_in(store, reg, path)
for e in res["errors"]:
    print("  refused:", e)

# COMMAND ----------

build = stages.build(store, reg)
print({k: v for k, v in build.items() if k in ("records", "status", "executable_now", "conflicts")})
