# Databricks notebook source
# MAGIC %md
# MAGIC # 01 · Sources: file what is new (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Every file in the inbox is recognised by its content (not its name), dated from its own words (an effective,
# MAGIC revision or "as of" date, never the download date) and archived once. A file whose bytes PIE already holds is
# MAGIC reported as a duplicate and not filed again, so the inbox can be left as it is between runs. A file no registry
# MAGIC row recognises goes to the quarantine folder with the reason.
# MAGIC
# MAGIC With FETCH set to True, PIE first downloads every active registry document that has a link, if this cluster
# MAGIC can reach the site (the egress check says so); downloads go through the same intake.
# MAGIC
# MAGIC Writes kb_source_registry and kb_source_versions. Next: 02.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import pandas as pd

from pie_kb.io.store import open_store

FETCH = False                       # True: download from azahcccs.gov first (needs egress from this cluster)

store = open_store(spark)  # noqa: F821
print("registry rows:", stages.sync_registry(store, reg))
new = stages.intake(store, reg, fetch=FETCH)

# COMMAND ----------

# MAGIC %md ## Every active version and where it stands

# COMMAND ----------

display(pd.DataFrame(stages.status(store, reg)))  # noqa: F821

# COMMAND ----------

q = [v for v in store.read("source_versions") if v.get("status") == "quarantined"]
if q:
    display(pd.DataFrame(q)[["original_name", "notes", "archive_path"]])  # noqa: F821
else:
    print("nothing in quarantine")
