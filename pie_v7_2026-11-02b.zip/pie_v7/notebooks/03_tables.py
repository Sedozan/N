# Databricks notebook source
# MAGIC %md
# MAGIC # 03 · Read the tables (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC B2 matrix, PA guidelines, telehealth code set, PEP-903, BH diagnosis lists, Exhibit 300-2A, and (when their files
# MAGIC are in) Same Day Disallow, daily limits and the NCCI edits. Every row is kept; records are made for the code spine
# MAGIC (every B2 code plus every code a BH narrative source names). What each column means is a reading in
# MAGIC reference/table_readings.csv: table records are approved only when every reading they rest on is signed (in the
# MAGIC review workbook, notebook 07).
# MAGIC
# MAGIC Writes kb_table_rows, kb_value_sets, kb_records (origin table), kb_readings, kb_sections (text inside table
# MAGIC files) and the processing ledger. Next: 04.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import pandas as pd

from pie_kb.io.store import open_store

FORCE = False
store = open_store(spark)  # noqa: F821
out = stages.tables(store, reg, force=FORCE)
print("read:", out["read"], "\nfailed:", out["failed"], "\nspine:", out.get("spine"))

# COMMAND ----------

recs = [r for r in store.read("records") if r.get("origin") == "table"]
if recs:
    df = pd.DataFrame(recs)
    display(df.groupby(["source_id", "kind", "execution_class"]).size().rename("records").reset_index())  # noqa: F821
