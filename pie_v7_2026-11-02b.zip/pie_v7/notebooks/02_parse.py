# Databricks notebook source
# MAGIC %md
# MAGIC # 02 · Parse the policy PDFs (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Each narrative PDF (AMPM policies, the CBHSG, the billing manuals, the A.A.C., Claims Clues, the FAQ) becomes
# MAGIC headed sections of located blocks: page, outline position (such as III.A.6.a), role (body, definitions, purpose;
# MAGIC history, front matter and boilerplate are kept but not extracted). Only versions not parsed under the current
# MAGIC parser code are read; a parser change makes them due again.
# MAGIC
# MAGIC Writes kb_sections and the processing ledger. Next: 03.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import pandas as pd

from pie_kb.io.store import open_store

FORCE = False                       # True: parse every version again under the current parser
ONLY = None                         # or a set of source ids, for example {"A7", "A8"}

store = open_store(spark)  # noqa: F821
out = stages.parse(store, reg, only=ONLY, force=FORCE)
print({k: (len(v) if isinstance(v, list) else v) for k, v in out.items()})

# COMMAND ----------

secs = store.read("sections")
if secs:
    df = pd.DataFrame(secs)
    display(df.groupby(["source_id", "source_version_id", "role"]).agg(sections=("section_id", "count"),  # noqa: F821
                                                                       chars=("n_chars", "sum")).reset_index())
