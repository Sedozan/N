# Databricks notebook source
# MAGIC %md
# MAGIC # d01 · What the knowledge base says about a code (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Every record that names the code (as its subject, a partner, a parent, or through a service code set), with its
# MAGIC source, page, quote, window, review status and class, as of the latest build; then the code sets that list it
# MAGIC and its open conflicts. Read only.

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

CODE = "H0004"


def t(name: str) -> str:
    return config.table(name)


display(spark.sql(f"""
    SELECT i.role, r.kind, r.statement, r.source_id, get_json_object(r.citation, '$.page_start') AS page,
           get_json_object(r.citation, '$.section_path') AS section, get_json_object(r.citation, '$.quote') AS quote,
           r.effective_start, r.effective_end, r.status, r.execution_class, r.executable_now, r.conflicts
    FROM {t('code_index')} i JOIN {t('records_current')} r ON r.record_id = i.record_id
    WHERE i.code = '{CODE}'
    ORDER BY r.executable_now DESC, r.status, r.source_id, r.kind"""))  # noqa: F821

# COMMAND ----------

display(spark.sql(f"""
    SELECT value_set_id, source_version_id, description, origin FROM {t('value_sets')} WHERE code = '{CODE}'
    ORDER BY value_set_id"""))  # noqa: F821
