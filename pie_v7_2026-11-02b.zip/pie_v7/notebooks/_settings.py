# Databricks notebook source
# MAGIC %md
# MAGIC # PIE settings
# MAGIC
# MAGIC Every PIE notebook runs this notebook first, so a value changed here applies everywhere. It sets where PIE keeps
# MAGIC its files, which Unity Catalog schema holds the tables, and which model backend the GPU step uses, then puts the
# MAGIC pie_kb package (the folder above this one) on the Python path. It never touches Spark, so the GPU notebook can run
# MAGIC it too.

# COMMAND ----------

import os
import sys


def _user() -> str:
    try:
        return dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()  # noqa: F821
    except Exception:                                    # noqa: BLE001 - outside a notebook
        return os.environ.get("PIE_USER", "")


# Files: inbox (drop source files here), archive, quarantine, stage (for the GPU), runs, review workbooks.
# A Unity Catalog volume you can write is best (for example /Volumes/main/policy_kb/pie); a Workspace folder works too.
DATA_DIR = os.environ.get("PIE_DATA_DIR") or f"/Workspace/Users/{_user()}/pie_v7_data"
CATALOG = "main"
SCHEMA = "policy_kb"                 # tables are CATALOG.SCHEMA.kb_<name>
MODEL_BACKEND = "hf_local"           # "hf_local": gpt-oss-120b on Serverless GPU; "serving": databricks-gpt-oss-120b
REASONING = "medium"                 # v6.3 measured on chapter 19: medium finds more rules than low, at 2.4x the time

os.environ.update({"PIE_DATA_DIR": DATA_DIR, "PIE_CATALOG": CATALOG, "PIE_SCHEMA": SCHEMA, "PIE_REASONING": REASONING})

_here = os.getcwd()
for _cand in (os.environ.get("PIE_REPO_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.isdir(os.path.join(_cand, "pie_kb")):
        if _cand not in sys.path:
            sys.path.insert(0, _cand)
        break
else:
    raise ImportError(f"the pie_kb package is not in {_here} or its parent; set PIE_REPO_DIR to the folder that holds it")

from pie_kb import config, stages                          # noqa: E402,F401 - used by the notebooks that run this
from pie_kb.sources import registry                        # noqa: E402

reg = registry.load()
print(f"PIE {config.PIE_VERSION} | files {config.DATA_DIR} | tables {config.CATALOG}.{config.SCHEMA}.kb_* | "
      f"backend {MODEL_BACKEND}, reasoning {REASONING}")
