# PIE v7: the AHCCCS behavioral health policy knowledge base

PIE reads the AHCCCS behavioral health policy sources (the CBHSG, AMPM policies, the FFS and IHS/Tribal billing
manuals, A.A.C. Title 9 Chapter 22, Claims Clues, the B2 matrix, the PA guidelines, the telehealth code set and the
other approved tables) and turns them into a knowledge base of records. A record is one thing a source says: its kind
(a units limit, a same-day pair, a prior authorization rule, a definition, a pointer, and 16 more), its codes and
conditions, its date window, and the source's own words it was read from (document, version, page, section, quote).
People sign what the records mean before any of them can judge a claim.

Version 7.0 is a clean start. Nothing from v6.3 (rules, seeds, table loads) is read or carried over.

## The notebooks, in order

| notebook | compute | what it does | writes |
|---|---|---|---|
| 00_setup | CPU, Unity Catalog | creates the schema and the folders; checks the registry and readings | |
| 01_sources | CPU, Unity Catalog | files what is new in the inbox (or fetched): recognised by content, dated from its own words, archived once | kb_source_registry, kb_source_versions |
| 02_parse | CPU, Unity Catalog | PDFs into located sections | kb_sections |
| 03_tables | CPU, Unity Catalog | tables into rows, records and value sets, under readings | kb_table_rows, kb_records, kb_value_sets, kb_readings |
| 04_export_narrative | CPU, Unity Catalog | stages the due sections as files; plans the model work | files |
| 05_extract_gpu | Serverless GPU (environment 5), no Spark | the model reads the pieces the cache does not hold; grounding keeps what the text says | a run folder |
| 06_persist_narrative | CPU, Unity Catalog | finished runs into the tables | kb_records, kb_proposals, kb_extraction_outcomes |
| 07_build_and_review | CPU, Unity Catalog | builds the knowledge base as of a date; exports the review workbook | kb_records_current and the build tables; a workbook |
| v01_review_ingest | CPU, Unity Catalog | reads a filled workbook into the review log; rebuilds | kb_review_log |
| v02_kb_report | CPU, Unity Catalog | where the knowledge base stands | |
| d01_code_lookup | CPU, Unity Catalog | everything the knowledge base says about one code | |

Every notebook first runs `_settings`, the one place for the file folder, the schema, the model backend and the
reasoning level.

## Getting it into Databricks

The folder layout matters: `notebooks/` must sit next to `pie_kb/` (the notebooks find the package in their parent
folder). Either:
- push this folder to your Git provider and clone it as a Databricks Git folder, or
- unzip it on your PC and import the whole folder with the Databricks CLI:
  `databricks workspace import-dir pie_v7 /Workspace/Users/<you>/pie_v7`
  The notebooks (files whose first line is `# Databricks notebook source`) arrive as notebooks, everything else as
  workspace files. Uploading the notebooks one by one, without `pie_kb/` beside them, does not work.

## First run

1. Open `notebooks/_settings` and check DATA_DIR (where PIE keeps its files; the default is a folder under your
   Workspace user folder) and SCHEMA. Run 00. Drop the source files in the inbox folder it prints (any file names,
   any subfolders).
2. Run 01, 02 and 03. 01 lists what it filed, what it recognised as a duplicate, and what it quarantined (with why).
3. Run 04. Its plan says how many pieces the model must read and about how long that takes.
4. Run 05 with DRY_RUN True: three sections. Read what the model proposed and what grounding kept or refused, with the
   reason. Then run it with DRY_RUN False. MAX_MINUTES caps a run; the next run continues where it stopped.
5. Run 06, then 07. Download the workbook from review/out, fill Decision and Reviewer, put it in review/in, run v01.

## Running again: only what is new or changed

- A file is identified by its bytes. Dropping the same file again changes nothing. A new version of a document is
  filed with the date written in it and goes through the stages.
- Each stage keeps a processing ledger. A version is due for a stage until a run finishes it under the stage's current
  configuration: parser code; table code and readings; prompt, extraction code, model and reasoning level, plus the
  version's own text. A code or prompt change makes versions due again only for that stage.
- Model answers are cached by message (prompt, section text, model, reasoning, budget). A section that did not change
  costs no model time, even in a new version of its document. A run stopped early loses nothing.
- A partial run (a piece failed or was not reached) leaves its versions due, and never replaces the records of a
  version that already had a complete run.

## Review: people sign what records mean

- Every decision is bound to a hash of what the reviewer saw. If the record, reading, statement or conflict changes
  later, the decision is shown as stale and not applied.
- Table records are approved when every reading they rest on is signed (reference/table_readings.csv lists 27
  readings, each with its evidence).
- A Fix becomes a new record that must still match the section's words, and someone other than its author approves it.
  An SME can add a record the extraction missed; the same rule applies.
- Approvals carry to the next version of a document only when the record's section reads the same and no term it uses
  was redefined. Otherwise the record goes back for review. An approval keeps judging its own version's window.
- Conflicts (two records about the same code that cannot both hold) are listed with a suggested prevailing record: a
  source's own precedence statement first, then authority, then specificity, then date. The suggestion is never
  applied unsigned; records in an open conflict cannot run.

## Execution classes

| class | meaning |
|---|---|
| executable | checkable on the claim lines as stated |
| conditional | checkable, but a condition, an exception or a field needs a person per finding |
| signal | ranks providers for review; never a violation (the Claims Clues documentation thresholds) |
| knowledge | definitions, pointers, duties a claim cannot show |
| unresolved | names a service no code set resolves yet, or flagged by grounding |

A record is executable now only when it is executable, approved, in force on the build date and in no open conflict.

## Model time

At the rate v6.3 measured on chapter 19 (Serverless GPU, one piece at a time), the 423 pieces of the sources in hand
take about 44 hours at reasoning medium (18 at low). Ways to shorten it: run in windows (MAX_MINUTES; P1 sources go
first), try BATCH above 1 on the GPU, or set MODEL_BACKEND to "serving" to use the Databricks endpoint
databricks-gpt-oss-120b with parallel requests, if the workspace allows it.

## Package layout

| module | what it holds |
|---|---|
| config.py | every name, path and switch (environment variables PIE_<NAME> override) |
| core/ | text, hashing, dates, code systems, the 21 record kinds, the record, execution classes per claim type |
| sources/ | the registry (reference/sources.csv), intake, version dating, ledgers, the fetcher |
| parse/ | PDF lines, document profiles, sections |
| tables/ | one spec per table family, readings |
| extract/ | list tokens, pieces, the prompt, answer reading, grounding, patterns, backends, the answer cache, the stage |
| review/ | decisions and the review workbook |
| kb/ | the code spine, status, category resolution, conflicts, overlays, diffs, the build |
| stages.py | one call per pipeline step (what the notebooks run) |

## Tests

`python -m pytest -q` from the repository root (139 tests); `python tools/local_e2e.py --compare` runs the whole
pipeline on local Spark and on Parquet files and compares the two. Tests that read the real source files look in
/home/claude/sources_raw/AHCCCS_BH_Files or in the folder PIE_TEST_SOURCES names, and are skipped when it is absent.

## Known limits

- Versions in hand are mostly current: most post-date the claims (October 2024 to September 2026). Earlier versions
  must come from AHCCCS or the Internet Archive.
- Same Day Disallow, daily limits and NCCI files are not in hand; their specs were built to the documented layouts and
  tested on synthetic files.
- A code range expands only over codes the knowledge base knows (the code spine).
- Checkmark tables inside narrative PDFs (AMPM 610) come through as rows of cells without their column headers.
- Managed care sources are deferred; records carry applicability (FFS, MC) so shared sources need no re-extraction.
- Four-eyes compares names without case or spacing, but cannot tell that "J. Doe" is "Jane Doe": the workbook shows
  each record's author next to the Reviewer column.
- On Delta, a stage replaces a version's rows with a delete and then an append (two transactions). A failure between
  them leaves that version's rows missing until the stage runs again, which it does on its next run.
