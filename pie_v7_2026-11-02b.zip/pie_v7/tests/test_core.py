"""Core: text, dates, codes, kinds, records, execution classes."""
from datetime import date

import pytest

from pie_kb.core import checkability as CK
from pie_kb.core import codes as C
from pie_kb.core import dates as D
from pie_kb.core import kinds as K
from pie_kb.core.record import Record, finalize
from pie_kb.core.text import clean, match_form, sentences


# ------------------------------------------------------------------ text
def test_clean_glyphs():
    assert clean("H0004 – counseling and “therapy”") == 'H0004 - counseling and "therapy"'
    assert match_form("A , B ;C") == "a, b; c"


def test_sentences_keep_abbreviations_together():
    t = "See A.A.C. R9-22-1205 for scope. H0004 must not be billed. (e.g., a child) Next one."
    spans = [t[a:b].strip() for a, b in sentences(t)]
    assert spans[0] == "See A.A.C. R9-22-1205 for scope."
    assert spans[1] == "H0004 must not be billed."


# ------------------------------------------------------------------ dates
def test_dates():
    assert D.mdy("As of 10/1/26") == date(2026, 10, 1)
    assert D.any_date("Effective Oct. 1, 2024") == date(2024, 10, 1)
    assert D.month_year("May 2023") == date(2023, 5, 1)
    assert D.fiscal_year_window(2027) == (date(2026, 10, 1), date(2027, 9, 30))
    assert D.months_between(date(2025, 8, 1), date(2025, 11, 1)) == [date(2025, 9, 1), date(2025, 10, 1)]
    assert D.overlaps("2025-01-01", None, "2024-01-01", "2025-01-01")
    assert not D.overlaps("2025-01-02", None, "2024-01-01", "2025-01-01")


# ------------------------------------------------------------------ codes
@pytest.mark.parametrize("tok,system", [("H0004", "HCPCS"), ("90837", "CPT"), ("0591T", "CPT_III"),
                                        ("D0120", "CDT"), (100, "CPT"), ("F1020", None), ("85007.0", "CPT")])
def test_procedure_system(tok, system):
    assert C.procedure_system(tok) == system


def test_codes_in_text_skip_zip_and_icd():
    t = "Mail to 150 N. 18th Ave., Phoenix, AZ 85007. H0004 may not be billed with H0035 for F10.239 or F1020."
    assert [c for c, *_ in C.procedure_codes_in(t)] == ["H0004", "H0035"]
    assert [c for c, *_ in C.diagnosis_codes_in(t)] == ["F10239", "F1020"]


def test_ranges_and_expansion():
    t = "codes H0001-H0005 and 90832 through 90838"
    assert [(a, b) for a, b, *_ in C.ranges_in(t)] == [("H0001", "H0005"), ("90832", "90838")]
    assert C.expand_range("H0001", "H0005", ["H0002", "H0004", "H0010", "T1016"]) == ["H0001", "H0002", "H0004",
                                                                                     "H0005"]


def test_modifiers_and_provider_types_in_text():
    assert C.modifiers_in("H0004 must be paired with the HQ modifier when") == ["HQ"]
    assert C.modifiers_in("modifiers GT, GQ or FQ") == ["GT", "GQ", "FQ"]
    assert C.provider_types_in("The group payment ID (PT 01) may only be used for billing.") == ["01"]
    assert C.provider_types_in("provider types B5 and B6") == ["B5", "B6"]


# ------------------------------------------------------------------ kinds
def test_every_kind_validates_its_example():
    examples = {
        "not_covered": {}, "prior_auth_rule": {"requirement": "required"},
        "pair_prohibited": {"partners": ["H0018"]}, "included_in": {"parent_category": "BHRF per diem"},
        "units_limit": {"max": 4, "per": "day"}, "frequency_limit": {"max": 1, "per": "year"},
        "dollar_limit": {"max_amount": 2000.0, "per": "year"},
        "provider_type_rule": {"mode": "allowed", "provider_types": ["77", "IC"]},
        "provider_qualification": {"requirement": "a BHT works under the clinical oversight of a BHP"},
        "modifier_rule": {"mode": "required", "modifiers": ["HQ"]}, "pos_rule": {"mode": "not_allowed", "pos": [2, 10]},
        "telehealth_rule": {"allowed": True, "modifiers": ["GT"]}, "claim_form_required": {"form": "UB-04"},
        "diagnosis_required": {"value_set": "A6"}, "age_limit": {"below_age": 21},
        "documentation_required": {"requirement": "assessment and treatment plan with the claim",
                                   "threshold_units": 8, "per": "day"},
        "coverage_scope": {"description": "psychotherapy"}, "definition": {"definition": "a person who ..."},
        "exception": {"effect": "waives", "applies_to": "prior authorization for emergency services"},
        "cross_reference": {"target": "AMPM Policy 820"}, "obligation": {"duty": "notify the PCP at intake"},
    }
    assert set(examples) == set(K.KINDS)
    for kind, params in examples.items():
        norm = K.normalize_params(kind, params)
        assert K.validate_params(kind, norm) == [], (kind, K.validate_params(kind, norm))


def test_kind_validation_refuses_bad_values():
    assert "units_limit needs max" in K.validate_params("units_limit", {"per": "day"})
    assert any("whole number" in p for p in K.validate_params("units_limit", {"max": 4.5, "per": "day"}))
    assert any("one of" in p for p in K.validate_params("units_limit", {"max": 4, "per": "fortnight"}))
    assert "pair_prohibited needs partners or partner_category" in K.validate_params("pair_prohibited", {})
    assert any("does not take" in p for p in K.validate_params("not_covered", {"max": 3}))
    assert K.normalize_params("pos_rule", {"mode": "allowed", "pos": [2, "10"]})["pos"] == ["02", "10"]


def test_conditions():
    assert K.validate_conditions([{"type": "age", "below_age": 21}]) == []
    assert K.validate_conditions([{"type": "weather", "text": "rain"}])
    assert K.validate_conditions([{"type": "modifier", "present": ["HQ"]}]) == []


# ------------------------------------------------------------------ records
def _rec(**kw):
    base = dict(kind="pair_prohibited", subject={"codes": ["h0004"]},
                params={"partners": ["H0018", "H0019"], "scope": "member_day", "modifier_bypass": "none"},
                citation={"source_id": "A7", "document_key": "main", "source_version_id": "A7@2026-10-01#d5da6d5a",
                          "locator": "p.26 Billing Limitations 6.a", "quote": "H0004 must not be billed on the same day"},
                origin="model")
    base.update(kw)
    return finalize(Record(**base))


def test_record_identity():
    a = _rec()
    b = _rec(citation={**a.citation, "source_version_id": "A7@2027-01-01#aaaaaaaa", "locator": "p.27"})
    assert a.subject["codes"] == ["H0004"]
    assert a.record_key == b.record_key            # same meaning in a new version
    assert a.record_id != b.record_id              # a different statement instance
    c = _rec(params={"partners": ["H0018"], "scope": "member_day", "modifier_bypass": "none"})
    assert c.record_key != a.record_key
    assert a.problems() == []
    assert "pair_prohibited needs partners or partner_category" in _rec(params={}).problems()
    assert any("quote" in p for p in _rec(citation={**a.citation, "quote": ""}).problems())


# ------------------------------------------------------------------ execution classes
def test_execution_classes():
    assert CK.execution_class(_rec())[0] == "executable"
    cls, why = CK.execution_class(_rec(params={"partners": ["H0018"]}))      # scope and bypass unstated
    assert cls == "conditional" and any("scope" in w for w in why)
    assert CK.execution_class(_rec(kind="definition", subject={"term": "BHRF staff"},
                                   params={"definition": "any employee"}))[0] == "knowledge"
    doc = _rec(kind="documentation_required", params={"requirement": "send records", "threshold_units": 8,
                                                      "per": "day"})
    assert CK.execution_class(doc)[0] == "signal"
    cat = _rec(kind="not_covered", subject={"category": "room and board"}, params={})
    assert CK.execution_class(cat)[0] == "unresolved"
    pos = _rec(kind="pos_rule", params={"mode": "allowed", "pos": ["11"], "complete_list": True})
    assert CK.execution_class(pos)[0] == "conditional"                       # POS not measured yet
    pt = _rec(kind="provider_type_rule", params={"mode": "allowed", "provider_types": ["77"], "complete_list": True,
                                                 "role": "billing_or_rendering"})
    assert CK.execution_class(pt)[0] == "executable"
    pt_incomplete = _rec(kind="provider_type_rule", params={"mode": "allowed", "provider_types": ["77"],
                                                            "role": "billing"})
    assert CK.execution_class(pt_incomplete)[0] == "knowledge"
    exc = _rec(exceptions=[{"text": "unless documentation of medical necessity supports it"}])
    assert CK.execution_class(exc)[0] == "conditional"
    setting = _rec(conditions=[{"type": "setting", "text": "while the member is in a BHRF"}])
    cls, why = CK.execution_class(setting)
    assert cls == "conditional" and any("not on the claim" in w for w in why)
    rev = _rec(kind="not_covered", params={})
    assert CK.execution_class(rev, "institutional")[0] == "conditional"      # PROC_CD on UB-04 not verified
