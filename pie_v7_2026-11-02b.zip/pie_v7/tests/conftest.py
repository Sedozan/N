import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

# The files SB downloaded on 2026-11-01 (AHCCCS_BH_Files.zip, unpacked). Tests that read them skip when absent.
REAL = os.environ.get("PIE_TEST_SOURCES", "/home/claude/sources_raw/AHCCCS_BH_Files")


def real_path(rel: str) -> str:
    p = os.path.join(REAL, rel)
    if not os.path.exists(p):
        pytest.skip(f"real source file not available: {rel}")
    return p


@pytest.fixture(scope="session")
def reg():
    from pie_kb.sources import registry
    return registry.load()
