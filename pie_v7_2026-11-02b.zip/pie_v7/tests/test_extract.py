"""Narrative extraction: list tokens, pieces, answers, grounding, patterns, the answer cache, and the stage end to end
with a replayed model (no GPU)."""
import json
import os
from functools import lru_cache

import pytest

from conftest import real_path
from pie_kb import config
from pie_kb.core import codes as C
from pie_kb.extract import cache as K
from pie_kb.extract import ground as G
from pie_kb.extract import lists as LS
from pie_kb.extract import patterns as PT
from pie_kb.extract import pieces as XP
from pie_kb.extract import run as XR
from pie_kb.extract.backends import CacheOnly, NoModel, ReplayBackend, Truncated
from pie_kb.extract.parse import AnswerError, read_answer
from pie_kb.io.store import LocalStore
from pie_kb.parse import run as PR
from pie_kb.parse import sections as S
from pie_kb.sources import intake, registry

AMPM_320V = "02_AMPM/AMPM_320-V.pdf"
CBHSG = "01_CBHSG/AHCCCS_CBHSG.pdf"
CH19 = "03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf"
AAC = "04_Arizona_Rules/AAC_Title9_Ch22_includes_Article12.pdf"
NONE = '{"records": [], "none_reason": "no rule in this text"}'


@lru_cache(maxsize=None)
def parsed(rel: str):
    reg = registry.load()
    path = real_path(rel)
    doc = intake.identify(path, reg).doc
    svid = f"{doc.doc_id}@test#00000000"
    return doc, S.to_rows(S.parse_pdf(path, doc, svid, reg), doc, svid)


def section(rel: str, *heads):
    doc, rows = parsed(rel)
    want = " > ".join(heads)
    return doc, next(r for r in rows if r["path_text"].endswith(want))


def synthetic(text: str, blocks=None, path: str = "TEST > SECTION") -> dict:
    return {"section_id": "S-test", "section_key": "SK-test", "source_version_id": "A7@test#00000000",
            "source_id": "A7", "document_key": "main", "path": path.split(" > "), "path_text": path,
            "heading": path.split(" > ")[-1], "level": 2, "page_start": 3, "page_end": 3, "text": text,
            "blocks": blocks or [{"kind": "para", "page": 3, "item": "", "start": 0, "end": len(text)}],
            "codes": {"procedure": [c for c, *_ in C.procedure_codes_in(text)]}, "signal": 1, "role": "body",
            "applicability": {"delivery_systems": ["FFS"]}, "ordinal": 1}


def ground_one(doc, sec, prop, universe=()):
    tk = LS.tokenize(sec["text"], universe)
    ctx = {"doc": doc, "source_version_id": sec["source_version_id"], "universe": set(universe), "extraction": {},
           "origin": "model"}
    return G.ground(prop, sec, tk, ctx)


# ------------------------------------------------------------------ answers and quotes
def test_read_answer_is_tolerant_but_strict_on_shape():
    good = {"records": [{"kind": "not_covered"}], "none_reason": None}
    assert read_answer("```json\n" + json.dumps(good) + "\n```")["records"] == good["records"]
    assert read_answer('Here it is: {"records": [{"kind": "definition"},], "none_reason": null}')["records"]
    assert read_answer('{"records": [], "none_reason": "headings only"}')["none_reason"] == "headings only"
    with pytest.raises(AnswerError):
        read_answer('{"rules": []}')
    with pytest.raises(AnswerError):
        read_answer('{"records": [{"kind": "not_cov')                        # cut off


def test_find_quote_ignores_spacing_case_and_glyphs_and_keeps_order():
    text = "Respite services are limited to 600 hours per benefit year.\nCSAs cannot provide respite services."
    assert G.find_quote(text, "respite services ARE limited to 600 hours") == (0, 41)
    assert G.find_quote(text, "Respite services are limited ... CSAs cannot provide") is not None
    assert G.find_quote(text, "CSAs cannot provide ... Respite services are limited") is None      # out of order
    assert G.find_quote(text, "Respite services are") is None                                     # too short
    assert G.find_quote(text, "Respite services are limited to 700 hours") is None


def test_numbers_are_read_as_digits_or_words():
    assert {8.0, 24.0, 600.0} <= G.numbers_in("eight (8) units per day, twenty-four units, 600 hours")
    assert 1000.0 in G.numbers_in("one thousand dollars")


# ------------------------------------------------------------------ list tokens
def test_list_tokens_do_not_depend_on_the_spine():
    text = "H0004 may not be billed with H0031, H0032, H2010-H2014, H2017 or S5150 on the same day."
    small, big = LS.tokenize(text, set()), LS.tokenize(text, {"H2011", "H2012", "H2013"})
    assert small.text == big.text == "H0004 may not be billed with [L1] on the same day."
    assert small.legend == big.legend and "(5 entries)" in small.legend
    assert set(big.codes("L1")) - set(small.codes("L1")) == {"H2011", "H2012", "H2013"}
    assert small.expand("billed with [L1] on") == "billed with H0031, H0032, H2010-H2014, H2017 or S5150 on"


def test_ch19_respite_list_becomes_one_token():
    _, sec = section(CH19, "RESPITE CARE (UNSKILLED)")
    tk = LS.tokenize(sec["text"])
    assert "prohibited from billing S5151 with [L1] or any other per diem code" in tk.text
    assert len(tk.codes("L1")) == 21 and "S5151" not in tk.codes("L1")


def test_ch19_day_program_keeps_the_typo_out_of_the_list():
    _, sec = section(CH19, "BEHAVIORAL HEALTH DAY PROGRAM")
    tk = LS.tokenize(sec["text"])
    irregular = [cl for cl in tk.lists.values() if cl.irregular]
    assert irregular and all(cl.irregular == ["S109"] for cl in irregular)
    assert all("S109" not in cl.codes for cl in tk.lists.values())


# ------------------------------------------------------------------ pieces
def _outline(n_items: int = 6, size: int = 400) -> dict:
    parts, blocks, pos = [], [], 0

    def add(kind, item, text):
        nonlocal pos
        parts.append(text)
        blocks.append({"kind": kind, "page": 1, "item": item, "start": pos, "end": pos + len(text)})
        pos += len(text) + 1
    add("para", "", "Billing limitations apply as follows. " * 3)
    for top in "AB":
        add("item", top, f"{top}. The following apply to these services:")
        for i in range(1, n_items + 1):
            add("item", f"{top}.{i}", f"{i}. " + "Rule text that states a requirement. " * (size // 38))
    return synthetic("\n".join(parts), blocks)


def test_pieces_prefer_paragraph_and_top_level_cuts():
    sec = _outline()
    starts = {b["start"]: b for b in sec["blocks"]}
    b_top = next(b for b in sec["blocks"] if b["item"] == "B")
    wide = XP.pieces(sec, max_chars=3000)
    assert [p.start for p in wide] == [0, b_top["start"]]                 # the cut lands on "B." when it can
    assert [p.part for p in wide] == ["1/2", "2/2"] and wide[1].context == ()
    narrow = XP.pieces(sec, max_chars=1500)
    assert narrow[0].start == 0 and narrow[-1].end == len(sec["text"])
    assert all(a.end == b.start for a, b in zip(narrow, narrow[1:]))
    assert all(p.end - p.start <= 1500 for p in narrow)
    inside = [p for p in narrow if "." in starts[p.start]["item"]]       # pieces opening inside A or B
    assert inside
    for p in inside:
        parent = next(x for x in sec["blocks"] if x["item"] == starts[p.start]["item"].split(".")[0])
        assert p.context == ((parent["start"], parent["end"]),)
    assert XP.pieces(sec, max_chars=len(sec["text"])) == [XP.Piece(0, len(sec["text"]))]


def test_halves_split_near_the_middle_and_carry_context():
    sec = _outline()
    whole = XP.Piece(0, len(sec["text"]))
    a, b = XP.halves(sec, whole)
    assert a.start == 0 and a.end == b.start and b.end == whole.end
    assert abs(a.end - whole.end / 2) < whole.end / 3
    assert a.part == "1/1.1/2" and b.part == "1/1.2/2"
    one = synthetic("A single sentence with no boundary in it at all, which cannot be cut")
    assert XP.halves(one, XP.Piece(0, len(one["text"]))) == []


# ------------------------------------------------------------------ grounding
def test_grounding_expands_a_list_token_and_cites_the_section_words():
    doc, sec = section(CH19, "RESPITE CARE (UNSKILLED)")
    prop = {"kind": "pair_prohibited", "subject": {"codes": ["S5151"]},
            "params": {"partners": ["L1"], "partner_category": "any other per diem code", "scope": "unstated",
                       "modifier_bypass": "none"}, "conditions": [], "exceptions": [],
            "quote": "NOTE: Providers are prohibited from billing S5151 with [L1] or any other per diem code on the "
                     "same day."}
    g = ground_one(doc, sec, prop)
    assert g.kept, g.reason
    r = g.record
    assert r.subject["codes"] == ["S5151"] and len(r.params["partners"]) == 21
    assert "H0030" in r.citation["quote"] and "[L1]" not in r.citation["quote"]
    assert r.citation["page_start"] == 31 and r.citation["locator"].startswith("p.31 RESPITE CARE")
    assert r.extraction["list_tokens"] == ["L1"]
    assert r.origin == "model" and r.status == "proposed"


def test_grounding_refuses_what_the_section_does_not_say():
    doc, sec = section(CH19, "RESPITE CARE (UNSKILLED)")
    hours = {"kind": "units_limit", "subject": {"category": "Respite services"},
             "params": {"max": 600, "per": "benefit_year", "scope": "member", "unit_basis": "hour"},
             "quote": "Respite services are limited to 600 hours per benefit year (October 1 through September 30) "
                      "per member"}
    assert ground_one(doc, sec, hours).kept
    assert "numbers not in the quote" in ground_one(doc, sec, {**hours, "params": {**hours["params"], "max": 720}}
                                                    ).reason
    assert "quote not found" in ground_one(doc, sec, {**hours, "quote": "Respite is unlimited for members"}).reason
    wrong = {**hours, "kind": "pair_prohibited", "subject": {"codes": ["H0019"]}, "params": {"partners": ["S5151"]},
             "quote": "Providers are prohibited from billing S5151 with"}
    assert "codes not in the quote" in ground_one(doc, sec, wrong).reason
    assert "unknown kind" in ground_one(doc, sec, {**hours, "kind": "limit"}).reason


def test_grounding_checks_sense_dates_and_exceptions():
    doc = registry.load().get("A7")
    sec = synthetic("Prior authorization is not required for H0031. Effective for dates of service on and after "
                    "October 1, 2024, H2017 is not covered when billed by a CSA, unless the member is in crisis. "
                    "H0038 is covered for peer support.")
    pa = {"kind": "prior_auth_rule", "subject": {"codes": ["H0031"]}, "params": {"requirement": "required"},
          "quote": "Prior authorization is not required for H0031."}
    assert "not required" in ground_one(doc, sec, pa).reason
    nc = {"kind": "not_covered", "subject": {"codes": ["H2017"]}, "params": {}, "effective": "2024-10-01",
          "exceptions": ["unless the member is in crisis"],
          "quote": "Effective for dates of service on and after October 1, 2024, H2017 is not covered when billed "
                   "by a CSA"}
    r = ground_one(doc, sec, nc).record
    assert r.effective_start == "2024-10-01" and r.window_basis == "stated"
    assert r.exceptions == [{"text": "unless the member is in crisis"}] and r.status == "proposed"
    r = ground_one(doc, sec, {**nc, "effective": "2025-01-01", "exceptions": ["except on weekends"]}).record
    assert r.effective_start is None and r.status == "needs_review"
    assert {f["code"] for f in r.flags} == {"date_not_in_quote", "exception_not_found"}
    pos = {"kind": "not_covered", "subject": {"codes": ["H0038"]}, "params": {},
           "quote": "H0038 is covered for peer support."}
    r = ground_one(doc, sec, pos).record
    assert [f["code"] for f in r.flags] == ["negation"] and r.status == "needs_review"


def test_quote_is_looked_for_in_the_piece_first():
    doc = registry.load().get("A7")
    text = "H0004 may not be billed with H0031 on the same day.\n" * 2
    sec = synthetic(text, [{"kind": "para", "page": 3, "item": "", "start": 0, "end": 51},
                           {"kind": "para", "page": 4, "item": "", "start": 52, "end": 103}])
    prop = {"kind": "pair_prohibited", "subject": {"codes": ["H0004"]}, "params": {"partners": ["H0031"]},
            "quote": "H0004 may not be billed with H0031 on the same day."}
    tk = LS.tokenize(text[52:], ())
    ctx = {"doc": doc, "source_version_id": sec["source_version_id"], "universe": set(), "extraction": {},
           "origin": "model", "span": (52, 104)}
    assert G.ground(prop, sec, tk, ctx).record.citation["page_start"] == 4


# ------------------------------------------------------------------ patterns
def test_definition_patterns_on_ampm_and_aac():
    doc, sec = section(AMPM_320V, "II. DEFINITIONS")
    props = PT.definition_proposals(sec)
    assert [p["subject"]["term"] for p in props] == ["BEHAVIORAL HEALTH RESIDENTIAL FACILITY STAFF ([BHRF] STAFF)",
                                                      "CO-OCCURRING", "SUPERVISION"]
    tk = LS.tokenize(sec["text"])
    ctx = {"doc": doc, "source_version_id": sec["source_version_id"], "universe": set(), "extraction": {},
           "origin": "pattern"}
    recs = [G.ground(p, sec, tk, ctx) for p in props]
    assert all(g.kept for g in recs), [g.reason for g in recs]
    assert {g.record.origin for g in recs} == {"pattern"}
    assert XR.wants_model(sec) == (False, "definitions read by pattern (3)")
    doc, sec = section(AAC, "R9-22-1201. Definitions")
    terms = {p["subject"]["term"]: p["params"]["definition"] for p in PT.definition_proposals(sec)}
    assert len(terms) >= 25 and "Clinical oversight" in terms and "Agency" in terms


def test_service_code_sets_and_cross_references_on_the_cbhsg():
    doc, sec = section(CBHSG, "Psychotherapy", "CPT Codes")
    rows = PT.service_code_sets(sec, doc.source_id, sec["source_version_id"])
    assert {r["value_set_id"] for r in rows} == {"SVC:A7:Outpatient Treatment Services > Psychotherapy"}
    assert {"90832", "90837", "90853"} <= {r["code"] for r in rows}
    assert all(r["code_system"] == "CPT" for r in rows)
    reg = registry.load()
    doc, sec = section(CBHSG, "Support Services", "Unskilled Respite Care")
    refs = {p["params"]["target"]: p for p in PT.cross_reference_proposals(sec, reg)}
    assert "A.A.C. R9-10-1025" in refs
    assert all(G.find_quote(sec["text"], p["quote"]) for p in refs.values())


# ------------------------------------------------------------------ the cache
def test_cache_keeps_answers_and_split_markers_across_runs(tmp_path):
    runs = tmp_path / "runs"
    first = K.AnswerCache(str(runs / "r1" / "answers.jsonl"))
    first.put("k1", NONE, {"run_id": "r1"})
    first.put_split("k2", {"run_id": "r1"})
    assert first.flush() == 2 and first.flush() == 0
    seeds = K.seed_files(str(runs))
    second = K.AnswerCache(str(runs / "r2" / "answers.jsonl"), seed_paths=seeds)
    assert second.get("k1") == NONE and second.lookup("k2")["split"] and second.lookup("k3") is None
    second.put("k3", NONE)
    second.flush()
    with open(runs / "r2" / "answers.jsonl", encoding="utf-8") as f:
        assert [json.loads(line)["key"] for line in f] == ["k3"]          # a run writes only what it added
    assert K.key("s", "u", "a") != K.key("s", "u", "b")


# ------------------------------------------------------------------ the stage
def _stage_store(tmp_path, rels):
    reg = registry.load()
    st = LocalStore(str(tmp_path / "store"))
    held = []
    for rel in rels:
        row = intake.accession(real_path(rel), reg, held, archive_dir=str(tmp_path / "archive"),
                               quarantine_dir=str(tmp_path / "quarantine"))
        held.append(row)
    st.write("source_versions", held)
    PR.run(st, reg, log=lambda m: None)
    return reg, st


RESPITE_ANSWER = json.dumps({"records": [
    {"kind": "pair_prohibited", "subject": {"codes": ["S5151"]},
     "params": {"partners": ["L1"], "partner_category": "any other per diem code", "scope": "unstated",
                "modifier_bypass": "none"}, "conditions": [], "exceptions": [],
     "quote": "Providers are prohibited from billing S5151 with [L1] or any other per diem code on the same day.",
     "effective": None, "end": None, "discretionary": False, "note": None},
    {"kind": "units_limit", "subject": {"category": "Respite services"},
     "params": {"max": 600, "per": "benefit_year", "scope": "member", "unit_basis": "hour"}, "conditions": [],
     "exceptions": [], "quote": "Respite services are limited to 600 hours per benefit year", "effective": None,
     "end": None, "discretionary": False, "note": None},
    {"kind": "not_covered", "subject": {"codes": ["S5151"]}, "params": {}, "conditions": [], "exceptions": [],
     "quote": "S5151 is never covered for anyone", "effective": None, "end": None, "discretionary": False,
     "note": None}], "none_reason": None})


def test_narrative_stage_end_to_end_with_a_replayed_model(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RUNS_DIR", str(tmp_path / "runs"))
    reg, st = _stage_store(tmp_path, [CH19])
    stage = str(tmp_path / "stage")
    state = {"fail": True, "calls": []}

    def model(system, user, budget):
        state["calls"].append(user)
        assert "BEHAVIORAL HEALTH NOTES" in system and "LISTS:" not in system
        if user.split("SECTION: ")[1].startswith("RESPITE CARE (UNSKILLED)"):
            return RESPITE_ANSWER
        if "SECTION: BEHAVIORAL HEALTH DAY PROGRAM" in user and "PART:" not in user:
            raise Truncated("cut off at 5000/5000 tokens")                # split in two, the halves answer
        if "SECTION: CRISIS SERVICES\n" in user and state["fail"]:
            raise RuntimeError("CUDA error: an illegal memory access was encountered")
        return NONE

    backend = ReplayBackend(fn=model, model="replay", reasoning="medium")
    summary = XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium", log=lambda m: None)
    assert summary["versions"] == 1 and summary["sections_to_model"] > 10
    with pytest.raises(ValueError, match="exported for"):
        XR.extract(stage, ReplayBackend(fn=model, model="other", reasoning="medium"), reg, log=lambda m: None)

    # run 1: one section fails, one splits, the respite section yields two records and one refusal
    out = XR.extract(stage, backend, reg, log=lambda m: None)
    assert out["outcomes"]["failed"] == 1 and out["generate"]["split"] == 1
    p1 = XR.persist(st, reg, out["run_dir"], log=lambda m: None)
    assert p1["partial"] == p1["versions"]
    recs = st.read("records")
    pair = next(r for r in recs if r["kind"] == "pair_prohibited")
    assert len(pair["params"]["partners"]) == 21 and pair["origin"] == "model"
    assert pair["execution_class"] in ("executable", "conditional")
    limit = next(r for r in recs if r["kind"] == "units_limit")
    assert limit["execution_class"] == "unresolved"                       # a category, not yet a code list
    props = st.read("proposals")
    refused = [p for p in props if not p["kept"]]
    assert [p["drop_reason"] for p in refused if p["origin"] == "model"] == ["quote not found in the section"]
    outcomes = st.read("extraction_outcomes")
    day = [o for o in outcomes if o["detail"].startswith("[1/1.")]
    assert len(day) == 2 and {o["outcome"] for o in day} == {"no_records"}
    assert XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium",
                     log=lambda m: None)["versions"] == 1                  # partial: still due

    # run 2: every answer but the failed piece comes from run 1's cache; the version is done
    state["fail"], n = False, len(state["calls"])
    plan = XR.plan_stage(stage, backend, reg)
    assert plan["to_model"] == 1 and plan["split_before"] == 1 and len(state["calls"]) == n
    out2 = XR.extract(stage, backend, reg, log=lambda m: None)
    assert len(state["calls"]) == n + 1 and out2["plan"]["to_model"] == 1 and out2["plan"]["split_before"] == 1
    p2 = XR.persist(st, reg, out2["run_dir"], log=lambda m: None)
    assert p2["partial"] == []
    assert XR.persist(st, reg, out2["run_dir"], log=lambda m: None)["records"] == p2["records"]   # idempotent
    assert len([p for p in st.read("proposals") if p["run_id"] == out2["run_id"]]) == \
        len([p for p in XR._read_jsonl(os.path.join(out2["run_dir"], "proposals.jsonl"))])
    assert len([r for r in st.read("records") if r["kind"] == "pair_prohibited"]) == 1
    assert XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium",
                     log=lambda m: None)["versions"] == 0                  # nothing due

    # a cache-only run re-grounds everything on a CPU without the model
    XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium", force=True, log=lambda m: None)
    n = len(state["calls"])
    out3 = XR.extract(stage, CacheOnly.like(backend), reg, log=lambda m: None)
    assert len(state["calls"]) == n and out3["model_calls"] == 0
    assert out3["records"] == out2["records"] and "needs_model" not in out3["outcomes"]

    # no answers at all: a time limit leaves every piece for the next run; no model: patterns only, still due
    out4 = XR.extract(stage, backend, reg, seeds=[], max_minutes=1e-9, log=lambda m: None)
    assert set(out4["outcomes"]) <= {"not_run", "skipped"} and out4["model_calls"] == 0
    out5 = XR.extract(stage, NoModel(), reg, seeds=[], log=lambda m: None)
    assert "patterns_only" in out5["outcomes"]
    p5 = XR.persist(st, reg, out5["run_dir"], log=lambda m: None)
    assert p5["partial"] == p5["kept"] == p5["versions"]                  # a complete run's records are kept
    assert len([r for r in st.read("records") if r["kind"] == "pair_prohibited"]) == 1


def test_a_dry_run_is_not_persisted(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RUNS_DIR", str(tmp_path / "runs"))
    reg, st = _stage_store(tmp_path, ["08_Additional_BH_References/ClaimsClues_Feb2024_BH_Per_Diem_Clarification.pdf"])
    stage = str(tmp_path / "stage")
    XR.export(st, reg, out_dir=stage, model="replay", reasoning="medium", log=lambda m: None)
    out = XR.extract(stage, ReplayBackend(fn=lambda s, u, b: NONE, model="replay"), reg, limit=1,
                     log=lambda m: None)
    assert out["dry_run"]
    with pytest.raises(ValueError, match="dry run"):
        XR.persist(st, reg, out["run_dir"], log=lambda m: None)


def test_batched_calls_retry_a_cut_off_answer_alone(tmp_path):
    reg = registry.load()
    sec = _outline(n_items=3, size=200)
    seen = []

    class Batch(ReplayBackend):
        def complete_many(self, items):
            seen.append(len(items))
            return [Truncated("cut off in a batch") if "A. The following" in u else NONE for _, u in items]

    def solo(system, user, budget):
        seen.append(("solo", budget))
        return NONE
    ex = XR.Extractor(Batch(fn=solo, model="replay", budget=5000), reg, batch=4, log=lambda m: None)
    secs = [sec, {**sec, "section_id": "S-two", "path_text": "TEST > OTHER", "path": ["TEST", "OTHER"]}]
    stats = ex.generate(secs)
    assert seen[0] == 2 and ("solo", int(5000 * config.RETRY_FACTOR)) in seen
    assert stats["answered"] == 2 and ex.calls == 4


def test_a_failed_batch_falls_back_to_one_at_a_time():
    reg = registry.load()
    sec = _outline(n_items=3, size=200)

    class Batch(ReplayBackend):
        def complete_many(self, items):
            raise RuntimeError("CUDA out of memory")
    ex = XR.Extractor(Batch(fn=lambda s, u, b: NONE, model="replay"), reg, batch=4, log=lambda m: None)
    stats = ex.generate([sec, {**sec, "section_id": "S-two", "path_text": "TEST > OTHER", "path": ["TEST", "OTHER"]}])
    assert stats["answered"] == 2 and "failed" not in stats


def test_pattern_and_model_finding_the_same_definition_merge():
    doc, sec = section(AAC, "R9-22-1201. Definitions")
    agency = next(p for p in PT.definition_proposals(sec) if p["subject"]["term"] == "Agency")
    answer = json.dumps({"records": [{"kind": "definition", "subject": {"term": "Agency"},
                                      "params": {"definition": "the agency, in other words"},
                                      "quote": agency["quote"]}], "none_reason": None})
    ex = XR.Extractor(ReplayBackend(fn=lambda s, u, b: answer, model="replay"), registry.load(), log=lambda m: None)
    ex.generate([sec])
    out = ex.ground_section(sec)
    rec = next(r for r in out["records"] if r.kind == "definition" and r.subject["term"] == "Agency")
    assert rec.origin == "pattern+model" and rec.params["definition"] != "the agency, in other words"
    model = [p for p in out["proposals"] if p["origin"] == "model"]
    assert model and all(p["record_id"] == rec.record_id and p["drop_reason"].startswith("merged") for p in model)
    assert len({r.record_id for r in out["records"]}) == len(out["records"])


# ------------------------------------------------------------------ the serving endpoint backend
class _Msg:
    def __init__(self, content):
        self.content = content


class _Resp:
    def __init__(self, content, finish="stop", tokens=100):
        self.choices = [type("C", (), {"message": _Msg(content), "finish_reason": finish})()]
        self.usage = type("U", (), {"completion_tokens": tokens, "prompt_tokens": 900})()


class _Client:
    def __init__(self, replies):
        self.replies, self.asked = list(replies), []
        self.chat = type("Chat", (), {"completions": self})()

    def create(self, **kw):
        self.asked.append(kw)
        r = self.replies.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


def test_serving_backend_reads_text_parts_retries_and_reports_cut_off_answers():
    from pie_kb.extract.backends import ServingBackend
    parts = [{"type": "reasoning", "summary": [{"text": "thinking"}]}, {"type": "text", "text": NONE}]
    client = _Client([_Resp(parts)])
    b = ServingBackend(client, "databricks-gpt-oss-120b", "medium", backoff_seconds=0)
    assert b.complete("sys", "user") == NONE
    assert client.asked[0]["reasoning_effort"] == "medium" and client.asked[0]["temperature"] == 0
    assert client.asked[0]["max_tokens"] == b.budget() and b.tag() == "serving|databricks-gpt-oss-120b|medium|5000"
    busy = type("RateLimit", (Exception,), {"status_code": 429})
    client = _Client([busy("slow down"), _Resp('{"records": [{"kind": "not_cov', "length"),
                      _Resp('{"records": [{"kind": "not_cov', "length")])
    b = ServingBackend(client, "databricks-gpt-oss-120b", "medium", backoff_seconds=0)
    with pytest.raises(Truncated):
        b.complete("sys", "user")
    assert [a["max_tokens"] for a in client.asked] == [5000, 5000, int(5000 * config.RETRY_FACTOR)]
    bad = type("BadRequest", (Exception,), {"status_code": 400})
    with pytest.raises(Exception, match="no such endpoint"):
        ServingBackend(_Client([bad("no such endpoint")]), "x", "low", backoff_seconds=0).complete("s", "u")


# ------------------------------------------------------------------ review fixes (2026-11-02)
def test_grounding_checks_every_coded_value_and_where_a_number_sits():
    doc = registry.load().get("A7")

    def g(text, prop):
        sec = synthetic(text)
        return ground_one(doc, sec, prop)
    assert "modifiers not in the quote" in g("H2014 shall not be billed with modifier GT.", {
        "kind": "modifier_rule", "subject": {"codes": ["H2014"]}, "params": {"mode": "not_allowed", "modifiers": ["HQ"]},
        "quote": "H2014 shall not be billed with modifier GT."}).reason
    pt = g("H2014 may not be billed by provider type 77.", {
        "kind": "provider_type_rule", "subject": {"codes": ["H2014"]},
        "params": {"mode": "not_allowed", "provider_types": ["B8"]},
        "quote": "H2014 may not be billed by provider type 77."}).record
    assert pt.status == "needs_review" and [f["code"] for f in pt.flags] == ["value_not_written"]
    assert "states a period (day), not year" in g("H2014 is limited to 4 units per day.", {
        "kind": "units_limit", "subject": {"codes": ["H2014"]}, "params": {"max": 4, "per": "year"},
        "quote": "H2014 is limited to 4 units per day."}).reason
    assert "numbers not in the quote" in g("H0004 counseling, per 15 minutes, is billed by the practitioner.", {
        "kind": "units_limit", "subject": {"codes": ["H0004"]}, "params": {"max": 4, "per": "day"},
        "quote": "H0004 counseling, per 15 minutes"}).reason                     # the 4 is inside H0004
    two = "H2014 is limited to 8 units per day. H0004 is limited to 4 units per day."
    for q in ("H2014 is limited to ... 4 units per day", two):
        assert "numbers not in the quote" in g(two, {"kind": "units_limit", "subject": {"codes": ["H2014"]},
                                                     "params": {"max": 4, "per": "day"}, "quote": q}).reason
    assert g(two, {"kind": "units_limit", "subject": {"codes": ["H0004"]}, "params": {"max": 4, "per": "day"},
                   "quote": two}).kept
    assert g("Codes H0031/H0032 require prior authorization for all members.", {
        "kind": "prior_auth_rule", "subject": {"codes": ["H0032"]}, "params": {"requirement": "required"},
        "quote": "Codes H0031/H0032 require prior authorization for all members."}).kept
    assert "condition values not in the section" in g("H2014 is limited to 4 units per day.", {
        "kind": "units_limit", "subject": {"codes": ["H2014"]}, "params": {"max": 4, "per": "day"},
        "conditions": [{"type": "place_of_service", "include": ["12"]}],
        "quote": "H2014 is limited to 4 units per day."}).reason


def test_an_answer_that_is_not_json_is_never_cached():
    reg = registry.load()
    sec = synthetic("H2014 is limited to 4 units per day for every member.")
    calls = []
    be = ReplayBackend(fn=lambda s, u, b: calls.append(1) or "I found no rules in this text.", model="replay")
    cache = K.AnswerCache()
    for _ in range(2):
        ex = XR.Extractor(be, reg, cache=cache, log=lambda m: None)
        ex.generate([sec])
        out = ex.ground_section(sec)
        assert [o["outcome"] for o in out["outcomes"]] == ["failed"]
    assert len(calls) == 2 and not cache.data                  # asked again by the second run, nothing cached
