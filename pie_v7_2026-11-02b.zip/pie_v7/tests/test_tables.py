"""Table specs on the files SB downloaded (B2, PA guidelines, telehealth, PEP-903, diagnosis lists, Exhibit 300-2A)
and on synthetic files built to the documented layouts (Same Day, daily limits, NCCI), plus the table stage."""
import csv
import zipfile
from functools import lru_cache

import openpyxl
import pytest

from conftest import real_path
from pie_kb import tables as T
from pie_kb.core import checkability as CK
from pie_kb.tables import readings as RD
from pie_kb.tables.base import Context
from pie_kb.sources import intake, registry

B2_OCT = "07_B2_Current/B2_Matrix.xlsx"
B2_AUG = "07_B2_History/20250830080724_76d2f258fcbc.xlsx"
PA = "06_Reference_XLSX/FFS_PA_Guidelines.xlsx"
TH = "06_Reference_XLSX/Telehealth_Code_Set.xlsx"
PEP = "06_Reference_XLSX/PEP-903.xlsx"
DX26 = "09_BH_Diagnosis_Lists/AHCCCS_2026_BH_SDOH_Diagnosis_List.pdf"
DX27 = "09_BH_Diagnosis_Lists/AHCCCS_2027_BH_Diagnosis_List.pdf"
EX = "02_AMPM/AMPM_Exhibit_300-2A.pdf"
SPINE = {"H0004", "H0018", "H0035", "H2014", "H2017", "S9480", "90791", "90832", "90837", "99494", "00104",
         "A0425", "82435", "T1016"}


@lru_cache(maxsize=None)
def read(rel: str, spine: frozenset | None = None):
    reg, rd = registry.load(), RD.load()
    path = real_path(rel)
    doc = intake.identify(path, reg).doc
    vi = intake.version_of(path, doc)
    ctx = Context(doc=doc, source_version_id=f"{doc.doc_id}@{vi.label}#test", readings=rd,
                  spine=set(spine) if spine is not None else None,
                  applicability={"delivery_systems": list(doc.delivery_systems), "basis": "registry"}, version=vi)
    return doc, vi, T.SPECS[doc.parser].extract(path, ctx)


def recs(out, kind=None, code=None):
    return [r for r in out.records if (kind is None or r.kind == kind)
            and (code is None or code in r.subject.get("codes", []))]


def test_readings_are_consistent():
    rd = RD.load()
    assert RD.validate(rd, T.SPECS) == []
    with open(RD.path(), newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert all(None not in r for r in rows), "a field with a comma is not quoted"
    assert all("—" not in r["reading"] for r in rows)
    assert rd["B2-PT"].bind("complete_codes") == "^H[02][0-9]{3}$"


# ------------------------------------------------------------------ intake recognises tables by layout
@pytest.mark.parametrize("rel,doc_id", [(B2_OCT, "A1"), (B2_AUG, "A1"), (PA, "A5"), (TH, "A4"), (PEP, "A25"),
                                        (DX27, "A6"), (EX, "A19")])
def test_table_files_are_recognised_by_content(rel, doc_id):
    reg = registry.load()
    ident = intake.identify(real_path(rel), reg)
    assert ident.doc is not None and ident.doc.doc_id == doc_id, ident


# ------------------------------------------------------------------ B2
def test_b2_both_layouts():
    _, v_oct, oct_ = read(B2_OCT)
    _, v_aug, aug = read(B2_AUG)
    assert (v_oct.date, v_aug.date) == ("2026-10-01", "2025-08-01")
    assert (oct_.stats["pairs"], aug.stats["pairs"]) == (3409, 3352)
    assert (oct_.stats["codes"], aug.stats["codes"]) == (363, 360)
    assert not oct_.warnings and not aug.warnings
    pt = recs(oct_, "provider_type_rule", "H0004")[0]
    assert pt.params["complete_list"] is True and "77" in pt.params["provider_types"]
    assert pt.params["role"] == "billing_or_rendering"
    assert CK.execution_class(pt)[0] == "executable"
    cpt = recs(oct_, "provider_type_rule", "90837")[0]
    assert cpt.params["complete_list"] is False and CK.execution_class(cpt)[0] == "knowledge"
    mod = [r for r in recs(oct_, "modifier_rule", "H0004") if r.conditions[0]["include"] == ["77"]][0]
    assert "HQ" in mod.params["modifiers"] and mod.citation["locator"].startswith("sheet 'October 2026' row ")
    pos = recs(oct_, "pos_rule", "H0004")[0]
    assert CK.execution_class(pos)[0] == "conditional"                       # place of service not measured yet
    # the same meaning in two versions keeps its key; the statement instance differs
    a = {r.record_key for r in recs(aug, "provider_type_rule", "H0004")}
    b = {r.record_key for r in recs(oct_, "provider_type_rule", "H0004")}
    same = recs(aug, "provider_type_rule", "H0004")[0].params == pt.params
    assert (a == b) == same


# ------------------------------------------------------------------ PA guidelines
def test_pa_guidelines():
    _, vi, out = read(PA, frozenset(SPINE))
    assert vi.date == "2026-10-10"
    assert out.stats["codes"] == 14757 and out.stats["notes"] == 3
    assert set(out.stats["local_codes"]) == {"LL321", "W3031", "W3032", "W3033", "W3034"}
    assert len(out.rows) == 14760                                             # kept whole
    h18 = recs(out, code="H0018")[0]
    assert h18.params == {"requirement": "required", "authorization": "prior", "programs": "all"}
    assert (h18.effective_start, h18.effective_end, h18.window_basis) == ("2019-06-01", None, "row")
    assert recs(out, code="H2017")[0].params["programs"] == "ltc"
    assert recs(out, code="H0004")[0].params["requirement"] == "not_required"
    assert {c for r in out.records for c in r.subject["codes"]} <= SPINE      # records for spine codes only


# ------------------------------------------------------------------ telehealth
def test_telehealth_code_set():
    _, vi, out = read(TH, frozenset(SPINE))
    assert (vi.date, vi.evidence) == ("2026-06-01", "EFFECTIVE DATE: 06/01/2026")
    assert out.stats["codes"] == 292
    r = recs(out, code="90832")[0]
    assert r.params["modifiers"] == ["FQ", "GT"]
    assert "02" not in r.params["pos"] and "10" not in r.params["pos"]       # TH-POS: the ** column
    row = next(x for x in out.rows if x["row_key"] == "90832")
    assert "02" in row["data"]["pos_other_column"]                            # the other column is kept, not used
    marked = recs(out, code="99494")[0]
    assert marked.flags and "GT*" in marked.flags[0]["text"]
    paths = {s["path_text"]: s for s in out.sections}
    assert "AHCCCS will not be utilizing POS 02 and POS 10 for telehealth" in paths["Guidelines"]["text"]
    assert "**POS 02 and 10 are only allowed for TPL members." in paths["2026 Final > Footnotes"]["text"]


# ------------------------------------------------------------------ PEP-903
def test_pep903_provider_types():
    _, vi, out = read(PEP)
    assert vi.basis == "file_metadata" and vi.date == "2026-10-20"
    pts = {v["code"]: v for v in out.value_sets if v["value_set_id"] == "PROVIDER_TYPES"}
    assert len(pts) == 105 and pts["01"]["description"] == "Group Biller"
    assert len(pts["39"]["attributes"]["variants"]) == 2                     # listed once per enrollment type
    assert pts["AB"]["attributes"]["risk_level"] == "High"
    assert sum(1 for v in out.value_sets if v["value_set_id"] == "ACRONYMS") == 44
    assert not out.records


# ------------------------------------------------------------------ diagnosis lists
def test_dx_lists():
    _, v27, d27 = read(DX27)
    assert (v27.date, v27.period_end) == ("2026-10-01", "2027-09-30")
    assert d27.stats["by_subset"] == {"BH": 974, "Z55-Z65": 115, "Z71-Z91": 17} and not d27.warnings
    f0150 = next(v for v in d27.value_sets if v["code"] == "F0150")
    assert f0150["description"].startswith("Vascular dementia, unspecified severity, without behavioral disturbance")
    assert f0150["value_set_id"] == "A6" and f0150["effective_end"] == "2027-09-30"
    _, v26, d26 = read(DX26)
    assert d26.stats["codes"] == d26.stats["codes_in_text"] == 1100
    z653 = next(v for v in d26.value_sets if v["code"] == "Z653")             # outside the ruled grid on p.26
    assert z653["value_set_id"] == "A6:Z55-Z65" and z653["attributes"]["read_from"] == "line"


# ------------------------------------------------------------------ Exhibit 300-2A
def test_exhibit_300_2a():
    _, vi, out = read(EX)
    assert vi.date == "2023-07-20" and out.stats["service_rows"] == 39
    rows = {r["row_key"]: r["data"] for r in out.rows}
    mst = rows["Other Professional: Multisystemic Therapy for Juveniles"]["cells"]
    assert mst["ACUTE CARE XIX <21"] == "X" and mst["ACUTE CARE XIX >21"] == "NA"
    th = rows["Other Professional: Mental Health Services (formerly Traditional Healing)"]
    assert th["cell_notes"]["ALTCS E/PD <21"] == ["**", "i"]
    assert set(rows["Mental Health Services NOS (Room and Board)"]["cells"]) == set(mst)   # page 2 labels aligned
    assert rows["Unskilled Respite Care"]["notes"] == ["ii"]
    nc = [r for r in out.records if r.kind == "not_covered"]
    assert len(nc) == 9 and all(CK.execution_class(r)[0] == "unresolved" for r in nc)
    lim = out.sections[0]
    assert lim["path_text"] == "EXHIBIT 300-2A > LIMITATIONS"
    assert "ii No more than 600 hours of respite care per contract year" in lim["text"]


# ------------------------------------------------------------------ synthetic: Same Day, daily limits, NCCI
def _ctx(parser, spine=None):
    reg = registry.load()
    doc = reg.by_parser(parser)[0]
    return Context(doc=doc, source_version_id=f"{doc.doc_id}@test", readings=RD.load(), spine=spine,
                   applicability={"delivery_systems": ["FFS", "MC"], "basis": "registry"})


def _book(path, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    for r in rows:
        ws.append(list(r))
    wb.save(path)
    return str(path)


def test_same_day_disallow(tmp_path):
    legend = ("D = Disallowed\nA = Allowable\nA* = Allowable on same day for the member, cannot be provided/billed by "
              "the same provider (service site or residential placement)")
    notes = ("1. Codes are listed by row. 2. Exceptions to limitations on service frequency or duration may be "
             "approved based on medical necessity. Providers shall submit requests for exceptions.")
    p = _book(tmp_path / "sameday.xlsx", [
        ["AHCCCS Same Day Disallow Table"], ["Updated: 9/14/2026"], [legend], [notes],
        ["Procedure", "Description", "Unit", "H0018", "H0035", "S9480"],
        [None, None, None, "BH short-term residential", "Partial hospitalization", "IOP"],
        [None, None, None, "Per diem", "Per diem", "Per diem"],
        ["H0004", "BH counseling", "15 min", "D", "A*", "A"],
        ["H0018", "BH short-term residential", "Per diem", "D", "D", "A"],
        ["H0035", "Partial hospitalization", "Per diem", "D", "D", "A*"]])
    assert T.detect_xlsx(p) == ["same_day"]
    assert T.version_of_file(p, "same_day").date == "2026-09-14"
    out = T.SPECS["same_day"].extract(p, _ctx("same_day", {"H0004", "H0018", "H0035"}))
    got = {(r.subject["codes"][0], r.params["partners"][0]): r for r in out.records}
    assert set(got) == {("H0004", "H0018"), ("H0004", "H0035"), ("H0018", "H0035"), ("H0035", "H0018"),
                        ("H0035", "S9480")}                                   # A and the diagonal build nothing
    assert got[("H0004", "H0018")].params["scope"] == "member_day"
    assert got[("H0004", "H0035")].params["scope"] == "member_provider_day"
    assert got[("H0018", "H0035")].params["both_ways"] is True
    assert got[("H0004", "H0018")].params["both_ways"] is False
    r = got[("H0004", "H0018")]
    assert r.exceptions and CK.execution_class(r)[0] == "conditional"        # note 2: a person checks exceptions
    assert out.stats["indicators"] == {"D": 5, "A*": 2, "A": 2}


def test_daily_limits(tmp_path):
    p = _book(tmp_path / "daily.xlsx", [
        ["HCPCS/CPT Procedures Daily Limits"], ["As of 9/14/26"],
        ["Procedure Description", "Procedure Maximum Occurrence", "Limit 1", "Frequency 1 Value", "Frequency 1 Cd",
         "Limit 2", "Frequency 2 Value", "Frequency 2 Cd"],
        ["H0004 - BH COUNSELING AND THERAPY", "000048"],
        ["00104 - ANESTHESIA FOR ELECTROSHOCK", "000001"],
        ["A0425 - GROUND MILEAGE", "000999"],
        ["82435 - ASSAY OF BLOOD CHLORIDE", "000001", 4, 1, "D"],
        ["H2014 - SKILLS TRAINING AND DEVELOPMENT", "000032", 100, 1, "Y"]])
    assert T.detect_xlsx(p) == ["daily_limits"]
    out = T.SPECS["daily_limits"].extract(p, _ctx("daily_limits", SPINE))
    day = {r.subject["codes"][0]: r for r in out.records if r.params["per"] == "day"}
    assert day["H0004"].params == {"max": 48, "per": "day", "scope": "member_provider", "combined": False,
                                   "unit_basis": "unit"}
    assert CK.execution_class(day["H0004"])[0] == "executable"
    for code in ("00104", "A0425", "82435"):                                 # DL-EXCL: recorded, never executable
        assert CK.execution_class(day[code])[0] == "unresolved", code
    year = [r for r in out.records if r.params["per"] == "year"]
    assert len(year) == 1 and CK.execution_class(year[0])[0] == "unresolved"  # DL-PERIOD undecided
    assert out.stats["blocked"] == {"anesthesia_time_units": 1, "placeholder_maximum": 1, "two_daily_limits": 1}


def _zip(path, members):
    with zipfile.ZipFile(path, "w") as z:
        for name, data in members.items():
            z.writestr(name, data)
    return str(path)


def test_ncci_ptp_and_mue(tmp_path):
    ptp_txt = "\n".join([
        "Medicaid NCCI PTP Edits - Practitioner Services", "CPT codes and descriptions copyright AMA",
        "Column 1\tColumn 2\t* = In existence prior to 1996\tEffective Date\tDeletion Date *=no data\t"
        "Modifier 0=not allowed 1=allowed 9=not applicable\tPTP Edit Rationale",
        "90791\t90832\t\t20100101\t*\t0\tMutually exclusive",
        "90792\t90832\t\t20100101\t*\t0\tMutually exclusive",
        "90837\tH0004\t\t20150101\t\t1\tMisuse of column two code",
        "99213\t90791\t\t20130101\t20200101\t1\tStandards of practice",
        "12001\t12002\t\t20100101\t*\t0\tnot BH",
        "90785\t90832\t\t20100101\t*\t9\tno edit"])
    p = _zip(tmp_path / "medicaid-ncci-2026q4-ptp-edits-practitioner-services.zip", {"ptp_practitioner.txt": ptp_txt})
    assert T.detect_zip(p) == ["ncci_ptp"]
    v = T.version_of_file(p, "ncci_ptp")
    assert (v.date, v.label) == ("2026-10-01", "2026q4")
    out = T.SPECS["ncci_ptp"].extract(p, _ctx("ncci_ptp", SPINE))
    by = {(r.subject["codes"][0], r.params["modifier_bypass"], r.effective_start): r for r in out.records}
    assert by[("90832", "none", "2010-01-01")].params["partners"] == ["90791", "90792"]   # one record per group
    assert by[("H0004", "allowed", "2015-01-01")].params["scope"] == "member_provider_day"
    old = by[("90791", "allowed", "2013-01-01")]
    assert old.effective_end == "2019-12-31"                                  # deleted 2020-01-01
    assert out.stats["edits"] == 6 and out.stats["edits_kept"] == 5           # 12002 is not in the spine
    assert all(r.conditions == [{"type": "claim_form", "form": "CMS-1500"}] for r in out.records)
    book = tmp_path / "mue.xlsx"
    _book(book, [["Medicaid NCCI MUE Edits - Practitioner Services"],
                 ["HCPCS/CPT Code", "Practitioner Services MUE Values", "MUE Rationale"],
                 ["90832", 1, "Code descriptor"], ["H0004", 24, "Clinical"], ["12002", 1, "x"]])
    m = _zip(tmp_path / "medicaid-ncci-q4-2026-mue-edits-practitioner-services.zip",
             {"mue.xlsx": open(book, "rb").read()})
    assert T.detect_zip(m) == ["ncci_mue"]
    mo = T.SPECS["ncci_mue"].extract(m, _ctx("ncci_mue", SPINE))
    h4 = recs(mo, code="H0004")[0]
    assert h4.params == {"max": 24, "per": "line", "scope": "member_provider", "combined": False, "unit_basis": "unit"}
    assert len(mo.records) == 2


# ------------------------------------------------------------------ the table stage
def test_table_stage_reads_once_and_keeps_narrative_records(tmp_path):
    from pie_kb.core.record import Record, finalize, store_row
    from pie_kb.io.store import LocalStore
    from pie_kb.tables import run as TR
    reg = registry.load()
    st = LocalStore(str(tmp_path / "store"))
    held = []
    for rel in (B2_OCT, PA, TH):
        held.append(intake.accession(real_path(rel), reg, held, archive_dir=str(tmp_path / "a"),
                                     quarantine_dir=str(tmp_path / "q")))
    st.write("source_versions", held)
    th_svid = held[2]["source_version_id"]
    narrative = finalize(Record(kind="obligation", subject={"category": "telehealth"}, params={"duty": "x"},
                                citation={"source_id": "A4", "document_key": "main", "source_version_id": th_svid,
                                          "quote": "Services provided via telehealth must be coded"}, origin="model"))
    st.write("records", [store_row(narrative)])
    logs = []
    out = TR.run(st, reg, log=logs.append)
    assert len(out["read"]) == 3 and not out["failed"]
    assert out["spine"]["b2"] == 363
    rows = st.read("records")
    assert any(r["origin"] == "model" for r in rows)                          # not replaced by the table stage
    pa = [r for r in rows if r["source_id"] == "A5"]
    assert pa and {c for r in pa for c in r["subject"]["codes"]} <= {
        (x["data"]["code"]) for x in st.read("table_rows") if x["spec"] == "b2"}
    assert {r["reading_id"] for r in st.read("readings")} >= {"B2-PT", "PA-CODES", "TH-POS"}
    assert TR.run(st, reg, log=logs.append)["read"] == []                     # nothing due the second time
