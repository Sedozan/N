"""The step functions the notebooks call: intake that can be run on the same inbox again and again."""
import os
import shutil

from conftest import real_path
from pie_kb import stages
from pie_kb.io.store import LocalStore
from pie_kb.sources import registry

CH19 = "03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf"
FAQ = "08_Additional_BH_References/CBHSG_FAQ.pdf"


def test_intake_files_once_and_reports_a_copy_once(tmp_path, monkeypatch):
    from pie_kb import config
    inbox = tmp_path / "inbox"
    for name in ("ARCHIVE_DIR", "QUARANTINE_DIR"):
        monkeypatch.setattr(config, name, str(tmp_path / name.lower()))
    reg = registry.load()
    st = LocalStore(str(tmp_path / "store"))
    os.makedirs(inbox / "a")
    shutil.copyfile(real_path(CH19), inbox / "a" / "ch19.pdf")
    shutil.copyfile(real_path(FAQ), inbox / "a" / "faq.pdf")
    (inbox / "a" / "notes.txt").write_text("not a policy")
    first = stages.intake(st, reg, inbox_dir=str(inbox), log=lambda m: None)
    assert len(first["active"]) == 2 and len(first["quarantined"]) == 1
    again = stages.intake(st, reg, inbox_dir=str(inbox), log=lambda m: None)
    assert again == {"active": [], "duplicate": [], "quarantined": []}
    shutil.copyfile(real_path(CH19), inbox / "a" / "chapter19_copy.pdf")
    third = stages.intake(st, reg, inbox_dir=str(inbox), log=lambda m: None)
    assert len(third["duplicate"]) == 1 and not third["active"]
    assert stages.intake(st, reg, inbox_dir=str(inbox), log=lambda m: None)["duplicate"] == []
    (inbox / "a" / "notes.txt").unlink()
    rows = st.read("source_versions")
    assert len(rows) == 4 and sorted(r["status"] for r in rows) == ["active", "active", "duplicate", "quarantined"]
    status = stages.status(st, reg)
    assert {r["source_id"] for r in status} == {"A8", "A28"} and all(r["parse"] == "" for r in status)


def test_an_undatable_table_is_quarantined_and_the_rest_is_filed(tmp_path, monkeypatch):
    import openpyxl
    from pie_kb import config
    for name in ("ARCHIVE_DIR", "QUARANTINE_DIR"):
        monkeypatch.setattr(config, name, str(tmp_path / name.lower()))
    reg = registry.load()
    st = LocalStore(str(tmp_path / "store"))
    inbox = tmp_path / "inbox"
    os.makedirs(inbox)
    shutil.copyfile(real_path(CH19), inbox / "ch19.pdf")
    wb = openpyxl.load_workbook(real_path("07_B2_Current/B2_Matrix.xlsx"))
    ws = wb.worksheets[0]
    for row in ws.iter_rows(max_row=12):
        for c in row:
            if isinstance(c.value, str) and "as of" in c.value.lower():
                c.value = "Matrix"
    wb.save(inbox / "b2_no_date.xlsx")
    out = stages.intake(st, reg, inbox_dir=str(inbox), log=lambda m: None)
    assert len(out["active"]) == 1 and len(out["quarantined"]) == 1
    q = next(r for r in st.read("source_versions") if r["status"] == "quarantined")
    assert "could not be dated" in q["notes"]


def test_local_store_keeps_long_columns_as_integers(tmp_path):
    st = LocalStore(str(tmp_path))
    st.write("sections", [{"section_id": "a", "page_start": 3}, {"section_id": "b", "page_start": None}])
    assert [r["page_start"] for r in st.read("sections")] == [3, None]
