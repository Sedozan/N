"""Review and build: decisions bound to content, readings, carry-forward across versions, windows, service categories,
conflicts with precedence suggestions, version diffs, and the review workbook out and back."""
import pytest

from pie_kb.core.hashing import short_hash, text_hash
from pie_kb.core.record import Record, finalize, store_row
from pie_kb.extract import ground as G
from pie_kb.extract import lists as LS
from pie_kb.io.store import LocalStore
from pie_kb.kb import build as KB
from pie_kb.kb import conflicts as CF
from pie_kb.kb import resolve as RS
from pie_kb.review import decisions as DC
from pie_kb.review import workbook as WB
from pie_kb.sources import registry
from pie_kb.tables import readings as RD

REG = registry.load()
V1, V2 = "A7@2025-10-01#11111111", "A7@2026-10-01#22222222"
AAC, CH19 = "A20@2025-12-31#33333333", "A8@2026-09-15#44444444"
RESPITE = "Support Services > Unskilled Respite Care > Billing Limitations"


def version(svid: str, day: str) -> dict:
    sid, rest = svid.split("@")
    return {"source_version_id": svid, "source_id": sid, "document_key": "main", "version_date": day,
            "version_label": rest.split("#")[0], "version_basis": "stated", "version_evidence": "test",
            "sha256": rest.split("#")[1] * 8, "status": "active", "first_seen_at": "2026-11-01T00:00:00+00:00",
            "file_kind": "pdf"}


def section(svid: str, path: str, text: str, page: int = 3) -> dict:
    sid = svid.split("@")[0]
    return {"section_id": "S-" + short_hash(svid, path), "section_key": "SK-" + short_hash(sid, path),
            "source_version_id": svid, "source_id": sid, "document_key": "main", "path": path.split(" > "),
            "path_text": path, "heading": path.split(" > ")[-1], "level": 2, "page_start": page, "page_end": page,
            "text": text, "text_hash": text_hash(text), "n_chars": len(text),
            "blocks": [{"kind": "para", "page": page, "item": "", "start": 0, "end": len(text)}],
            "codes": {"procedure": []}, "signal": 1, "role": "body", "applicability": {"delivery_systems": ["FFS"]},
            "defined_terms": [], "stated_dates": [], "ordinal": 1}


def record(sec: dict, prop: dict, origin: str = "model") -> Record:
    doc = REG.get(sec["source_id"], "main")
    g = G.ground(prop, sec, LS.tokenize(sec["text"], set()), {"doc": doc, "source_version_id": sec["source_version_id"],
                                                                "universe": set(), "extraction": {}, "origin": origin})
    assert g.kept, g.reason
    return g.record


def limit(code_or_cat, n, quote, per="day"):
    subject = {"codes": [code_or_cat]} if code_or_cat[0].isupper() and code_or_cat[1:].isdigit() else \
        {"category": code_or_cat}
    return {"kind": "units_limit", "subject": subject, "params": {"max": n, "per": per, "scope": "member"},
            "quote": quote}


def b2_record() -> Record:
    return finalize(Record(kind="provider_type_rule", subject={"codes": ["H0004"]},
                           params={"mode": "allowed", "provider_types": ["77"], "complete_list": True,
                                   "role": "billing_or_rendering"},
                           citation={"source_id": "A1", "document_key": "main",
                                     "source_version_id": "A1@2026-10-01#55555555", "locator": "sheet 'B2' rows 7-8",
                                     "quote": "H0004 | provider types: 77", "row_key": "H0004"},
                           applicability={"delivery_systems": ["FFS", "MC"]}, origin="table", authority_level=5,
                           extraction={"spec": "b2", "readings": ["B2-PT", "B2-VER"]}))


@pytest.fixture()
def world(tmp_path):
    """Two CBHSG versions, the A.A.C. and Ch19, with records whose decisions the tests make."""
    st = LocalStore(str(tmp_path / "store"))
    secs = {
        "respite1": section(V1, RESPITE, "Respite services are limited to 600 hours per benefit year per member."),
        "respite2": section(V2, RESPITE, "Respite services are limited to 600 hours per benefit year per member."),
        "couns1": section(V1, "Counseling > Billing Limitations", "H0004 is limited to 24 units per day per member."),
        "couns2": section(V2, "Counseling > Billing Limitations", "H0004 is limited to 24 units per day per member. "
                                                                  "Documentation is required for every session."),
        "pa2": section(V2, "Crisis > Billing Limitations", "Prior authorization is required for H2011 crisis care."),
        "aac": section(AAC, "R9-22-1205", "H0004 is limited to 16 units per day per member under this rule."),
        "ch19": section(CH19, "CRISIS SERVICES", "Prior authorization is not required for H2011 in a crisis."),
    }
    hours = {"kind": "units_limit", "subject": {"category": "Respite services"},
             "params": {"max": 600, "per": "benefit_year", "scope": "member", "unit_basis": "hour"},
             "quote": "Respite services are limited to 600 hours per benefit year per member."}
    recs = {
        "respite1": record(secs["respite1"], hours), "respite2": record(secs["respite2"], hours),
        "couns1": record(secs["couns1"], limit("H0004", 24, "H0004 is limited to 24 units per day per member.")),
        "couns2": record(secs["couns2"], limit("H0004", 24, "H0004 is limited to 24 units per day per member.")),
        "pa2": record(secs["pa2"], {"kind": "prior_auth_rule", "subject": {"codes": ["H2011"]},
                                    "params": {"requirement": "required"},
                                    "quote": "Prior authorization is required for H2011 crisis care."}),
        "aac": record(secs["aac"], limit("H0004", 16, "H0004 is limited to 16 units per day per member under this "
                                                      "rule.")),
        "ch19": record(secs["ch19"], {"kind": "prior_auth_rule", "subject": {"codes": ["H2011"]},
                                      "params": {"requirement": "not_required"},
                                      "quote": "Prior authorization is not required for H2011 in a crisis."}),
        "b2": b2_record(),
    }
    st.write("source_versions", [version(V1, "2025-10-01"), version(V2, "2026-10-01"), version(AAC, "2025-12-31"),
                                 version(CH19, "2026-09-15"), version("A1@2026-10-01#55555555", "2026-10-01")])
    st.write("sections", list(secs.values()))
    st.write("records", [store_row(r) for r in recs.values()])
    vs = [{"value_set_id": "SVC:A7:Support Services > Unskilled Respite Care", "source_version_id": v, "code": c,
           "code_system": "HCPCS", "description": "", "attributes": {}, "origin": "pattern"}
          for v in (V1, V2) for c in ("S5150", "S5151")]
    st.write("value_sets", vs)
    return st, secs, recs


def decide(st, subject_type, sid, decision, sha, who="Reviewer One", **kw):
    st.write("review_log", [DC.row(subject_type, sid, decision, who, sha, **kw)], mode="append")


def current(st) -> dict:
    return {c["record_id"]: c for c in st.read("records_current")}


# ------------------------------------------------------------------ status, windows, carry-forward
def test_decisions_bind_to_content_and_carry_forward_only_over_unchanged_text(world):
    st, secs, recs = world
    decide(st, "record", recs["respite1"].record_id, "approve", recs["respite1"].content_sha)
    decide(st, "record", recs["couns1"].record_id, "approve", recs["couns1"].content_sha)
    decide(st, "record", recs["aac"].record_id, "approve", "not-the-content")              # stale: never applied
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["respite1"].record_id]["status"] == "approved"
    r2 = cur[recs["respite2"].record_id]
    assert r2["status"] == "approved" and r2["status_basis"] == f"carried forward from {recs['respite1'].record_id}"
    assert any(f["code"] == "carried_forward" for f in r2["flags"])
    c2 = cur[recs["couns2"].record_id]
    assert c2["status"] == "needs_review" and "its section changed" in c2["status_basis"]
    a = cur[recs["aac"].record_id]
    assert a["status"] == "proposed" and any(f["code"] == "stale_decision" for f in a["flags"])


def test_windows_follow_versions_and_old_approvals_keep_their_window(world):
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    old, new = cur[recs["respite1"].record_id], cur[recs["respite2"].record_id]
    assert (old["effective_start"], old["effective_end"]) == ("2025-10-01", "2026-09-30")
    assert (new["effective_start"], new["effective_end"]) == ("2026-10-01", None)
    assert not old["in_force_today"] and new["in_force_today"]


def test_table_records_follow_their_readings(world):
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    b2 = current(st)[recs["b2"].record_id]
    assert b2["status"] == "proposed" and "B2-PT" in b2["status_basis"]
    rd = RD.load()
    for rid in ("B2-PT", "B2-VER"):
        decide(st, "reading", rid, "sign", DC.reading_sha(rd[rid]))
    KB.build(st, REG, log=lambda m: None)
    b2 = current(st)[recs["b2"].record_id]
    assert b2["status"] == "approved" and b2["execution_class"] == "executable" and b2["executable_now"]
    decide(st, "reading", "B2-PT", "reject", DC.reading_sha(rd["B2-PT"]), who="Reviewer Two")
    KB.build(st, REG, log=lambda m: None)
    assert current(st)[recs["b2"].record_id]["status"] == "rejected"


def test_a_service_named_without_codes_resolves_to_its_section_code_set(world):
    st, _, recs = world
    KB.build(st, REG, log=lambda m: None)
    r = current(st)[recs["respite2"].record_id]
    assert r["resolved_codes"] == ["S5150", "S5151"] and r["resolution"].startswith("section: SVC:A7:")
    assert r["execution_class"] in ("executable", "conditional")
    key, sha = DC.category_key("A7", "Respite services"), DC.category_sha("A7", "Respite services")
    decide(st, "category", key, "none", sha)
    KB.build(st, REG, log=lambda m: None)
    r = current(st)[recs["respite2"].record_id]
    assert r["resolved_codes"] == [] and r["execution_class"] == "unresolved"
    assert RS.suggestions("unskilled respite", st.read("value_sets"))[0][0] == \
        "SVC:A7:Support Services > Unskilled Respite Care"


# ------------------------------------------------------------------ conflicts
def test_conflicts_are_listed_with_a_suggestion_and_hold_records_until_signed(world):
    st, _, recs = world
    for k in ("couns2", "aac", "pa2", "ch19"):
        decide(st, "record", recs[k].record_id, "approve", recs[k].content_sha)
    KB.build(st, REG, log=lambda m: None)
    rows = st.read("conflicts")
    by = {frozenset((c["record_a"], c["record_b"])): c for c in rows}
    lim = by[frozenset((recs["couns2"].record_id, recs["aac"].record_id))]
    assert lim["relationship"] == "different_limit" and lim["suggested_prevailing"] == recs["aac"].record_id
    assert lim["basis"].startswith("higher authority") and lim["status"] == "open"
    pa = by[frozenset((recs["pa2"].record_id, recs["ch19"].record_id))]
    assert pa["relationship"] == "contradiction" and pa["suggested_prevailing"] == recs["ch19"].record_id
    assert frozenset((recs["couns1"].record_id, recs["aac"].record_id)) in by           # windows overlap in 2026
    cur = current(st)
    assert not cur[recs["aac"].record_id]["executable_now"]
    assert any("open conflict" in w for w in cur[recs["aac"].record_id]["execution_reasons"])
    a, b = (recs["aac"], recs["couns2"]) if lim["record_a"] == recs["aac"].record_id else (recs["couns2"], recs["aac"])
    decide(st, "conflict", lim["conflict_id"], "a" if a is recs["aac"] else "b",
           DC.conflict_sha(a.content_sha, b.content_sha))
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["aac"].record_id]["executable_now"] or cur[recs["aac"].record_id]["conflicts"]
    assert any("does not prevail" in w for w in cur[recs["couns2"].record_id]["execution_reasons"])


def test_relation_needs_the_same_conditions_and_period(world):
    _, secs, recs = world
    a, b = recs["couns2"], recs["aac"]
    assert CF.relation(a, b)[0] == "different_limit"
    wsec = section(AAC, "R9-22-1206", "H0004 is limited to 16 units per week per member under this rule.")
    weekly = record(wsec, limit("H0004", 16, "H0004 is limited to 16 units per week per member under this rule.",
                                per="week"))
    assert CF.relation(a, weekly) is None


# ------------------------------------------------------------------ diffs
def test_diffs_list_added_removed_and_changed(world):
    st, secs, recs = world
    changed = record(secs["couns2"], {"kind": "documentation_required", "subject": {"category": "counseling"},
                                      "params": {"requirement": "documentation for every session"},
                                      "quote": "Documentation is required for every session."})
    st.write("records", [store_row(changed)], mode="append")
    KB.build(st, REG, log=lambda m: None)
    d = [x for x in st.read("record_diffs") if x["source_id"] == "A7"]
    assert {x["change"] for x in d} == {"added"} and d[0]["record_id_to"] == changed.record_id


# ------------------------------------------------------------------ the workbook
def _fill(path, sheet, match, values):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = wb[sheet]
    head = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        cells = dict(zip(head, row))
        if all(str(cells[k].value or "").startswith(v) for k, v in match.items()):
            for k, v in values.items():
                cells[k].value = v
            wb.save(path)
            return
    raise AssertionError(f"no row in {sheet} matching {match}")


def _append_new(path, values):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = wb["New records"]
    head = [c.value for c in ws[1]]
    ws.append([values.get(h, "") for h in head])
    wb.save(path)


def test_workbook_round_trip(world, tmp_path):
    st, secs, recs = world
    KB.build(st, REG, log=lambda m: None)
    path = str(tmp_path / "review.xlsx")
    out = WB.export(st, REG, path)
    assert out["Records"] == 7 and out["Readings"] == len(RD.load()) and out["Precedence"] == 3
    _fill(path, "Records", {"record_id": recs["aac"].record_id}, {"Decision": "Approve", "Reviewer": "Ann"})
    _fill(path, "Records", {"record_id": recs["couns2"].record_id},
          {"Decision": "Fix", "Reviewer": "Ann", "Fix: params": '{"max": 24, "per": "day", "scope": "member", '
                                                               '"unit_basis": "unit"}'})
    _fill(path, "Records", {"record_id": recs["pa2"].record_id},
          {"Decision": "Fix", "Reviewer": "Ann", "Fix: params": '{"requirement": "not_required"}'})  # contradicts text
    _fill(path, "Readings", {"reading_id": "B2-PT"}, {"Decision": "Sign", "Reviewer": "Ann"})
    _fill(path, "Precedence", {"precedence_id": "P1"}, {"Decision": "Sign", "Reviewer": "Ann"})
    _append_new(path, {"Source version id": V2, "Section id": secs["pa2"]["section_id"], "Kind": "obligation",
                       "Subject": '{"codes": ["H2011"]}', "Params": '{"duty": "obtain prior authorization"}',
                       "Quote": "Prior authorization is required for H2011 crisis care.", "Author": "Ann"})
    _append_new(path, {"Source version id": V2, "Section id": secs["pa2"]["section_id"], "Kind": "obligation",
                       "Subject": '{"codes": ["H2011"]}', "Params": '{"duty": "x"}', "Quote": "Not in the text at all",
                       "Author": "Ann"})
    res = WB.ingest(st, REG, path, log=lambda m: None)
    assert res["decisions"] == 5 and res["new_records"] == 3, res["errors"]
    assert len(res["errors"]) == 1 and "quote not found" in res["errors"][0]
    assert WB.ingest(st, REG, path, log=lambda m: None)["decisions"] == 0                  # idempotent
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    assert cur[recs["aac"].record_id]["status"] == "approved"
    assert cur[recs["couns2"].record_id]["status"] == "superseded"
    assert cur[recs["pa2"].record_id]["status"] == "superseded"
    sme = [c for c in cur.values() if c["origin"] == "sme"]
    assert len(sme) == 3 and {c["status"] for c in sme} == {"needs_review"}
    fixed = next(c for c in sme if c["kind"] == "units_limit")
    assert fixed["params"]["unit_basis"] == "unit" and fixed["review"]["author"] == "Ann"
    flipped = next(c for c in sme if c["kind"] == "prior_auth_rule")       # a fix against the words is flagged
    assert flipped["params"]["requirement"] == "not_required" and any(f["code"] == "negation" for f in flipped["flags"])

    # the author cannot approve her own record; someone else can; a changed record makes its row stale
    path2 = str(tmp_path / "review2.xlsx")
    WB.export(st, REG, path2)
    _fill(path2, "Records", {"record_id": fixed["record_id"]}, {"Decision": "Approve", "Reviewer": "Ann"})
    res = WB.ingest(st, REG, path2, log=lambda m: None)
    assert res["decisions"] == 0 and "another person approves it" in res["errors"][0]
    _fill(path2, "Records", {"record_id": fixed["record_id"]}, {"Decision": "Approve", "Reviewer": "Ben"})
    assert WB.ingest(st, REG, path2, log=lambda m: None)["decisions"] == 1
    KB.build(st, REG, log=lambda m: None)
    assert current(st)[fixed["record_id"]]["status"] == "approved"
    rows = st.read("records")
    for r in rows:
        if r["record_id"] == recs["respite2"].record_id:
            r["content_sha"] = "edited"
    st.write("records", rows)
    _fill(path2, "Records", {"record_id": recs["respite2"].record_id}, {"Decision": "Reject", "Reviewer": "Ben"})
    res = WB.ingest(st, REG, path2, log=lambda m: None)
    assert any("stale" in e for e in res["errors"])


def test_an_exception_in_another_source_makes_a_rule_conditional(world):
    st, secs, recs = world
    sec = section(CH19, "EPSDT", "For members under 21, H0004 limits may be exceeded when medically necessary.")
    x = record(sec, {"kind": "exception", "subject": {"codes": ["H0004"]},
                     "params": {"effect": "waives", "applies_to": "H0004 limits", "target_kinds": ["units_limit"]},
                     "conditions": [{"type": "age", "below_age": 21}],
                     "quote": "For members under 21, H0004 limits may be exceeded when medically necessary."})
    st.write("sections", [sec], mode="append")
    st.write("records", [store_row(x)], mode="append")
    KB.build(st, REG, log=lambda m: None)
    cur = current(st)
    a = cur[recs["aac"].record_id]
    assert a["overlays"] == [x.record_id] and a["execution_class"] == "conditional"
    assert any("exception in A8" in w for w in a["execution_reasons"])
    assert cur[recs["pa2"].record_id]["overlays"] == []                    # another code and kind


def test_a_guide_rule_meets_a_b2_row_for_one_provider_type(world):
    st, secs, recs = world
    b2 = finalize(Record(kind="modifier_rule", subject={"codes": ["H0004"]},
                         params={"mode": "allowed", "modifiers": ["HQ"], "complete_list": True},
                         conditions=[{"type": "provider_type", "include": ["77"]}],
                         citation={"source_id": "A1", "document_key": "main",
                                   "source_version_id": "A1@2026-10-01#55555555", "locator": "rows 9-10",
                                   "quote": "H0004 | 77 | HQ", "row_key": "H0004|77"},
                         applicability={"delivery_systems": ["FFS"]}, origin="table", authority_level=5,
                         extraction={"spec": "b2", "readings": ["B2-MOD"]}))
    sec = section(V2, "Counseling > Modifiers", "H0004 is never billed with modifier HQ by any provider.")
    guide = record(sec, {"kind": "modifier_rule", "subject": {"codes": ["H0004"]},
                         "params": {"mode": "not_allowed", "modifiers": ["HQ"]},
                         "quote": "H0004 is never billed with modifier HQ by any provider."})
    st.write("sections", [sec], mode="append")
    st.write("records", [store_row(b2), store_row(guide)], mode="append")
    KB.build(st, REG, log=lambda m: None)
    c = [x for x in st.read("conflicts") if {x["record_a"], x["record_b"]} == {b2.record_id, guide.record_id}]
    assert c and c[0]["relationship"] == "contradiction" and "narrower" in c[0]["detail"]
    assert c[0]["suggested_prevailing"] == b2.record_id and c[0]["precedence_id"] == "P1"


def test_four_eyes_ignores_case_and_spacing():
    assert DC.same_person("Jane Doe", "jane  doe") and not DC.same_person("Jane Doe", "John Doe")
    assert not DC.same_person("", "")
