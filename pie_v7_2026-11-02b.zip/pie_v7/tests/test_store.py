"""The local store round-trips rows and replaces by key."""
from pie_kb.io.store import SCHEMAS, LocalStore


def test_local_store_round_trip(tmp_path):
    st = LocalStore(str(tmp_path))
    rows = [{"value_set_id": "A6", "source_version_id": "v1", "code": "F0150", "code_system": "ICD10CM",
             "description": "Vascular dementia", "attributes": {"page": 1}, "effective_start": "2026-10-01",
             "effective_end": None},
            {"value_set_id": "A6", "source_version_id": "v2", "code": "Z634", "code_system": "ICD10CM",
             "description": "Disappearance", "attributes": {"page": 27}, "effective_start": "2026-10-01",
             "effective_end": None}]
    st.write("value_sets", rows)
    back = st.read("value_sets")
    assert back[0]["attributes"] == {"page": 1} and back[1]["code"] == "Z634"
    st.replace_where("value_sets", "source_version_id", ["v1"], [{**rows[0], "code": "F0151"}])
    codes = sorted(r["code"] for r in st.read("value_sets"))
    assert codes == ["F0151", "Z634"]
    st.write("value_sets", [rows[1]], mode="append")
    assert len(st.read("value_sets")) == 3


def test_every_schema_names_unique_columns():
    for name, cols in SCHEMAS.items():
        names = [c for c, _ in cols]
        assert len(names) == len(set(names)), name
