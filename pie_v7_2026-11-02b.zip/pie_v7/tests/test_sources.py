"""Registry, intake, version dates and the ledgers, on the files SB downloaded."""
import csv
import os

import pytest

from conftest import real_path
from pie_kb import config
from pie_kb.sources import intake, ledger, registry, versions


def test_registry_is_consistent(reg):
    assert registry.validate(reg) == []
    with open(os.path.join(config.REFERENCE_DIR, "sources.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    assert all(None not in r for r in rows), "a field with a comma is not quoted"
    assert reg.get("A24").status == "obsolete"
    assert {d.source_id for d in reg.docs if d.status == "deferred"} == {"M1", "M2", "M3", "M4", "M5", "M6"}


PDFS = [("01_CBHSG/AHCCCS_CBHSG.pdf", "A7", "2026-10-01"),
        ("02_AMPM/AMPM_1620-G.pdf", "A18", "2021-06-01"),
        ("02_AMPM/AMPM_310-B.pdf", "A10", "2025-07-22"),
        ("02_AMPM/AMPM_320-I.pdf", "A13", "2023-10-01"),
        ("02_AMPM/AMPM_320-O.pdf", "A12", "2026-05-21"),
        ("02_AMPM/AMPM_320-V.pdf", "A11", "2026-10-01"),
        ("02_AMPM/AMPM_590.pdf", "A14", "2024-09-27"),
        ("02_AMPM/AMPM_610.pdf", "A15", "2024-12-09"),
        ("02_AMPM/AMPM_660.pdf", "A16", "2026-10-01"),
        ("02_AMPM/AMPM_963.pdf", "A17", "2026-10-01"),
        ("02_AMPM/AMPM_Exhibit_300-2A.pdf", "A19", "2023-07-20"),
        ("03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf", "A8", "2026-09-15"),
        ("03_Billing_Manuals/IHS_Tribal_Chapter12_BehavioralHealth.pdf", "A9", "2023-02-11"),
        ("04_Arizona_Rules/AAC_Title9_Ch22_includes_Article12.pdf", "A20", "2025-12-31"),
        ("05_Claims_Clues/ClaimsClues_Feb_2024.pdf", "A23/cc_2024_02", "2024-02-01"),
        ("05_Claims_Clues/ClaimsClues_July_2023.pdf", "A23/cc_2023_07", "2023-07-01"),
        ("05_Claims_Clues/ClaimsClues_May_2023.pdf", "A23/cc_2023_05", "2023-05-01"),
        ("08_Additional_BH_References/CBHSG_FAQ.pdf", "A28", "2024-10-01"),
        ("08_Additional_BH_References/ClaimsClues_Feb2024_BH_Per_Diem_Clarification.pdf",
         "A23/bh_per_diem_2024_02", "2024-02-06"),
        ("08_Additional_BH_References/ClaimsClues_May2023_BH_Billing_Clarification.pdf",
         "A23/bh_clarification_2023_05", "2023-05-03"),
        ("09_BH_Diagnosis_Lists/AHCCCS_2026_BH_SDOH_Diagnosis_List.pdf", "A6", "2025-10-01"),
        ("09_BH_Diagnosis_Lists/AHCCCS_2027_BH_Diagnosis_List.pdf", "A6", "2026-10-01")]


@pytest.mark.parametrize("rel,doc_id,version", PDFS)
def test_real_pdf_is_recognised_and_dated(reg, rel, doc_id, version):
    p = real_path(rel)
    ident = intake.identify(p, reg)
    assert ident.doc is not None, ident.reason
    assert ident.doc.doc_id == doc_id
    assert ident.how.startswith("title"), "recognised by its content, not its file name"
    assert intake.version_of(p, ident.doc).date == version


def test_renamed_file_is_still_recognised(reg, tmp_path):
    import shutil
    p = tmp_path / "download (3).pdf"
    shutil.copyfile(real_path("02_AMPM/AMPM_320-V.pdf"), p)
    assert intake.identify(str(p), reg).doc.doc_id == "A11"


def test_fiscal_year_list_states_its_end(reg):
    p = real_path("09_BH_Diagnosis_Lists/AHCCCS_2027_BH_Diagnosis_List.pdf")
    vi = intake.version_of(p, reg.get("A6"))                 # the list states its own period: preferred
    assert (vi.date, vi.period_end, vi.basis) == ("2026-10-01", "2027-09-30", "stated")
    assert "EFFECTIVE 10/01/2026 TO 09/30/2027" in vi.evidence
    old = versions.from_pdf_text("dx_list_fy", versions.pdf_head_text(p))   # the title rule agrees
    assert (old.date, old.period_end) == (vi.date, vi.period_end)


def test_applicability_read_from_the_purpose_statement(reg):
    text = versions.pdf_head_text(real_path("02_AMPM/AMPM_320-V.pdf"))
    a = registry.applicability_from_purpose(text, reg)
    assert set(a["programs_include"]) >= {"ACC", "ACC_RBHA", "ALTCS_EPD", "DCS_CHP", "DES_DDD", "AIHP", "DDD_THP",
                                          "TRIBAL_ALTCS", "TRBHA", "FFS_ALL"}
    assert a["programs_exclude"] == ["FESP"]
    assert a["delivery_systems"] == ["FFS", "MC"]
    t963 = versions.pdf_head_text(real_path("02_AMPM/AMPM_963.pdf"))
    a963 = registry.applicability_from_purpose(t963, reg)
    assert "FFS" in a963["delivery_systems"] and "AIHP" in a963["programs_include"]     # SME question 4


def test_accession_archives_once_and_flags_duplicates(reg, tmp_path):
    src = real_path("02_AMPM/AMPM_660.pdf")
    arch, quar = str(tmp_path / "archive"), str(tmp_path / "quarantine")
    row = intake.accession(src, reg, [], archive_dir=arch, quarantine_dir=quar)
    assert row["status"] == "active" and row["source_version_id"].startswith("A16@2026-10-01#")
    assert os.path.exists(row["archive_path"]) and row["archive_path"].startswith(arch)
    again = intake.accession(src, reg, [row], archive_dir=arch, quarantine_dir=quar)
    assert again["status"] == "duplicate" and again["duplicate_of"] == row["source_version_id"]
    junk = tmp_path / "notes.pdf"
    junk.write_bytes(b"%PDF-1.4 not a policy")
    q = intake.accession(str(junk), reg, [], archive_dir=arch, quarantine_dir=quar)
    assert q["status"] == "quarantined"


def test_windows_and_gaps():
    vs = [{"source_version_id": "A1@2025-08-01#a", "source_id": "A1", "document_key": "main", "status": "active",
           "version_date": "2025-08-01", "first_seen_at": "x", "period_end": None},
          {"source_version_id": "A1@2026-10-01#b", "source_id": "A1", "document_key": "main", "status": "active",
           "version_date": "2026-10-01", "first_seen_at": "x", "period_end": None},
          {"source_version_id": "A6@2026-10-01#c", "source_id": "A6", "document_key": "main", "status": "active",
           "version_date": "2026-10-01", "first_seen_at": "x", "period_end": "2027-09-30"}]
    from datetime import date
    w = {v["source_version_id"]: v for v in ledger.windows(vs, today=date(2026, 11, 2), monthly_cadence={"A1"})}
    old, new, dx = w["A1@2025-08-01#a"], w["A1@2026-10-01#b"], w["A6@2026-10-01#c"]
    assert (old["effective_start"], old["effective_end"], old["window_basis"]) == ("2025-08-01", "2026-09-30",
                                                                                   "next_version")
    assert len(old["gap_months"]) == 13 and old["gap_months"][0] == "2025-09-01"
    assert new["effective_end"] is None and new["in_force_today"]
    assert (dx["effective_end"], dx["window_basis"]) == ("2027-09-30", "stated")


def test_due_is_per_configuration():
    vs = [{"source_version_id": "A11@x#1", "source_id": "A11", "status": "active"},
          {"source_version_id": "A12@x#2", "source_id": "A12", "status": "active"}]
    done = [ledger.processing_row("A11@x#1", "parse", "cfg1", "run1", "ok")]
    assert [v["source_version_id"] for v in ledger.due(vs, done, "parse", "cfg1")] == ["A12@x#2"]
    assert len(ledger.due(vs, done, "parse", "cfg2")) == 2          # a new parser makes both due again


def test_quotes_in_the_precedence_file_are_real(reg):
    """Every precedence statement quotes its source word for word (checked against the PDF text)."""
    from pie_kb.core.text import match_form
    files = {"A7": "01_CBHSG/AHCCCS_CBHSG.pdf", "A8": "03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf",
             "A9": "03_Billing_Manuals/IHS_Tribal_Chapter12_BehavioralHealth.pdf"}
    import pymupdf
    for pr in reg.precedence:
        with pymupdf.open(real_path(files[pr.stated_in])) as doc:
            page = doc[pr.page - 1].get_text()
        assert match_form(pr.quote) in match_form(page), pr.precedence_id
