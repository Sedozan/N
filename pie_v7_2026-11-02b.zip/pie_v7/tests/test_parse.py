"""Parsing: PDF lines, sections, outline positions, on the files SB downloaded."""
import re
from collections import Counter
from functools import lru_cache

import pytest

from conftest import real_path
from pie_kb.core.text import match_form
from pie_kb.parse import sections as S
from pie_kb.sources import intake, registry


@lru_cache(maxsize=None)
def parsed(rel: str, version: str = "v1"):
    reg = registry.load()
    path = real_path(rel)
    doc = intake.identify(path, reg).doc
    pd = S.parse_pdf(path, doc, f"{doc.doc_id}@{version}", reg)
    return pd, S.to_rows(pd, doc, f"{doc.doc_id}@{version}")


def by_path(rows, *heads):
    want = " > ".join(heads)
    hits = [r for r in rows if r["path_text"].endswith(want)]
    assert hits, f"no section {want!r}"
    return hits[0]


def all_text(rows):
    return "\n".join(r["text"] for r in rows)


AMPM_320V = "02_AMPM/AMPM_320-V.pdf"
CBHSG = "01_CBHSG/AHCCCS_CBHSG.pdf"
CH19 = "03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf"
IHS = "03_Billing_Manuals/IHS_Tribal_Chapter12_BehavioralHealth.pdf"
AAC = "04_Arizona_Rules/AAC_Title9_Ch22_includes_Article12.pdf"
CC_MAY = "05_Claims_Clues/ClaimsClues_May_2023.pdf"
FAQ = "08_Additional_BH_References/CBHSG_FAQ.pdf"
NARRATIVE = [AMPM_320V, "02_AMPM/AMPM_1620-G.pdf", "02_AMPM/AMPM_310-B.pdf", "02_AMPM/AMPM_320-I.pdf",
             "02_AMPM/AMPM_320-O.pdf", "02_AMPM/AMPM_590.pdf", "02_AMPM/AMPM_610.pdf", "02_AMPM/AMPM_660.pdf",
             "02_AMPM/AMPM_963.pdf", CBHSG, CH19, IHS, AAC, CC_MAY, "05_Claims_Clues/ClaimsClues_July_2023.pdf",
             "05_Claims_Clues/ClaimsClues_Feb_2024.pdf", FAQ,
             "08_Additional_BH_References/ClaimsClues_Feb2024_BH_Per_Diem_Clarification.pdf",
             "08_Additional_BH_References/ClaimsClues_May2023_BH_Billing_Clarification.pdf"]


# ------------------------------------------------------------------ helpers without files
def test_join_rejoins_broken_words_and_keeps_real_hyphens():
    words = Counter({"services": 5, "ahcccs": 9, "registered": 2})
    compounds = Counter({"acc-rbha": 3})
    assert S.join("Behavioral Health Ser-", "vices", words, compounds, False) == "Behavioral Health Services"
    assert S.join("the AHC-", "CCS website", words, compounds, False) == "the AHCCCS website"
    assert S.join("ACC-", "RBHA Contractors", words, compounds, False) == "ACC-RBHA Contractors"
    assert S.join("AAC R9-", "10-702", words, compounds, False) == "AAC R9-10-702"
    assert S.join("AMPM Policy 310-", "B for limits", words, compounds, False) == "AMPM Policy 310-B for limits"
    assert S.join("self-", "administration", words, compounds, False) == "self-administration"
    assert S.join("physi-", "cal health", words, compounds, True) == "physical health"
    assert S.join("email APEPTrainingQuestions@", "azahcccs.gov", words, compounds, False) == \
        "email APEPTrainingQuestions@azahcccs.gov"


def test_outline_markers_letter_or_roman():
    stack = [S.Item("num", ".", 2, 108, "2"), S.Item("lower", ".", 8, 126, "h")]
    assert S._accept(stack, S._readings("i", "."), ".", 126, False)[1:] == ("lower", 9, "sibling")
    stack = [S.Item("num", ".", 2, 108, "2"), S.Item("lower", ".", 2, 126, "b")]
    assert S._accept(stack, S._readings("i", "."), ".", 144, False)[1:] == ("rlower", 1, "child")
    assert S._accept(stack, S._readings("v", "."), ".", 144, False) is None       # 'v.' cannot open a list
    assert S._accept(stack, S._readings("c", "."), ".", 126, False)[1:] == ("lower", 3, "sibling")
    assert S._readings("BHTS", ")") == []                                          # '(BHTS) OR ...' is text


# ------------------------------------------------------------------ every narrative document
@pytest.mark.parametrize("rel", NARRATIVE)
def test_every_document_sections_cleanly(rel):
    pd, rows = parsed(rel)
    assert pd.warnings == [] or all("out of sequence" in w for w in pd.warnings), pd.warnings
    assert sum(1 for r in rows if r["role"] in S.EXTRACTABLE and r["text"]) >= 1
    assert len({r["section_id"] for r in rows}) == len(rows)
    assert len({r["section_key"] for r in rows}) == len(rows)
    text = all_text(rows)
    assert not re.search(r"\bPage \d+ of \d+\b", text)                    # AMPM running footer
    assert not re.search(r"(?m)^\d+ of \d+$", text)                       # CBHSG / FAQ page numbers
    assert not re.search(r"\.{8,}", text)                                 # table of contents leaders
    for r in rows:                                                       # block offsets point into the text
        for b in r["blocks"]:
            if b["kind"] != "footnote":
                assert 0 <= b["start"] <= b["end"] <= len(r["text"])


def test_section_keys_are_stable_across_versions():
    _, a = parsed(AMPM_320V, "v1")
    _, b = parsed(AMPM_320V, "v2")
    assert [r["section_key"] for r in a] == [r["section_key"] for r in b]
    assert not set(r["section_id"] for r in a) & set(r["section_id"] for r in b)


# ------------------------------------------------------------------ AMPM
def test_ampm_320v_outline_and_dates():
    pd, rows = parsed(AMPM_320V)
    title = rows[0]
    assert title["role"] == "title" and title["heading"] == "320-V - BEHAVIORAL HEALTH RESIDENTIAL FACILITIES"
    assert "2026-10-01" in title["stated_dates"]["effective"]
    assert "2026-09-02" in title["stated_dates"]["approval"]
    a = by_path(rows, "III. POLICY", "A. BEHAVIORAL HEALTH RESIDENTIAL FACILITY (BHRF) OVERVIEW AND REQUIREMENTS")
    i = a["text"].index("Health and wellness education")
    assert S.locate(a, i, i + 20) == {"page": 3, "pages": [3], "item": "3.b.ii"}
    d = by_path(rows, "II. DEFINITIONS")
    assert d["role"] == "definitions"
    assert "BEHAVIORAL HEALTH RESIDENTIAL FACILITY STAFF ([BHRF] STAFF)" in d["defined_terms"]
    assert "SUPERVISION: Directly overseeing and inspecting" in d["text"]
    assert pd.applicability["basis"] == "stated"
    assert "FFS" in pd.applicability["delivery_systems"] and "FESP" in pd.applicability["programs_exclude"]


def test_ampm_letter_i_heading_after_h():
    _, rows = parsed("02_AMPM/AMPM_963.pdf")
    i = [r for r in rows if r["heading"].startswith("I. PEER SUPPORT EMPLOYMENT")]
    assert i and i[0]["level"] == 3 and "III. POLICY" in i[0]["path_text"]


def test_ampm_word_spaces_set_as_separate_spans():
    _, rows = parsed("02_AMPM/AMPM_310-B.pdf")
    assert rows[0]["heading"] == "310-B - TITLE XIX/XXI BEHAVIORAL HEALTH SERVICE BENEFIT"
    assert any(r["heading"] == "A. GENERAL REQUIREMENTS" for r in rows)


# ------------------------------------------------------------------ CBHSG
def test_cbhsg_billing_limitations():
    pd, rows = parsed(CBHSG)
    bl = by_path(rows, "Outpatient Treatment Services", "Behavioral Health Counseling and Therapy",
                 "Billing Limitations")
    q = "H0004 must not be billed on the same day that residential"
    i = bl["text"].index(q)
    assert S.locate(bl, i, i + len(q)) == {"page": 26, "pages": [26], "item": "6.a"}
    assert "H0004" in bl["codes"]["procedure"]
    assert "HQ" in bl["codes"]["modifier"]
    psy = by_path(rows, "Psychotherapy", "CPT Codes")
    assert {"90832", "90837", "90853"} <= set(psy["codes"]["procedure"])
    text = all_text(rows)
    assert "Updated:" not in text
    assert rows[0]["role"] == "cover"
    assert pd.stats["footnotes"] >= 1                         # revision footnotes kept aside, not in the text
    assert "Table of Contents has been revised" not in text


# ------------------------------------------------------------------ billing manuals
def test_ffs_chapter19():
    _, rows = parsed(CH19)
    heads = [r["heading"] for r in rows]
    assert "BH SERVICES PROVIDED BY BEHAVIORAL HEALTH TECHNICIANS (BHTS) OR BEHAVIORAL HEALTH PARAPROFESSIONALS " \
           "(BHPPS)" in heads
    assert "AHCCCS COMPLETE CARE PLANS AND THE AMERICAN INDIAN HEALTH PROGRAM (AIHP)" in heads
    assert by_path(rows, "REVISION HISTORY")["role"] == "history"
    first = by_path(rows, "BEHAVIORAL HEALTH SERVICES")
    assert "• Inpatient hospital services" in first["text"]
    assert not re.search(r"\d+ \| 39", all_text(rows))


@pytest.mark.parametrize("pid", ["P1", "P2", "P3"])
def test_precedence_quotes_are_found_in_parsed_sections(pid):
    reg = registry.load()
    pr = next(p for p in reg.precedence if p.precedence_id == pid)
    rel = {"A7": CBHSG, "A8": CH19, "A9": IHS}[pr.stated_in]
    _, rows = parsed(rel)
    hits = [r for r in rows if match_form(pr.quote) in match_form(r["text"])]
    assert hits and hits[0]["page_start"] <= pr.page <= hits[0]["page_end"]


# ------------------------------------------------------------------ A.A.C.
def test_aac_scope_columns_and_hyphenation():
    pd, rows = parsed(AAC)
    inscope = [r for r in rows if r["role"] != "excluded"]
    assert all("ARTICLE 12." in r["path_text"] or "R9-22-210.01." in r["path_text"] for r in inscope)
    assert {r["role"] for r in inscope} == {"body", "history"}
    sec = by_path(rows, "R9-22-1205. Scope and Coverage of Behavioral Health Services")
    t = sec["text"]
    i = t.index("ix. A medical practitioner.")
    assert S.locate(sec, i, i + 5)["item"] == "A.2.b.ix"
    j = t.index("i. A medical practitioner.", t.index("C. Covered Inpatient sub-acute"))
    assert S.locate(sec, j, j + 5)["item"] == "C.3.i"                # the letter i after h, not roman one
    assert "AHCCCS-approved accrediting body" in t
    emerg = by_path(rows, "R9-22-210.01. Emergency Behavioral Health Services for Non-FES Members")
    k = emerg["text"].index("Prohibition against limitation or denial of payment")
    assert S.locate(emerg, k, k + 10) == {"page": 24, "pages": [24], "item": "A.7"}   # left column of the next page
    defs = by_path(rows, "R9-22-1201. Definitions")
    assert {"Assessment", "Respite", "Crisis services"} <= set(defs["defined_terms"])
    assert pd.stats["seq_breaks"] == 0


# ------------------------------------------------------------------ notices and FAQ
def test_claims_clues_columns_and_sidebar():
    _, rows = parsed(CC_MAY)
    heads = {r["heading"]: r for r in rows}
    assert heads["TRAINING AND CONTACTS"]["role"] == "boilerplate"
    rem = heads["Reminder: Claim Date Span Billing Requirement"]
    assert "AHCCCS DFSM will deny any claim line submitted by a provider type 77 or IC" in rem["text"]
    assert "servicedesk" not in rem["text"]                          # the sidebar is not read into the article
    assert rem["codes"]["provider_type"] == ["77", "IC"] or "77" in rem["codes"].get("provider_type", [])


def test_faq_questions_are_sections():
    _, rows = parsed(FAQ)
    qs = [r for r in rows if re.match(r"^Q\d+:", r["heading"])]
    assert len(qs) == 29
    assert rows[0]["role"] == "front"                                # the list of questions on page 1
    q29 = qs[-1]
    assert q29["heading"].startswith("Q29: Regarding S9480") and q29["text"]


# ------------------------------------------------------------------ the parse stage
def test_parse_stage_runs_once_per_parser_configuration(tmp_path):
    from pie_kb.io.store import LocalStore
    from pie_kb.parse import run as R
    reg = registry.load()
    st = LocalStore(str(tmp_path / "store"))
    held = []
    for rel in (AMPM_320V, "08_Additional_BH_References/ClaimsClues_Feb2024_BH_Per_Diem_Clarification.pdf"):
        row = intake.accession(real_path(rel), reg, held, archive_dir=str(tmp_path / "archive"),
                               quarantine_dir=str(tmp_path / "quarantine"))
        assert row["status"] == "active"
        held.append(row)
    st.write("source_versions", held)
    logs = []
    out = R.run(st, reg, log=logs.append)
    assert len(out["parsed"]) == 2 and not out["failed"]
    secs = st.read("sections")
    assert {r["source_version_id"] for r in secs} == {h["source_version_id"] for h in held}
    assert out["sections"] == len(secs)
    proc = st.read("processing_ledger")
    assert {p["status"] for p in proc} == {"ok"} and all(p["config_id"] == out["config_id"] for p in proc)
    assert R.run(st, reg, log=logs.append)["parsed"] == []              # nothing due under the same parser
    again = R.run(st, reg, force=True, log=logs.append)                  # forced: parsed again, rows replaced
    assert len(again["parsed"]) == 2 and len(st.read("sections")) == len(secs)
