"""The whole pipeline end to end, outside Databricks, on either store; with --compare, on both, and their tables
compared.

  python tools/local_e2e.py --compare [--sources DIR]

  spark   SparkStore on a local Spark session (Parquet tables in a local warehouse: Delta row deletes are replaced by
          read, filter and overwrite, the store's documented fallback)
  local   LocalStore (Parquet files)
The model is replayed (no GPU): the Ch19 respite section gets a fixed answer, every other piece "no rule". After the
first build, the script signs the B2 readings and approves one record in the review workbook, ingests it and builds
again, so the review path runs too. Each run prints a JSON summary; --compare runs both in separate processes (the
configuration is read at import) and reports any table whose row count or content hash differs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = ["03_Billing_Manuals/FFS_Chapter19_BehavioralHealth.pdf", "02_AMPM/AMPM_320-V.pdf",
         "07_B2_Current/B2_Matrix.xlsx", "07_B2_History/20250830080724_76d2f258fcbc.xlsx",
         "06_Reference_XLSX/Telehealth_Code_Set.xlsx"]
RESPITE = {"records": [
    {"kind": "pair_prohibited", "subject": {"codes": ["S5151"]},
     "params": {"partners": ["L1"], "partner_category": "any other per diem code", "scope": "unstated",
                "modifier_bypass": "none"}, "conditions": [], "exceptions": [],
     "quote": "Providers are prohibited from billing S5151 with [L1] or any other per diem code on the same day."},
    {"kind": "units_limit", "subject": {"category": "Respite services"},
     "params": {"max": 600, "per": "benefit_year", "scope": "member", "unit_basis": "hour"}, "conditions": [],
     "exceptions": [], "quote": "Respite services are limited to 600 hours per benefit year"}], "none_reason": None}
NONE = '{"records": [], "none_reason": "no rule in this text"}'
TABLES = ("source_versions", "processing_ledger", "sections", "table_rows", "value_sets", "readings", "records",
          "proposals", "extraction_outcomes", "review_log", "conflicts", "record_diffs", "code_index",
          "records_current", "build_log")
# columns that differ between two runs by nature (run ids, times, paths), left out of the content hash
VOLATILE = {"run_id", "started_at", "finished_at", "first_seen_at", "archive_path", "build_id", "built_at",
            "decided_at", "decision_id", "workbook", "extraction", "synced_at", "counts", "seconds", "detail",
            "message", "package_sha", "attributes", "review", "status_basis", "flags", "execution_reasons"}


def run(kind: str, sources: str, work: str) -> dict:
    os.environ.update({"PIE_DATA_DIR": os.path.join(work, "data"), "PIE_CATALOG": "spark_catalog",
                       "PIE_SCHEMA": "pie_e2e", "PIE_TABLE_FORMAT": "parquet",
                       "PIE_STORE": "delta" if kind == "spark" else "parquet",
                       "PIE_LOCAL_STORE_DIR": os.path.join(work, "tables")})
    sys.path.insert(0, ROOT)
    from openpyxl import load_workbook

    from pie_kb import config, stages
    from pie_kb.extract.backends import ReplayBackend
    from pie_kb.io.store import open_store
    from pie_kb.sources import registry
    from pie_kb.tables import readings as RD
    from pie_kb.review import decisions as DC

    spark = None
    if kind == "spark":
        from pyspark.sql import SparkSession
        spark = (SparkSession.builder.master("local[2]").appName("pie-e2e")
                 .config("spark.sql.warehouse.dir", os.path.join(work, "warehouse"))
                 .config("spark.ui.enabled", "false").config("spark.sql.shuffle.partitions", "2").getOrCreate())
        spark.sparkContext.setLogLevel("ERROR")
        spark.sql("CREATE DATABASE IF NOT EXISTS pie_e2e")
    store = open_store(spark)
    log = (lambda m: None)
    reg = registry.load()
    for rel in FILES:
        dest = os.path.join(config.INBOX_DIR, rel)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copyfile(os.path.join(sources, rel), dest)
    stages.sync_registry(store, reg)
    first = stages.intake(store, reg, log=log)
    again = stages.intake(store, reg, log=log)                         # the same inbox: nothing new
    stages.parse(store, reg, log=log)
    stages.tables(store, reg, log=log)
    stages.export_narrative(store, reg, model="replay", reasoning="medium", log=log)

    def model(system, user, budget):
        return json.dumps(RESPITE) if user.split("SECTION: ")[1].startswith("RESPITE CARE (UNSKILLED)") else NONE
    be = ReplayBackend(fn=model, model="replay", reasoning="medium")
    stages.extract_narrative(be, reg, log=log)
    persisted = stages.persist_narrative(store, reg, log=log)
    b1 = stages.build(store, reg, log=log)
    wb = stages.review_out(store, reg, path=os.path.join(config.REVIEW_DIR, "review.xlsx"))
    book = load_workbook(wb["path"])
    rd = RD.load()
    for sheet, key, want in (("Readings", "reading_id", {"B2-PT", "B2-POS", "B2-MOD", "B2-COV", "B2-VER"}),):
        ws = book[sheet]
        head = [c.value for c in ws[1]]
        for row in ws.iter_rows(min_row=2):
            cells = dict(zip(head, row))
            if cells[key].value in want:
                cells["Decision"].value, cells["Reviewer"].value = "Sign", "E2E Reviewer"
    ws = book["Records"]
    head = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        cells = dict(zip(head, row))
        if cells["Kind"].value == "pair_prohibited":
            cells["Decision"].value, cells["Reviewer"].value = "Approve", "E2E Reviewer"
    book.save(wb["path"])
    ing = stages.review_in(store, reg, wb["path"], log=log)
    b2 = stages.build(store, reg, log=log)
    cur = store.read("records_current")
    summary = {"store": kind, "intake_first": {k: len(v) for k, v in first.items()},
               "intake_again": {k: len(v) for k, v in again.items()}, "persisted": len(persisted),
               "build1_executable_now": b1["executable_now"], "ingested": ing["decisions"],
               "ingest_errors": ing["errors"], "build2_executable_now": b2["executable_now"],
               "build2_status": b2["status"], "pair_status": sorted({c["status"] for c in cur
                                                                     if c["kind"] == "pair_prohibited"}),
               "readings_signed": sorted(r for r in rd if DC.reading_status(rd[r], DC.Log(store.read("review_log")))[0]
                                         == "signed"),
               "tables": {}}
    for name in TABLES:
        rows = store.read(name)
        h = hashlib.sha256()
        for line in sorted(json.dumps({k: v for k, v in r.items() if k not in VOLATILE}, sort_keys=True, default=str)
                           for r in rows):
            h.update(line.encode())
        summary["tables"][name] = {"rows": len(rows), "content": h.hexdigest()[:12]}
    if spark is not None:
        spark.stop()
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", choices=("spark", "local"))
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--sources", default=os.environ.get("PIE_TEST_SOURCES", "/home/claude/sources_raw/AHCCCS_BH_Files"))
    ap.add_argument("--work", default=None)
    a = ap.parse_args()
    if a.compare:
        out = {}
        for kind in ("local", "spark"):
            work = tempfile.mkdtemp(prefix=f"pie_e2e_{kind}_")
            p = subprocess.run([sys.executable, __file__, "--store", kind, "--sources", a.sources, "--work", work],
                               capture_output=True, text=True)
            if p.returncode:
                print(p.stdout[-3000:], p.stderr[-6000:])
                raise SystemExit(f"{kind} run failed")
            out[kind] = json.loads(p.stdout.strip().splitlines()[-1])
        diff = [n for n in TABLES if out["local"]["tables"][n] != out["spark"]["tables"][n]]
        same = {k: out["local"][k] == out["spark"][k] for k in out["local"] if k not in ("store", "tables")}
        print(json.dumps({"local": {k: v for k, v in out["local"].items() if k != "tables"},
                          "tables": out["local"]["tables"], "tables_that_differ": {n: (out["local"]["tables"][n],
                                                                                         out["spark"]["tables"][n])
                                                                                     for n in diff},
                          "summary_fields_equal": same}, indent=1, default=str))
        raise SystemExit(1 if diff or not all(same.values()) else 0)
    print(json.dumps(run(a.store, a.sources, a.work or tempfile.mkdtemp(prefix="pie_e2e_")), default=str))


if __name__ == "__main__":
    main()
