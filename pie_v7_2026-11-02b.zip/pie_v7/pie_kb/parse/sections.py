"""Sections: a parsed document as headed sections of located blocks.

A section is the text under one heading, down to the next heading of any level; its path is the chain of headings
above it. Inside a section the text is a list of blocks (paragraph, outline item, bullet, table row), each with the
page it starts on and its outline position (6.a.ii), so a quote found in the section text is cited to the page and
item it came from.

Roles say what a section is for: body, definitions, purpose (extracted); cover, front matter, toc, history,
boilerplate, excluded (stored for the record, not extracted). `excluded` means outside the registry's section scope
(the A.A.C. chapter is read whole; only Article 12 and R9-22-210.01 are in scope).
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field, replace

from ..core import codes as C
from ..core import dates as D
from ..core.hashing import short_hash, text_hash
from ..core.text import BULLETS, clean, match_form, sentences
from .pdf import Line, PdfDoc, read
from .profiles import PARSER_PROFILE, PROFILES, Ctx, Profile

EXTRACTABLE = ("body", "definitions", "purpose")     # the other roles: title, cover, front, toc, history,
                                                     # references, boilerplate, excluded
INHERITED = ("history", "boilerplate", "toc")
ROMAN_L = ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii", "xiii", "xiv", "xv", "xvi",
           "xvii", "xviii", "xix", "xx"]
ROMAN_U = [r.upper() for r in ROMAN_L]
MARKER = re.compile(r"^(\(?)([A-Za-z]{1,5}|\d{1,3})([.)])\s+(?=\S)")
BULLET = re.compile(rf"^([{re.escape(BULLETS)}])\s*")
TERMINAL = re.compile(r"[.:;?!]\"?\)?$")
TOL = 7.0                                   # points: same indent (outline levels sit 18 points apart)
RULE_CUE = re.compile(
    r"\b(?:must|shall|may not|cannot|can not|will not|not covered|non-?covered|not (?:be )?billed|not (?:be )?"
    r"reimbursed|not reimbursable|limited to|limit(?:s|ed)?|maximum|no more than|not to exceed|exceed|prior "
    r"authori[sz]ation|requires?|required|only|excluded|exclusions?|den(?:y|ied|ial)|per diem|included in|bundled|"
    r"same day|units?|modifier|allowed|allowable|eligible)\b", re.I)
DATE_LABEL = re.compile(r"\b(EFFECTIVE DATES?|APPROVAL DATES?|REVISION DATES?|Updated|Effective Date|Revised)\s*:\s*",
                        re.I)
QUOTED_TERM = re.compile(r'^"([^"]{2,90})"\s+(?:or\s+"[^"]{2,90}"\s+)?(?:means|has the same meaning|as defined|is '
                         r'defined|for the purposes)', re.I)


def _upper_share(t: str) -> float:
    letters = [c for c in t if c.isalpha()]
    return sum(c.isupper() for c in letters) / len(letters) if letters else 0.0


@dataclass
class Item:
    kind: str           # num | lower | upper | rlower | rupper | bullet
    style: str          # "." | ")" | "()" | "" (bullet)
    n: int
    x: float
    label: str


@dataclass
class Block:
    kind: str                     # para | item | bullet | row | footnote
    page: int
    x0: float
    text: str = ""
    item: tuple = ()              # outline labels of the open items, innermost last
    marker: str = ""
    cells: list = field(default_factory=list)      # row: [[x, text], ...]
    cont_x: float | None = None   # indent of the continuation lines
    last_y1: float = 0.0
    start: int = -1
    end: int = -1

    @property
    def is_definition(self) -> bool:
        """A two-cell row whose right cell is prose: TERM | definition (not a list of terms set in columns)."""
        parts = [t for _, t in self.cells if t]
        return self.kind == "row" and len(parts) == 2 and _upper_share(parts[1]) < 0.6

    def render(self) -> str:
        if self.kind == "row":
            parts = [t for _, t in self.cells if t]
            return f"{parts[0]}: {parts[1]}" if self.is_definition else " | ".join(parts)
        return self.text


@dataclass
class Section:
    path: list
    level: int
    role: str
    page_start: int
    blocks: list = field(default_factory=list)
    heading_page: int = 0
    seq_breaks: int = 0
    section_id: str = ""
    section_key: str = ""
    text: str = ""

    @property
    def heading(self) -> str:
        return self.path[-1] if self.path else ""

    @property
    def path_text(self) -> str:
        return " > ".join(self.path)


@dataclass
class ParsedDoc:
    sections: list
    pages: int
    body_size: float
    profile: str
    stats: dict
    warnings: list
    applicability: dict


# ------------------------------------------------------------------ outline markers
def _readings(label: str, style: str) -> list[tuple[str, int]]:
    """(kind, ordinal) readings of an outline label: 'i' is roman one or the letter i; 'C' is the letter C."""
    if label.isdigit():
        return [("num", int(label))]
    out = []
    if label in ROMAN_L:
        out.append(("rlower", ROMAN_L.index(label) + 1))
    if label in ROMAN_U:
        out.append(("rupper", ROMAN_U.index(label) + 1))
    if len(label) == 1:
        out.append(("lower", ord(label) - 96) if label.islower() else ("upper", ord(label) - 64))
    return out


def _accept(stack: list[Item], readings: list, style: str, x: float, new_para: bool, closed: tuple = ()):
    """Where an outline marker at indent x goes: (depth, kind, n, how), or None when the token is just text that
    happens to start a line ("A. Smith", "5. The" in the middle of a paragraph). how: sibling | child | restart |
    resumed (out of sequence, accepted only at a paragraph break and counted as a warning). `closed` holds items a
    plain paragraph closed ("1. ... a. ... b." then "Refer to ..." then "2."): the list goes on after it."""
    for kind, n in readings:                               # the next sibling of an open item at this indent
        for d in range(len(stack) - 1, -1, -1):
            it = stack[d]
            if abs(it.x - x) <= TOL and it.kind == kind and it.style == style and n == it.n + 1:
                return d, kind, n, "sibling"
    for kind, n in readings:                               # ... or of one a paragraph closed
        for it in closed:
            if abs(it.x - x) <= TOL and it.kind == kind and it.style == style and n == it.n + 1:
                return sum(1 for o in stack if o.x < x - TOL), kind, n, "sibling"
    for kind, n in readings:                               # the first child, deeper than the innermost open item
        if n == 1 and (not stack or x > stack[-1].x + TOL):
            return len(stack), kind, n, "child"
    for kind, n in readings:                               # a list restarting at an open item's indent
        if n == 1:
            for d in range(len(stack) - 1, -1, -1):
                if abs(stack[d].x - x) <= TOL:
                    return d, kind, n, "restart"
    if new_para and readings:
        kind, n = readings[0]
        depth = sum(1 for it in stack if it.x < x - TOL)
        return depth, kind, n, "resumed"
    return None


def _is_marker(text: str) -> bool:
    m = MARKER.match(text)
    return bool(m) and bool(_readings(m.group(2), m.group(3)))


def _label(it: Item) -> str:
    return f"•{it.n}" if it.kind == "bullet" else it.label


# ------------------------------------------------------------------ joining lines
def _vocab(lines: list[Line]) -> tuple[Counter, Counter]:
    words, compounds = Counter(), Counter()
    for ln in lines:
        toks = re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)*-?", ln.text)
        if toks and toks[-1].endswith("-") and ln.text.rstrip().endswith("-"):
            toks = toks[:-1]                          # a word broken at the line end is not a word
        for t in toks:
            t = t.rstrip("-").lower()
            if "-" in t:
                compounds[t] += 1
            words[t.replace("-", "")] += 1 if "-" not in t else 0
            for part in t.split("-"):
                words[part] += 1
    return words, compounds


def join(prev: str, nxt: str, words: Counter, compounds: Counter, dehyphenate: bool) -> str:
    """Join two lines of one paragraph. A word broken at the line end is rejoined when the document itself writes it
    whole ("Ser-" + "vices"); a real hyphen stays ("ACC-" + "RBHA", "self-" + "administration"); a code or citation
    broken after a hyphen closes up ("R9-" + "10-702", "310-" + "B")."""
    if not prev:
        return nxt
    if not nxt:
        return prev
    if prev.endswith("-") and len(prev) > 1 and prev[-2].isalnum():
        hw = re.search(r"([A-Za-z]+)-$", prev)
        tw = re.match(r"([A-Za-z]+)", nxt)
        if hw and tw:
            whole = (hw.group(1) + tw.group(1)).lower()
            hyph = (hw.group(1) + "-" + tw.group(1)).lower()
            if words.get(whole, 0) > compounds.get(hyph, 0):
                return prev[:-1] + nxt
            if compounds.get(hyph, 0):
                return prev + nxt
            if dehyphenate and tw.group(1)[0].islower():
                return prev[:-1] + nxt
            return prev + nxt
        return prev + nxt
    if prev.endswith(("/", "@")) and not prev.endswith((" /", " @")):
        return prev + nxt                           # a path or an e-mail address broken at the line end
    return prev + " " + nxt


# ------------------------------------------------------------------ the sectioner
class _Builder:
    def __init__(self, doc: PdfDoc, profile: Profile, words: Counter, compounds: Counter, pitch: float):
        self.doc, self.p, self.pitch = doc, profile, pitch
        self.words, self.compounds = words, compounds
        self.sections: list[Section] = []
        self.heads: list[tuple[int, str]] = []
        self.stack: list[Item] = []
        self.block: Block | None = None
        self.sec: Section | None = None
        self.prev: Line | None = None
        self.prev_heading: Line | None = None
        self.seen_heading = False
        self.closed: list[Item] = []

    # sections
    def open_section(self, path: list, level: int, role: str, page: int) -> None:
        self.close_block()
        self.sec = Section(path=list(path), level=level, role=role, page_start=page, heading_page=page)
        self.sections.append(self.sec)
        self.stack = []
        self.closed: list[Item] = []

    def role_for(self, heading: str) -> str:
        """A heading's role from the profile; a subsection of a history, boilerplate or toc section shares it."""
        for rx, role in self.p.roles:
            if re.search(rx, heading, re.I):
                return role
        parent = [h for _, h in self.heads[:-1]]
        if parent:
            for s in reversed(self.sections[:-1]):
                if s.path == parent:
                    return s.role if s.role in INHERITED else "body"
        return "body"

    def sequence_level(self, text: str, level: int) -> int:
        """'I.' after 'H.' is the letter I at H's level, not the roman numeral one level up (AMPM 963 III.I)."""
        m = MARKER.match(text)
        if not m:
            return level
        readings = _readings(m.group(2), m.group(3))
        if len(readings) < 2:
            return level
        for lvl, head in reversed(self.heads):
            m2 = MARKER.match(head)
            if not m2:
                continue
            prior = _readings(m2.group(2), m2.group(3))
            for kind, n in readings:
                if any(k2 == kind and n2 + 1 == n for k2, n2 in prior):
                    return lvl
        return level

    # blocks
    def close_block(self) -> None:
        if self.block is not None and self.sec is not None:
            self.sec.blocks.append(self.block)
        self.block = None

    def new_block(self, kind: str, ln: Line, text: str = "", marker: str = "", cells=None) -> None:
        self.close_block()
        self.block = Block(kind=kind, page=ln.page, x0=ln.x0, text=text, item=tuple(_label(i) for i in self.stack),
                           marker=marker, cells=[[x, t] for x, t, _ in (cells or [])], last_y1=ln.y1)

    def extend(self, ln: Line) -> None:
        b = self.block
        if b.cont_x is None:
            b.cont_x = ln.x0
        b.last_y1 = ln.y1
        if b.kind == "row":
            if ln.cells:
                for x, t, _ in ln.cells:
                    tgt = min(b.cells, key=lambda c: abs(c[0] - x))
                    tgt[1] = join(tgt[1], t, self.words, self.compounds, self.p.dehyphenate)
            else:
                tgt = min(b.cells, key=lambda c: abs(c[0] - ln.x0))
                tgt[1] = join(tgt[1], ln.text, self.words, self.compounds, self.p.dehyphenate)
            return
        b.text = join(b.text, ln.text, self.words, self.compounds, self.p.dehyphenate)

    def continues_across_break(self, ln: Line) -> bool:
        """A paragraph carried over a page or column break."""
        b = self.block
        if b is None or b.kind == "footnote":
            return False
        text = b.render()
        if ln.text[:1].islower():
            return True
        if TERMINAL.search(text):
            return False
        if b.kind == "row":
            return any(abs(c[0] - ln.x0) <= 8 for c in b.cells)
        if b.cont_x is not None:
            return abs(ln.x0 - b.cont_x) <= TOL
        return ln.x0 >= b.x0 - TOL

    def row_continues(self, ln: Line) -> bool:
        b = self.block
        if ln.cells:
            return all(min(abs(c[0] - x) for c in b.cells) <= 20 for x, _, _ in ln.cells)
        return min(abs(c[0] - ln.x0) for c in b.cells) <= 8

    # the walk
    def feed(self, ln: Line) -> None:
        prev = self.prev
        brk = prev is None or ln.page != prev.page or ln.col != prev.col or ln.y0 < prev.y0 - 1
        body = self.doc.body_size
        # the next line of the same paragraph: its baseline one line pitch down (glyph boxes overlap in tightly set
        # text, so box gaps say little); a blank line or extra spacing before a line starts a new paragraph
        dy = None if brk else ln.y0 - prev.y0
        tight = dy is not None and 0 < dy <= 1.35 * self.pitch * max(1.0, max(ln.size, prev.size) / body)
        ctx = Ctx(body_size=body, page_width=self.doc.width, first_page=ln.page == 1)

        # a wrapped heading: the next line in the same style, set tight under it
        ph = self.prev_heading
        if ph is not None and prev is ph and tight and abs(ln.size - ph.size) <= 0.3 and ln.bold == ph.bold \
                and not TERMINAL.search(self.sec.path[-1]) and not _is_marker(ln.text):
            lvl = self.p.heading(ln, ctx)
            if lvl is None or (lvl == self.heads[-1][0] and not self.p.strong_headings):
                merged = join(self.sec.path[-1], ln.text, self.words, self.compounds, self.p.dehyphenate)
                self.sec.path[-1] = merged
                self.heads[-1] = (self.heads[-1][0], merged)
                self.prev = self.prev_heading = ln
                return

        level = None if (ln.lead_sup and ln.size <= body - 0.8) else self.p.heading(ln, ctx)
        if level is not None and not self.p.strong_headings and abs(ln.size - body) <= 0.6 and tight \
                and self.prev_heading is not prev:
            level = None                                    # a bold line inside a paragraph is not a heading
        if level is not None:
            level = self.sequence_level(ln.text, level)
            while self.heads and self.heads[-1][0] >= level:
                self.heads.pop()
            self.heads.append((level, ln.text))
            self.open_section([h for _, h in self.heads], level, "body", ln.page)
            self.sec.role = self.role_for(ln.text)
            self.seen_heading = True
            self.prev = self.prev_heading = ln
            return
        self.prev_heading = None
        if self.sec is None:
            self.open_section(["(front matter)"], 0, "front", ln.page)

        # footnotes at the page foot (a raised marker opening a smaller line)
        if (ln.lead_sup and ln.size <= body - 0.8) or (self.block is not None and self.block.kind == "footnote"
                                                       and tight and ln.size <= body - 0.8):
            if ln.lead_sup and ln.size <= body - 0.8:
                self.new_block("footnote", ln, ln.text, marker=ln.lead_sup)
            else:
                self.extend(ln)
            self.prev = ln
            return

        text = ln.text
        new_para = not tight
        mb = BULLET.match(text)
        mm = MARKER.match(text)
        if mb:
            sib = next((d for d in range(len(self.stack) - 1, -1, -1)
                        if self.stack[d].kind == "bullet" and abs(self.stack[d].x - ln.x0) <= TOL), None)
            if sib is not None:
                n = self.stack[sib].n + 1
                del self.stack[sib:]
            else:
                n = 1
                while self.stack and self.stack[-1].x >= ln.x0 - TOL:
                    self.stack.pop()
            self.stack.append(Item("bullet", "", n, ln.x0, f"•{n}"))
            self.new_block("bullet", ln, text, marker=mb.group(1))
            self.prev = ln
            return
        if mm:
            paren, label, close = mm.groups()
            style = "()" if paren and close == ")" else close
            got = _accept(self.stack, _readings(label, style), style, ln.x0, new_para, tuple(self.closed))
            if got is not None:
                d, kind, n, how = got
                if how == "resumed":
                    self.sec.seq_breaks += 1
                del self.stack[d:]
                self.stack.append(Item(kind, style, n, ln.x0, label))
                self.new_block("item", ln, text, marker=f"{paren}{label}{close}")
                self.prev = ln
                return

        if self.p.rows_from_cells and len(ln.cells) >= 2:
            if self.block is not None and self.block.kind == "row" and tight and self.row_continues(ln):
                self.extend(ln)
            else:
                self.close_block()
                while self.stack and self.stack[-1].x >= ln.x0 - TOL:
                    self.stack.pop()
                self.new_block("row", ln, cells=ln.cells)
            self.prev = ln
            return

        if self.block is not None and self.block.kind != "footnote":
            if tight and (self.block.kind != "row" or self.row_continues(ln)):
                self.extend(ln)
                self.prev = ln
                return
            if brk and self.continues_across_break(ln):
                self.extend(ln)
                self.prev = ln
                return
        while self.stack and self.stack[-1].x >= ln.x0 - TOL:
            it = self.stack.pop()
            if it.kind != "bullet":
                self.closed = [c for c in self.closed if abs(c.x - it.x) > TOL or c.kind != it.kind] + [it]
        self.new_block("para", ln, text)
        self.prev = ln

    def finish(self) -> list[Section]:
        self.close_block()
        return self.sections


def _drop_toc(lines: list[Line], profile: Profile) -> tuple[list[Line], int]:
    rx = re.compile(profile.toc_line)
    by_page: dict[int, list[Line]] = {}
    for ln in lines:
        by_page.setdefault(ln.page, []).append(ln)
    toc_pages = {p for p, ls in by_page.items() if sum(1 for ln in ls if rx.search(ln.text)) >= max(3, 0.3 * len(ls))}
    out, n = [], 0
    for ln in lines:
        if ln.page in toc_pages or rx.search(ln.text):
            ln.noise = ln.noise or "table of contents"
            n += 1
        else:
            out.append(ln)
    return out, n


def _line_pitch(lines: list[Line], body: float) -> float:
    """The usual distance between the tops of consecutive body-size lines of one paragraph."""
    c = Counter()
    for a, b in zip(lines, lines[1:]):
        if a.page == b.page and a.col == b.col and abs(a.size - body) <= 0.6 and abs(b.size - body) <= 0.6:
            dy = b.y0 - a.y0
            if 0 < dy < 3 * body:
                c[round(dy * 2) / 2] += 1
    return c.most_common(1)[0][0] if c else 1.2 * body


def _right_column_shift(lines: list[Line]) -> float:
    """How far the right column's left edge sits from the left column's (the usual one over the document's pages), so
    outline indents compare across columns: '6.' at x 333 in the right column and '7.' at x 72 on the next page's
    left column are siblings."""
    mins: dict[tuple, float] = {}
    for ln in lines:
        if ln.col in (0, 1):
            k = (ln.page, ln.col)
            mins[k] = min(mins.get(k, 1e9), ln.x0)
    left = Counter(round(v) for (_, c), v in mins.items() if c == 0)
    right = Counter(round(v) for (_, c), v in mins.items() if c == 1)
    if not right:
        return 0.0
    return float(right.most_common(1)[0][0] - (left.most_common(1)[0][0] if left else 0))


def _cover(lines: list[Line], profile: Profile, words, compounds) -> tuple[Section | None, list[Line]]:
    if not profile.cover_pages:
        return None, lines
    cover = [ln for ln in lines if ln.page <= profile.cover_pages]
    rest = [ln for ln in lines if ln.page > profile.cover_pages]
    if not cover:
        return None, lines
    sec = Section(path=["(cover)"], level=0, role="cover", page_start=1, heading_page=1)
    for ln in cover:
        sec.blocks.append(Block(kind="para", page=ln.page, x0=ln.x0, text=ln.text))
    return sec, rest


def _assemble(sec: Section) -> None:
    parts, pos = [], 0
    for b in sec.blocks:
        if b.kind == "footnote":
            continue
        depth = len(b.item) - (1 if b.kind in ("item", "bullet") else 0)
        indent = "  " * max(0, depth)
        line = b.render()
        b.start = pos + len(indent)
        b.end = b.start + len(line)
        parts.append(indent + line)
        pos += len(indent) + len(line) + 1
    sec.text = "\n".join(parts)


def _strip_marker(h: str) -> str:
    return re.sub(r"^(?:[ivxlc]+|[a-z]|\d{1,3})[.)]\s+", "", h)


def stated_dates(text: str) -> dict:
    """Dates a section states with a label (EFFECTIVE DATES:, APPROVAL DATES:, REVISION DATE:, Updated:)."""
    out: dict[str, list] = {}
    for line in text.splitlines():
        for m in DATE_LABEL.finditer(line):
            label = m.group(1).lower().rstrip("s").replace(" date", "").strip() or "date"
            rest = line[m.end():]
            nxt = DATE_LABEL.search(rest)
            rest = rest[:nxt.start()] if nxt else rest
            ds = [D.iso(d) for d in D.all_mdy(rest)]
            if not ds:
                d = D.any_date(rest)
                ds = [D.iso(d)] if d else []
            if ds:
                out.setdefault(label, [])
                out[label] += [d for d in ds if d not in out[label]]
    return out


def section_codes(text: str) -> dict:
    proc = []
    for c, *_ in C.procedure_codes_in(text):
        if c not in proc:
            proc.append(c)
    dx = []
    for c, *_ in C.diagnosis_codes_in(text):
        if c not in dx and c not in proc:
            dx.append(c)
    out = {"procedure": proc, "ranges": [[a, b] for a, b, *_ in C.ranges_in(text)], "diagnosis": dx,
           "modifier": C.modifiers_in(text), "provider_type": C.provider_types_in(text)}
    return {k: v for k, v in out.items() if v}


def signal(text: str) -> int:
    return sum(1 for a, b in sentences(text) if RULE_CUE.search(text[a:b]))


def defined_terms(sec: Section) -> list[str]:
    out = []
    for b in sec.blocks:
        if b.is_definition:
            out.append(clean(b.cells[0][1]))
        elif b.kind in ("para", "item"):
            m = QUOTED_TERM.match(clean(re.sub(r"^\S+\s+", "", b.text) if b.kind == "item" else b.text))
            if m:
                out.append(m.group(1))
    return out


def sectionize(doc: PdfDoc, profile: Profile) -> tuple[list[Section], dict]:
    lines = doc.kept()
    words, compounds = _vocab(lines)
    lines, n_toc = _drop_toc(lines, profile)
    shift = _right_column_shift(lines)
    if shift:
        lines = [replace(ln, x0=ln.x0 - shift, x1=ln.x1 - shift, cells=[(x - shift, t, bd) for x, t, bd in ln.cells])
                 if ln.col == 1 else ln for ln in lines]
    cover, lines = _cover(lines, profile, words, compounds)
    pitch = _line_pitch(lines, doc.body_size)
    b = _Builder(doc, profile, words, compounds, pitch)
    for ln in lines:
        b.feed(ln)
    secs = b.finish()
    if cover is not None:
        secs.insert(0, cover)
    if not b.seen_heading:
        for s in secs:
            if s.role == "front":
                s.role, s.path = "body", ["(document)"]
    for s in secs:
        _assemble(s)
    noise = Counter(ln.noise for ln in doc.lines if ln.noise)
    stats = {"lines": len(doc.lines), "noise": dict(noise), "toc_lines": n_toc, "sections": len(secs),
             "line_pitch": pitch, "column_shift": shift,
             "footnotes": sum(1 for s in secs for bl in s.blocks if bl.kind == "footnote"),
             "seq_breaks": sum(s.seq_breaks for s in secs)}
    return secs, stats


def _applicability(secs: list[Section], reg, sdoc) -> dict:
    from ..sources.registry import applicability_from_purpose
    candidates = [s for s in secs if s.role == "purpose"] + [s for s in secs if s.role in ("body", "front")][:4]
    for s in candidates:
        a = applicability_from_purpose(s.text, reg) if reg is not None else {}
        if a:
            return {**a, "basis": "stated", "section": s.path_text}
    return {"delivery_systems": list(sdoc.delivery_systems) if sdoc is not None else [], "basis": "registry"}


def parse_pdf(path: str, sdoc, source_version_id: str, reg=None) -> ParsedDoc:
    """Read and section one registry document's PDF; sections carry ids, roles and the document's applicability."""
    profile = PROFILES[PARSER_PROFILE.get(sdoc.parser, "generic")]
    doc = read(path, columns=profile.columns, gutter=profile.gutter, header_frac=profile.header_frac,
               footer_frac=profile.footer_frac, noise_patterns=profile.noise)
    secs, stats = sectionize(doc, profile)
    warnings = []
    scope = re.compile(sdoc.section_scope) if getattr(sdoc, "section_scope", "") else None
    if scope is not None:
        for s in secs:
            if not scope.search(s.path_text):
                s.role = "excluded"
        if not any(s.role != "excluded" for s in secs):
            warnings.append(f"no section matches the scope {sdoc.section_scope!r}")
    seen = Counter()
    for s in secs:
        key = s.path_text
        seen[key] += 1
        uniq = key if seen[key] == 1 else f"{key} [{seen[key]}]"
        norm = " > ".join(_strip_marker(match_form(h)) for h in s.path)
        norm = norm if seen[key] == 1 else f"{norm} [{seen[key]}]"
        s.section_id = "S-" + short_hash(source_version_id, uniq)
        s.section_key = "SK-" + short_hash(sdoc.source_id, sdoc.document_key, norm)
        if s.seq_breaks:
            warnings.append(f"{s.path_text}: {s.seq_breaks} outline marker(s) out of sequence")
    if not any(s.role in EXTRACTABLE and s.text for s in secs):
        warnings.append("no extractable text (scanned PDF or unknown layout?)")
    appl = _applicability(secs, reg, sdoc)
    return ParsedDoc(sections=secs, pages=doc.pages, body_size=doc.body_size, profile=profile.name, stats=stats,
                     warnings=warnings, applicability=appl)


def to_rows(pd: ParsedDoc, sdoc, source_version_id: str) -> list[dict]:
    """kb_sections rows."""
    rows = []
    for i, s in enumerate(pd.sections):
        pages = [b.page for b in s.blocks] or [s.page_start]
        blocks = []
        for b in s.blocks:
            d = {"kind": b.kind, "page": b.page, "item": ".".join(b.item), "start": b.start, "end": b.end}
            if b.marker:
                d["marker"] = b.marker
            if b.kind == "row":
                d["cells"] = len(b.cells)
            if b.kind == "footnote":
                d["text"] = b.text
            blocks.append(d)
        rows.append({
            "section_id": s.section_id, "section_key": s.section_key, "source_version_id": source_version_id,
            "source_id": sdoc.source_id, "document_key": sdoc.document_key, "path": s.path, "path_text": s.path_text,
            "heading": s.heading, "level": s.level, "page_start": min([s.heading_page] + pages),
            "page_end": max([s.heading_page] + pages), "text": s.text, "text_hash": text_hash(s.text),
            "n_chars": len(s.text), "blocks": blocks, "codes": section_codes(s.text), "signal": signal(s.text),
            "role": s.role, "applicability": pd.applicability, "defined_terms": defined_terms(s),
            "stated_dates": stated_dates(s.text), "ordinal": i})
    return rows


def text_section(sdoc, source_version_id: str, path: list, paragraphs: list, *, role: str = "body",
                 ordinal: int = 0, applicability: dict | None = None) -> dict:
    """A kb_sections row for text that sits inside a table file (a workbook's guideline sheet, the notes under an
    exhibit grid): `paragraphs` is [(text, locator, page)], one block each. Ids and fields follow parse_pdf's rows, so
    the narrative extractor reads these sections like any other."""
    blocks, parts, pos = [], [], 0
    for text, locator, page in paragraphs:
        t = clean(text)
        if not t:
            continue
        blocks.append({"kind": "para", "page": int(page or 0), "item": "", "start": pos, "end": pos + len(t),
                       "locator": locator})
        parts.append(t)
        pos += len(t) + 1
    text = "\n".join(parts)
    path = [clean(h) for h in path]
    path_text = " > ".join(path)
    pages = [b["page"] for b in blocks] or [0]
    sec = Section(path=path, level=len(path), role=role, page_start=min(pages))
    sec.blocks = [Block(kind="para", page=b["page"], x0=0.0, text=parts[i]) for i, b in enumerate(blocks)]
    norm = " > ".join(match_form(h) for h in path)
    return {"section_id": "S-" + short_hash(source_version_id, path_text),
            "section_key": "SK-" + short_hash(sdoc.source_id, sdoc.document_key, norm),
            "source_version_id": source_version_id, "source_id": sdoc.source_id, "document_key": sdoc.document_key,
            "path": path, "path_text": path_text, "heading": path[-1] if path else "", "level": len(path),
            "page_start": min(pages), "page_end": max(pages), "text": text, "text_hash": text_hash(text),
            "n_chars": len(text), "blocks": blocks, "codes": section_codes(text), "signal": signal(text),
            "role": role, "applicability": applicability or {}, "defined_terms": defined_terms(sec),
            "stated_dates": stated_dates(text), "ordinal": ordinal}


def locate(section: dict, start: int, end: int) -> dict:
    """Page and outline position of a character span of a section's text: {page, pages, item}, plus the cell or row
    (locator) for text read from a table file."""
    hits = [b for b in section["blocks"] if b.get("start", -1) >= 0 and b["start"] < end and b["end"] > start]
    if not hits:
        return {"page": section["page_start"], "pages": [section["page_start"]], "item": ""}
    items = [b["item"] for b in hits]
    common = items[0].split(".") if items[0] else []
    for it in items[1:]:
        parts = it.split(".") if it else []
        k = 0
        while k < min(len(common), len(parts)) and common[k] == parts[k]:
            k += 1
        common = common[:k]
    out = {"page": hits[0]["page"], "pages": sorted({b["page"] for b in hits}), "item": ".".join(common)}
    if hits[0].get("locator"):
        out["locator"] = hits[0]["locator"]
    return out
