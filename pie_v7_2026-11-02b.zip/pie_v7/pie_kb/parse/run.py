"""The parse stage: each active narrative document version not yet parsed by the current parser is read from the
archive into kb_sections (its earlier rows replaced), with one processing-ledger row per version.

"Already parsed" holds per parser configuration: the configuration id is a hash of the parser's own code, so a change
to the reader, the sectioner or a profile re-parses everything (seconds), while unchanged section text keeps its
text_hash and therefore its cached extraction downstream.
"""
from __future__ import annotations

import time

from ..core.hashing import code_version
from ..sources import ledger
from ..sources.intake import new_run_id
from . import sections as S
from .profiles import PARSER_PROFILE



# what a section row depends on: the parser, the code finders and text rules in core, the registry (section scope,
# programs for applicability, document families)
PARSE_DEPENDS = ("parse", "core", "sources/registry.py", "reference/sources.csv", "reference/programs.csv")


def parser_config_id() -> str:
    return "parse-" + code_version(*PARSE_DEPENDS, n=12)


def parseable(doc) -> bool:
    return doc is not None and doc.method == "narrative" and doc.parser in PARSER_PROFILE


def run(store, reg, only: set | None = None, force: bool = False, log=print) -> dict:
    """Parse what is due. Returns {"config_id", "run_id", "parsed": [...], "failed": [...], "sections": n}."""
    cfg = parser_config_id()
    run_id = new_run_id("parse")
    versions = store.read("source_versions")
    processing = [] if force else store.read("processing_ledger")
    due = []
    for v in ledger.due(versions, processing, "parse", cfg, only):
        try:
            doc = reg.get(v["source_id"], v["document_key"])
        except KeyError:
            continue
        if parseable(doc):
            due.append((v, doc))
    out = {"config_id": cfg, "run_id": run_id, "parsed": [], "failed": [], "sections": 0}
    proc_rows = []
    for v, doc in due:
        t0, started = time.time(), ledger.now_iso()
        svid = v["source_version_id"]
        try:
            pd = S.parse_pdf(v["archive_path"], doc, svid, reg)
            rows = S.to_rows(pd, doc, svid)
            store.replace_where("sections", "source_version_id", [svid], rows)
            roles = {}
            for r in rows:
                roles[r["role"]] = roles.get(r["role"], 0) + 1
            counts = {"pages": pd.pages, "sections": len(rows), "roles": roles,
                      "extractable_chars": sum(r["n_chars"] for r in rows if r["role"] in S.EXTRACTABLE),
                      "seconds": round(time.time() - t0, 2), **{k: v for k, v in pd.stats.items()
                                                                 if k in ("footnotes", "seq_breaks", "toc_lines")}}
            proc_rows.append(ledger.processing_row(svid, "parse", cfg, run_id, "ok", counts, "; ".join(pd.warnings),
                                                   started))
            out["parsed"].append(svid)
            out["sections"] += len(rows)
            log(f"parsed {svid}: {len(rows)} sections, {counts['extractable_chars']:,} extractable characters"
                + (f" ({len(pd.warnings)} warning(s))" if pd.warnings else ""))
        except Exception as e:                                   # noqa: BLE001 - one bad file does not stop the run
            proc_rows.append(ledger.processing_row(svid, "parse", cfg, run_id, "error", {},
                                                   f"{type(e).__name__}: {e}", started))
            out["failed"].append(svid)
            log(f"FAILED {svid}: {type(e).__name__}: {e}")
    if proc_rows:
        store.write("processing_ledger", proc_rows, mode="append")
    return out
