"""PDF -> visual lines in reading order, running headers and footers marked.

What a person reads on the page, not what the PDF's content stream happens to hold:
  * spans on one baseline form one line, sorted left to right (justified text arrives one span per word);
  * superscripts are taken out of the text: footnote markers ("services2") are kept aside on the line, ordinal
    suffixes ("25th") stay in the word;
  * a wide horizontal gap inside a line splits it into cells (a definitions table: TERM | definition);
  * two-column pages (A.A.C., newsletters) are read column by column, between full-width lines; a line that runs
    across the gutter (a heading, a full-width paragraph) stays whole;
  * a line repeated in the top or bottom band of most pages (running header, page number, "Updated: ...") and lines
    matching the profile's noise patterns are marked, not deleted, so the record of what was dropped survives.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field

from ..core.text import clean

CELL_GAP = 40.0            # points: a gap this wide inside a line separates two cells
SUP_RATIO = 0.8            # a span this much smaller than its line and raised above the baseline is a superscript
ORDINAL_SUP = re.compile(r"^(?:st|nd|rd|th)$", re.I)


@dataclass
class Line:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float
    size: float
    bold: bool
    page: int                          # 1-based
    col: int = 0                       # 0 single or left column, 1 right column, -1 runs across the gutter
    cells: list = field(default_factory=list)   # [(x0, text, bold)] when the line has a wide gap
    sups: list = field(default_factory=list)    # footnote markers removed from the text
    lead_sup: str = ""                 # a footnote marker that opens the line (the footnote itself)
    noise: str = ""                    # why the line is not content ("" = content)

    @property
    def height(self) -> float:
        return max(1.0, self.y1 - self.y0)


@dataclass
class PdfDoc:
    path: str
    pages: int
    width: float
    height: float
    lines: list                        # every line in reading order, noise included (noise != "")
    body_size: float = 11.0

    def kept(self) -> list:
        return [ln for ln in self.lines if not ln.noise]


def _spans(page, spaces: list | None = None) -> list[dict]:
    """Text spans of a page. Spans holding only white space (some PDFs set every word space as its own span) are not
    text, but where they sit is where a word space goes; they are collected in `spaces` when a list is given."""
    out, w, h = [], page.rect.width, page.rect.height
    for b in page.get_text("dict")["blocks"]:
        for ln in b.get("lines", []):
            if abs(ln.get("dir", (1.0, 0.0))[1]) > 0.1:          # rotated or vertical text (stamps, margins)
                continue
            for s in ln.get("spans", []):
                t = s.get("text", "")
                if not t.strip():
                    if spaces is not None and t:
                        x0, y0, x1, y1 = s["bbox"]
                        spaces.append({"x0": x0, "x1": x1, "y0": y0, "y1": y1})
                    continue
                x0, y0, x1, y1 = s["bbox"]
                if x1 < 0 or y1 < 0 or x0 > w or y0 > h:         # outside the page
                    continue
                font = s.get("font", "")
                out.append({"i": len(out), "text": t, "x0": x0, "y0": y0, "x1": x1, "y1": y1,
                            "size": round(s.get("size", 0), 1),
                            "bold": ("Bold" in font or "Black" in font or "Heavy" in font
                                     or bool(s.get("flags", 0) & 16)),
                            "cy": (y0 + y1) / 2, "base": s.get("origin", (x0, y1))[1]})
    return out


def _rows(spans: list[dict]) -> list[list[dict]]:
    """Spans grouped into visual lines: a span joins a recent line it overlaps vertically by half its height."""
    rows: list[list[dict]] = []
    for s in sorted(spans, key=lambda s: (s["cy"], s["x0"])):
        h = s["y1"] - s["y0"]
        for g in reversed(rows[-3:]):
            gy0, gy1 = min(x["y0"] for x in g), max(x["y1"] for x in g)
            if min(gy1, s["y1"]) - max(gy0, s["y0"]) >= 0.5 * min(h, gy1 - gy0):
                g.append(s)
                break
        else:
            rows.append([s])
    return rows


def _line(g: list[dict], page_no: int, col: int, spaces: list = ()) -> Line:
    g = sorted(g, key=lambda s: s["x0"])
    ly0, ly1 = min(s["y0"] for s in g), max(s["y1"] for s in g)
    sp = [w for w in spaces if min(ly1, w["y1"]) - max(ly0, w["y0"]) > 0.3 * (ly1 - ly0)]
    sizes = Counter()
    for s in g:
        sizes[s["size"]] += len(s["text"].strip())
    dom = sizes.most_common(1)[0][0]
    bases = sorted(s["base"] for s in g if s["size"] == dom)
    base = bases[len(bases) // 2]
    for s in g:
        s["sup"] = s["size"] <= SUP_RATIO * dom and s["base"] < base - 1.0
    cells, cur, cur_x0, last_x1 = [], [], None, None
    sups, lead = [], ""
    for k, s in enumerate(g):
        t = s["text"]
        if s["sup"] and not ORDINAL_SUP.match(t.strip()):
            sups.append(t.strip())
            if not any(not x["sup"] for x in g[:k]):
                lead = lead or t.strip()
            continue
        gap = None if last_x1 is None else s["x0"] - last_x1
        if gap is not None and gap > CELL_GAP:
            cells.append((cur_x0, cur))
            cur, cur_x0 = [], None
            gap = None
        if cur_x0 is None:
            cur_x0 = s["x0"]
        if cur and gap is not None and not s["sup"] and not cur[-1]["text"].endswith(" ") \
                and not t.startswith(" ") and (gap > max(1.0, 0.2 * s["size"]) or (gap > -0.5 and any(
                    w["x0"] >= last_x1 - 1.0 and w["x1"] <= s["x0"] + 1.0 for w in sp))):
            cur.append({"text": " ", "bold": cur[-1]["bold"]})
        cur.append({"text": t, "bold": s["bold"]})
        last_x1 = s["x1"]
    if cur:
        cells.append((cur_x0, cur))
    out_cells = []
    for x0, parts in cells:
        text = clean("".join(p["text"] for p in parts))
        n = sum(len(p["text"].strip()) for p in parts) or 1
        nb = sum(len(p["text"].strip()) for p in parts if p["bold"])
        if text:
            out_cells.append((x0, text, nb / n >= 0.6))
    text = " ".join(t for _, t, _ in out_cells)
    body = [s for s in g if not s["sup"]] or g
    bold_chars = sum(len(s["text"].strip()) for s in body if s["bold"])
    all_chars = sum(len(s["text"].strip()) for s in body) or 1
    return Line(text=text, x0=min(s["x0"] for s in body), y0=min(s["y0"] for s in body),
                x1=max(s["x1"] for s in body), y1=max(s["y1"] for s in body), size=dom,
                bold=bold_chars / all_chars >= 0.6, page=page_no, col=col,
                cells=out_cells if len(out_cells) > 1 else [], sups=sups, lead_sup=lead)


def _gutter(spans: list[dict], width: float) -> float | None:
    """The centre of the widest vertical white band between 25% and 75% of the page that body-size text does not
    cross, with text on both sides; None for a single-column page."""
    sizes = Counter()
    for s in spans:
        sizes[s["size"]] += len(s["text"])
    if not sizes:
        return None
    body = sizes.most_common(1)[0][0]
    bs = [s for s in spans if abs(s["size"] - body) <= 1.5]
    if len(bs) < 12:
        return None
    ok = []
    for x in range(int(width * 0.25), int(width * 0.75), 2):
        crossing = sum(1 for s in bs if s["x0"] < x - 2 and s["x1"] > x + 2)
        left = sum(1 for s in bs if s["x1"] <= x)
        right = sum(1 for s in bs if s["x0"] >= x)
        if crossing <= max(3, len(bs) * 0.04) and left >= 8 and right >= 8:
            ok.append((x, crossing))
    if not ok:
        return None
    runs, cur = [], [ok[0]]
    for a, b in zip(ok, ok[1:]):
        if b[0] - a[0] <= 2:
            cur.append(b)
        else:
            runs.append(cur)
            cur = [b]
    runs.append(cur)
    best = max(runs, key=lambda r: (len(r), -min(c for _, c in r)))
    return float(best[len(best) // 2][0])


def _overlap(a: list[dict], b: list[dict]) -> bool:
    ay0, ay1 = min(s["y0"] for s in a), max(s["y1"] for s in a)
    by0, by1 = min(s["y0"] for s in b), max(s["y1"] for s in b)
    return min(ay1, by1) - max(ay0, by0) >= 0.5 * min(ay1 - ay0, by1 - by0)


def _columns(spans: list[dict], g: float, page_no: int, spaces: list = ()) -> list[Line]:
    """Lines of a page with a gutter at x = g: left column, right column, and lines that run across."""
    left = [s for s in spans if s["x1"] <= g + 2]
    lids = {s["i"] for s in left}
    right = [s for s in spans if s["i"] not in lids and s["x0"] >= g - 2]
    rids = {s["i"] for s in right}
    over = [s for s in spans if s["i"] not in lids and s["i"] not in rids]
    rl, rr, ro = _rows(left), _rows(right), _rows(over)
    # a column fragment on the same baseline as a crossing line is part of that line
    for frag_rows in (rl, rr):
        for r in list(frag_rows):
            for o in ro:
                if _overlap(r, o):
                    o.extend(r)
                    frag_rows.remove(r)
                    break
    # a left and a right fragment that meet at the gutter with word spacing are one full-width line
    for a in list(rl):
        for b in list(rr):
            if _overlap(a, b):
                gap = min(s["x0"] for s in b) - max(s["x1"] for s in a)
                if gap < 0.6 * max(s["size"] for s in a + b):
                    ro.append(a + b)
                    rl.remove(a)
                    rr.remove(b)
                    break
    return [_line(r, page_no, 0, spaces) for r in rl] + [_line(r, page_no, 1, spaces) for r in rr] + \
        [_line(r, page_no, -1, spaces) for r in ro]


def _order(lines: list[Line]) -> list[Line]:
    """Reading order on one page: bands separated by full-width lines; inside a band, left column then right."""
    full = sorted([ln for ln in lines if ln.col == -1], key=lambda ln: ln.y0)
    cols = [ln for ln in lines if ln.col != -1]
    if not full and all(ln.col == 0 for ln in cols):
        return sorted(cols, key=lambda ln: (round(ln.y0, 1), ln.x0))
    bounds = [ln.y0 for ln in full] + [float("inf")]
    out, prev = [], float("-inf")
    for i, b in enumerate(bounds):
        band = [ln for ln in cols if prev <= ln.y0 < b]
        out += sorted([ln for ln in band if ln.col == 0], key=lambda ln: ln.y0)
        out += sorted([ln for ln in band if ln.col == 1], key=lambda ln: ln.y0)
        if i < len(full):
            out.append(full[i])
        prev = b
    return out


def read(path: str, columns: str = "single", gutter: float | None = None, header_frac: float = 0.09,
         footer_frac: float = 0.08, noise_patterns: tuple = (), repeat_share: float = 0.4) -> PdfDoc:
    """Read a PDF into lines.

    columns: "single" | "two" (gutter at `gutter`, default page centre) | "auto" (gutter detected per page).
    noise_patterns: regexes (matched on the cleaned line text) marked wherever the line sits in the top or bottom
    band; a pattern starting with '^!' is marked anywhere on the page.
    """
    import pymupdf
    with pymupdf.open(path) as doc:
        n = doc.page_count
        width, height = doc[0].rect.width, doc[0].rect.height
        all_lines = []
        for i in range(n):
            page = doc[i]
            spaces: list = []
            spans = _spans(page, spaces)
            g = None
            if columns == "two":
                g = gutter or page.rect.width / 2
            elif columns == "auto":
                g = _gutter(spans, page.rect.width)
            if g is None:
                lines = [_line(r, i + 1, 0, spaces) for r in _rows(spans)]
            else:
                lines = _columns(spans, g, i + 1, spaces)
            all_lines += _order(lines)
    _mark_noise(all_lines, n, height, header_frac, footer_frac, noise_patterns, repeat_share)
    sizes = Counter()
    for ln in all_lines:
        if not ln.noise:
            sizes[ln.size] += len(ln.text)
    body = sizes.most_common(1)[0][0] if sizes else 11.0
    return PdfDoc(path=path, pages=n, width=width, height=height, lines=all_lines, body_size=body)


def _mark_noise(lines: list[Line], n_pages: int, height: float, header_frac: float, footer_frac: float,
                patterns: tuple, repeat_share: float) -> None:
    top, bottom = height * header_frac, height * (1 - footer_frac)
    anywhere = [re.compile(p[2:], re.I) for p in patterns if p.startswith("^!")]
    banded = [re.compile(p, re.I) for p in patterns if not p.startswith("^!")]

    def key(t: str) -> str:
        return re.sub(r"\d+", "#", clean(t).lower())

    def in_band(ln: Line) -> bool:
        cy = (ln.y0 + ln.y1) / 2
        return cy <= top or cy >= bottom

    pages_of = {}
    for ln in lines:
        if in_band(ln):
            pages_of.setdefault(key(ln.text), set()).add(ln.page)
    need = max(2, int(n_pages * repeat_share + 0.999)) if n_pages > 2 else 2
    repeated = {k for k, pages in pages_of.items() if len(pages) >= need}
    for ln in lines:
        t = clean(ln.text)
        if any(p.search(t) for p in anywhere):
            ln.noise = "pattern"
        elif in_band(ln):
            if any(p.search(t) for p in banded):
                ln.noise = "pattern"
            elif key(t) in repeated:
                ln.noise = "running header/footer"
