"""Document family profiles: how each kind of AHCCCS document marks its headings, columns and noise.

Measured on the files SB downloaded on 2026-11-01 (see the devlog for the layout facts). A new document family is
one new Profile; the reader and the sectioner do not change.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

ROMAN_UP = r"(?:I|II|III|IV|V|VI|VII|VIII|IX|X|XI|XII)"


def _upper_ratio(t: str) -> float:
    letters = [c for c in t if c.isalpha()]
    return sum(c.isupper() for c in letters) / len(letters) if letters else 0.0


def _short_label(t: str, max_len: int = 70, max_words: int = 10) -> bool:
    return len(t) <= max_len and len(t.split()) <= max_words and not re.search(r"[.:;,]$", t)


@dataclass(frozen=True)
class Ctx:
    body_size: float
    page_width: float
    first_page: bool


@dataclass(frozen=True)
class Profile:
    name: str
    heading: Callable[[object, Ctx], int | None]
    columns: str = "single"
    gutter: float | None = None
    header_frac: float = 0.09
    footer_frac: float = 0.08
    noise: tuple = ()
    rows_from_cells: bool = True             # a line with two cells is a table row (TERM: definition)
    toc_line: str = r"\.{6,}|(?:\. ){5,}"     # a table-of-contents line (dotted leader)
    roles: tuple = ()                        # (heading regex, role): purpose, definitions, history, boilerplate, toc
    cover_pages: int = 0                     # leading pages that are a cover (title, dates), not content
    dehyphenate: bool = False                # True when the typesetter hyphenates words at line ends (A.A.C.)
    strong_headings: bool = False            # headings are recognised by a pattern (R9-22-1205., III., Q4:), so a
                                             # body-size heading set tight under a paragraph is still a heading
    notes: str = ""
    extra: dict = field(default_factory=dict)


# ----------------------------------------------------------------- AMPM policies
def _ampm_heading(ln, ctx: Ctx) -> int | None:
    t = ln.text
    if ln.bold and ln.page == 1 and ln.size >= ctx.body_size + 0.5 and re.match(r"^\d{3,4}-?[A-Z0-9]*\s*-\s+\S", t):
        return 1                                                    # "320-V - BEHAVIORAL HEALTH RESIDENTIAL ..."
    if ln.bold and re.match(rf"^{ROMAN_UP}\.\s+[A-Z]", t) and _upper_ratio(t) > 0.8:
        return 2                                                    # "III. POLICY"
    if ln.bold and re.match(r"^[A-Z]\.\s+\S", t) and _upper_ratio(t) > 0.85 and len(t) < 160:
        return 3                                                    # "A. BEHAVIORAL HEALTH RESIDENTIAL FACILITY ..."
    return None


AMPM = Profile("ampm", _ampm_heading, noise=(r"^AHCCCS MEDICAL POLICY MANUAL$", r"^AHCCCS CONTRACTOR OPERATIONS MANUAL$",
                                             r"^CHAPTER \d+\s*-", r"^SECTION \d+\s*-", r"Page \d+ of \d+$",
                                             r"^SERVICES WITH SPECIAL CIRCUMSTANCES$", r"^REQUIREMENTS$",
                                             r"^QUALITY MANAGEMENT$", r"^PROVIDER REQUIREMENTS$"),
               header_frac=0.115, footer_frac=0.09, strong_headings=True,
               roles=((r"^\d{3,4}(?:-[A-Z0-9]+)?\s*-\s+\S", "title"), (r"^I\.\s+PURPOSE\b", "purpose"),
                      (r"^II\.\s+DEFINITIONS\b", "definitions")),
               notes="Outline I. / A. / 1. / a. / i.; definitions are two-cell rows; Purpose states the programs")


# ----------------------------------------------------------------- CBHSG
def _cbhsg_heading(ln, ctx: Ctx) -> int | None:
    t = ln.text
    if ln.bold and ln.size >= ctx.body_size + 4:
        return 1                                                    # 16pt bold, centred: "Billing for Services"
    if ln.bold and ln.size >= ctx.body_size + 1.5:
        return 2                                                    # 13pt bold: "Psychotherapy"
    if ln.bold and abs(ln.size - ctx.body_size) <= 0.6 and _short_label(t) and not re.match(r"^\(?\d+[.)]\s", t) \
            and not t.startswith(("Q", "Note", "NOTE")) and t[:1].isupper():
        return 3                                                    # 11pt bold label: "Billing Limitations"
    return None


CBHSG = Profile("cbhsg", _cbhsg_heading, noise=(r"^Updated\s*:", r"^\d+ of \d+$"), header_frac=0.08,
                footer_frac=0.10, cover_pages=1, roles=((r"^table of contents$", "toc"),),
                notes="16pt / 13pt / 11pt bold headings; footer 'Updated:' and 'N of 90'; footnotes mark revisions")


# ----------------------------------------------------------------- billing manuals
def _ffs_heading(ln, ctx: Ctx) -> int | None:
    t = ln.text
    if ln.bold and ln.size >= ctx.body_size + 2:
        return 1                                                    # 14pt bold ALL CAPS
    if ln.bold and abs(ln.size - ctx.body_size) <= 0.6 and _upper_ratio(t) >= 0.85 and len(t) <= 90 \
            and not t.endswith(":") and not t.startswith(("NOTE", "•")):
        return 2                                                    # 11.5pt bold ALL CAPS
    return None


FFS_MANUAL = Profile("ffs_manual", _ffs_heading,
                     noise=(r"^FEE-FOR-SERVICE PROVIDER BILLING MANUAL$", r"^CHAPTER \d+[A-Z]? [A-Z ]+$",
                            r"^\d+ \| \d+$", r"^\d{2}/\d{2}/\d{4}$"),
                     header_frac=0.08, footer_frac=0.09,
                     roles=((r"^DEFINITIONS$", "definitions"), (r"^REVISION HISTORY$", "history"),
                            (r"^REFERENCES$", "references")))


def _ihs_heading(ln, ctx: Ctx) -> int | None:
    t = ln.text
    if ln.bold and ln.size >= ctx.body_size + 3.5:
        return 1                                                    # 16pt bold
    if ln.size >= ctx.body_size + 2 and _short_label(t, 90, 14):
        return 2                                                    # 14pt regular
    if ln.bold and abs(ln.size - ctx.body_size) <= 0.6 and _short_label(t, 60, 8) and t[:1].isupper():
        return 3                                                    # 11.5pt bold label
    return None


IHS_MANUAL = Profile("ihs_manual", _ihs_heading,
                     noise=(r"^IHS/TRIBAL PROVIDER BILLING MANUAL$", r"^CHAPTER \d+ [A-Z ]+$",
                            r"^Arizona Health Care Cost Containment System$", r"^IHS/Tribal Provider Billing Manual$",
                            r"^\d+ \| [\d ]+$"),
                     header_frac=0.12, footer_frac=0.10)


# ----------------------------------------------------------------- Arizona Administrative Code
def _aac_heading(ln, ctx: Ctx) -> int | None:
    t = ln.text
    if ln.bold and re.match(r"^ARTICLE \d+\.\s+[A-Z]", t):
        return 1
    if ln.bold and re.match(r"^R\d+-\d+-\d+(?:\.\d+)?\.\s*\S", t):
        return 2                                                    # "R9-22-1205. Scope and Coverage of ..."
    if ln.bold and re.match(r"^(?:Historical|Editor's) Note$", t):
        return 3                                                    # the Section's history, not rule text
    return None


AAC = Profile("aac", _aac_heading, columns="two", noise=(r"^\d+ A\.A\.C\. \d+$", r"^Arizona Administrative Code$",
                                                        r"^TITLE \d+\. ", r"^CHAPTER \d+\. ", r"^Page \d+$",
                                                        r"^Supp\. \d+-\d$", r"^[A-Z][a-z]+ \d{1,2}, \d{4}$"),
              header_frac=0.10, footer_frac=0.07, rows_from_cells=False, dehyphenate=True, strong_headings=True,
              roles=((r"^(?:Historical|Editor's) Note$", "history"),),
              notes="Two columns, hyphenation, historical notes after each Section; list markers are separate spans")


# ----------------------------------------------------------------- notices
def _cc_heading(ln, ctx: Ctx) -> int | None:
    t = ln.text
    if len(t) > 140:
        return None
    if ln.size >= ctx.body_size + 2.5:
        return 1                                                    # 22pt article title, 14pt notice title
    if ln.bold and ln.size >= ctx.body_size + 1.5:
        return 1                                                    # 14pt bold article title over 12pt text
    if ln.size >= ctx.body_size + 0.9 and _upper_ratio(t) > 0.9 and _short_label(t, 40, 6):
        return 1                                                    # 12pt "TRAINING AND CONTACTS" sidebar title
    return None


CLAIMS_CLUES = Profile("claims_clues", _cc_heading, columns="auto",
                       noise=(r"^!^CLAIMS\s+CLUES(?: Supplemental)?$", r"^!^A Publication of the AHCCCS DFSM Claims",
                              r"^!^Please note that these materials are designed for Fee-for-Service",
                              r"^\d+$", r"^Pl\b"),
                       header_frac=0.08, footer_frac=0.06, rows_from_cells=False,
                       roles=((r"^TRAINING AND CONTACTS", "boilerplate"),))


def _faq_heading(ln, ctx: Ctx) -> int | None:
    if ln.bold and re.match(r"^Q\d+:", ln.text):
        return 1
    return None


FAQ = Profile("faq", _faq_heading, noise=(r"^AHCCCS Covered Behavioral Health$", r"^Services Guide \(CBHSG\)",
                                          r"^Frequently Asked Questions$", r"^\d+ of \d+$"),
              header_frac=0.09, footer_frac=0.08, rows_from_cells=False, strong_headings=True)


def _generic_heading(ln, ctx: Ctx) -> int | None:
    if ln.size >= ctx.body_size + 4:
        return 1
    if ln.bold and ln.size >= ctx.body_size + 1.5:
        return 2
    if ln.bold and _short_label(ln.text, 60, 8) and ln.text[:1].isupper():
        return 3
    return None


GENERIC = Profile("generic", _generic_heading)

PROFILES = {p.name: p for p in [AMPM, CBHSG, FFS_MANUAL, IHS_MANUAL, AAC, CLAIMS_CLUES, FAQ, GENERIC]}
# registry parser name -> profile
PARSER_PROFILE = {"ampm": "ampm", "cbhsg": "cbhsg", "ffs_manual": "ffs_manual", "ihs_manual": "ihs_manual",
                  "aac": "aac", "claims_clues": "claims_clues", "faq": "faq", "training_deck": "generic"}
