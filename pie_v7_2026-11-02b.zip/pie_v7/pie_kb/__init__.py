"""PIE v7: the AHCCCS policy knowledge base engine (clean start, 2026-11-02).

Sources -> versions -> sections or table rows -> records -> review -> knowledge base.
Nothing from PIE v6.3 is read or migrated. See README.md for the run order.
"""
__version__ = "7.0.0"
