"""Deterministic extraction: what a section states in a fixed form needs no model.

  definitions        a two-cell row (AMPM: TERM | definition) or a quoted-term paragraph (A.A.C.: "Agency" means ...)
  cross references   a pointer to another policy, rule or statute (AMPM Policy 820, A.A.C. R9-22-1205, A.R.S. § 36-501,
                     42 CFR 433.139, Exhibit 300-2A), one record per section and target
  service code sets  the code lists the CBHSG sets under a service ("Psychotherapy > CPT Codes: ● 90832 - ...") as
                     value sets SVC:<source>:<service>, which later resolve records that name a service instead of
                     codes
Pattern proposals go through the same grounding as the model's (origin "pattern").
"""
from __future__ import annotations

import re

from ..core import codes as C
from ..core.text import BULLETS, sentences
from .domains import bh
from .ground import WORD
from .pieces import context

SHORT_QUOTE_WORDS = 6                          # a pointer quoted in fewer words gets its lead-in

QUOTED_DEF = re.compile(r'^"([^"]{2,90})"(?:\s+or\s+"[^"]{2,90}")?\s+(?:for the purposes of this \w+,?\s+)?'
                        r"(means|has the same meaning as|as defined in|is defined (?:as|in)|means the same as)\s+(.+)$",
                        re.I | re.S)
REFS = [
    (re.compile(r"\bAMPM\s+(?:Policy\s+)?(\d{3,4}(?:-[A-Z0-9]{1,3})?)\b"), "AMPM Policy {0}"),
    (re.compile(r"\bACOM\s+(?:Policy\s+)?(\d{3,4}(?:-[A-Z0-9]{1,3})?)\b"), "ACOM Policy {0}"),
    (re.compile(r"\b(?:A\.\s?A\.\s?C\.|AAC)\s*(R\d{1,2}-\d{1,2}-\d{2,4}(?:\.\d{1,2})?)"), "A.A.C. {0}"),
    (re.compile(r"(?<![\w-])(R9-(?:10|22|28|31)-\d{2,4}(?:\.\d{1,2})?)\b"), "A.A.C. {0}"),
    (re.compile(r"\bA\.\s?R\.\s?S\.\s*§*\s*(\d{1,2}-\d{3,4}(?:\.\d{1,2})?)"), "A.R.S. § {0}"),
    (re.compile(r"\b(\d{1,2})\s+CFR\s+(?:Part\s+)?(\d{1,4}(?:\.\d{1,4})?)"), "{0} CFR {1}"),
    (re.compile(r"\bExhibit\s+(\d{3,4}-\d{1,2}[A-Z]?)\b"), "AMPM Exhibit {0}"),
]


def definition_proposals(section: dict) -> list[dict]:
    out, text = [], section["text"]
    for b in section.get("blocks") or []:
        if b.get("start", -1) < 0:
            continue
        t = text[b["start"]:b["end"]]
        if b["kind"] == "row" and b.get("cells") == 2 and ": " in t:
            term, definition = t.split(": ", 1)
            if term.strip() and definition.strip() and definition.strip()[:1].isalpha() and term.upper() == term:
                out.append({"kind": "definition", "subject": {"term": term.strip()},
                            "params": {"definition": definition.strip()}, "quote": t})
        elif b["kind"] in ("para", "item"):
            body = re.sub(r"^\S+\s+", "", t) if b["kind"] == "item" else t
            m = QUOTED_DEF.match(body.strip())
            if m:
                verb, rest = m.group(2).lower(), m.group(3).strip()
                definition = rest if verb == "means" else f"{verb} {rest}"
                out.append({"kind": "definition", "subject": {"term": m.group(1).strip()},
                            "params": {"definition": definition}, "quote": t})
    return out


def _target_sources(reg) -> dict:
    """'AMPM Policy 320-V' -> 'A11', from the registry titles; A.A.C. R9-22 -> the A.A.C. source."""
    out = {}
    if reg is None:
        return out
    for d in reg.docs:
        m = re.match(r"^AMPM\s+(\d{3,4}(?:-[A-Z0-9]{1,3})?)\b", d.title)
        if m:
            out[f"AMPM Policy {m.group(1)}"] = d.source_id
        m = re.match(r"^AMPM Exhibit\s+(\S+)", d.title)
        if m:
            out[f"AMPM Exhibit {m.group(1)}"] = d.source_id
        if d.parser == "aac":
            out["A.A.C. R9-22"] = d.source_id
    return out


def _ref_quote(section: dict, spans: list, pos: int, end: int) -> str:
    """The sentence that names the target; a short list item ("h. ACOM Policy 446.") is quoted with its lead-in
    ("... the following Policies: ... h. ACOM Policy 446."), the form grounding accepts for words in order."""
    text = section["text"]
    a, b = next(((s, e) for s, e in spans if s <= pos < e), (pos, end))
    quote = text[a:b].strip()
    if len(WORD.findall(quote)) >= SHORT_QUOTE_WORDS:
        return quote
    blk = next((x for x in section.get("blocks") or [] if x.get("start", -1) >= 0 and x["start"] <= pos < x["end"]),
               None)
    lead = context(section, blk["start"]) if blk else ()
    if blk and lead:
        return " ... ".join([text[x:y].strip() for x, y in lead] + [text[blk["start"]:blk["end"]].strip()])
    i = next((k for k, (s, e) in enumerate(spans) if s <= pos < e), None)
    if i:                                      # the sentence before it
        return text[spans[i - 1][0]:b].strip()
    return quote


def cross_reference_proposals(section: dict, reg=None) -> list[dict]:
    text, seen, out = section["text"], set(), []
    known = _target_sources(reg)
    spans = sentences(text)
    for rx, fmt in REFS:
        for m in rx.finditer(text):
            target = fmt.format(*m.groups())
            if target in seen:
                continue
            seen.add(target)
            quote = _ref_quote(section, spans, m.start(), m.end())
            params = {"target": target}
            src = known.get(target) or (known.get("A.A.C. R9-22") if target.startswith("A.A.C. R9-22-") else None)
            if src:
                params["target_source_id"] = src
            out.append({"kind": "cross_reference", "subject": {"category": section["path_text"]}, "params": params,
                        "quote": quote})
    return out


_LINE_CODE = re.compile(rf"^\s*(?:[{re.escape(BULLETS)}]\s*)?((?:[{C.HCPCS_LETTERS}D]\d{{4}})|(?:\d{{4}}[0-9FTUM])|"
                        rf"(?:0\d{{3}}))\b\s*(?:-|–|:)?\s*(.*)$")


def service_code_sets(section: dict, source_id: str, source_version_id: str) -> list[dict]:
    """kb_value_sets rows for a 'CPT Codes' / 'HCPCS Codes' / 'Revenue Codes' section under a service heading."""
    if not bh.SERVICE_LIST_HEADING.search(section.get("heading") or "") or len(section.get("path") or []) < 2:
        return []
    service = " > ".join(section["path"][:-1])
    revenue = re.search(r"revenue|\brev\b", section["heading"], re.I) is not None
    rows = []
    for line in section["text"].split("\n"):
        m = _LINE_CODE.match(line)
        if not m:
            continue
        raw, desc = m.group(1), m.group(2).strip()
        if raw.isdigit() and len(raw) == 4:
            if not revenue:
                continue
            system, code = "REVENUE", raw
        else:
            code = C.norm_procedure(raw)
            system = C.procedure_system(raw) if code else None
            if not code:
                continue
        rows.append({"value_set_id": f"SVC:{source_id}:{service}", "source_version_id": source_version_id,
                     "code": code, "code_system": system, "description": desc,
                     "attributes": {"section_id": section["section_id"], "service": service,
                                    "heading": section["heading"], "page": section.get("page_start")},
                     "effective_start": None, "effective_end": None})
    return rows
