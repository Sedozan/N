"""Model backends. A backend turns (system prompt, user message) into the model's final text, or raises.

  HFLocalBackend  openai/gpt-oss-120b through transformers and openai-harmony on Serverless GPU (environment 5:
                  transformers 4.57.1, torch 2.9.0), loaded once per process; the "final" channel is the answer, the
                  "analysis" channel (reasoning) is never returned. An answer that runs out of budget is retried once
                  at RETRY_FACTOR times the budget; still cut off, it raises Truncated and the caller splits the piece.
  ServingBackend  the same model behind an OpenAI-compatible serving endpoint (the Databricks Foundation Model API
                  endpoint databricks-gpt-oss-120b, which takes reasoning_effort low, medium or high): no GPU to
                  manage, and EXTRACT_BATCH requests run in parallel; needs the workspace to allow the endpoint
  CacheOnly       answers only from the cache, under another backend's tag: re-grounds a run on a CPU after a
                  grounding change; a message the cache does not hold is reported as needing the model
  ReplayBackend   answers from a dict or a function (tests, the format dry run)
  NoModel         patterns only: says so in every outcome, never pretends to be complete
Ported from v6.3's working loader (SB's summarization notebook pattern); the interface is new.
"""
from __future__ import annotations

import os
import time

from .. import config
from .parse import complete_json


class Truncated(RuntimeError):
    """The answer ran out of budget even after the retry: split the piece."""


class NeedsModel(RuntimeError):
    """A cache-only run met a message the cache does not hold."""


class Backend:
    name = "base"
    model = ""
    reasoning = ""

    def budget(self) -> int:
        return 0

    def complete(self, system: str, user: str, budget: int | None = None) -> str:
        raise NotImplementedError

    def tag(self) -> str:
        """What keys the answer cache besides the prompt text: model, reasoning, budget."""
        return f"{self.name}|{self.model}|{self.reasoning}|{self.budget()}"


class NoModel(Backend):
    name = "none"

    def complete(self, system: str, user: str, budget: int | None = None) -> str:
        raise RuntimeError("no model backend (patterns only)")


class CacheOnly(Backend):
    """Never calls a model. Its tag is the tag of the backend whose answers it reads, so the cache keys match."""

    def __init__(self, name: str = "hf_local", model: str | None = None, reasoning: str | None = None,
                 budget: int | None = None):
        self.name, self.model = name, model or config.HF_MODEL
        self.reasoning = reasoning or config.REASONING
        self._budget = budget or int(config.TOKEN_BUDGET.get(self.reasoning, 5000))

    @classmethod
    def like(cls, backend: "Backend") -> "CacheOnly":
        return cls(backend.name, backend.model, backend.reasoning, backend.budget())

    def budget(self) -> int:
        return self._budget

    def complete(self, system: str, user: str, budget: int | None = None) -> str:
        raise NeedsModel("not in the cache: this message needs the model")


class ReplayBackend(Backend):
    """Answers by user message (exact) or by a function; raises when it has none."""
    name = "replay"

    def __init__(self, answers: dict | None = None, fn=None, model: str = "replay", reasoning: str = "medium",
                 budget: int = 5000):
        self.answers, self.fn, self.model, self.reasoning, self._budget = answers or {}, fn, model, reasoning, budget
        self.calls = 0

    def budget(self) -> int:
        return self._budget

    def complete(self, system: str, user: str, budget: int | None = None) -> str:
        self.calls += 1
        if self.fn is not None:
            out = self.fn(system, user, budget)
        else:
            out = self.answers.get(user)
        if out is None:
            raise KeyError("no recorded answer for this message")
        if isinstance(out, Exception):
            raise out
        return out


_RT: dict = {"model": None, "tokenizer": None, "encoding": None, "model_id": None}


def load_runtime(model_id: str | None = None, token_path: str | None = None, log=print) -> dict:
    """Tokenizer, model and harmony encoding, loaded once per process (65 GB; minutes)."""
    model_id = model_id or config.HF_MODEL
    if _RT["model"] is not None and _RT["model_id"] == model_id:
        return _RT
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")   # v6.3: fragmentation at OOM
    import importlib.metadata as md

    from openai_harmony import HarmonyEncodingName, load_harmony_encoding
    from transformers import AutoModelForCausalLM, AutoTokenizer

    def ver(pkg):
        try:
            return md.version(pkg)
        except Exception:                      # noqa: BLE001 - not installed
            return "absent"
    log(f"stack: transformers {ver('transformers')} | torch {ver('torch')} | openai-harmony {ver('openai-harmony')} "
        f"(known good: Serverless GPU environment 5, transformers 4.57.1, torch 2.9.0)")
    path = config.HF_TOKEN_PATH if token_path is None else token_path
    if path and os.path.exists(path):
        from huggingface_hub import login
        with open(path) as f:
            login(f.read().strip())
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="auto", device_map="auto",
                                                 trust_remote_code=True)
    enc = load_harmony_encoding(HarmonyEncodingName.HARMONY_GPT_OSS)
    _RT.update(model=model, tokenizer=tok, encoding=enc, model_id=model_id)
    log(f"model {model_id} loaded in {time.time() - t0:.0f}s")
    return _RT


def _channel_text(msg) -> tuple:
    channel = getattr(msg, "channel", None)
    content = getattr(msg, "content", msg)
    if isinstance(content, str):
        return channel, content
    return channel, "".join(getattr(c, "text", None) or (c.get("text", "") if isinstance(c, dict) else str(c))
                            for c in (content or []))


class HFLocalBackend(Backend):
    name = "hf_local"

    def __init__(self, model_id: str | None = None, reasoning: str | None = None):
        self.model = model_id or config.HF_MODEL
        self.reasoning = reasoning or config.REASONING
        self.calls = self.retries = self.truncated = self.tokens = 0
        self.last_meta: dict = {}

    def budget(self) -> int:
        return int(config.TOKEN_BUDGET.get(self.reasoning, 5000))

    def _generate(self, messages: list, budget: int) -> tuple[str, dict]:
        import torch
        from openai_harmony import Role
        rt = _RT if _RT["model"] is not None else load_runtime(self.model)
        model, tok, enc = rt["model"], rt["tokenizer"], rt["encoding"]
        inputs = tok.apply_chat_template(messages, return_tensors="pt", add_generation_prompt=True, return_dict=True,
                                         reasoning_effort=self.reasoning)
        ids = inputs["input_ids"].to(model.device)
        t0 = time.time()
        with torch.no_grad():
            out = model.generate(ids, max_new_tokens=budget, do_sample=False)
        new = out[0][ids.shape[1]:].tolist()
        final, err = "", None
        try:
            for msg in enc.parse_messages_from_completion_tokens(new, role=Role.ASSISTANT):
                ch, text = _channel_text(msg)
                if ch == "final":
                    final = text
        except Exception as e:                  # noqa: BLE001 - recorded, decided below
            err = f"{type(e).__name__}: {e}"
        meta = {"input_tokens": int(ids.shape[1]), "tokens": len(new), "budget": budget,
                "hit_budget": len(new) >= budget - 2, "final": bool(final.strip()), "parse_error": err,
                "seconds": round(time.time() - t0, 1)}
        self.tokens += len(new)
        return final.strip(), meta

    def _safe_generate(self, messages: list, budget: int) -> tuple[str, dict]:
        try:
            return self._generate(messages, budget)
        except Exception as e:                  # noqa: BLE001 - CUDA out of memory: free the cache, report
            if "out of memory" in str(e).lower():
                import torch
                torch.cuda.empty_cache()
                raise RuntimeError(f"CUDA out of memory at budget {budget}: {str(e)[:200]}") from e
            raise

    def complete(self, system: str, user: str, budget: int | None = None) -> str:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        self.calls += 1
        b = budget or self.budget()
        final, meta = self._safe_generate(messages, b)
        cut = meta["hit_budget"] and (not meta["final"] or not complete_json(final))
        if cut and budget is None:
            self.retries += 1
            final, meta = self._safe_generate(messages, int(b * config.RETRY_FACTOR))
            meta["retried"] = True
            cut = meta["hit_budget"] and (not meta["final"] or not complete_json(final))
        self.last_meta = meta
        if cut:
            self.truncated += 1
            raise Truncated(f"answer cut off at {meta['tokens']}/{meta['budget']} tokens")
        if not meta["final"]:
            raise RuntimeError(f"no final channel ({meta['parse_error'] or 'empty'}) after {meta['tokens']} tokens")
        return final

    def complete_many(self, items: list) -> list:
        """Several (system, user) pairs in one generate() call, left-padded (EXTRACT_BATCH > 1; try it on a few
        sections with the dry run first). Each result is the final text, or an exception; a cut-off answer is
        returned as Truncated with no retry, so the caller retries that piece alone."""
        import torch
        from openai_harmony import Role
        if len(items) == 1:
            try:
                return [self.complete(*items[0])]
            except Exception as e:              # noqa: BLE001 - handed back to the caller
                return [e]
        rt = _RT if _RT["model"] is not None else load_runtime(self.model)
        model, tok, enc = rt["model"], rt["tokenizer"], rt["encoding"]
        pad = tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id
        seqs = []
        for system, user in items:
            ids = tok.apply_chat_template([{"role": "system", "content": system}, {"role": "user", "content": user}],
                                          add_generation_prompt=True, reasoning_effort=self.reasoning)
            seqs.append(list(ids["input_ids"] if isinstance(ids, dict) else ids))
        width = max(len(x) for x in seqs)
        input_ids = torch.tensor([[pad] * (width - len(x)) + x for x in seqs]).to(model.device)
        mask = torch.tensor([[0] * (width - len(x)) + [1] * len(x) for x in seqs]).to(model.device)
        budget = self.budget()
        with torch.no_grad():
            out = model.generate(input_ids=input_ids, attention_mask=mask, max_new_tokens=budget, do_sample=False,
                                 pad_token_id=pad)
        results = []
        self.calls += len(items)
        for row in out:
            new = row[width:].tolist()
            while new and new[-1] == pad:
                new.pop()
            self.tokens += len(new)
            final = ""
            try:
                for msg in enc.parse_messages_from_completion_tokens(new, role=Role.ASSISTANT):
                    ch, text = _channel_text(msg)
                    if ch == "final":
                        final = text.strip()
            except Exception as e:              # noqa: BLE001 - this item is retried alone
                results.append(RuntimeError(f"harmony parse failed in a batch: {e}"))
                continue
            if len(new) >= budget - 2 and (not final or not complete_json(final)):
                results.append(Truncated(f"answer cut off at {len(new)}/{budget} tokens in a batch"))
            elif not final:
                results.append(RuntimeError("no final channel in a batch"))
            else:
                results.append(final)
        return results

    def healthcheck(self) -> tuple[bool, str]:
        try:
            t0 = time.time()
            reply = self.complete("Reply with one JSON object.", 'Return exactly {"records": [], "none_reason": "ok"}',
                                  budget=600)
            return True, f"{self.model} ok in {time.time() - t0:.0f}s ({self.reasoning}): {reply[:80]!r}"
        except Exception as e:                  # noqa: BLE001 - reported to the notebook
            return False, f"{self.model} failed: {type(e).__name__}: {e}"


def _message_text(message) -> str:
    """The answer text of a chat completion message: a string, or the text parts of a list (reasoning parts are
    left out)."""
    content = getattr(message, "content", None)
    if content is None and isinstance(message, dict):
        content = message.get("content")
    if isinstance(content, str):
        return content
    out = []
    for part in content or []:
        typ = part.get("type") if isinstance(part, dict) else getattr(part, "type", None)
        text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
        if typ in (None, "text", "output_text") and text:
            out.append(text)
    return "".join(out)


class ServingBackend(Backend):
    """An OpenAI-compatible chat completions client. In a Databricks notebook:
        from databricks.sdk import WorkspaceClient
        client = WorkspaceClient().serving_endpoints.get_open_ai_client()
        backend = ServingBackend(client, "databricks-gpt-oss-120b", "medium")
    Temperature 0, so the cache holds what the endpoint would answer again. Transient errors (rate limits, 5xx,
    timeouts) are retried with backoff; an answer cut off at max_tokens is retried once at RETRY_FACTOR."""
    name = "serving"

    def __init__(self, client, endpoint: str | None = None, reasoning: str | None = None, attempts: int = 4,
                 backoff_seconds: float = 5.0):
        self.client = client
        self.model = endpoint or config.SERVING_ENDPOINT
        self.reasoning = reasoning or config.REASONING
        self.attempts, self.backoff = attempts, backoff_seconds
        self.calls = self.retries = self.truncated = self.tokens = 0
        self.last_meta: dict = {}

    def budget(self) -> int:
        return int(config.TOKEN_BUDGET.get(self.reasoning, 5000))

    def _once(self, system: str, user: str, budget: int) -> tuple[str, dict]:
        last = None
        for attempt in range(self.attempts):
            t0 = time.time()
            try:
                r = self.client.chat.completions.create(
                    model=self.model, messages=[{"role": "system", "content": system},
                                                {"role": "user", "content": user}],
                    max_tokens=budget, temperature=0, reasoning_effort=self.reasoning)
            except Exception as e:              # noqa: BLE001 - transient errors are retried below
                last = e
                status = getattr(e, "status_code", None) or getattr(getattr(e, "response", None), "status_code",
                                                                    None)
                transient = status in (408, 409, 429, 500, 502, 503, 504) or "timeout" in str(e).lower() or \
                    type(e).__name__ in ("APITimeoutError", "APIConnectionError", "RateLimitError",
                                         "InternalServerError", "Timeout", "ConnectionError")
                if not transient or attempt + 1 == self.attempts:
                    raise
                time.sleep(self.backoff * (2 ** attempt))
                continue
            choice = r.choices[0]
            text = _message_text(choice.message).strip()
            usage = getattr(r, "usage", None)
            out_tokens = int(getattr(usage, "completion_tokens", 0) or 0)
            self.tokens += out_tokens
            meta = {"tokens": out_tokens, "budget": budget, "finish_reason": getattr(choice, "finish_reason", None),
                    "input_tokens": int(getattr(usage, "prompt_tokens", 0) or 0), "final": bool(text),
                    "hit_budget": getattr(choice, "finish_reason", None) == "length",
                    "seconds": round(time.time() - t0, 1)}
            return text, meta
        raise RuntimeError(f"serving endpoint failed: {last}")

    def complete(self, system: str, user: str, budget: int | None = None) -> str:
        self.calls += 1
        b = budget or self.budget()
        text, meta = self._once(system, user, b)
        cut = meta["hit_budget"] and not complete_json(text)
        if cut and budget is None:
            self.retries += 1
            text, meta = self._once(system, user, int(b * config.RETRY_FACTOR))
            meta["retried"] = True
            cut = meta["hit_budget"] and not complete_json(text)
        self.last_meta = meta
        if cut:
            self.truncated += 1
            raise Truncated(f"answer cut off at {meta['tokens']}/{meta['budget']} tokens")
        if not text:
            raise RuntimeError(f"empty answer (finish_reason {meta['finish_reason']})")
        return text

    def complete_many(self, items: list) -> list:
        """Parallel requests, one per (system, user); a cut-off answer comes back as Truncated with no retry, so
        the caller retries that piece alone (as with the local batch)."""
        from concurrent.futures import ThreadPoolExecutor

        def one(item):
            system, user = item
            try:
                self.calls += 1
                text, meta = self._once(system, user, self.budget())
                if meta["hit_budget"] and not complete_json(text):
                    return Truncated(f"answer cut off at {meta['tokens']}/{meta['budget']} tokens in a batch")
                return text if text else RuntimeError("empty answer in a batch")
            except Exception as e:              # noqa: BLE001 - handed back to the caller
                return e
        with ThreadPoolExecutor(max_workers=max(1, len(items))) as pool:
            return list(pool.map(one, items))

    def healthcheck(self) -> tuple[bool, str]:
        try:
            t0 = time.time()
            reply = self.complete("Reply with one JSON object.", 'Return exactly {"records": [], "none_reason": "ok"}',
                                  budget=600)
            return True, f"{self.model} ok in {time.time() - t0:.0f}s ({self.reasoning}): {reply[:80]!r}"
        except Exception as e:                  # noqa: BLE001 - reported to the notebook
            return False, f"{self.model} failed: {type(e).__name__}: {e}"
