"""The model's answer as proposals: the JSON object it was asked for, read tolerantly (code fences, text around the
object, a trailing comma), and checked for shape before any record is built."""
from __future__ import annotations

import json
import re


class AnswerError(ValueError):
    """The answer is not the JSON object the prompt asks for."""


def _objects(text: str):
    """Every balanced {...} in the text, last first (the answer is the last object; reasoning may precede it)."""
    out, depth, start, in_str, esc = [], 0, None, False, False
    for i, ch in enumerate(text):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}" and depth:
            depth -= 1
            if depth == 0 and start is not None:
                out.append(text[start:i + 1])
    return list(reversed(out))


def complete_json(text: str) -> bool:
    """Whether the text holds at least one balanced JSON object (a truncated answer does not)."""
    return any(_load(o) is not None for o in _objects(text or ""))


def _load(s: str):
    try:
        return json.loads(s)
    except ValueError:
        try:
            return json.loads(re.sub(r",\s*([}\]])", r"\1", s))        # a trailing comma
        except ValueError:
            return None


def read_answer(text: str) -> dict:
    """{"records": [...], "none_reason": ...} from the model's final text."""
    t = re.sub(r"```(?:json)?", "", text or "").strip()
    for obj in _objects(t):
        d = _load(obj)
        if isinstance(d, dict) and isinstance(d.get("records"), list):
            return {"records": [r for r in d["records"] if isinstance(r, dict)], "none_reason": d.get("none_reason")}
    raise AnswerError("no JSON object with a 'records' list in the answer")
