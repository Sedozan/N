"""The answer cache: a model answer is asked once per (prompt, message, model, reasoning, budget).

The message carries the source, the section path, its applicability and its text, not the version date or the pages,
so a section that did not change between two versions of a document hits the cache and costs no GPU time.

An entry is an answer, or a split marker: the message's answer ran out of budget even after the retry, so the piece
was cut in two and its halves were asked instead. With greedy decoding the same message gives the same answer, so
the next run goes straight to the halves instead of paying for two cut-off answers again. A failure (an error, an
answer cut off at the last resort) is never an entry: the piece is asked again by the next run.

Each run writes the entries it added to its own answers.jsonl, and reads every earlier run's file as seeds. The file
is written whole (local temporary file, then copied): Unity Catalog volumes do not support appending to a file.
"""
from __future__ import annotations

import glob
import json
import os
import shutil
import tempfile

from ..core.hashing import sha256_text


def key(system: str, user: str, tag: str) -> str:
    return sha256_text(f"{system}\x00{user}\x00{tag}")[:32]


def seed_files(runs_dir: str, exclude: str | None = None) -> list:
    """Every earlier run's answers file, oldest first (a later answer to the same key wins)."""
    files = sorted(glob.glob(os.path.join(runs_dir, "*", "answers.jsonl")), key=os.path.getmtime)
    return [f for f in files if not exclude or os.path.abspath(f) != os.path.abspath(exclude)]


def write_whole(path: str, lines: list[str]) -> None:
    """Write a text file in one sequential pass from a local copy (safe on a Unity Catalog volume)."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix=".jsonl")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for line in lines:
                f.write(line + "\n")
        shutil.copyfile(tmp, path)
    finally:
        os.remove(tmp)


class AnswerCache:
    def __init__(self, path: str | None = None, seed_paths: list | None = None):
        self.path = path
        self.data: dict = {}
        self.own: dict = {}                      # entries this run added, written to `path`
        self.dirty = False
        for p in seed_paths or []:
            self._load(p, own=False)
        if path:
            self._load(path, own=True)           # a resumed run keeps what it already wrote

    def _load(self, p: str, own: bool) -> None:
        if not p or not os.path.exists(p):
            return
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    k = d["key"]
                except (ValueError, KeyError):
                    continue
                self.data[k] = d
                if own:
                    self.own[k] = d

    def lookup(self, k: str) -> dict | None:
        """{"answer": text} or {"split": True}, or None when the message was never answered."""
        return self.data.get(k)

    def get(self, k: str) -> str | None:
        d = self.data.get(k)
        return d.get("answer") if d else None

    def put(self, k: str, answer: str, meta: dict | None = None) -> None:
        self._add({"key": k, "answer": answer, "split": False, "meta": meta or {}})

    def put_split(self, k: str, meta: dict | None = None) -> None:
        self._add({"key": k, "answer": None, "split": True, "meta": meta or {}})

    def _add(self, d: dict) -> None:
        self.data[d["key"]] = d
        self.own[d["key"]] = d
        self.dirty = True

    def flush(self) -> int:
        if not self.path or not self.dirty:
            return 0
        write_whole(self.path, [json.dumps(d, ensure_ascii=False) for d in self.own.values()])
        self.dirty = False
        return len(self.own)
