"""The behavioral health domain pack: what is particular to AHCCCS BH text, kept out of the core.

  PROMPT_NOTES          phrasing the model meets in BH sources (per diems, practitioner levels, same provider);
                        words only, never a code, so the model cannot copy a value from the prompt
  SERVICE_LIST_HEADING  the headings under which the CBHSG lists a service's codes ("CPT Codes", "HCPCS Code",
                        "Revenue Codes"); those lists become service value sets (SVC:...), which later resolve a
                        record that names a service instead of codes
A new domain (dental, pharmacy) is a sibling module with the same names.
"""
from __future__ import annotations

import re

NAME = "BH"

PROMPT_NOTES = """BEHAVIORAL HEALTH NOTES
- A per diem code pays for a whole day of a program or residential stay. "Included in the per diem", "inclusive of",
  "all-inclusive" or "cannot be billed separately" make an included_in record with the per diem codes (or the program
  named) as parent.
- BHP (behavioral health professional), BHT (technician) and BHPP (paraprofessional) are practitioner levels: who may
  provide or supervise a service is provider_qualification; which AHCCCS provider type codes may bill is
  provider_type_rule.
- "Same provider" means member_provider_day; "any provider" or "regardless of provider" means member_day.
- A threshold above which documents must accompany the claim (Claims Clues) is documentation_required with
  threshold_units; it caps nothing.
- "TRBHA", "AIHP", "Tribal ALTCS", "DDD THP", "IHS/638" name programs or settings: a program condition, or a setting
  condition for IHS/638 facilities.
- A section that lists a service's codes with their descriptions ("CPT Codes", "HCPCS Codes", "Revenue Codes") is read
  by the program as the service's code set: return no record per listed code. Return the rules the section states
  about the codes (who may bill them, limits, modifiers, documentation), naming the list token when a rule covers the
  whole list.
- A service named without a code ("respite services are limited to N hours per year") keeps that name as the subject
  category; the program resolves it to the service's codes."""

SERVICE_LIST_HEADING = re.compile(r"\b(?:CPT|HCPCS|Revenue|Rev\.?)\b.*\bCodes?\b|\bCodes?\b.*\b(?:CPT|HCPCS)\b", re.I)
