"""Grounding: a model's proposal becomes a record only when the section says it.

  quote     the quoted words must appear in the section, in order (spacing, punctuation, quote glyphs and case aside);
            an ellipsis splits the quote into parts that must appear in that order; the record cites the section's
            own words, not the model's copy
  codes     every code the record names is in its quote, or in a list token the quote carries (or a bulleted list
            that follows the quoted lead-in); a partner equal to the subject is dropped
  numbers   every number in the parameters and in an age condition is in the quote, as digits or as words, in the
            sentence that names the subject (or its lead-in); digits inside codes, dates, citations and outline
            markers never count
  values    every modifier and place of service the record names is written in the quote; a provider type, period
            or condition value not written there is flagged (refused when the quote states another period, or when
            the section does not hold the value at all)
  dates     a stated start or end date is in the quote (else the date is dropped, the record kept and flagged)
  sense     a contradiction (PA "required" where the quote says not required) is refused; a negative kind whose
            quote has no negative word is kept and flagged
A refused proposal is kept in kb_proposals with its reason; nothing the model said is lost from the record.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import timedelta

from ..core import codes as C
from ..core import dates as D
from ..core.text import sentences
from ..core.kinds import KINDS
from ..core.record import Record, finalize
from .lists import TOKEN, Tokenized

WORD = re.compile(r"[A-Za-z0-9]+")
MIN_QUOTE_WORDS = 4
NEGATION = re.compile(r"\b(?:not|no|never|cannot|can't|nor|none|prohibit\w*|exclud\w*|disallow\w*|den(?:y|ied|ial)|"
                      r"only|unless|except\w*|bundled|included|inclusive|separately|neither)\b", re.I)
NOT_REQUIRED = re.compile(r"\b(?:not\s+(?:be\s+)?required|does\s+not\s+require|do\s+not\s+require|no\s+prior\s+auth|"
                          r"not\s+req'?d)\b", re.I)
NUMBER_PARAMS = ("max", "threshold_units", "max_amount", "min_age", "below_age")
CODE_LIST_PARAMS = ("partners", "parent_codes")
_UNITS = {w: i for i, w in enumerate("zero one two three four five six seven eight nine ten eleven twelve thirteen "
                                     "fourteen fifteen sixteen seventeen eighteen nineteen".split())}
_TENS = {w: 10 * i for i, w in enumerate("_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()) if i > 1}


@dataclass
class Outcome:
    record: Record | None
    kept: bool
    reason: str = ""
    checks: dict = field(default_factory=dict)


# ------------------------------------------------------------------ quotes
def _find_seq(words: list, q: list, pos: int) -> int | None:
    n = len(q)
    for i in range(pos, len(words) - n + 1):
        if words[i] == q[0] and words[i:i + n] == q:
            return i
    return None


def find_quote(text: str, quote: str, min_words: int = MIN_QUOTE_WORDS) -> tuple[int, int] | None:
    """(start, end) of the quote in text, or None."""
    toks = [(m.start(), m.end(), m.group(0).lower()) for m in WORD.finditer(text or "")]
    words = [t[2] for t in toks]
    parts = [p for p in re.split(r"\.{3,}|…", quote or "") if WORD.search(p)]
    if not parts or (len(parts) > 1 and any(len(WORD.findall(p)) < 2 for p in parts)):
        return None                              # a one-word part can be matched anywhere: no evidence
    total = sum(len(WORD.findall(p)) for p in parts)
    if total < min(min_words, len(words)):
        return None
    pos, first, last = 0, None, None
    for part in parts:
        q = [w.lower() for w in WORD.findall(part)]
        i = _find_seq(words, q, pos)
        if i is None:
            return None
        first = i if first is None else first
        last, pos = i + len(q) - 1, i + len(q)
    return toks[first][0], toks[last][1]


# ------------------------------------------------------------------ numbers
def _word_number(tokens: list) -> list:
    out, i = [], 0
    while i < len(tokens):
        t = tokens[i]
        val = None
        if t in _UNITS:
            val = _UNITS[t]
        elif t in _TENS:
            val = _TENS[t]
            if i + 1 < len(tokens) and tokens[i + 1] in _UNITS and _UNITS[tokens[i + 1]] < 10:
                val += _UNITS[tokens[i + 1]]
                i += 1
        if val is not None:
            if i + 1 < len(tokens) and tokens[i + 1] == "hundred":
                val *= 100
                i += 1
            elif i + 1 < len(tokens) and tokens[i + 1] == "thousand":
                val *= 1000
                i += 1
            out.append(float(val))
        i += 1
    return out


def numbers_in(text: str) -> set:
    nums = {float(n.replace(",", "")) for n in re.findall(r"\d[\d,]*(?:\.\d+)?", text or "") if n.replace(",", "")}
    words = re.findall(r"[a-z]+", (text or "").lower().replace("-", " "))
    return nums | set(_word_number(words))


_CITE = re.compile(r"\bR\d{1,2}-\d{1,2}-\d{2,4}(?:\.\d{1,2})?|\b\d{1,2}\s*CFR\s*(?:Part\s*)?[\d.]+|"
                   r"\b(?:A\.\s?R\.\s?S\.|ARS)\s*§*\s*\d{1,2}-\d{3,4}(?:\.\d+)?|"
                   r"\b(?:Policy|Exhibit|Chapter|Section|Article|Rule|Attachment|§)\s*\d[\w.-]*", re.I)
_OUTLINE = re.compile(r"(?m)^\s*(?:\d{1,2}|[A-Za-z]|[ivxIVX]{1,4})[.)]\s")


def masked(text: str) -> str:
    """The text with procedure and diagnosis codes, ranges, dates, citations and outline markers blanked out, so
    their digits never pass for a number the record states ('H0004' is not a 4, 'R9-22-1205' not a 22)."""
    text = text or ""
    spans = [(a, b) for *_, a, b in C.ranges_in(text)] + [(a, b) for _, a, b in C.procedure_codes_in(text)] + \
        [(a, b) for _, a, b in C.diagnosis_codes_in(text)]
    for rx in (D.MDY_RE, D.MONTH_DAY_YEAR_RE, D.MONTH_YEAR_RE, D.ISO_RE, _CITE, _OUTLINE):
        spans += [m.span() for m in rx.finditer(text)]
    chars = list(text)
    for a, b in spans:
        chars[a:b] = " " * (b - a)
    return "".join(chars)


def _written(value, text: str, case: bool = True) -> bool:
    return re.search(rf"(?<![A-Za-z0-9]){re.escape(str(value))}(?![A-Za-z0-9])", text or "",
                     0 if case else re.I) is not None


PERIOD_WORDS = {"day": r"\bdays?\b|\bdaily\b|date of service|per diem|24[- ]hours?", "week": r"\bweeks?\b|\bweekly\b",
                "month": r"\bmonths?\b|\bmonthly\b",
                "year": r"\byears?\b|\bannual(?:ly)?\b|\byearly\b|12[- ]months?",
                "benefit_year": r"benefit year|contract year|fiscal year|\byears?\b|\bannual(?:ly)?\b|october 1",
                "lifetime": r"\blifetime\b", "stay": r"\bstays?\b|\badmissions?\b", "episode": r"\bepisodes?\b",
                "session": r"\bsessions?\b|\bvisits?\b|\bencounters?\b", "line": r"\blines?\b|\bper unit\b"}


def _number_text(quote: str, subject_codes: list) -> str:
    """The sentences of the quote that name a subject code, with any lead-in ending in ':' (the whole quote when no
    sentence names one, for a record about a named service)."""
    if not subject_codes:
        return quote
    want = set(subject_codes)
    keep = []
    for a, b in sentences(quote):
        sent = quote[a:b]
        found = {c for c, *_ in C.procedure_codes_in(sent)} | {x for lo, hi, *_ in C.ranges_in(sent) for x in (lo, hi)}
        if found & want or sent.rstrip().endswith(":"):
            keep.append(sent)
    return " ".join(keep) if keep else quote


def dates_in(text: str) -> set:
    out = {d.isoformat() for d in D.all_mdy(text or "")}
    for m in D.MONTH_DAY_YEAR_RE.finditer(text or ""):
        d = D.any_date(m.group(0))
        if d:
            out.add(d.isoformat())
    return out


# ------------------------------------------------------------------ the check
def _expand_codes(values, tk: Tokenized) -> tuple[list, list, list]:
    """(codes, list tokens named, invalid entries) of a code list from the model."""
    codes, tokens, bad = [], [], []
    for v in values or []:
        s = str(v).strip().strip("[]").upper()
        if TOKEN.fullmatch(f"[{s}]") and s in tk.lists:
            tokens.append(s)
            codes += tk.codes(s)
            continue
        n = C.norm_procedure(s)
        (codes.append(n) if n else bad.append(str(v)))
    return list(dict.fromkeys(codes)), tokens, bad


def _allowed_codes(quote_span: str, model_quote: str, tk: Tokenized, tokens: list, quote_end: int,
                   universe) -> set:
    allowed = {c for c, *_ in C.procedure_codes_in(quote_span)}
    for lo, hi, *_ in C.ranges_in(quote_span):
        allowed |= set(C.expand_range(lo, hi, universe))
    named = set(TOKEN.findall(model_quote or ""))
    for t in tokens:
        cl = tk.lists[t]
        follows = cl.kind == "bullets" and 0 <= cl.start - quote_end <= 250     # a lead-in and the list under it
        if t in named or follows:
            allowed |= set(cl.codes)
    return allowed


def ground(prop: dict, section: dict, tk: Tokenized, ctx: dict) -> Outcome:
    """Check one proposal against its section; build the record when it holds.

    ctx: doc (SourceDoc), source_version_id, universe (codes for range expansion), extraction (run metadata), origin,
    part (the piece of a long section), span (the piece's (start, end) in the section: the quote is looked for there
    first, then in the whole section), context (spans of the lead-ins shown with the piece: a quote of one of them
    counts as the lead-in of the list that opens the piece)."""
    text = section["text"]
    kind = str(prop.get("kind") or "").strip()
    checks: dict = {}
    if kind not in KINDS:
        return Outcome(None, False, f"unknown kind {kind!r}")
    mq = str(prop.get("quote") or "")
    lo, hi = ctx.get("span") or (0, len(text))
    span = find_quote(text[lo:hi], tk.expand(mq))
    span = (span[0] + lo, span[1] + lo) if span else find_quote(text, tk.expand(mq))
    if span is None:
        return Outcome(None, False, "quote not found in the section", {"quote": mq[:300]})
    q0, q1 = span
    anchor = lo if any(a <= q0 and q1 <= b for a, b in ctx.get("context") or ()) else q1
    quote = re.sub(r"\s+", " ", text[q0:q1]).strip()
    checks["quote"] = "found"
    flags = []
    subj = prop.get("subject") if isinstance(prop.get("subject"), dict) else {}
    subject, tokens_used, bad = {}, [], []
    if subj.get("codes") is not None:
        codes, tks, b = _expand_codes(subj.get("codes") if isinstance(subj.get("codes"), list) else
                                      [subj.get("codes")], tk)
        subject["codes"], tokens_used, bad = codes, tks, b
    for k in ("category", "term"):
        if subj.get(k):
            subject[k] = str(subj[k])
    params = dict(prop.get("params") or {}) if isinstance(prop.get("params"), dict) else {}
    for name in CODE_LIST_PARAMS:
        if name in params:
            codes, tks, b = _expand_codes(params[name] if isinstance(params[name], list) else [params[name]], tk)
            params[name], tokens_used, bad = codes, tokens_used + tks, bad + b
    if bad:
        flags.append({"code": "invalid_code", "text": f"not valid procedure codes, left out: {bad[:8]}"})
    universe = ctx.get("universe") or set()
    allowed = _allowed_codes(quote, mq, tk, tokens_used, anchor, universe)
    named = list(subject.get("codes") or []) + [c for n in CODE_LIST_PARAMS for c in params.get(n) or []]
    missing = sorted({c for c in named if c not in allowed})
    if missing:
        return Outcome(None, False, f"codes not in the quote: {missing[:8]}", {"quote": quote[:300]})
    if subject.get("codes"):
        for n in CODE_LIST_PARAMS:
            if params.get(n):
                params[n] = [c for c in params[n] if c not in subject["codes"]] if len(subject["codes"]) == 1 else \
                    params[n]
    checks["codes"] = "in quote"
    nums = numbers_in(masked(_number_text(quote, subject.get("codes") or [])))
    conds = [c for c in (prop.get("conditions") or []) if isinstance(c, dict)]
    wanted = [(n, params[n]) for n in NUMBER_PARAMS if isinstance(params.get(n), (int, float))
              and not isinstance(params.get(n), bool)]
    wanted += [(f"condition {c.get('type')} {k}", c[k]) for c in conds if c.get("type") == "age"
               for k in ("min_age", "below_age") if isinstance(c.get(k), (int, float))]
    off = [(n, v) for n, v in wanted if float(v) not in nums and not (n.endswith("below_age") and float(v) - 1 in nums)]
    if off:
        return Outcome(None, False, f"numbers not in the quote (in the sentence naming the subject): {off}",
                       {"quote": quote[:300]})
    checks["numbers"] = "in quote" if wanted else "none"
    refusal, value_flags = _check_values(kind, params, conds, quote, text)
    if refusal:
        return Outcome(None, False, refusal, {"quote": quote[:300]})
    flags += value_flags
    checks["values"] = "in quote" if not value_flags else "flagged"
    if len(sentences(quote)) > 3:
        flags.append({"code": "long_quote", "text": f"the quote runs over {len(sentences(quote))} sentences: check "
                                                    f"that each value belongs to this record"})
    if kind == "prior_auth_rule" and params.get("requirement") == "required" and NOT_REQUIRED.search(quote):
        return Outcome(None, False, "prior authorization 'required' where the quote says it is not required")
    negative = kind in ("not_covered", "pair_prohibited", "included_in") or params.get("mode") == "not_allowed" or \
        (kind == "telehealth_rule" and params.get("allowed") is False) or \
        (kind == "prior_auth_rule" and params.get("requirement") == "not_required")
    if negative and not NEGATION.search(quote):
        flags.append({"code": "negation", "text": "a negative record whose quote has no negative word"})
    start = end = None
    stated = dates_in(quote)
    for key in ("effective", "end"):
        v = prop.get(key)
        d = D.to_date(v) if v else None
        if not d:
            continue
        ok = d.isoformat() in stated or (key == "end" and (d + timedelta(days=1)).isoformat() in stated)
        if not ok:
            flags.append({"code": "date_not_in_quote", "text": f"{key} {d.isoformat()} is not in the quote; dropped"})
            continue
        if key == "effective":
            start = d.isoformat()
        else:
            end = d.isoformat()
    exceptions = []
    for e in prop.get("exceptions") or []:
        e = str(e).strip()
        if not e:
            continue
        if find_quote(text, tk.expand(e), min_words=2) is None:
            flags.append({"code": "exception_not_found", "text": f"exception not found in the section: {e[:120]}"})
        exceptions.append({"text": tk.expand(e)})
    if prop.get("discretionary") is True:
        flags.append({"code": "discretionary", "text": "the text says may (not shall): a finding is discretionary"})
    note = prop.get("note")
    if note:
        flags.append({"code": "model_note", "text": str(note)[:300]})
    from ..parse.sections import locate
    loc = locate(section, q0, q1)
    locator = f"p.{loc['page']}" + (f"-{loc['pages'][-1]}" if len(loc["pages"]) > 1 else "") + \
        f" {section.get('heading') or ''}".rstrip() + (f" {loc['item']}" if loc.get("item") else "") + \
        (f" ({loc['locator']})" if loc.get("locator") else "")
    doc = ctx["doc"]
    rec = Record(kind=kind, subject=subject, params=params,
                 citation={"source_id": doc.source_id, "document_key": doc.document_key,
                           "source_version_id": ctx["source_version_id"], "section_id": section["section_id"],
                           "section_key": section.get("section_key"), "section_path": section["path_text"],
                           "page_start": loc["page"], "page_end": loc["pages"][-1], "item": loc.get("item", ""),
                           "locator": locator, "quote": quote, "title": doc.title},
                 conditions=conds, exceptions=exceptions, applicability=dict(section.get("applicability") or {}),
                 effective_start=start, effective_end=end,
                 window_basis="stated" if (start or end) else "version", origin=ctx.get("origin", "model"),
                 authority_level=doc.authority_level, jurisdiction=doc.jurisdiction, binding=doc.binding,
                 flags=flags, confidence=None,
                 extraction={**ctx.get("extraction", {}), "part": ctx.get("part", ""),
                             "list_tokens": sorted(set(tokens_used)), "note": note},
                 status="needs_review" if flags else "proposed")
    rec = finalize(rec)
    problems = rec.problems()
    if problems:
        return Outcome(None, False, "; ".join(problems), checks)
    return Outcome(rec, True, "", checks)


def _check_values(kind: str, params: dict, conds: list, quote: str, section_text: str) -> tuple[str, list]:
    """(refusal reason or '', flags) for the coded values a record names besides procedure codes."""
    flags = []
    mods = [m for m in params.get("modifiers") or []]
    pos = [p for p in params.get("pos") or []]
    gone = [m for m in mods if not _written(m, quote)]
    if gone:
        return f"modifiers not in the quote: {gone[:8]}", []
    gone = [p for p in pos if not _written(p, quote)]
    if gone:
        return f"places of service not in the quote: {gone[:8]}", []
    pts = [p for p in params.get("provider_types") or [] if not _written(p, quote)]
    if pts:
        flags.append({"code": "value_not_written", "text": f"provider type(s) {pts[:8]} are not written in the quote: "
                                                           f"the model's reading of the provider named there"})
    per = params.get("per")
    if per in PERIOD_WORDS and not re.search(PERIOD_WORDS[per], quote, re.I):
        others = [p for p, rx in PERIOD_WORDS.items() if p != per and re.search(rx, quote, re.I)
                  and not (per == "year" and p == "benefit_year") and not (per == "benefit_year" and p == "year")]
        if others:
            return f"the quote states a period ({', '.join(others)}), not {per}", []
        flags.append({"code": "period_not_written", "text": f"the period '{per}' is not written in the quote"})
    for c in conds:
        typ = c.get("type")
        vals = [v for k in ("include", "exclude", "present", "absent", "codes") for v in (c.get(k) or [])]
        if typ in ("place_of_service", "modifier", "provider_type", "diagnosis", "program", "delivery_system"):
            case = typ in ("place_of_service", "modifier", "diagnosis")
            missing = [v for v in vals if not _written(v, section_text, case)]
            if missing and typ in ("place_of_service", "modifier", "diagnosis"):
                return f"{typ.replace('_', ' ')} condition values not in the section: {missing[:8]}", []
            if missing:
                flags.append({"code": "value_not_written", "text": f"{typ.replace('_', ' ')} condition {missing[:8]} "
                                                                   f"is not written in the section"})
            elif [v for v in vals if not _written(v, quote, case)]:
                flags.append({"code": "condition_outside_quote", "text": f"the {typ.replace('_', ' ')} condition "
                                                                         f"comes from outside the quote"})
        elif typ in ("setting", "member_attribute", "service_context", "other") and c.get("text"):
            if find_quote(section_text, str(c["text"]), min_words=1) is None:
                flags.append({"code": "condition_not_written", "text": f"condition '{str(c['text'])[:80]}' is not "
                                                                       f"in the section's words"})
    return "", flags
