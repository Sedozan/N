"""The extraction prompt: what the model is asked, in one versioned text.

The kind catalogue is generated from core/kinds.py, so the prompt and the validator never disagree on a parameter.
The rules carry what v6.3 learned on chapter 19 (one record per obligation, exempting versus narrowing clauses, list
handling, hours are not units) rewritten for the v7 record. The prompt's sha is part of the answer cache key: an edit
never reuses an answer to the earlier text.
"""
from __future__ import annotations

import json

from ..core.hashing import sha256_text
from ..core.kinds import CONDITION_TYPES, KINDS

PROMPT_VERSION = "v7.1"


def _param_sig(p) -> str:
    t = p.type
    if t == "enum":
        t = "|".join(p.choices)
    elif t == "list_codes":
        t = "[codes or list token]"
    elif t in ("list_pt", "list_mod", "list_pos", "list_str"):
        t = "[" + {"list_pt": "provider types", "list_mod": "modifiers", "list_pos": "places of service",
                   "list_str": "text"}[t] + "]"
    return t + ("" if p.required else "?")


def kind_catalogue() -> str:
    lines = []
    for k in KINDS.values():
        params = ", ".join(f"{n}: {_param_sig(p)}" for n, p in k.params.items()) or "none"
        lines.append(f"  {k.name:<24} {k.summary} Params: {params}")
    return "\n".join(lines)


def condition_catalogue() -> str:
    return "\n".join(f"  {t:<17} {', '.join(keys)}" for t, keys in CONDITION_TYPES.items())


SYSTEM_PROMPT = f"""You read one section of an Arizona Medicaid (AHCCCS) behavioral health policy source and return every
rule, limit, requirement, permission, definition and pointer it states, as JSON records. You are an extractor, not a
decider: return only what the TEXT states, quote it word for word, and flag what is unclear instead of resolving it.
Never invent a code, number, date, provider type, modifier or quote. The examples below show the form only; never
copy a value from them.

OUTPUT: one JSON object and nothing else:
{{"records": [...], "none_reason": null}}
Each record:
  "kind"        one of the kinds below
  "subject"     what the record is about: {{"codes": ["H0004"]}}, {{"codes": ["L1"]}} for a whole list, {{"category":
                "the service as written"}} when the text names a service but no code, or {{"term": "..."}} for a definition
  "params"      the kind's parameters (below); a code list parameter may name a list token ("partners": ["L2"])
  "conditions"  typed conditions that NARROW when the record applies (below); [] when none
  "exceptions"  the verbatim clauses that EXEMPT cases ("unless ...", "except ...", "excluding ..."); [] when none
  "quote"       the exact sentence(s) of the TEXT that state the record, copied character for character; a list token
                stays as written ("[L1]")
  "effective"   "YYYY-MM-DD" only when the quote says the rule starts on a date ("effective with dates of service on
                and after May 3, 2023"); else null
  "end"         "YYYY-MM-DD" only when the quote says the rule ends ("prior to 10/1/2024": the day before); else null
  "discretionary" true when the text says MAY be denied, MAY not be reimbursed, or should (not shall); else false
  "note"        one short sentence when something is ambiguous, derived or incomplete; else null

KINDS (closed list):
{kind_catalogue()}

CONDITION TYPES (each condition is {{"type": ..., <keys>}}):
{condition_catalogue()}

RULES
1. One record per distinct obligation. A cap the text calls combined ("in total", "combined", "inclusive of", "in any
   combination") across several codes is ONE units_limit with those codes and "combined": true.
2. pair_prohibited: the subject is the code the text says may not be billed (or may be denied); the partners are the
   codes it may not be billed with. "H2014 may be denied when billed on the same day as [L1]" -> subject ["H2014"],
   partners ["L1"]. "A, B and C cannot be billed on the same day" -> one record per code with the others as partners.
   "scope": "member_day" when the text says the same member or any provider; "member_provider_day" when it says the
   same provider; "unstated" otherwise. "modifier_bypass": "none" unless the text names a modifier that lets the pair
   through. A token that is not a valid code (listed as irregular in the legend) is never a partner: say so in "note".
3. A clause that EXEMPTS cases goes verbatim in "exceptions" and the record keeps its kind. A clause that NARROWS when
   the record applies ("when provided in a residential setting", "for members under 21", "in an IHS/638 facility",
   "billed with modifier HQ", "for TRBHA members") becomes a typed condition: age for ages (EPSDT = below_age 21),
   program for a program or population, place_of_service, modifier, provider_type, claim_form, diagnosis; setting,
   member_attribute or service_context (with the words of the text) for anything not on a claim line.
4. included_in when the text says a service is included in, bundled into or covered by another service's rate or a
   per diem ("is included in the rate", "cannot be billed separately"), naming the parent codes or the parent category.
5. not_covered only when the text says the service is not covered or not payable; a service barred only in one
   context keeps that context as a condition.
6. Limits: units_limit counts units; frequency_limit counts services or visits; dollar_limit counts money. Keep the
   basis the text writes next to each number ("4 units per day and 24 units per month" are two records). A limit in
   hours keeps hours: "unit_basis": "hour" with the hours as max ("600 hours per contract year"); a limit in minutes
   of a timed code keeps the text's unit too. Numbers written as words count ("eight (8) units" -> 8).
7. documentation_required for records or documents a provider must keep or send; a threshold ("billing more than 8
   units ... in one day are required to provide documentation") goes in threshold_units and per, with
   "submit_with_claim": true when the documents go with the claim.
8. provider_type_rule with "complete_list": true only when the text says ONLY these provider types may bill; "role":
   "billing_or_rendering" when it says billed by, "rendering" when it says provided or rendered by. Credentials,
   licences, supervision and training are provider_qualification.
9. prior_auth_rule for prior or continued authorization ("requires prior authorization", "PA is not required").
10. definition for a term the text defines (subject {{"term": ...}}); coverage_scope for what a covered service is or
   includes; cross_reference when the text sends the reader to another policy, manual or rule for the requirement;
   exception for a statement that waives, narrows or extends rules stated elsewhere; obligation for any other duty,
   prohibition or permission that has no kind of its own.
11. A lead-in ending with ":" and the list under it is one record over the listed codes, quoting the lead-in; when
   the list carries a token, name the token.
12. Return nothing for headings, page furniture, contact details, links, history notes and examples that state no
   rule. If the section states no rule, return {{"records": [], "none_reason": "<why>"}}.
13. Before answering, reread the TEXT once and add any obligation you missed, and any condition or exception missing
   from a record you returned.
"""

PROMPT_SHA = sha256_text(SYSTEM_PROMPT)[:12]


def system_prompt(notes: str = "") -> str:
    """The system prompt with a domain pack's notes (domains/bh.py) appended; its sha is part of the config id."""
    return SYSTEM_PROMPT + (f"\n{notes.strip()}\n" if notes and notes.strip() else "")


USER_TEMPLATE = """SOURCE: {title} ({source_id}; {family}, authority level {authority})
APPLIES TO: {applies}
SECTION: {path}{part}
{context}
TEXT:
{text}
{legend}"""


def user_message(section: dict, doc, text: str, legend: str, part: str = "", context: str = "") -> str:
    """The message for one section or piece. No version date and no page numbers: an unchanged section of a new
    version sends the same message and reuses the cached answer (pages and dates come from grounding). A piece that
    opens inside an outline item or a list carries the lead-in it continues as CONTEXT."""
    a = section.get("applicability") or {}
    applies = a.get("stated") or ", ".join(a.get("delivery_systems") or []) or "not stated"
    ctx = (f"\nCONTEXT (the lead-in this piece continues, from earlier in the section; quote it when a record rests "
           f"on it):\n{context}\n") if context else ""
    return USER_TEMPLATE.format(title=doc.title, source_id=doc.doc_id, family=doc.family, authority=doc.authority_level,
                                applies=applies[:600], path=section["path_text"],
                                part=f"\nPART: {part} (the section is long; this is one piece of it)" if part else "",
                                context=ctx, text=text, legend=f"\nLISTS:\n{legend}\n" if legend else "")


def example_output() -> str:
    """A well-formed answer (used by tests and the format dry run; never sent to the model)."""
    return json.dumps({"records": [{"kind": "pair_prohibited", "subject": {"codes": ["H0004"]},
                                    "params": {"partners": ["L1"], "scope": "member_day", "modifier_bypass": "none"},
                                    "conditions": [], "exceptions": [], "quote": "...", "effective": None,
                                    "end": None, "discretionary": False, "note": None}], "none_reason": None})
