"""Pieces: what the model reads at once.

A section of at most EXTRACT_MAX_CHARS is one piece. A longer one is cut at block boundaries (the parser's
paragraphs, outline items, bullets and table rows), preferring, in each window, the furthest boundary that opens a
paragraph, a table row or a top-level outline item over one inside a list; a piece is never cut shorter than a third
of the limit, and a lead-in is kept with a block too long to share a piece (the piece then runs over the limit).

A piece that opens inside an outline item or a list carries its lead-ins as context: the parent items of the item it
opens with ("B." and "B.2." for "B.2.c."), the sentence that introduces a bulleted list, or the first row of a table.
The model sees them, may quote them, and grounding accepts a quote of a lead-in for the list the piece opens with.

An answer that runs out of budget splits its piece in two at the boundary nearest the middle (in the middle third
when there is one, then any block boundary, then a sentence end).
"""
from __future__ import annotations

from dataclasses import dataclass

from .. import config
from ..core.text import sentences

CONTEXT_MAX_CHARS = 600


@dataclass(frozen=True)
class Piece:
    start: int
    end: int
    part: str = ""
    context: tuple = ()                 # ((start, end), ...): lead-ins shown with the piece, in section offsets


def _blocks(section: dict) -> list:
    return sorted((b for b in section.get("blocks") or [] if b.get("start", -1) >= 0), key=lambda b: b["start"])


def _quality(b: dict) -> int:
    """How good a cut just before this block is: 2 opens a paragraph, a row or a top-level item; 1 is inside a list."""
    if b.get("kind") in ("para", "row", "footnote"):
        return 2
    if b.get("kind") == "item" and "." not in (b.get("item") or ""):
        return 2
    return 1


def boundaries(section: dict) -> list:
    n = len(section["text"])
    seen, out = set(), []
    for b in _blocks(section):
        if 0 < b["start"] < n and b["start"] not in seen:
            seen.add(b["start"])
            out.append((b["start"], _quality(b)))
    return out


def _trim(text: str, a: int, b: int) -> tuple:
    """A lead-in span cut to CONTEXT_MAX_CHARS at a sentence end (or at the limit)."""
    if b - a <= CONTEXT_MAX_CHARS:
        return a, b
    ends = [a + e for _, e in sentences(text[a:b]) if e <= CONTEXT_MAX_CHARS]
    return a, (ends[-1] if ends else a + CONTEXT_MAX_CHARS)


def context(section: dict, pos: int) -> tuple:
    """The lead-ins of the block that holds `pos`."""
    text, blocks = section["text"], _blocks(section)
    here = [i for i, b in enumerate(blocks) if b["start"] <= pos < max(b["end"], b["start"] + 1)]
    if not here:
        return ()
    i = here[-1]
    b = blocks[i]
    spans = []
    if b.get("kind") == "item" and "." in (b.get("item") or ""):
        parts = b["item"].split(".")
        for depth in range(1, len(parts)):
            want = ".".join(parts[:depth])
            parent = next((x for x in reversed(blocks[:i]) if x.get("kind") == "item" and x.get("item") == want), None)
            if parent is not None:
                spans.append(_trim(text, parent["start"], parent["end"]))
    elif b.get("kind") == "bullet":
        lead = next((x for x in reversed(blocks[:i]) if x.get("kind") != "bullet"), None)
        if lead is not None:
            spans.append(_trim(text, lead["start"], lead["end"]))
    elif b.get("kind") == "row" and i > 0 and blocks[i - 1].get("kind") == "row":
        j = i
        while j > 0 and blocks[j - 1].get("kind") == "row":
            j -= 1
        spans.append(_trim(text, blocks[j]["start"], blocks[j]["end"]))
    return tuple(s for s in spans if s[1] > s[0] and s[1] <= pos)


def pieces(section: dict, max_chars: int | None = None) -> list[Piece]:
    limit = max_chars or config.EXTRACT_MAX_CHARS
    n = len(section["text"])
    if n <= limit:
        return [Piece(0, n)]
    bounds = boundaries(section)
    spans, a = [], 0
    while n - a > limit:
        window = [(p, q) for p, q in bounds if a + limit // 3 <= p <= a + limit]
        if window:
            best = max(q for _, q in window)
            cut = max(p for p, q in window if q == best)
        else:                                  # a block too long for one piece: it and its lead-in go together
            after = [p for p, _ in bounds if p > a + limit]
            cut = after[0] if after else n
        if cut >= n:
            break
        spans.append((a, cut))
        a = cut
    spans.append((a, n))
    k = len(spans)
    return [Piece(s, e, f"{i}/{k}" if k > 1 else "", context(section, s) if s else ())
            for i, (s, e) in enumerate(spans, start=1)]


def halves(section: dict, piece: Piece) -> list[Piece]:
    """The piece in two, or [] when it holds no boundary and no sentence end."""
    text = section["text"]
    mid, third = (piece.start + piece.end) // 2, (piece.end - piece.start) // 3
    inner = [(p, q) for p, q in boundaries(section) if piece.start < p < piece.end]
    window = [(p, q) for p, q in inner if piece.start + third <= p <= piece.end - third]
    if window:
        best = max(q for _, q in window)
        cut = min((p for p, q in window if q == best), key=lambda p: abs(p - mid))
    elif inner:
        cut = min((p for p, _ in inner), key=lambda p: abs(p - mid))
    else:
        ends = [piece.start + e for _, e in sentences(text[piece.start:piece.end])]
        ends = [e for e in ends if piece.start < e < piece.end and text[e:piece.end].strip()]
        if not ends:
            return []
        cut = min(ends, key=lambda p: abs(p - mid))
    tag = piece.part or "1/1"
    return [Piece(piece.start, cut, f"{tag}.1/2", piece.context),
            Piece(cut, piece.end, f"{tag}.2/2", context(section, cut) or piece.context)]
