"""Code lists, replaced by short tokens before the model reads a section.

A sentence that names 21 codes made v6.3's model write 21 records, each repeating its quote, until the answer ran out
of budget; the section then failed on every run. Here a run of codes in one sentence ("H0036, H2015. H0018, ...,
S5151, S9480, or H0015") becomes [L1] in the text the model reads, with a legend under the text (L1 = ...), and the
model writes one record that names L1; the program expands it. A bulleted list of codes (one code per line, with its
description) stays visible and gets a label line [L2] above it, so a lead-in sentence can name the whole list.

A token that looks like a code but is not one ("S109", a typo for a five-character code) does not break the list: it
is kept in the legend as irregular, never paired and never corrected.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .. import config
from ..core import codes as C
from ..core.text import BULLETS

TOKEN = re.compile(r"\[(L\d+)\]")
_SEP_WORDS = re.compile(r"\b(?:and/or|or|and)\b", re.I)
_PAREN = re.compile(r"\([^()\n]{0,90}\)")
_IRREGULAR = re.compile(r"^(?:[A-Z]\d{2,5}|\d{3,4})$")
_BULLET_CODE = re.compile(rf"^\s*(?:[{re.escape(BULLETS)}]|\(?[A-Za-z0-9]{{1,4}}[.)])?\s*"
                          rf"((?:[{C.HCPCS_LETTERS}D]\d{{4}})|(?:\d{{4}}[0-9FTUM]))\b")


@dataclass
class CodeList:
    token: str
    kind: str                         # inline | bullets
    items: list                       # codes and ranges as written, in order
    codes: list                       # every code the list names (ranges expanded over the known codes)
    start: int                        # span in the section text
    end: int
    text: str
    irregular: list = field(default_factory=list)

    def legend(self) -> str:
        """What the model reads. It names the entries as written (a range stays a range) and never the expansion,
        so the message, and the cached answer, do not change when the code spine grows."""
        shown = ", ".join(self.items)
        extra = f"; also {', '.join(repr(x) for x in self.irregular)} (not valid codes)" if self.irregular else ""
        where = " (the lines below the label)" if self.kind == "bullets" else ""
        return f"{self.token} = {shown} ({len(self.items)} entries{extra}){where}"


@dataclass
class Tokenized:
    text: str                         # what the model reads
    lists: dict                       # token -> CodeList
    source: str                       # the section text it was made from
    marks: list                       # (start in model text, end, token) for inline tokens and labels

    @property
    def legend(self) -> str:
        return "\n".join(cl.legend() for cl in self.lists.values())

    def expand(self, s: str) -> str:
        """Model-text words back to the section's words: inline tokens become the list as written, labels vanish."""
        def rep(m):
            cl = self.lists.get(m.group(1))
            if cl is None:
                return m.group(0)
            return cl.text if cl.kind == "inline" else ""
        return re.sub(r"\s{2,}", " ", TOKEN.sub(rep, s)).strip()

    def codes(self, token: str) -> list:
        cl = self.lists.get(token)
        return list(cl.codes) if cl else []


def _gap_ok(gap: str) -> tuple[bool, list]:
    """Whether the text between two codes only separates them; the irregular code-like tokens it holds."""
    if "\n" in gap:
        return False, []
    g = _PAREN.sub(" ", gap)
    g = _SEP_WORDS.sub(" ", g)
    irregular = []
    for tok in re.split(r"[\s,;/.&]+", g):
        if not tok:
            continue
        if _IRREGULAR.match(tok):
            irregular.append(tok)
            continue
        return False, []
    return True, irregular


def _items(text: str) -> list:
    """(start, end, written, codes) for every code and range in the text, ranges first where they overlap."""
    out, taken = [], []
    for lo, hi, a, b in C.ranges_in(text):
        out.append((a, b, f"{lo}-{hi}", [lo, hi]))
        taken.append((a, b))
    for code, a, b in C.procedure_codes_in(text):
        if any(x <= a < y for x, y in taken):
            continue
        out.append((a, b, code, [code]))
    return sorted(out)


def find_lists(text: str, universe=None, min_codes: int | None = None) -> list[CodeList]:
    """Inline runs and bulleted lists of at least `min_codes` entries (a code or a range as written), in text order.
    The universe only expands ranges into `codes`; which runs become tokens does not depend on it."""
    n_min = min_codes or config.LIST_TOKEN_MIN_CODES
    universe = set(universe or ())
    found: list[CodeList] = []
    # bulleted lists: consecutive lines that open with a code
    pos, run = 0, []
    lines = text.split("\n")
    spans = []
    for ln in lines:
        spans.append((pos, pos + len(ln), ln))
        pos += len(ln) + 1
    i = 0
    while i < len(spans):
        j = i
        while j < len(spans) and _BULLET_CODE.match(spans[j][2]):
            j += 1
        if j - i >= n_min:
            codes = [C.norm_procedure(_BULLET_CODE.match(spans[k][2]).group(1)) for k in range(i, j)]
            found.append(CodeList("", "bullets", codes, list(dict.fromkeys(codes)), spans[i][0], spans[j - 1][1],
                                  text[spans[i][0]:spans[j - 1][1]]))
            i = j
        else:
            i += 1
    in_bullets = [(cl.start, cl.end) for cl in found]
    # inline runs inside one line
    items = [it for it in _items(text) if not any(a <= it[0] < b for a, b in in_bullets)]
    k = 0
    while k < len(items):
        run, irregular = [items[k]], []
        while k + 1 < len(items):
            ok, irr = _gap_ok(text[run[-1][1]:items[k + 1][0]])
            if not ok:
                break
            irregular += irr
            run.append(items[k + 1])
            k += 1
        k += 1
        codes = []
        for _, _, written, cs in run:
            if len(cs) == 2 and "-" in written:
                codes += C.expand_range(cs[0], cs[1], universe)
            else:
                codes += cs
        codes = list(dict.fromkeys(codes))
        if len(run) >= n_min:                 # entries as written: a token never depends on the spine
            a, b = run[0][0], run[-1][1]
            found.append(CodeList("", "inline", [w for _, _, w, _ in run], codes, a, b, text[a:b], irregular))
    found.sort(key=lambda cl: cl.start)
    for n, cl in enumerate(found, start=1):
        cl.token = f"L{n}"
    return found


def tokenize(text: str, universe=None, min_codes: int | None = None) -> Tokenized:
    lists = find_lists(text, universe, min_codes)
    out, marks, pos = [], [], 0
    cur = 0
    for cl in lists:
        out.append(text[pos:cl.start])
        cur += len(text[pos:cl.start])
        if cl.kind == "inline":
            tok = f"[{cl.token}]"
            marks.append((cur, cur + len(tok), cl.token))
            out.append(tok)
            cur += len(tok)
            pos = cl.end
        else:
            label = f"[{cl.token}]\n"
            marks.append((cur, cur + len(label) - 1, cl.token))
            out.append(label)
            cur += len(label)
            pos = cl.start
    out.append(text[pos:])
    return Tokenized("".join(out), {cl.token: cl for cl in lists}, text, marks)
