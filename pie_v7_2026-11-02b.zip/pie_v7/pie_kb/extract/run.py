"""The narrative extraction stage, in three steps so the GPU never needs Spark:

  export (CPU)   STAGE_DIR/narrative: the sections of every version due, their version rows, the code spine, and a
                 manifest that holds each version's configuration id
  extract (GPU)  three passes over the exported sections, into a run folder RUNS_DIR/<run_id>:
                   plan      every piece the model must read, and how many the answer cache already holds
                   generate  the model reads the pieces the cache does not hold (one at a time, or EXTRACT_BATCH
                             together); answers are cached as they come, so a run that stops early loses nothing
                   ground    patterns and cached answers become records; a refused proposal is kept with its reason
  persist (CPU)  the run folder into kb_records, kb_proposals, kb_extraction_outcomes, kb_value_sets and the
                 processing ledger

A version is due until a run finished it under its configuration id: the prompt, the extraction code, the model and
reasoning level, plus a fingerprint of the version's own inputs (its section rows, and the codes its ranges expand to
over the spine). A re-parse, a prompt edit, or a spine change that alters one of its ranges makes it due again; answers
to messages that did not change come from the cache, so only changed pieces cost model time.

Outcomes, one row per piece (or per section that does not go to the model):
  proposals | no_records   the model answered (the detail says when the answer came from an earlier run)
  failed                   an error, an answer cut off at the last resort, or an answer that is not the JSON asked for
                           (such an answer is never cached: its piece is split when it can be, else asked again)
  not_run                  the run stopped (time limit, repeated failures) before the model read the piece
  needs_model              a cache-only run met a piece the cache does not hold
  skipped | patterns_only  not sent to the model (the detail says why) | a run with no model
A version with a failed, not_run, needs_model or patterns_only outcome is persisted as "partial" and stays due. A
partial run never replaces the records of a version that already had a complete run: the knowledge base shows each
version's last complete extraction, or, until there is one, its latest partial one.
"""
from __future__ import annotations

import json
import os
import re
import time
from collections import Counter, deque

from .. import config
from ..core import codes as C
from ..core.hashing import canonical, code_version, sha256_text
from ..core.record import Record, store_row
from ..core.text import match_form
from ..parse.sections import EXTRACTABLE
from ..sources import ledger
from ..sources.intake import new_run_id
from . import cache as K
from . import lists as LS
from . import patterns as PT
from . import prompt as PR
from .backends import Backend, CacheOnly, NoModel, Truncated
from .domains import bh
from .ground import ground
from .parse import AnswerError, read_answer
from .pieces import Piece, halves, pieces

STAGE = "extract_narrative"
MODEL_ORIGINS = ("model", "pattern", "pattern+model")
OPEN = ("failed", "not_run", "needs_model", "patterns_only")   # outcomes that leave a version due
# what a record read from a section depends on (this file is orchestration and left out)
CODE_FILES = ("extract/lists.py", "extract/pieces.py", "extract/prompt.py", "extract/parse.py", "extract/ground.py",
              "extract/patterns.py", "extract/domains", "core", "parse/sections.py", "sources/registry.py",
              "reference/sources.csv")


def system_prompt() -> str:
    return PR.system_prompt(bh.PROMPT_NOTES)


def code_hash() -> str:
    """The code that decides what a section yields."""
    return code_version(*CODE_FILES)


def config_id(model: str | None = None, reasoning: str | None = None) -> str:
    m = (model or config.HF_MODEL).split("/")[-1]
    prompt = sha256_text(system_prompt())[:8]
    return f"narr-{PR.PROMPT_VERSION}-{prompt}-{code_hash()}-{m}-{reasoning or config.REASONING}"


def universe_of(section: dict, spine_codes) -> set:
    """The codes a range in the section expands over: the spine and the codes the section itself names."""
    return set(spine_codes or ()) | set((section.get("codes") or {}).get("procedure") or [])


def inputs_fingerprint(secs: list, spine_codes) -> str:
    rows = sorted((canonical(s) for s in secs))
    ranges = sorted({(lo, hi, ",".join(C.expand_range(lo, hi, universe_of(s, spine_codes))))
                     for s in secs for lo, hi, *_ in C.ranges_in(s.get("text") or "")})
    return sha256_text(canonical([rows, ranges]))[:8]


def wants_model(s: dict) -> tuple[bool, str]:
    if s.get("role") not in EXTRACTABLE:
        return False, f"role {s.get('role')}"
    words = len(re.findall(r"\w+", s.get("text") or ""))
    if words < config.MIN_MODEL_WORDS:
        return False, f"{words} words"
    if s.get("role") == "definitions":
        n = len(PT.definition_proposals(s))
        if n:
            return False, f"definitions read by pattern ({n})"
    return True, ""


# ------------------------------------------------------------------ records within a section
def _same(r: Record):
    if r.kind == "definition":
        return "definition", match_form(r.subject.get("term") or "")
    if r.kind == "cross_reference":
        return "cross_reference", match_form(str(r.params.get("target") or "")), tuple(r.subject.get("codes") or ())
    return r.record_key


def dedupe(records: list) -> tuple[list, dict]:
    """One record per meaning within a section: the first is kept (patterns are grounded before the model, so a
    verbatim pattern record wins over the model's wording); found by both, it becomes 'pattern+model'. Returns the
    records and {dropped record_id: the record_id it was merged into}."""
    kept: dict = {}
    merged: dict = {}
    for r in records:
        k = _same(r)
        if k not in kept:
            kept[k] = r
            continue
        a = kept[k]
        if r.record_id != a.record_id:
            merged[r.record_id] = a.record_id
        if {a.origin, r.origin} == {"pattern", "model"}:
            a.origin = "pattern+model"
            a.extraction = {**a.extraction, "confirmed_by_model": r.record_id}
    return list(kept.values()), merged


# ------------------------------------------------------------------ the extractor
class Extractor:
    def __init__(self, backend: Backend, reg, *, spine_codes=None, cache: K.AnswerCache | None = None,
                 run_id: str = "", batch: int | None = None, max_minutes: float | None = None, log=print):
        self.backend, self.reg, self.spine = backend, reg, set(spine_codes or ())
        self.cache = cache or K.AnswerCache()
        self.run_id, self.log = run_id or new_run_id("narr"), log
        self.batch = max(1, batch or config.EXTRACT_BATCH)
        self.deadline = time.time() + 60 * max_minutes if max_minutes else None
        self.system = system_prompt()
        self.failures: dict = {}                     # cache key -> why this run got no usable answer
        self.calls = 0
        self._msg: dict = {}
        self.extraction = {"run_id": self.run_id, "backend": backend.name, "model": backend.model,
                           "reasoning": backend.reasoning, "prompt_version": PR.PROMPT_VERSION,
                           "prompt_sha": sha256_text(self.system)[:12], "code": code_hash(),
                           "config_id": config_id(backend.model, backend.reasoning)}

    def doc(self, s: dict):
        return self.reg.get(s["source_id"], s["document_key"])

    def message(self, s: dict, p: Piece) -> tuple[str, str, LS.Tokenized]:
        """(cache key, user message, tokenized piece) with list spans in section offsets."""
        mk = (s["section_id"], p.start, p.end, p.context)
        if mk not in self._msg:
            text = s["text"]
            tk = LS.tokenize(text[p.start:p.end], universe_of(s, self.spine))
            for cl in tk.lists.values():
                cl.start += p.start
                cl.end += p.start
            ctx = "\n".join(text[a:b].strip() for a, b in p.context)
            user = PR.user_message(s, self.doc(s), tk.text, tk.legend, p.part, ctx)
            self._msg[mk] = (K.key(self.system, user, self.backend.tag()), user, tk)
        return self._msg[mk]

    # -------------------------------------------------------------- pass 1: plan
    def plan(self, sections: list) -> dict:
        c: Counter = Counter()
        for s in sections:
            if not wants_model(s)[0]:
                c["sections_skipped"] += 1
                continue
            c["sections_to_model"] += 1
            for p in pieces(s):
                c["pieces"] += 1
                self._plan_piece(s, p, c)
        out = dict(c)
        if out.get("to_model") and self.backend.name == "hf_local":   # one piece at a time; a batch is faster
            rate = config.EST_SECONDS_PER_PIECE.get(self.backend.reasoning, 374)
            out["estimated_hours"] = round(out["to_model"] * rate / 3600, 1)
        return out

    def _plan_piece(self, s: dict, p: Piece, c: Counter) -> None:
        k, _, _ = self.message(s, p)
        e = self.cache.lookup(k)
        if e is None:
            c["to_model"] += 1
            c["chars_to_model"] += p.end - p.start
        elif e.get("split"):
            c["split_before"] += 1
            for h in halves(s, p):
                self._plan_piece(s, h, c)
        else:
            c["cached"] += 1

    # -------------------------------------------------------------- pass 2: generate
    def generate(self, sections: list) -> dict:
        stats: Counter = Counter()
        if isinstance(self.backend, NoModel):
            return {"calls": 0, "note": "no model in this run"}
        queue = deque((s, p, 0) for s in sections if wants_model(s)[0] for p in pieces(s))
        t0 = time.time()
        try:
            self._drain(queue, stats)
        finally:                                        # whatever stops the loop, the answers so far are kept
            self.cache.flush()
        stats["calls"] = self.calls
        stats["seconds"] = round(time.time() - t0, 1)
        return dict(stats)

    def _drain(self, queue: deque, stats: Counter) -> None:
        streak, spent = 0, []
        while queue:
            if self.deadline and time.time() > self.deadline:
                stats["left_at_time_limit"] = len(queue)
                self.log(f"time limit reached: {len(queue)} piece(s) left for the next run (answers so far are "
                         f"cached)")
                break
            batch = []
            while queue and len(batch) < self.batch:
                s, p, depth = queue.popleft()
                k, user, _ = self.message(s, p)
                e = self.cache.lookup(k)
                if e is not None:
                    if e.get("split"):
                        for h in reversed(halves(s, p)):
                            queue.appendleft((s, h, depth + 1))
                    stats["cached"] += 1
                    continue
                if isinstance(self.backend, CacheOnly):
                    stats["needs_model"] += 1
                    continue
                batch.append((s, p, depth, k, user))
            if not batch:
                continue
            before = self.calls
            c0 = time.time()
            results, solo = None, True
            if len(batch) > 1 and hasattr(self.backend, "complete_many"):
                self.calls += len(batch)
                try:
                    results, solo = self.backend.complete_many([(self.system, b[4]) for b in batch]), False
                except Exception as e:                  # noqa: BLE001 - the whole batch failed (memory): one by one
                    self.log(f"  a batch of {len(batch)} failed ({type(e).__name__}: {str(e)[:120]}); one at a time")
            if results is None:
                results = [self._solo(b[4]) for b in batch]
            seconds = (time.time() - c0) / len(batch)   # per piece: the batch's wall time shared
            for (s, p, depth, k, user), res in zip(batch, results):
                more, what = self._settle(s, p, depth, k, user, res, solo, seconds)
                stats[what] += 1
                for h in reversed(more):
                    queue.appendleft((s, h, depth + 1))
                streak = streak + 1 if what == "failed" else 0
                spent.append(seconds)
                left = len(queue)
                eta = f"; about {sum(spent) / len(spent) * left / 60:.0f} min left at this pace" if left else ""
                self.log(f"  [{self.calls} calls] {s['source_id']} {s['path_text'][-60:]} {p.part}: {what} in "
                         f"{seconds:.0f}s; {left} piece(s) queued{eta}")
            if self.calls // config.CACHE_FLUSH_EVERY != before // config.CACHE_FLUSH_EVERY:
                self.cache.flush()
            if streak >= config.MAX_CONSECUTIVE_FAILURES:
                stats["left_after_failures"] = len(queue)
                self.log(f"STOPPED: {streak} model calls in a row failed (last: "
                         f"{list(self.failures.values())[-1][:200]}); {len(queue)} piece(s) left for the next run")
                break

    def _solo(self, user: str, budget: int | None = None):
        self.calls += 1
        try:
            return self.backend.complete(self.system, user, budget=budget)
        except Exception as e:                        # noqa: BLE001 - settled by the caller
            return e

    def _meta(self, s: dict, p: Piece, seconds: float, solo: bool, **kw) -> dict:
        """What the cache keeps with an answer; the backend's own numbers only for a call made alone."""
        bm = (getattr(self.backend, "last_meta", {}) or {}) if solo else {}
        return {"run_id": self.run_id, "section_id": s["section_id"], "part": p.part, "seconds": round(seconds, 1),
                "backend": bm, **kw}

    def _settle(self, s, p, depth, k, user, res, solo, seconds) -> tuple[list, str]:
        """Cache an answer, or decide what a cut-off or failed call leads to: (halves to ask next, what happened).
        `solo`: the result came from a call made alone (which already retried once at RETRY_FACTOR)."""
        if isinstance(res, Truncated) and not solo:             # a batch answer cut off: retry alone, larger
            res, solo = self._solo(user, int(self.backend.budget() * config.RETRY_FACTOR)), True
        if isinstance(res, Truncated):
            hs = halves(s, p) if depth < config.MAX_SPLIT_DEPTH else []
            if hs:
                self.cache.put_split(k, self._meta(s, p, seconds, solo, reason=str(res)))
                return hs, "split"
            res, solo = self._solo(user, int(self.backend.budget() * config.LAST_RESORT_FACTOR)), True
            if isinstance(res, Truncated):
                res = RuntimeError(f"cut off at the last resort ({config.LAST_RESORT_FACTOR}x budget): {res}")
        if not isinstance(res, Exception):
            try:
                read_answer(res)
            except AnswerError as e:                     # not the JSON asked for: never cached (the next run asks
                hs = halves(s, p) if depth < config.MAX_SPLIT_DEPTH else []   # again); a smaller piece may answer
                if hs:
                    self.cache.put_split(k, self._meta(s, p, seconds, solo, reason=f"answer not JSON: {e}"))
                    return hs, "split"
                res = RuntimeError(f"the answer is not the JSON asked for ({e}): {str(res)[:200]}")
        if isinstance(res, Exception):
            self.failures[k] = f"{type(res).__name__}: {res}"[:500]
            return [], "failed"
        self.cache.put(k, res, self._meta(s, p, seconds, solo))
        return [], "answered"

    # -------------------------------------------------------------- pass 3: ground
    def ground_section(self, s: dict) -> dict:
        doc, svid = self.doc(s), s["source_version_id"]
        out = {"records": [], "proposals": [], "outcomes": [], "value_sets": []}
        out["value_sets"] = [{**v, "origin": "pattern"} for v in PT.service_code_sets(s, doc.source_id, svid)]
        whole = Piece(0, len(s.get("text") or ""))
        if s.get("role") in EXTRACTABLE and s.get("text"):
            props = PT.definition_proposals(s) + PT.cross_reference_proposals(s, self.reg)
            if props:
                tk = LS.tokenize(s["text"], universe_of(s, self.spine))
                self._ground(props, s, tk, doc, "pattern", whole, out)
        go, why = wants_model(s)
        if not go:
            out["outcomes"].append(self._outcome(s, whole, "skipped", why, 0, len(out["records"])))
        elif isinstance(self.backend, NoModel):
            out["outcomes"].append(self._outcome(s, whole, "patterns_only", "no model in this run: not a complete "
                                                 "extraction", 0, len(out["records"])))
        else:
            for p in pieces(s):
                self._ground_piece(s, doc, p, out)
        n = len(out["records"])
        out["records"], merged = dedupe(out["records"])
        for prop in out["proposals"]:                     # a merged proposal points at the record that stands
            if prop["record_id"] in merged:
                prop["grounding"] = {**prop["grounding"], "record_id_before_merge": prop["record_id"]}
                prop["record_id"] = merged[prop["record_id"]]
                prop["drop_reason"] = "merged: the section states the same record again"
        if n > len(out["records"]) and out["outcomes"]:
            o = out["outcomes"][-1]
            o["detail"] = (o["detail"] + f" ({n - len(out['records'])} duplicate record(s) merged)").strip()
        return out

    def _ground_piece(self, s: dict, doc, p: Piece, out: dict) -> None:
        k, _, tk = self.message(s, p)
        e = self.cache.lookup(k)
        if e is None:
            if k in self.failures:
                out["outcomes"].append(self._outcome(s, p, "failed", self.failures[k], 0, 0))
            elif isinstance(self.backend, CacheOnly):
                out["outcomes"].append(self._outcome(s, p, "needs_model", "not in the cache", 0, 0))
            else:
                out["outcomes"].append(self._outcome(s, p, "not_run", "the run stopped before the model read it",
                                                     0, 0))
            return
        if e.get("split"):
            for h in halves(s, p):
                self._ground_piece(s, doc, h, out)
            return
        meta = e.get("meta") or {}
        here = meta.get("run_id") == self.run_id
        seconds = float(meta.get("seconds") or 0) if here else 0.0
        try:
            parsed = read_answer(e.get("answer") or "")
        except AnswerError as err:
            out["outcomes"].append(self._outcome(s, p, "failed", f"answer is not the JSON asked for: {err}", 0, 0,
                                                 seconds))
            return
        n0 = len(out["records"])
        self._ground(parsed["records"], s, tk, doc, "model", p, out)
        what = "proposals" if parsed["records"] else "no_records"
        detail = "" if parsed["records"] else str(parsed.get("none_reason") or "")
        if not here and meta.get("run_id"):
            detail = (detail + f" [answer from {meta['run_id']}]").strip()
        out["outcomes"].append(self._outcome(s, p, what, detail, len(parsed["records"]), len(out["records"]) - n0,
                                             seconds))

    def _ground(self, props: list, s: dict, tk: LS.Tokenized, doc, origin: str, p: Piece, out: dict) -> None:
        ctx = {"doc": doc, "source_version_id": s["source_version_id"], "universe": universe_of(s, self.spine),
               "extraction": self.extraction, "part": p.part, "origin": origin, "span": (p.start, p.end),
               "context": p.context}
        base = len(out["proposals"])
        for i, prop in enumerate(props):
            g = ground(prop, s, tk, ctx)
            out["proposals"].append({"run_id": self.run_id, "source_version_id": s["source_version_id"],
                                     "section_id": s["section_id"], "proposal_index": base + i, "origin": origin,
                                     "kept": g.kept, "drop_reason": g.reason,
                                     "record_id": g.record.record_id if g.record else "", "raw": prop,
                                     "grounding": {**g.checks, "part": p.part}})
            if g.kept:
                out["records"].append(g.record)

    def _outcome(self, s: dict, p: Piece, outcome: str, detail: str, n_prop: int, n_rec: int,
                 seconds: float = 0.0) -> dict:
        return {"run_id": self.run_id, "source_version_id": s["source_version_id"], "section_id": s["section_id"],
                "outcome": outcome, "detail": ((f"[{p.part}] " if p.part else "") + str(detail or "")).strip()[:500],
                "n_proposals": n_prop, "n_records": n_rec, "seconds": round(seconds, 2)}


# ------------------------------------------------------------------ files
def _write_jsonl(path: str, rows: list) -> None:
    K.write_whole(path, [json.dumps(r, ensure_ascii=False, default=str) for r in rows])


def _write_json(path: str, obj: dict) -> None:
    K.write_whole(path, [json.dumps(obj, indent=1, default=str)])


def _read_jsonl(path: str) -> list:
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def _read_json(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------------ the three steps
def export(store, reg, out_dir: str | None = None, only: set | None = None, force: bool = False,
           model: str | None = None, reasoning: str | None = None, log=print) -> dict:
    """CPU: the sections of every version due, with the spine and a manifest, as files for the GPU run."""
    from ..kb.spine import spine
    out_dir = out_dir or os.path.join(config.STAGE_DIR, "narrative")
    base = config_id(model, reasoning)
    processing = store.read("processing_ledger")
    done = {(p["source_version_id"], p["config_id"]) for p in processing
            if p["stage"] == STAGE and p["status"] == "ok"}
    by_version: dict = {}
    for s in store.read("sections"):
        by_version.setdefault(s["source_version_id"], []).append(s)
    codes, counts = spine(store, reg)
    order = {(d.source_id, d.document_key): (d.priority, i) for i, d in enumerate(reg.docs)}
    due, versions, unparsed = {}, [], []
    for v in store.read("source_versions"):
        svid = v["source_version_id"]
        if v.get("status") != "active" or (only is not None and v["source_id"] not in only):
            continue
        try:
            doc = reg.get(v["source_id"], v["document_key"])
        except KeyError:
            continue
        if svid not in by_version:                    # a table file with no text in it, or not parsed yet
            if doc.method == "narrative":
                unparsed.append(svid)
            continue
        cfg = f"{base}-{inputs_fingerprint(by_version[svid], codes)}"
        if force or (svid, cfg) not in done:
            due[svid] = cfg
            versions.append(v)
    if unparsed:
        log(f"{len(unparsed)} narrative version(s) have no sections yet (run the parse stage first): "
            f"{', '.join(unparsed[:5])}")
    # P1 sources first, in registry order, so a run stopped by its time limit has read the most important ones
    secs = sorted((s for svid in due for s in by_version[svid]),
                  key=lambda s: (order.get((s["source_id"], s["document_key"]), ("P9", 0)), s["source_version_id"],
                                 s.get("ordinal") or 0, s["section_id"]))
    _write_jsonl(os.path.join(out_dir, "sections.jsonl"), secs)
    _write_jsonl(os.path.join(out_dir, "versions.jsonl"), versions)
    to_model = [s for s in secs if wants_model(s)[0]]
    manifest = {"config_id": base, "model": model or config.HF_MODEL, "reasoning": reasoning or config.REASONING,
                "exported_at": ledger.now_iso(), "versions": due, "sections": len(secs),
                "sections_to_model": len(to_model), "chars_to_model": sum(len(s["text"]) for s in to_model),
                "spine": sorted(codes), "spine_counts": counts}
    _write_json(os.path.join(out_dir, "manifest.json"), manifest)
    summary = {k: v for k, v in manifest.items() if k not in ("spine", "versions")}
    summary["versions"] = len(due)
    log(f"exported {len(due)} version(s), {len(secs)} section(s) ({len(to_model)} to the model, "
        f"{summary['chars_to_model']:,} characters) to {out_dir}")
    return summary


def plan_stage(stage_dir: str, backend: Backend, reg, seeds: list | None = None) -> dict:
    """What a run of this backend over the stage would ask the model, from the cache alone: nothing is loaded, so
    the GPU notebook can decide whether to load the model at all."""
    manifest = _read_json(os.path.join(stage_dir, "manifest.json"))
    seeds = K.seed_files(config.RUNS_DIR) if seeds is None else seeds
    ex = Extractor(backend, reg, spine_codes=manifest.get("spine"), cache=K.AnswerCache(None, seed_paths=seeds),
                   log=lambda m: None)
    return {"config_id": manifest["config_id"], "exported_at": manifest.get("exported_at"),
            **ex.plan(_read_jsonl(os.path.join(stage_dir, "sections.jsonl")))}


def extract(stage_dir: str, backend: Backend, reg, run_dir: str | None = None, seeds: list | None = None,
            sections: list | None = None, limit: int | None = None, max_minutes: float | None = None,
            batch: int | None = None, log=print) -> dict:
    """GPU (or a CPU with a cache-only or no-model backend): plan, generate and ground the exported sections.

    seeds: answers files to read before asking the model (default: every earlier run's under RUNS_DIR). sections
    (ids) or limit make a dry run, which persist refuses. max_minutes stops asking the model after that long."""
    manifest = _read_json(os.path.join(stage_dir, "manifest.json"))
    if not isinstance(backend, NoModel):
        want = config_id(backend.model, backend.reasoning)
        if manifest["config_id"] != want:
            raise ValueError(f"the stage was exported for {manifest['config_id']}, this backend is {want}: export "
                             f"again with model={backend.model!r}, reasoning={backend.reasoning!r}")
    run_id = new_run_id("narr")
    run_dir = run_dir or os.path.join(config.RUNS_DIR, run_id)
    answers = os.path.join(run_dir, "answers.jsonl")
    seeds = K.seed_files(config.RUNS_DIR, exclude=answers) if seeds is None else seeds
    cache = K.AnswerCache(answers, seed_paths=seeds)
    secs = _read_jsonl(os.path.join(stage_dir, "sections.jsonl"))
    dry = bool(sections) or bool(limit)
    if sections:
        secs = [s for s in secs if s["section_id"] in set(sections)]
    if limit:
        secs = secs[:limit]
    ex = Extractor(backend, reg, spine_codes=manifest.get("spine"), cache=cache, run_id=run_id, batch=batch,
                   max_minutes=max_minutes, log=log)
    info = {"run_id": run_id, "config_id": manifest["config_id"], "versions": manifest["versions"],
            "stage_exported_at": manifest.get("exported_at"), "extraction": ex.extraction, "dry_run": dry,
            "started_at": ledger.now_iso(), "sections": len(secs), "seeded_answers": len(cache.data),
            "finished": False}
    _write_json(os.path.join(run_dir, "manifest.json"), info)
    plan = ex.plan(secs)
    info["plan"] = plan
    est = f"; about {plan['estimated_hours']} h one at a time at the v6.3 rate" if plan.get("estimated_hours") else ""
    log(f"plan: {plan.get('sections_to_model', 0)} section(s) to the model in {plan.get('pieces', 0)} piece(s); "
        f"{plan.get('cached', 0)} answered by the cache, {plan.get('to_model', 0)} for the model "
        f"({plan.get('chars_to_model', 0):,} characters){est}")
    _write_json(os.path.join(run_dir, "manifest.json"), info)
    info["generate"] = ex.generate(secs)
    rows: dict = {"records": [], "proposals": [], "outcomes": [], "value_sets": []}
    for s in secs:
        res = ex.ground_section(s)
        rows["records"] += [r.to_row() for r in res["records"]]
        for name in ("proposals", "outcomes", "value_sets"):
            rows[name] += res[name]
    for name, data in rows.items():
        _write_jsonl(os.path.join(run_dir, f"{name}.jsonl"), data)
    oc = Counter(o["outcome"] for o in rows["outcomes"])
    info.update(finished=True, finished_at=ledger.now_iso(), records=len(rows["records"]),
                proposals=len(rows["proposals"]), outcomes=dict(oc), model_calls=ex.calls,
                tokens=getattr(backend, "tokens", None))
    _write_json(os.path.join(run_dir, "manifest.json"), info)
    log(f"run {run_id}: {len(rows['records']):,} records from {len(rows['proposals']):,} proposals; outcomes "
        f"{dict(oc)}; {ex.calls} model call(s)")
    return {**{k: v for k, v in info.items() if k != "versions"}, "run_dir": run_dir}


def persist(store, reg, run_dir: str, claim_type: str | None = None, log=print) -> dict:
    """CPU: a finished run folder into the knowledge base tables and the processing ledger (idempotent)."""
    info = _read_json(os.path.join(run_dir, "manifest.json"))
    if not info.get("finished"):
        raise ValueError(f"{info.get('run_id')} did not finish; its answers are cached: run extract again")
    if info.get("dry_run"):
        raise ValueError(f"{info.get('run_id')} is a dry run (some sections only); it is not persisted")
    run_id = info["run_id"]
    records = [Record.from_row(r) for r in _read_jsonl(os.path.join(run_dir, "records.jsonl"))]
    proposals = _read_jsonl(os.path.join(run_dir, "proposals.jsonl"))
    outcomes = _read_jsonl(os.path.join(run_dir, "outcomes.jsonl"))
    value_sets = _read_jsonl(os.path.join(run_dir, "value_sets.jsonl"))
    versions: dict = info["versions"]
    svids = sorted(versions)
    ct = claim_type or config.CLAIM_TYPE
    complete_before = {p["source_version_id"] for p in store.read("processing_ledger")
                       if p["stage"] == STAGE and p["status"] == "ok"}
    status, still = {}, {}
    for svid in svids:
        oc = Counter(x["outcome"] for x in outcomes if x["source_version_id"] == svid)
        still[svid] = {k: oc[k] for k in OPEN if oc[k]}
        status[svid] = "partial" if still[svid] else "ok"
    # the knowledge base shows a version's last complete extraction; until it has one, its latest partial one
    write = [v for v in svids if status[v] == "ok" or v not in complete_before]
    kept = [v for v in svids if v not in write]
    mine = set(write)
    store.replace_where("records", "source_version_id", write,
                        [store_row(r, ct) for r in records if r.citation.get("source_version_id") in mine],
                        where={"origin": list(MODEL_ORIGINS)})
    store.replace_where("value_sets", "source_version_id", write,
                        [v for v in value_sets if v["source_version_id"] in mine], where={"origin": "pattern"})
    store.replace_where("proposals", "run_id", [run_id], proposals)
    store.replace_where("extraction_outcomes", "run_id", [run_id], outcomes)
    rows = []
    for svid in svids:
        counts = {"records": sum(1 for r in records if r.citation.get("source_version_id") == svid),
                  "outcomes": dict(sorted(Counter(x["outcome"] for x in outcomes
                                                  if x["source_version_id"] == svid).items())),
                  "records_written": svid in mine}
        msg = ""
        if still[svid]:
            msg = ", ".join(f"{n} {k}" for k, n in still[svid].items()) + ": due again"
            if svid in kept:
                msg += "; the records of its last complete run are kept (this run's are in its folder)"
        rows.append(ledger.processing_row(svid, STAGE, versions[svid], run_id, status[svid], counts, msg,
                                          started_at=info.get("started_at")))
    store.write("processing_ledger", rows, mode="append")
    partial = [v for v in svids if status[v] == "partial"]
    log(f"persisted {run_id}: {len(records):,} records, {len(proposals):,} proposals, {len(outcomes):,} outcomes for "
        f"{len(svids)} version(s)" + (f"; {len(partial)} partial (due again)" if partial else "") +
        (f"; {len(kept)} kept their last complete records" if kept else ""))
    return {"run_id": run_id, "records": len(records), "versions": svids, "partial": partial, "kept": kept}
