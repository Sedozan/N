"""One call per pipeline step: what the notebooks run, and what a local end-to-end run calls in the same order.

  sync_registry       kb_source_registry from reference/sources.csv
  intake              new files (dropped in the inbox, or fetched where the site is reachable) into the archive and
                      kb_source_versions; a file already held is recognised by its bytes and not filed again
  parse               PDFs into kb_sections (stage "parse")
  tables              table files into rows, records, value sets (stage "extract_tables")
  export_narrative    due sections to files for the GPU notebook
  extract_narrative   the GPU step: plan, generate, ground (files only, no Spark)
  persist_narrative   every finished run folder not persisted yet into the tables
  build               the knowledge base as of a date (kb_records_current and the rest)
  review_out          the review workbook of the latest build
  review_in           a filled workbook into the review log (rebuild afterwards)
  status              every active version and where each stage stands
"""
from __future__ import annotations

import glob
import json
import os

from . import config
from .sources import intake as IN
from .sources import ledger
from .sources.registry import Registry


def sync_registry(store, reg: Registry) -> int:
    rows = [{"source_id": d.source_id, "document_key": d.document_key, "doc_id": d.doc_id, "title": d.title,
             "family": d.family, "method": d.method, "parser": d.parser, "authority_level": d.authority_level,
             "binding": d.binding, "jurisdiction": d.jurisdiction, "delivery_systems": list(d.delivery_systems),
             "priority": d.priority, "status": d.status, "cadence": d.cadence, "version_rule": d.version_rule,
             "url": d.url, "listing_url": d.listing_url, "notes": d.notes, "synced_at": ledger.now_iso()}
            for d in reg.docs]
    store.write("source_registry", rows)
    return len(rows)


def intake(store, reg: Registry, inbox_dir: str | None = None, fetch: bool = False, log=print) -> dict:
    """File what is new. A file whose bytes are already held is never filed again: under its filed name it is just
    already filed; under another name it is reported once as a duplicate of the version it repeats. The inbox can stay
    as it is between runs."""
    held = store.read("source_versions")
    ids = {h["source_version_id"] for h in held}
    # a file seen again under the name it was filed with is simply already filed; under another name it is reported
    # once as a duplicate of the version it repeats
    dup_seen = {(h.get("duplicate_of"), h.get("original_name")) for h in held if h.get("status") == "duplicate"} | \
        {(h["source_version_id"], h.get("original_name")) for h in held if h.get("status") == "active"}
    rows, fetched = [], set()
    if fetch:
        from .sources import fetch as F
        ok, detail = F.egress_check()
        log(f"egress: {detail}")
        if ok:
            last = {}
            for h in held:
                if h.get("origin") == "fetch" and h.get("http_last_modified"):
                    last[f"{h['source_id']}" + ("" if h["document_key"] == "main" else f"/{h['document_key']}")] = \
                        {"last_modified": h["http_last_modified"]}
            for res in F.fetch_all(reg, previous=last):
                if res["status"] != "downloaded":
                    log(f"  fetch {res['doc_id']}: {res['status']} {res.get('reason', '')}".rstrip())
                    continue
                fetched.add(os.path.abspath(res["path"]))
                rows.append(IN.accession(res["path"], reg, held + [r for r in rows if r["status"] == "active"],
                                         origin="fetch", origin_url=res["headers"].get("final_url") or res["url"],
                                         http_last_modified=res["headers"].get("last_modified")))
    known = held + [r for r in rows if r["status"] == "active"]
    for path in IN.scan(inbox_dir):
        if os.path.abspath(path) in fetched:
            continue
        row = IN.accession(path, reg, known)
        rows.append(row)
        if row["status"] == "active":
            known.append(row)
    new = []
    for r in rows:
        if r["status"] == "duplicate":
            if (r["duplicate_of"], r["original_name"]) in dup_seen:
                continue
            dup_seen.add((r["duplicate_of"], r["original_name"]))
        elif r["source_version_id"] in ids:
            continue
        ids.add(r["source_version_id"])
        new.append(r)
    if new:
        store.write("source_versions", new, mode="append")
    out = {s: [r["source_version_id"] for r in new if r["status"] == s] for s in ("active", "duplicate", "quarantined")}
    log(f"intake: {len(out['active'])} new version(s), {len(out['duplicate'])} new duplicate(s), "
        f"{len(out['quarantined'])} quarantined, {len(rows) - len(new)} file(s) already filed")
    for r in new:
        if r["status"] == "quarantined":
            log(f"  quarantined {r['original_name']}: {r['notes'][:160]}")
    return out


def parse(store, reg, only=None, force=False, log=print) -> dict:
    from .parse import run as R
    return R.run(store, reg, only=only, force=force, log=log)


def tables(store, reg, only=None, force=False, log=print) -> dict:
    from .tables import run as R
    return R.run(store, reg, only=only, force=force, log=log)


def export_narrative(store, reg, model=None, reasoning=None, only=None, force=False, log=print) -> dict:
    from .extract import run as R
    return R.export(store, reg, only=only, force=force, model=model, reasoning=reasoning, log=log)


def backend(kind: str = "hf_local", reasoning: str | None = None, client=None):
    """hf_local: gpt-oss-120b on this GPU; serving: the Databricks endpoint (client from WorkspaceClient); cache_only:
    re-ground on a CPU from earlier answers of the hf_local backend; none: patterns only."""
    from .extract import backends as B
    if kind == "hf_local":
        return B.HFLocalBackend(reasoning=reasoning)
    if kind == "serving":
        if client is None:
            from databricks.sdk import WorkspaceClient
            client = WorkspaceClient().serving_endpoints.get_open_ai_client()
        return B.ServingBackend(client, reasoning=reasoning)
    if kind == "cache_only":
        return B.CacheOnly(reasoning=reasoning)
    if kind == "none":
        return B.NoModel()
    raise ValueError(f"unknown backend {kind!r}: hf_local, serving, cache_only or none")


def extract_narrative(be, reg, stage_dir=None, max_minutes=None, batch=None, limit=None, sections=None,
                      log=print) -> dict:
    from .extract import run as R
    return R.extract(stage_dir or os.path.join(config.STAGE_DIR, "narrative"), be, reg, max_minutes=max_minutes,
                     batch=batch, limit=limit, sections=sections, log=log)


def runs(runs_dir: str | None = None) -> list:
    """Run folders, oldest first, with their manifests."""
    out = []
    for p in glob.glob(os.path.join(runs_dir or config.RUNS_DIR, "*", "manifest.json")):
        try:
            with open(p, encoding="utf-8") as f:
                m = json.load(f)
        except (OSError, ValueError):
            continue
        out.append({"run_dir": os.path.dirname(p), **{k: m.get(k) for k in ("run_id", "started_at", "finished",
                                                                              "dry_run", "records", "outcomes")}})
    return sorted(out, key=lambda r: r.get("started_at") or "")


def persist_narrative(store, reg, run_dir: str | None = None, log=print) -> list:
    """The given run folder, or every finished, non-dry run not persisted yet, oldest first."""
    from .extract import run as R
    if run_dir:
        return [R.persist(store, reg, run_dir, log=log)]
    done = {p["run_id"] for p in store.read("processing_ledger") if p["stage"] == R.STAGE}
    out = []
    for r in runs():
        if r["finished"] and not r["dry_run"] and r["run_id"] not in done:
            out.append(R.persist(store, reg, r["run_dir"], log=log))
    if not out:
        log("no finished run waiting to be persisted")
    return out


def build(store, reg, today=None, log=print) -> dict:
    from .kb import build as KB
    return KB.build(store, reg, today=today, log=log)


def review_out(store, reg, path: str | None = None, sources: set | None = None) -> dict:
    from .review import workbook as WB
    path = path or os.path.join(config.REVIEW_OUT_DIR, f"review_{IN.stamp()}.xlsx")
    return WB.export(store, reg, path, sources=sources)


def review_in(store, reg, path: str, log=print) -> dict:
    from .review import workbook as WB
    return WB.ingest(store, reg, path, log=log)


def status(store, reg) -> list:
    """One row per active version: its date, each stage's latest outcome, and its records by origin."""
    proc = store.read("processing_ledger")
    latest: dict = {}
    for p in sorted(proc, key=lambda p: p.get("finished_at") or ""):
        latest[(p["source_version_id"], p["stage"])] = p
    counts: dict = {}
    for r in store.read("records"):
        key = (r.get("source_version_id"), r.get("origin"))
        counts[key] = counts.get(key, 0) + 1
    out = []
    for v in store.read("source_versions"):
        if v.get("status") != "active":
            continue
        svid = v["source_version_id"]
        row = {"source_version_id": svid, "source_id": v["source_id"], "version_date": v.get("version_date"),
               "file": v.get("original_name")}
        for stage in ("parse", "extract_tables", "extract_narrative"):
            p = latest.get((svid, stage))
            row[stage] = f"{p['status']} ({p['finished_at'][:10]})" if p else ""
        for origin in ("table", "pattern", "model", "pattern+model", "sme"):
            row[f"records_{origin}"] = counts.get((svid, origin), 0)
        out.append(row)
    return sorted(out, key=lambda r: (r["source_id"], r["version_date"] or ""))
