"""Review decisions, each bound to the exact content it was made on.

Every decision is a kb_review_log row; `content_sha_reviewed` is a hash of what the person saw:
  record      approve | reject | fix | defer, on the record's content_sha. A fix makes a corrected record (origin "sme",
              authored by the reviewer) that needs a second reviewer; the original is superseded.
  reading     sign | reject, on a table reading's text and binds
  precedence  sign | reject, on a precedence statement's quote, sources and matter
  conflict    a | b | both | defer, on the content of both records (a: the record listed first prevails)
  category    map | none | defer, on the category's words and source: map names the value set it means
A decision made on other content (the record changed since) is stale: shown to the reviewer, never applied. The latest
decision on the current content wins.

Four eyes: a record a person authored (origin "sme", review.author) is approved only by someone else.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone

from ..core.hashing import sha256_text, short_hash
from ..core.text import match_form

SUBJECTS = {"record": ("approve", "reject", "fix", "defer"), "reading": ("sign", "reject"),
            "precedence": ("sign", "reject"), "conflict": ("a", "b", "both", "defer"),
            "category": ("map", "none", "defer")}


def same_person(a: str | None, b: str | None) -> bool:
    """Names compared without case or spacing ('Jane  Doe' is 'jane doe'); initials are not resolved, so the
    workbook shows each record's author next to the Reviewer column."""
    def norm(x):
        return " ".join(str(x or "").split()).casefold()
    return bool(norm(a)) and norm(a) == norm(b)


def reading_sha(reading) -> str:
    return sha256_text(f"{reading.reading}|{reading.binds}")[:16]


def precedence_sha(p) -> str:
    return sha256_text(f"{p.quote}|{';'.join(p.prevails)}|{';'.join(p.over)}|{p.matter}")[:16]


def conflict_sha(sha_a: str, sha_b: str) -> str:
    return sha256_text("|".join(sorted([sha_a or "", sha_b or ""])))[:16]


def category_key(source_id: str, category: str) -> str:
    return f"{source_id}:{match_form(category)}"


def category_sha(source_id: str, category: str) -> str:
    return sha256_text(category_key(source_id, category))[:16]


def row(subject_type: str, subject_id: str, decision: str, reviewer: str, sha: str, *, note: str = "",
        correction: dict | None = None, source_version_id: str = "", workbook: str = "",
        decided_at: str | None = None) -> dict:
    if decision not in SUBJECTS[subject_type]:
        raise ValueError(f"{decision!r} is not a {subject_type} decision ({', '.join(SUBJECTS[subject_type])})")
    if not (reviewer or "").strip():
        raise ValueError("a decision needs the reviewer's name")
    # microseconds: two decisions in one second (a sign, then a reject) must keep their order
    at = decided_at or datetime.now(timezone.utc).isoformat(timespec="microseconds")
    # from a workbook the id leaves the time out, so ingesting the same workbook twice adds nothing
    ident = (subject_type, subject_id, decision, reviewer.strip(), sha, workbook, note or "") if workbook else \
        (subject_type, subject_id, decision, reviewer.strip(), sha, at)
    return {"decision_id": "D-" + short_hash(*ident),
            "subject_type": subject_type, "record_id": subject_id, "decision": decision,
            "reviewer": reviewer.strip(), "decided_at": at, "note": note or "", "correction": correction or {},
            "content_sha_reviewed": sha, "source_version_id": source_version_id, "applied": "ingested",
            "workbook": workbook}


class Log:
    """The review log indexed by (subject type, id)."""

    def __init__(self, rows: list):
        self.by: dict = defaultdict(list)
        for r in rows or []:
            r = dict(r)
            if isinstance(r.get("correction"), str):
                try:
                    r["correction"] = json.loads(r["correction"] or "{}")
                except ValueError:
                    r["correction"] = {}
            self.by[(r.get("subject_type") or "record", r["record_id"])].append(r)
        for v in self.by.values():
            v.sort(key=lambda r: (r["decided_at"], r["decision_id"]))

    def current(self, subject_type: str, subject_id: str, sha: str) -> tuple[dict | None, list]:
        """(the latest decision on this content, the decisions made on other content)."""
        rows = self.by.get((subject_type, subject_id), [])
        mine = [r for r in rows if r["content_sha_reviewed"] == sha]
        return (mine[-1] if mine else None), [r for r in rows if r["content_sha_reviewed"] != sha]

    def all(self, subject_type: str) -> list:
        return [r for (t, _), rows in self.by.items() if t == subject_type for r in rows]


def reading_status(reading, log: Log) -> tuple[str, str]:
    """(signed | rejected | proposed, basis). A decision in the review log on the current text wins; otherwise the
    status written in table_readings.csv (signed only with a reviewer's name)."""
    d, _ = log.current("reading", reading.reading_id, reading_sha(reading))
    if d:
        return ("signed" if d["decision"] == "sign" else "rejected"), f"{d['decision']} by {d['reviewer']}"
    if reading.status == "signed" and reading.reviewer:
        return "signed", f"signed by {reading.reviewer} (table_readings.csv)"
    if reading.status == "rejected" and reading.reviewer:
        return "rejected", f"rejected by {reading.reviewer} (table_readings.csv)"
    return "proposed", "not signed"


def precedence_status(p, log: Log) -> tuple[str, str]:
    d, _ = log.current("precedence", p.precedence_id, precedence_sha(p))
    if d:
        return ("signed" if d["decision"] == "sign" else "rejected"), f"{d['decision']} by {d['reviewer']}"
    if p.status == "signed" and p.reviewer:
        return "signed", f"signed by {p.reviewer} (precedence.csv)"
    return p.status or "proposed", "not signed"
