"""The review workbook: what needs a person's decision, out to Excel and back into the review log.

  Records      records waiting for a decision (proposed or needs review; table records are decided through their
               readings): Approve, Reject, Fix (fill the corrected fields) or Defer
  Readings     table readings not yet signed: Sign or Reject
  Precedence   precedence statements not yet signed: Sign or Reject
  Conflicts    open conflicts of the latest build: A (record A prevails), B, Both (no conflict: both apply) or Defer
  Categories   services named without codes, with the closest service code sets: Map (give the value set id), None
               (names no code set) or Defer
  New records  a record the extraction missed, quoted verbatim from its section; someone other than its author
               approves it
Every row carries, in its last columns, the id and content hash its decision binds to. Ingest refuses a row whose
record, reading, statement or conflict changed since the export, a Fix the section does not support, and an author
approving their own record. The workbook is exported after a build (kb/build.py), whose state it shows.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from collections import defaultdict

from .. import config
from ..core.record import Record, store_row
from ..extract import lists as LS
from ..extract.ground import ground
from ..kb import resolve as RS
from ..tables import readings as RD
from . import decisions as DC

DECISIONS = {"Records": ("Approve", "Reject", "Fix", "Defer"), "Readings": ("Sign", "Reject"),
             "Precedence": ("Sign", "Reject"), "Conflicts": ("A", "B", "Both", "Defer"),
             "Categories": ("Map", "None", "Defer")}
REVIEW_COLS = ["Decision", "Reviewer", "Note"]
HELP = [
    "PIE review workbook",
    "",
    "Fill Decision and Reviewer (your name) on the rows you decide; leave the others blank. Note is optional.",
    "Records: Approve, Reject, Fix or Defer. For Fix, write the corrected fields in the Fix columns (JSON for subject,"
    " params, conditions; exceptions as a JSON list of verbatim clauses). A fixed record becomes a new record that a"
    " second person approves. Rows that can judge claims come first; pointers and definitions (class knowledge) come"
    " last and can be approved in bulk once a sample reads right.",
    "Readings and Precedence: Sign or Reject the reading as written. Table records are approved when every reading"
    " they rest on is signed.",
    "Conflicts: A (record A prevails), B, Both (they do not conflict: both apply) or Defer. The suggestion follows the"
    " source's own precedence statement, then authority, then specificity, then date; it is never applied unsigned.",
    "Categories: Map (and give the value set id, e.g. SVC:A7:Support Services > Unskilled Respite Care), None or"
    " Defer.",
    "New records: one row per record the extraction missed; the quote must be the section's own words. Author is"
    " your name; someone else approves it in a later workbook.",
    "Do not edit the id and hash columns at the right of each sheet: they bind your decision to what you saw.",
]


def _j(v) -> str:
    return "" if v in (None, "", [], {}) else json.dumps(v, ensure_ascii=False, sort_keys=True)


def _latest_build(store) -> tuple[str, list]:
    """(build id, its records): kb_records_current holds exactly the latest build."""
    current = store.read("records_current")
    if not current:
        raise ValueError("no build yet: run the knowledge base build (kb/build.py) before exporting a workbook")
    ids = {c["build_id"] for c in current}
    if len(ids) != 1:
        raise ValueError(f"kb_records_current mixes builds {sorted(ids)}: run the build again")
    return ids.pop(), current


# ------------------------------------------------------------------ export
def rows_for(store, reg, sources: set | None = None) -> dict:
    """The rows of each sheet, as lists of dicts (the workbook's content without Excel)."""
    build_id, current = _latest_build(store)
    by_id = {c["record_id"]: c for c in current}
    rlog = DC.Log(store.read("review_log"))

    def wanted(c):
        return sources is None or c["source_id"] in sources
    order = {(d.source_id, d.document_key): (d.priority, i) for i, d in enumerate(reg.docs)}
    recs = [c for c in current if c["origin"] != "table" and c["status"] in ("proposed", "needs_review") and wanted(c)]
    # rules that can judge claims first; pointers and definitions (knowledge) last, where they can be approved in bulk
    weight = {"executable": 0, "conditional": 1, "signal": 2, "unresolved": 3, "knowledge": 4}
    recs.sort(key=lambda c: (weight.get(c["execution_class"], 5), order.get((c["source_id"], c["document_key"]),
                                                                              ("P9", 0)), c["source_version_id"],
                             (c["citation"] or {}).get("page_start") or 0, (c["citation"] or {}).get("section_path")
                             or "", c["kind"]))
    records = []
    for c in recs:
        cit = c["citation"] or {}
        records.append({
            "Source": cit.get("title") or c["source_id"], "Version": c["source_version_id"],
            "Page": cit.get("page_start") or "", "Section": cit.get("section_path") or cit.get("locator"),
            "Kind": c["kind"], "Statement": c["statement"], "Quote": cit.get("quote"),
            "Subject": _j(c["subject"]), "Params": _j(c["params"]), "Conditions": _j(c["conditions"]),
            "Exceptions": _j([e.get("text") for e in c["exceptions"] or []]),
            "Window": f"{c['effective_start'] or '?'} to {c['effective_end'] or 'open'}",
            "Class": c["execution_class"], "Why": "; ".join(c["execution_reasons"] or []),
            "Codes resolved": ", ".join(c["resolved_codes"] or []) + (f" ({c['resolution']})" if c["resolution"]
                                                                      else ""),
            "Flags": "; ".join(f.get("text") or f.get("code") for f in c["flags"] or []),
            "Origin": c["origin"], "Author": (c["review"] or {}).get("author", ""),
            "Status": f"{c['status']}: {c['status_basis']}",
            "Fix: kind": "", "Fix: subject": "", "Fix: params": "", "Fix: conditions": "", "Fix: exceptions": "",
            "Fix: quote": "", "record_id": c["record_id"], "content_sha": c["content_sha"]})
    readings = []
    for rid, r in sorted(RD.load().items()):
        st, basis = DC.reading_status(r, rlog)
        if st != "signed":
            readings.append({"Reading": rid, "Table": r.spec, "Reads": r.reading, "Evidence": r.evidence,
                             "Settings": r.binds, "Status": f"{st}: {basis}", "reading_id": rid,
                             "content_sha": DC.reading_sha(r)})
    precedence = []
    for p in reg.precedence:
        st, basis = DC.precedence_status(p, rlog)
        if st != "signed":
            precedence.append({"Statement": p.precedence_id, "Stated in": f"{p.stated_in} p.{p.page}", "Quote": p.quote,
                               "Prevails": ", ".join(p.prevails), "Over": ", ".join(p.over), "Matter": p.matter,
                               "Meaning": p.notes, "Status": f"{st}: {basis}", "precedence_id": p.precedence_id,
                               "content_sha": DC.precedence_sha(p)})
    conflicts = []
    for c in store.read("conflicts"):
        if c["build_id"] != build_id or c["status"] != "open":
            continue
        a, b = by_id.get(c["record_a"]), by_id.get(c["record_b"])
        if not a or not b or not (wanted(a) or wanted(b)):
            continue

        def side(x):
            cit = x["citation"] or {}
            return f"{cit.get('title') or x['source_id']} p.{cit.get('page_start') or '?'}: {x['statement']}"
        conflicts.append({"Conflict": c["conflict_id"], "Relationship": c["relationship"], "Codes": ", ".join(
            c["codes"] or []), "Detail": c["detail"], "Overlap": f"{c['window_start'] or '?'} to "
                                                               f"{c['window_end'] or 'open'}",
            "A": side(a), "A quote": (a["citation"] or {}).get("quote"), "B": side(b),
            "B quote": (b["citation"] or {}).get("quote"),
            "Suggested": "A" if c["suggested_prevailing"] == a["record_id"] else
            "B" if c["suggested_prevailing"] == b["record_id"] else "", "Basis": c["basis"],
            "conflict_id": c["conflict_id"], "record_a": a["record_id"], "record_b": b["record_id"],
            "content_sha": DC.conflict_sha(a["content_sha"], b["content_sha"])})
    value_sets = store.read("value_sets")
    cats: dict = defaultdict(list)
    for c in current:
        if wanted(c) and c["resolution"].startswith("unresolved") and (c["subject"] or {}).get("category"):
            cats[(c["source_id"], c["subject"]["category"])].append(c)
    categories = []
    for (src, cat), cs in sorted(cats.items()):
        sug = RS.suggestions(cat, value_sets)
        categories.append({"Category": cat, "Source": src, "Records": len(cs), "Example": cs[0]["statement"],
                           "Suggestions": "; ".join(f"{v} (match {s}, {n} codes)" for v, s, n in sug),
                           "Value set id": sug[0][0] if sug else "", "category_key": DC.category_key(src, cat),
                           "content_sha": DC.category_sha(src, cat)})
    return {"build_id": build_id, "Records": records, "Readings": readings, "Precedence": precedence,
            "Conflicts": conflicts, "Categories": categories}


def export(store, reg, path: str, sources: set | None = None) -> dict:
    """Write the workbook to `path` (built locally, then copied: Unity Catalog volumes take whole files only)."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font
    from openpyxl.worksheet.datavalidation import DataValidation
    data = rows_for(store, reg, sources)
    wb = Workbook()
    ws = wb.active
    ws.title = "How to review"
    for i, line in enumerate(HELP + ["", f"Build: {data['build_id']}"], start=1):
        ws.cell(row=i, column=1, value=line).alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(row=1, column=1).font = Font(bold=True, size=14)
    ws.column_dimensions["A"].width = 120
    for name in ("Records", "Readings", "Precedence", "Conflicts", "Categories"):
        rows = data[name]
        sheet = wb.create_sheet(name)
        keys = list(rows[0].keys()) if rows else []
        first = ["Value set id"] if name == "Categories" else []      # the cell a reviewer fills, next to Decision
        cols = REVIEW_COLS + first + [k for k in keys if k not in first]
        for j, col in enumerate(cols, start=1):
            cell = sheet.cell(row=1, column=j, value=col)
            cell.font = Font(bold=True)
            sheet.column_dimensions[cell.column_letter].width = 60 if col in (
                "Statement", "Quote", "Reads", "A", "B", "A quote", "B quote", "Example", "Why", "Evidence",
                "Suggestions") else 18
        for i, r in enumerate(rows, start=2):
            for j, col in enumerate(cols, start=1):
                v = r.get(col, "")
                sheet.cell(row=i, column=j, value=v if not isinstance(v, (list, dict)) else _j(v)).alignment = \
                    Alignment(wrap_text=True, vertical="top")
        dv = DataValidation(type="list", formula1='"' + ",".join(DECISIONS[name]) + '"', allow_blank=True)
        sheet.add_data_validation(dv)
        dv.add(f"A2:A{max(2, len(rows) + 1)}")
        sheet.freeze_panes = "D2"
    new = wb.create_sheet("New records")
    cols = ["Source version id", "Section id", "Kind", "Subject", "Params", "Conditions", "Exceptions", "Quote",
            "Author", "Note"]
    for j, col in enumerate(cols, start=1):
        new.cell(row=1, column=j, value=col).font = Font(bold=True)
        new.column_dimensions[new.cell(row=1, column=j).column_letter].width = 30
    new.cell(row=2, column=1, value="(example) A7@2026-10-01#4bec407f")
    new.cell(row=2, column=3, value="units_limit")
    new.cell(row=2, column=4, value='{"category": "Unskilled respite care"}')
    new.cell(row=2, column=5, value='{"max": 600, "per": "benefit_year", "unit_basis": "hour"}')
    new.cell(row=2, column=8, value="(the section's words, verbatim)")
    fd, tmp = tempfile.mkstemp(suffix=".xlsx")
    os.close(fd)
    try:
        wb.save(tmp)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        shutil.copyfile(tmp, path)
    finally:
        os.remove(tmp)
    counts = {k: len(data[k]) for k in DECISIONS}
    return {"path": path, "build_id": data["build_id"], **counts}


# ------------------------------------------------------------------ ingest
def _sheet_rows(wb, name: str) -> list:
    if name not in wb.sheetnames:
        return []
    ws = wb[name]
    it = ws.iter_rows(values_only=True)
    head = next(it, None)
    if not head:
        return []
    head = [str(h or "").strip() for h in head]
    out = []
    for n, vals in enumerate(it, start=2):
        r = {h: (v.strip() if isinstance(v, str) else v) for h, v in zip(head, vals) if h}
        if any(v not in (None, "") for v in r.values()):
            r["_row"] = n
            out.append(r)
    return out


def _json(v, what: str):
    if v in (None, ""):
        return None
    try:
        return json.loads(v) if isinstance(v, str) else v
    except ValueError as e:
        raise ValueError(f"{what} is not valid JSON: {e}") from e


def _ground_sme(prop: dict, section: dict, doc, svid: str, author: str, extra: dict, store_universe: set):
    tk = LS.tokenize(section["text"], store_universe | set((section.get("codes") or {}).get("procedure") or []))
    ctx = {"doc": doc, "source_version_id": svid, "universe": store_universe, "origin": "sme",
           "extraction": {"author": author, **extra}}
    g = ground(prop, section, tk, ctx)
    if not g.kept:
        return None, g.reason
    rec = g.record
    rec.review = {"author": author, **extra}
    rec.status = "needs_review"
    rec.flags = list(rec.flags) + [{"code": "authored", "text": f"written by {author}; another person approves it"}]
    return rec, ""


def ingest(store, reg, path: str, log=print) -> dict:
    """Read a filled workbook into kb_review_log (and corrected or new records into kb_records)."""
    from openpyxl import load_workbook
    from ..kb.spine import spine
    wb = load_workbook(path, read_only=True, data_only=True)
    with open(path, "rb") as f:                   # the file's content is in each decision id: a later workbook
        digest = hashlib.sha256(f.read()).hexdigest()[:10]   # with the same name is a new set of decisions
    name = f"{os.path.basename(path)}#{digest}"
    have = {r["decision_id"] for r in store.read("review_log")}
    records = {r["record_id"]: Record.from_row(r) for r in store.read("records")}
    sections = {s["section_id"]: s for s in store.read("sections")}
    readings = RD.load()
    statements = {p.precedence_id: p for p in reg.precedence}
    universe, _ = spine(store, reg)
    svc = set(RS.service_sets(store.read("value_sets")))
    decisions, new_records, errors = [], [], []

    def err(sheet, r, msg):
        errors.append(f"{sheet} row {r['_row']}: {msg}")

    def add(row):
        if row["decision_id"] not in have:
            have.add(row["decision_id"])
            decisions.append(row)

    for r in _sheet_rows(wb, "Records"):
        dec, who = (r.get("Decision") or ""), (r.get("Reviewer") or "")
        if not dec:
            continue
        if dec not in DECISIONS["Records"] or not who:
            err("Records", r, "Decision must be Approve, Reject, Fix or Defer, with a Reviewer")
            continue
        rec = records.get(r.get("record_id"))
        if rec is None:
            err("Records", r, f"record {r.get('record_id')} is no longer in the knowledge base")
            continue
        if rec.content_sha != r.get("content_sha"):
            err("Records", r, "the record changed since this workbook was exported (stale): export a new one")
            continue
        if dec == "Approve" and rec.origin == "sme" and DC.same_person((rec.review or {}).get("author"), who):
            err("Records", r, f"{who} wrote this record; another person approves it")
            continue
        if dec == "Fix":
            if rec.origin == "table":
                err("Records", r, "a table record is corrected through its reading, not here")
                continue
            sec = sections.get(rec.citation.get("section_id"))
            if sec is None:
                err("Records", r, "its section is not in kb_sections")
                continue
            try:
                prop = {"kind": r.get("Fix: kind") or rec.kind,
                        "subject": _json(r.get("Fix: subject"), "Fix: subject") or rec.subject,
                        "params": _json(r.get("Fix: params"), "Fix: params") or rec.params,
                        "conditions": _json(r.get("Fix: conditions"), "Fix: conditions") or rec.conditions,
                        "exceptions": _json(r.get("Fix: exceptions"), "Fix: exceptions") or
                        [e["text"] for e in rec.exceptions], "quote": r.get("Fix: quote") or rec.citation["quote"],
                        "effective": rec.effective_start, "end": rec.effective_end}
            except ValueError as e:
                err("Records", r, str(e))
                continue
            doc = reg.get(rec.citation["source_id"], rec.citation.get("document_key") or "main")
            fixed, why = _ground_sme(prop, sec, doc, rec.citation["source_version_id"], who,
                                     {"corrected_from": rec.record_id}, universe)
            if fixed is None:
                err("Records", r, f"the fix does not hold against the section: {why}")
                continue
            if fixed.record_key == rec.record_key and fixed.citation["quote"] == rec.citation["quote"]:
                err("Records", r, "the fix changes nothing: use Approve")
                continue
            new_records.append(fixed)
        add(DC.row("record", rec.record_id, dec.lower(), who, rec.content_sha, note=r.get("Note") or "",
                   correction={"record_id": new_records[-1].record_id} if dec == "Fix" else None,
                   source_version_id=rec.citation.get("source_version_id"), workbook=name))
    for sheet, kind, lookup, sha_of in (("Readings", "reading", readings, DC.reading_sha),
                                        ("Precedence", "precedence", statements, DC.precedence_sha)):
        id_col = "reading_id" if kind == "reading" else "precedence_id"
        for r in _sheet_rows(wb, sheet):
            dec, who = (r.get("Decision") or ""), (r.get("Reviewer") or "")
            if not dec:
                continue
            item = lookup.get(r.get(id_col))
            if dec not in DECISIONS[sheet] or not who or item is None:
                err(sheet, r, "Decision must be Sign or Reject, with a Reviewer, on a known row")
                continue
            if sha_of(item) != r.get("content_sha"):
                err(sheet, r, "its wording changed since this workbook was exported (stale)")
                continue
            add(DC.row(kind, r[id_col], dec.lower(), who, sha_of(item), note=r.get("Note") or "", workbook=name))
    for r in _sheet_rows(wb, "Conflicts"):
        dec, who = (r.get("Decision") or ""), (r.get("Reviewer") or "")
        if not dec:
            continue
        a, b = records.get(r.get("record_a")), records.get(r.get("record_b"))
        if dec not in DECISIONS["Conflicts"] or not who or not a or not b:
            err("Conflicts", r, "Decision must be A, B, Both or Defer, with a Reviewer, on two known records")
            continue
        sha = DC.conflict_sha(a.content_sha, b.content_sha)
        if sha != r.get("content_sha"):
            err("Conflicts", r, "one of the records changed since this workbook was exported (stale)")
            continue
        add(DC.row("conflict", r["conflict_id"], dec.lower(), who, sha, note=r.get("Note") or "",
                   correction={"record_a": a.record_id, "record_b": b.record_id}, workbook=name))
    for r in _sheet_rows(wb, "Categories"):
        dec, who = (r.get("Decision") or ""), (r.get("Reviewer") or "")
        if not dec:
            continue
        if dec not in DECISIONS["Categories"] or not who or not r.get("category_key"):
            err("Categories", r, "Decision must be Map, None or Defer, with a Reviewer")
            continue
        vid = r.get("Value set id") or ""
        if dec == "Map" and vid not in svc:
            err("Categories", r, f"{vid!r} is not a service code set (SVC:...)")
            continue
        src, cat = r.get("Source") or "", r.get("Category") or ""
        if DC.category_sha(src, cat) != r.get("content_sha"):
            err("Categories", r, "the category or source cell was edited")
            continue
        add(DC.row("category", DC.category_key(src, cat), dec.lower(), who, r["content_sha"],
                   note=r.get("Note") or "", correction={"value_set_id": vid} if dec == "Map" else None,
                   workbook=name))
    for r in _sheet_rows(wb, "New records"):
        svid, who = r.get("Source version id") or "", r.get("Author") or ""
        if not r.get("Kind") or str(svid).startswith("(example)"):
            continue
        sec = sections.get(r.get("Section id") or "")
        if sec is None or sec["source_version_id"] != svid or not who:
            err("New records", r, "needs a Source version id, the Section id of that version, and an Author")
            continue
        try:
            prop = {"kind": r["Kind"], "subject": _json(r.get("Subject"), "Subject") or {},
                    "params": _json(r.get("Params"), "Params") or {},
                    "conditions": _json(r.get("Conditions"), "Conditions") or [],
                    "exceptions": _json(r.get("Exceptions"), "Exceptions") or [], "quote": r.get("Quote") or ""}
        except ValueError as e:
            err("New records", r, str(e))
            continue
        doc = reg.get(sec["source_id"], sec["document_key"])
        rec, why = _ground_sme(prop, sec, doc, svid, who, {"note": r.get("Note") or ""}, universe)
        if rec is None:
            err("New records", r, f"does not hold against the section: {why}")
            continue
        new_records.append(rec)
    if new_records:
        store.replace_where("records", "record_id", [x.record_id for x in new_records],
                            [store_row(x, config.CLAIM_TYPE) for x in new_records])
    if decisions:
        store.write("review_log", decisions, mode="append")
    if not decisions and not new_records and not errors:
        log(f"WARNING: {name} has no filled row (no Decision with a Reviewer): is it the filled workbook, or a fresh "
            f"export?")
    log(f"ingested {name}: {len(decisions)} decision(s), {len(new_records)} new record(s), {len(errors)} row(s) "
        f"refused")
    for e in errors[:20]:
        log(f"  {e}")
    return {"decisions": len(decisions), "new_records": len(new_records), "errors": errors}
