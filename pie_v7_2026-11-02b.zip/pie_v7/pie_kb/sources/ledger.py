"""The ledgers: every file version PIE holds (kb_source_versions) and every processing step run on it
(kb_processing_ledger). Pure Python over lists of dicts; io/store.py writes them to Delta.

"Already processed" holds per configuration: a version is due for a stage until a run with the CURRENT config id
finished that stage on it. A parser or prompt change gives a new config id, so the versions become due again, but
only when a run asks for that stage.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from ..core import dates as D

VERSION_COLUMNS = ("source_version_id", "source_id", "document_key", "version_date", "version_label",
                   "version_basis", "version_evidence", "period_end", "sha256", "bytes", "file_kind",
                   "archive_path", "original_name", "origin", "origin_url", "http_last_modified", "first_seen_at",
                   "status", "duplicate_of", "notes")
PROCESSING_COLUMNS = ("source_version_id", "stage", "config_id", "run_id", "status", "started_at", "finished_at",
                      "counts", "message")
STAGES = ("parse", "extract_tables", "extract_narrative", "review", "build")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def version_id(doc_id: str, label: str, sha256: str) -> str:
    """A11@2026-10-01#4bec407f: the document, its version date and the first 8 characters of the file's sha256."""
    return f"{doc_id}@{label}#{sha256[:8]}"


def windows(versions: list[dict], today: date | None = None, monthly_cadence: set | None = None) -> list[dict]:
    """Effective window of every active version: from its own date to the day before the next version of the same
    document starts (or to the end the version states, whichever is first). The newest is open-ended.

    Adds: effective_start, effective_end, window_basis, in_force_today, future, gap_months (monthly sources: months
    with no version between this one and the next; the older version is presumed in force there, labelled)."""
    today = today or date.today()
    monthly_cadence = monthly_cadence or set()
    out, by_doc = [], {}
    for v in versions:
        if v.get("status") != "active":
            continue
        by_doc.setdefault((v["source_id"], v["document_key"]), []).append(v)
    for (sid, dk), vs in by_doc.items():
        dated = sorted([v for v in vs if v.get("version_date")], key=lambda v: (v["version_date"], v["first_seen_at"]))
        for i, v in enumerate(dated):
            start = D.to_date(v["version_date"])
            nxt = D.to_date(dated[i + 1]["version_date"]) if i + 1 < len(dated) else None
            stated_end = D.to_date(v.get("period_end"))
            ends = [e for e in (D.day_before(nxt) if nxt else None, stated_end) if e]
            end = min(ends) if ends else None
            basis = "next_version" if nxt and (not stated_end or D.day_before(nxt) <= stated_end) else \
                "stated" if stated_end else "open"
            gaps = [m.isoformat() for m in D.months_between(start, nxt)] if (nxt and sid in monthly_cadence) else []
            out.append({**v, "effective_start": start.isoformat(), "effective_end": D.iso(end),
                        "window_basis": basis, "future": start > today,
                        "in_force_today": start <= today and (end is None or end >= today), "gap_months": gaps})
        for v in vs:
            if not v.get("version_date"):
                out.append({**v, "effective_start": None, "effective_end": None, "window_basis": "undated",
                            "future": False, "in_force_today": False, "gap_months": []})
    return out


def due(versions: list[dict], processing: list[dict], stage: str, config_id: str,
        only: set | None = None) -> list[dict]:
    """Active versions with no successful `stage` run under `config_id` (optionally limited to some source ids)."""
    done = {(p["source_version_id"]) for p in processing
            if p["stage"] == stage and p["config_id"] == config_id and p["status"] == "ok"}
    return [v for v in versions if v.get("status") == "active" and v["source_version_id"] not in done
            and (only is None or v["source_id"] in only)]


def processing_row(source_version_id: str, stage: str, config_id: str, run_id: str, status: str,
                   counts: dict | None = None, message: str = "", started_at: str | None = None) -> dict:
    import json
    return {"source_version_id": source_version_id, "stage": stage, "config_id": config_id, "run_id": run_id,
            "status": status, "started_at": started_at or now_iso(), "finished_at": now_iso(),
            "counts": json.dumps(counts or {}, sort_keys=True), "message": message[:2000]}
