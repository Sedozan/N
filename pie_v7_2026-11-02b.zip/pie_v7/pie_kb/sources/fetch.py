"""Fetching registry documents over HTTPS, where the compute can reach the site (decision 10).

Standard library only. A conditional request (If-None-Match / If-Modified-Since) is sent when an earlier download left
an ETag or Last-Modified date; the downloaded bytes must be the file type the registry expects (an error page is
refused, never filed as a policy). Downloads land in INBOX_DIR/downloaded/<source>/ and go through intake like any
dropped file, so a fetched file and a hand-dropped one are treated the same.
"""
from __future__ import annotations

import os
import urllib.error
import urllib.request

from .. import config
from .intake import file_kind
from .registry import Registry, SourceDoc


def egress_check(url: str = "https://www.azahcccs.gov/", timeout: int = 20) -> tuple[bool, str]:
    """(reachable, detail): one HEAD request, so notebook 01 can say up front whether fetching works here."""
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": config.FETCH_USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return True, f"HTTP {r.status} from {url}"
    except Exception as e:                       # noqa: BLE001 - any failure means "not reachable from here"
        return False, f"{type(e).__name__}: {e}"


def fetch(doc: SourceDoc, etag: str = "", last_modified: str = "", dest_dir: str | None = None) -> dict:
    """Download one registry document. Returns {status: downloaded | not_modified | refused | failed, path, headers}."""
    if not doc.url:
        return {"status": "failed", "reason": "the registry row has no URL", "path": ""}
    headers = {"User-Agent": config.FETCH_USER_AGENT, "Accept": "*/*"}
    if etag:
        headers["If-None-Match"] = etag
    if last_modified:
        headers["If-Modified-Since"] = last_modified
    try:
        req = urllib.request.Request(doc.url, headers=headers)
        with urllib.request.urlopen(req, timeout=config.FETCH_TIMEOUT_SECONDS) as r:
            data = r.read(config.MAX_FILE_BYTES + 1)
            info = {"etag": r.headers.get("ETag", ""), "last_modified": r.headers.get("Last-Modified", ""),
                    "final_url": r.geturl()}
    except urllib.error.HTTPError as e:
        if e.code == 304:
            return {"status": "not_modified", "path": "", "headers": {}}
        return {"status": "failed", "reason": f"HTTP {e.code}", "path": ""}
    except Exception as e:                       # noqa: BLE001
        return {"status": "failed", "reason": f"{type(e).__name__}: {e}", "path": ""}
    if len(data) > config.MAX_FILE_BYTES:
        return {"status": "refused", "reason": "larger than MAX_FILE_BYTES", "path": ""}
    want = os.path.splitext(doc.url.split("?")[0])[1].lower().lstrip(".") or "pdf"
    got = file_kind(data)
    if got != want:
        return {"status": "refused", "reason": f"expected a {want} file, got {got} (an error page?)", "path": ""}
    folder = os.path.join(dest_dir or os.path.join(config.INBOX_DIR, "downloaded"), doc.source_id, doc.document_key)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, os.path.basename(doc.url.split("?")[0]))
    with open(path, "wb") as f:
        f.write(data)
    return {"status": "downloaded", "path": path, "headers": info}


def fetch_all(reg: Registry, previous: dict | None = None, dest_dir: str | None = None) -> list[dict]:
    """Fetch every active registry document that has a URL. previous: {doc_id: {etag, last_modified}}."""
    previous = previous or {}
    out = []
    for doc in reg.active():
        if not doc.url:
            continue
        prev = previous.get(doc.doc_id, {})
        res = fetch(doc, prev.get("etag", ""), prev.get("last_modified", ""), dest_dir)
        out.append({"doc_id": doc.doc_id, "url": doc.url, **res})
    return out
