"""The version date of a file, read from the file itself (decision 12): never the download date.

Each registry row names a version rule. Tables (B2, PA guidelines, ...) date themselves through their table spec;
documents are dated here from their first pages. When a file states no date, the server's Last-Modified date is
used and labelled; when there is none either, the version is undated and the build log lists it.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

from ..core import dates as D
from ..core.text import clean


@dataclass(frozen=True)
class VersionInfo:
    date: str | None          # ISO date the version takes effect (or is "as of")
    label: str                # used in ids: the ISO date, or "undated"
    basis: str                # stated | title_fiscal_year | supplement | server_date | file_date | undated
    evidence: str             # the words the date was read from
    period_end: str | None = None   # a version that states its own end (a fiscal-year list)


def _undated(why: str) -> VersionInfo:
    return VersionInfo(None, "undated", "undated", why)


def _dated(d: date | None, basis: str, evidence: str, period_end: date | None = None) -> VersionInfo:
    if d is None:
        return _undated(evidence or "no date found")
    return VersionInfo(d.isoformat(), d.isoformat(), basis, clean(evidence)[:300], D.iso(period_end))


def _list_after(label_rx: str, text: str, stop_rx: str = r"APPROVAL DATES?|PURPOSE|I\.\s|This chapter") -> tuple:
    m = re.search(label_rx + r"\s*:?\s*(.{0,400}?)(?:" + stop_rx + r"|$)", text, re.I | re.S)
    if not m:
        return [], ""
    return D.all_mdy(m.group(1)), m.group(0)


def from_pdf_text(rule: str, text: str, *, server_date: date | None = None) -> VersionInfo:
    """Version of a document from the text of its first pages, by the registry's version rule."""
    t = text or ""
    if rule == "ampm_effective":
        found, ev = _list_after(r"EFFECTIVE DATES?", t)
        return _dated(max(found) if found else None, "stated", ev)
    if rule == "cbhsg_updated":
        m = re.search(r"Updated\s*:?\s*((?:\d{1,2}/\d{1,2}/\d{2,4}[,;\s]*)+)", t, re.I)
        found = D.all_mdy(m.group(1)) if m else []
        return _dated(max(found) if found else None, "stated", m.group(0) if m else "")
    if rule == "manual_revision":
        found, ev = _list_after(r"REVISION DATES?", t, r"[A-Z][A-Z ]{8,}\n|This chapter|The covered|$")
        return _dated(max(found) if found else None, "stated", ev)
    if rule == "aac_supplement":
        m = re.search(r"Supp\.\s*(\d{2})-(\d)", t)
        if m:
            year, q = 2000 + int(m.group(1)), int(m.group(2))
            end = {1: date(year, 3, 31), 2: date(year, 6, 30), 3: date(year, 9, 30), 4: date(year, 12, 31)}.get(q)
            return _dated(end, "supplement", m.group(0) + " (rules codified through the end of that quarter)")
        return _undated("no 'Supp. YY-Q' line")
    if rule == "claims_clues_issue":
        head = t[:600]
        m = re.search(r"Claims\s+Clues.{0,200}?\b((?:January|February|March|April|May|June|July|August|September|"
                      r"October|November|December)\s+\d{4})", head, re.I | re.S)
        return _dated(D.month_year(m.group(1)) if m else None, "stated", m.group(0) if m else "")
    if rule in ("notice_date", "faq_title"):
        m = re.search(r"Effective\s+(?:with\s+claims\s+\w+\s+on\s+and\s+after\s+)?(.{0,30}\d{4})", t[:1500], re.I)
        d = D.any_date(m.group(1)) if m else None
        if d is None:
            d = D.any_date(t[:1500])
            return _dated(d, "stated", "first date in the document")
        return _dated(d, "stated", m.group(0))
    if rule == "dx_list_fy":
        m = re.search(r"\b(20\d{2})\s+AHCCCS\s+BEHAVIORAL\s+HEALTH|AHCCCS\s+(20\d{2})\s+BEHAVIORAL\s+HEALTH", t[:400],
                      re.I)
        if m:
            fy = int(m.group(1) or m.group(2))
            start, end = D.fiscal_year_window(fy)
            return _dated(start, "title_fiscal_year", m.group(0) + f" (read as federal fiscal year {fy})", end)
        return _undated("no year in the list title")
    if rule == "server_date":
        return _dated(server_date, "server_date", "the server's Last-Modified date (the file states none)")
    return _undated(f"no version rule {rule!r} for documents")


def pdf_head_text(path: str, pages: int = 2) -> str:
    import pymupdf
    with pymupdf.open(path) as doc:
        return "\n".join(doc[i].get_text() for i in range(min(pages, doc.page_count)))
