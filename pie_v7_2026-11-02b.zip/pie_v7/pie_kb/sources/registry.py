"""The source registry: one row per approved document (reference/sources.csv), plus the program vocabulary and the
precedence statements sources make about each other.

A row says what a document is (family, authority level, binding), who it applies to by default, how a file is
recognised (file name and title patterns, or a table layout), how its version date is read, and its status:
  active    approved and loadable
  pending   approved, no file or no loader yet
  deferred  approved for a later release (managed care)
  obsolete  no longer in force (kept for the record)
"""
from __future__ import annotations

import csv
import os
import re
from dataclasses import dataclass, field

from .. import config

METHODS = ("table", "narrative", "value_set", "reference")
STATUSES = ("active", "pending", "deferred", "obsolete")
AUTHORITY_LABELS = {1: "federal law, regulation or federal edit", 2: "Arizona statute or administrative rule",
                    3: "AHCCCS Medical Policy Manual or AHCCCS policy", 4: "AHCCCS billing manual",
                    5: "AHCCCS guide or reference table", 6: "AHCCCS notice", 7: "health plan policy"}


@dataclass(frozen=True)
class SourceDoc:
    source_id: str
    document_key: str
    title: str
    family: str
    method: str
    parser: str
    authority_level: int
    binding: str
    jurisdiction: str
    delivery_systems: tuple
    priority: str
    status: str
    cadence: str
    version_rule: str
    url: str
    listing_url: str
    match_filename: str
    match_title: str
    match_not: str
    notes: str
    section_scope: str = ""        # regex on a section's path: only matching sections are extracted ("" = all)

    @property
    def doc_id(self) -> str:
        """source_id/document_key, e.g. A23/cc_2023_05; 'A11' for single-document sources."""
        return self.source_id if self.document_key == "main" else f"{self.source_id}/{self.document_key}"

    def filename_matches(self, name: str) -> bool:
        return bool(self.match_filename) and bool(re.search(self.match_filename, name, re.I))

    def title_matches(self, text: str) -> bool:
        """The title pattern is searched in the first pages; match_not only in the head (the masthead), since a word
        like "supplemental" can occur in any article body."""
        if not self.match_title or not re.search(self.match_title, text, re.I | re.S):
            return False
        return not (self.match_not and re.search(self.match_not, text[:400], re.I | re.S))


@dataclass(frozen=True)
class Program:
    program_id: str
    name: str
    delivery_systems: tuple
    pattern: str


@dataclass(frozen=True)
class Precedence:
    precedence_id: str
    stated_in: str
    document_key: str
    page: int
    quote: str
    prevails: tuple
    over: tuple
    matter: str
    status: str
    reviewer: str
    notes: str


@dataclass
class Registry:
    docs: list = field(default_factory=list)
    programs: list = field(default_factory=list)
    precedence: list = field(default_factory=list)

    def get(self, source_id: str, document_key: str = "main") -> SourceDoc:
        for d in self.docs:
            if d.source_id == source_id and d.document_key == document_key:
                return d
        raise KeyError(f"{source_id}/{document_key} is not in the source registry")

    def active(self, method: str | None = None) -> list:
        return [d for d in self.docs if d.status == "active" and (method is None or d.method == method)]

    def by_parser(self, parser: str) -> list:
        return [d for d in self.docs if d.parser == parser and d.status == "active"]

    def sources(self) -> list:
        return sorted({d.source_id for d in self.docs})


def _split(v: str) -> tuple:
    return tuple(x.strip() for x in (v or "").split(";") if x.strip())


def load(reference_dir: str | None = None) -> Registry:
    ref = reference_dir or config.REFERENCE_DIR
    reg = Registry()
    with open(os.path.join(ref, "sources.csv"), newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            reg.docs.append(SourceDoc(
                source_id=row["source_id"].strip(), document_key=(row["document_key"] or "main").strip(),
                title=row["title"].strip(), family=row["family"].strip(), method=row["method"].strip(),
                parser=(row["parser"] or "none").strip(), authority_level=int(row["authority_level"]),
                binding=row["binding"].strip(), jurisdiction=row["jurisdiction"].strip(),
                delivery_systems=_split(row["delivery_systems"]), priority=row["priority"].strip(),
                status=row["status"].strip(), cadence=row["cadence"].strip(), version_rule=row["version_rule"].strip(),
                url=row["url"].strip(), listing_url=row["listing_url"].strip(),
                match_filename=row["match_filename"].strip(), match_title=row["match_title"].strip(),
                match_not=row["match_not"].strip(), notes=row["notes"].strip(),
                section_scope=(row.get("section_scope") or "").strip()))
    with open(os.path.join(ref, "programs.csv"), newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            reg.programs.append(Program(row["program_id"].strip(), row["name"].strip(),
                                        _split(row["delivery_system"]), row["pattern"].strip()))
    with open(os.path.join(ref, "precedence.csv"), newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            reg.precedence.append(Precedence(row["precedence_id"].strip(), row["stated_in"].strip(),
                                             (row["document_key"] or "main").strip(), int(row["page"]),
                                             row["quote"].strip(), _split(row["prevails"]), _split(row["over"]),
                                             row["matter"].strip(), row["status"].strip(),
                                             (row.get("reviewer") or "").strip(), row["notes"].strip()))
    return reg


def validate(reg: Registry) -> list[str]:
    """Problems with the registry itself ([] = consistent)."""
    p, seen = [], set()
    for d in reg.docs:
        key = (d.source_id, d.document_key)
        if key in seen:
            p.append(f"{d.doc_id} appears twice")
        seen.add(key)
        if d.method not in METHODS:
            p.append(f"{d.doc_id}: unknown method {d.method!r}")
        if d.status not in STATUSES:
            p.append(f"{d.doc_id}: unknown status {d.status!r}")
        if d.authority_level not in AUTHORITY_LABELS:
            p.append(f"{d.doc_id}: authority level {d.authority_level} is not 1 to 7")
        if d.status == "active" and d.parser in ("", "none"):
            p.append(f"{d.doc_id}: active but has no parser")
        if d.status == "active" and d.method in ("narrative", "value_set") and not (d.match_filename or d.match_title):
            p.append(f"{d.doc_id}: active document with no way to recognise its file")
        for rx in (d.match_filename, d.match_title, d.match_not, d.section_scope):
            if rx:
                try:
                    re.compile(rx)
                except re.error as e:
                    p.append(f"{d.doc_id}: bad pattern {rx!r}: {e}")
        if not set(d.delivery_systems) <= {"FFS", "MC"}:
            p.append(f"{d.doc_id}: delivery systems must be FFS and/or MC")
    ids = {d.source_id for d in reg.docs} | {"AMPM"}
    for pr in reg.precedence:
        for s in pr.prevails + pr.over + (pr.stated_in,):
            if s not in ids:
                p.append(f"precedence {pr.precedence_id}: unknown source {s}")
    for prog in reg.programs:
        try:
            re.compile(prog.pattern)
        except re.error as e:
            p.append(f"program {prog.program_id}: bad pattern: {e}")
    return p


def programs_in(text: str, reg: Registry) -> list[str]:
    """Program ids named in a text (an 'applies to' sentence)."""
    text = re.sub(r"\s+", " ", text or "")
    return [p.program_id for p in reg.programs if re.search(p.pattern, text)]


def applicability_from_purpose(text: str, reg: Registry) -> dict:
    """Programs a policy says it applies to, and those it excludes ("excluding Federal Emergency Services Program").

    AMPM policies open with "This Policy applies to ACC, ACC-RBHA, ... and Fee-For-Service (FFS) Programs including
    ...; and all FFS populations, excluding Federal Emergency Services Program (FESP)."
    """
    text = re.sub(r"\s+", " ", text or "")          # a program name can break across lines ("Tribal\nALTCS")
    m = re.search(r"(?:This|The)\s+[Pp]olicy\s+applies\s+to\s+(.+?)(?:\.\s+(?:\(For|This|The|For|Throughout|[A-Z])|$)",
                  text, re.S)
    if not m:
        return {}
    clause = m.group(1)
    excl_part = ""
    em = re.search(r"\bexcluding\b(.+)$", clause, re.I | re.S)
    if em:
        excl_part, clause = em.group(1), clause[:em.start()]
    include = programs_in(clause, reg)
    exclude = programs_in(excl_part, reg)
    systems = sorted({ds for p in reg.programs if p.program_id in include for ds in p.delivery_systems})
    if re.search(r"Fee-For-Service|\bFFS\b", clause, re.I) and "FFS" not in systems:
        systems.append("FFS")
    if re.search(r"Contractors?|managed care", clause, re.I) and "MC" not in systems:
        systems.append("MC")
    return {"delivery_systems": sorted(systems), "programs_include": sorted(include),
            "programs_exclude": sorted(exclude), "stated": re.sub(r"\s+", " ", m.group(0)).strip()[:600]}
