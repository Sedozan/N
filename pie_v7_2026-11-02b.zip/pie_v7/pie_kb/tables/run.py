"""The table stage: each active table version not yet read under the current configuration is read from the archive
into kb_table_rows, kb_value_sets, kb_records (origin 'table') and, for text inside the file, kb_sections; one
processing-ledger row per version.

Order: specs that define the code spine (B2) first; the spine is then recomputed and the other tables are read with
it. The configuration id covers the table code, what the readings say (not who signed them) and, for tables other than
B2, the spine: a new B2 code makes every other table version due again, so its PA, telehealth or NCCI records appear.
"""
from __future__ import annotations

import time

from ..core.hashing import code_version
from ..core.record import store_row
from ..kb.spine import fingerprint, spine
from ..sources import ledger
from ..sources.intake import new_run_id
from ..sources.versions import VersionInfo
from . import SPECS
from . import readings as RD
from .base import Context

STAGE = "extract_tables"


# what a table record depends on: the specs, the PDF reader they share, core (kinds, records, codes) and the registry
TABLES_DEPENDS = ("tables", "parse/pdf.py", "parse/sections.py", "core", "sources/registry.py",
                  "reference/sources.csv")


def _code_hash() -> str:
    return code_version(*TABLES_DEPENDS)


def config_ids(readings: dict, spine_codes: set) -> tuple[str, str]:
    """(id for spine-defining specs, id for the others)."""
    base = f"tables-{_code_hash()}-{RD.fingerprint(readings)}"
    return base, f"{base}-{fingerprint(spine_codes)}"


def _version_info(v: dict) -> VersionInfo:
    return VersionInfo(v.get("version_date"), v.get("version_label") or "undated", v.get("version_basis") or "",
                       v.get("version_evidence") or "", v.get("period_end"))


def _read_one(store, v: dict, doc, readings: dict, spine_codes: set | None, cfg: str, run_id: str, log) -> dict:
    spec = SPECS[doc.parser]
    svid, t0, started = v["source_version_id"], time.time(), ledger.now_iso()
    ctx = Context(doc=doc, source_version_id=svid, readings=readings,
                  spine=None if spec.defines_spine else spine_codes,
                  applicability={"delivery_systems": list(doc.delivery_systems), "basis": "registry"},
                  version=_version_info(v))
    try:
        out = spec.extract(v["archive_path"], ctx)
        store.replace_where("table_rows", "source_version_id", [svid], out.rows)
        store.replace_where("value_sets", "source_version_id", [svid],
                            [{**vs, "origin": "table"} for vs in out.value_sets], where={"origin": "table"})
        store.replace_where("records", "source_version_id", [svid], [store_row(r) for r in out.records],
                            where={"origin": "table"})
        store.replace_where("sections", "source_version_id", [svid], out.sections)
        bad = [(r.record_id, p) for r in out.records for p in r.problems()]
        if bad:
            out.warnings.append(f"{len(bad)} record problem(s), first: {bad[0]}")
        counts = {"rows": len(out.rows), "records": len(out.records), "value_sets": len(out.value_sets),
                  "sections": len(out.sections), "warnings": len(out.warnings), "seconds": round(time.time() - t0, 2),
                  "stats": out.stats}
        log(f"read {svid} ({spec.name}): {len(out.rows):,} rows, {len(out.records):,} records, "
            f"{len(out.value_sets):,} value set codes, {len(out.sections)} sections"
            + (f"; {len(out.warnings)} warning(s)" if out.warnings else ""))
        return ledger.processing_row(svid, STAGE, cfg, run_id, "ok", counts, " | ".join(out.warnings), started)
    except Exception as e:                                     # noqa: BLE001 - one bad file does not stop the run
        log(f"FAILED {svid} ({spec.name}): {type(e).__name__}: {e}")
        return ledger.processing_row(svid, STAGE, cfg, run_id, "error", {}, f"{type(e).__name__}: {e}", started)


def run(store, reg, only: set | None = None, force: bool = False, log=print) -> dict:
    readings = RD.load()
    problems = RD.validate(readings, SPECS)
    if problems:
        raise ValueError("table_readings.csv: " + "; ".join(problems))
    store.write("readings", [r.row() for r in readings.values()])
    run_id = new_run_id("tables")
    versions = store.read("source_versions")

    def candidates(processing: list, cfg: str, spine_specs: bool) -> list:
        out = []
        for v in ledger.due(versions, processing, STAGE, cfg, only):
            try:
                doc = reg.get(v["source_id"], v["document_key"])
            except KeyError:
                continue
            if doc.parser in SPECS and SPECS[doc.parser].defines_spine == spine_specs:
                out.append((v, doc))
        return sorted(out, key=lambda t: (t[0].get("version_date") or "", t[0]["source_version_id"]))

    summary = {"run_id": run_id, "read": [], "failed": []}
    rows = []
    codes, _ = spine(store, reg)
    cfg_spine, _ = config_ids(readings, codes)
    processing = [] if force else store.read("processing_ledger")
    for v, doc in candidates(processing, cfg_spine, True):
        rows.append(_read_one(store, v, doc, readings, None, cfg_spine, run_id, log))
    codes, counts = spine(store, reg)
    _, cfg = config_ids(readings, codes)
    summary.update({"config_spine": cfg_spine, "config": cfg, "spine": counts})
    if not codes:
        log("the code spine is empty (no B2 version and no parsed section yet): table rows are kept, records wait")
    processing = ([] if force else store.read("processing_ledger")) + rows
    for v, doc in candidates(processing, cfg, False):
        rows.append(_read_one(store, v, doc, readings, codes, cfg, run_id, log))
    if rows:
        store.write("processing_ledger", rows, mode="append")
    for r in rows:
        (summary["read"] if r["status"] == "ok" else summary["failed"]).append(r["source_version_id"])
    return summary
