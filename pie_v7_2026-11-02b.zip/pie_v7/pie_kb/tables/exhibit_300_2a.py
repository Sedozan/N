"""AMPM Exhibit 300-2A, AHCCCS Covered Services Behavioral Health: which services are covered for which program and
age band.

A ruled grid over two pages: three header rows (ACUTE CARE / ALTCS / CHIP*, then XIX / E/PD / DDD / XXI, then <21 / >21
/ <19) and one row per service, labelled by a category and, for some, a service under it. Cells hold X, NA, '**',
'X**', a blank, or one sentence spanning the row ('Provided at no charge to the member'); markers i, ii, iii and *,
*** point to the LIMITATIONS notes under the grid on the last page.

Records (reading EX-GRID), one subject per service row, named by its category (no codes in the exhibit):
  coverage_scope  what the row says for every column (knowledge)
  not_covered     the columns marked NA, '**' or blank, as a member condition (unresolved until the category is
                  mapped to codes)
The LIMITATIONS notes go to the narrative extractor as a section (600 hours of respite per contract year, ...).
"""
from __future__ import annotations

import re

from ..core.text import clean
from ..parse.sections import text_section
from ..sources import versions
from .base import Context, Spec, TableOutput, table_record
from .pdfgrid import grids, text_below

NAME = "exhibit_300_2a"
READINGS = ("EX-GRID",)
FOOTER = re.compile(r"(Page \d+ of \d+|^Effective Dates?:|^Approval Dates?:|^AHCCCS MEDICAL POLICY MANUAL|"
                    r"^EXHIBIT 300-2A)", re.I)
NOTE_START = re.compile(r"^(?:\*{1,3}\s|i{1,3}\s|LIMITATIONS|Refer\b)")
MARKS = re.compile(r"\s*((?:\*{1,3})|(?:\b(?:iii|ii|i)\b))\s*$")


def version(path: str, http_last_modified: str | None = None):
    return versions.from_pdf_text("ampm_effective", versions.pdf_head_text(path, pages=1))


def _fill(cells: list) -> list:
    out, last = [], ""
    for c in cells:
        last = c.text if c is not None else last
        out.append(last)
    return out


def _label(cell) -> tuple[str, list]:
    """A row label without its footnote markers ('Medical Services ***' -> 'Medical Services', ['***'])."""
    if cell is None:
        return "", []
    t, marks = cell.text, list(cell.sups)
    while True:
        m = MARKS.search(t)
        if not m or not t[:m.start()].strip():
            break
        marks.insert(0, m.group(1))
        t = t[:m.start()]
    return clean(t), marks


def _value(t: str) -> tuple[str, list]:
    t = clean(t)
    m = re.match(r"^(X|NA)?\s*(\*{1,3})?\s*((?:iii|ii|i))?$", t)
    if t and m and (m.group(1) or m.group(2)):
        return (m.group(1) or "") + (m.group(2) or ""), [x for x in (m.group(2), m.group(3)) if x]
    return t, []


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    gs = grids(path)
    if not gs:
        raise ValueError("exhibit_300_2a: no ruled grid found")
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    n_rows, first_columns = 0, []
    for g in gs:
        if len(g.rows) < 4:
            continue
        head = [_fill(r[2:]) for r in g.rows[:3]]
        columns = [clean(f"{a} {b} {c}") for a, b, c in zip(*head)]
        if first_columns and len(columns) == len(first_columns):
            columns = first_columns                         # page 2 repeats the header ('EPD' for 'E/PD')
        first_columns = first_columns or columns
        category = ""
        for i, row in enumerate(g.rows[3:], start=4):
            cat, cat_marks = _label(row[0])
            svc, svc_marks = _label(row[1] if len(row) > 1 else None)
            if row[0] is not None and cat:
                category = cat
            elif row[0] is not None:
                category = ""
            name = f"{category}: {svc}" if category and svc else (svc or category)
            if not name:
                continue
            if not any(c is not None for c in row[2:]):
                continue
            filled, last = [], None
            for c in row[2:]:                               # a merged cell's value covers the columns it spans
                last = c if c is not None else last
                filled.append(last)
            values = []
            for c in filled:
                v, ms = _value(c.text if c else "")
                values.append((v, ms + [x for x in (c.sups if c else []) if x not in ms]))
            n_rows += 1
            marks = list(dict.fromkeys(cat_marks + svc_marks + [m for _, ms in values for m in ms]))
            locator = f"p.{g.page} row {i}"
            cells = dict(zip(columns, (v for v, _ in values)))
            cell_notes = {col: ms for col, (_, ms) in zip(columns, values) if ms}
            out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": name,
                             "locator": locator, "data": {"service": name, "cells": cells, "notes": marks,
                                                          "cell_notes": cell_notes, "page": g.page, "row": i}})
            groups: dict = {}
            for col, v in cells.items():
                groups.setdefault(v or "blank", []).append(col)
            summary = "; ".join(f"{v}: {', '.join(cols)}" for v, cols in groups.items())
            quote = f"{name} | " + " | ".join(f"{c} {v or '(blank)'}{''.join(cell_notes.get(c, [])[1:]) if v else ''}"
                                              for c, v in cells.items())
            note = f" (LIMITATIONS notes {', '.join(dict.fromkeys(marks))})" if marks else ""
            out.records.append(table_record(
                ctx, NAME, kind="coverage_scope", subject={"category": name},
                params={"description": f"Exhibit 300-2A: {summary}{note}"}, locator=locator, quote=quote,
                row_key=name, readings=READINGS,
                statement=f"{name}, by program and age band: {summary}{note}."))
            for v, cols in groups.items():
                if v.startswith("X") or v not in ("NA", "**", "blank") and not v.startswith("**"):
                    continue
                why = {"NA": "not available (NA)", "blank": "not listed as covered (blank cell)"}.get(
                    v, "not available with Title XIX/XXI funding ('**'); other funds may apply")
                out.records.append(table_record(
                    ctx, NAME, kind="not_covered", subject={"category": name}, params={},
                    conditions=[{"type": "member_attribute", "text": "; ".join(cols)}], locator=locator, quote=quote,
                    row_key=f"{name}|{v}", readings=READINGS,
                    flags=[{"code": "blank_cell", "text": "a blank cell read as not covered (EX-GRID)",
                            "blocks": False}] if v == "blank" else [],
                    statement=f"{name}: {why} for {', '.join(cols)}."))
    last = gs[-1]
    lines = [t for t, *_ in text_below(path, last.page, last.bbox[3]) if not FOOTER.search(t)]
    paras: list = []
    for t in lines:
        if not paras or NOTE_START.match(t):
            paras.append(t)
        else:
            paras[-1] += " " + t
    if paras:
        out.sections.append(text_section(ctx.doc, svid, ["EXHIBIT 300-2A", "LIMITATIONS"],
                                         [(p, f"p.{last.page} below the grid", last.page) for p in paras],
                                         applicability=dict(ctx.applicability)))
    out.stats = {"service_rows": n_rows, "records": len(out.records), "notes": len(paras)}
    return out


SPEC = Spec(NAME, "pdf", version, extract, None, READINGS,
            description="AMPM Exhibit 300-2A AHCCCS Covered Services Behavioral Health")
