"""HCPCS/CPT Procedures Daily Limits Guidelines: the most units of a code per member, provider and day.

Layout (v6.3 knowledge; no file received yet): 'As of m/d/yy' above the header 'Procedure Description | Procedure
Maximum Occurrence | Limit 1 | Frequency 1 Value | Frequency 1 Cd | Limit 2 | Frequency 2 Value | Frequency 2 Cd'; a
row reads 'H0004 - BEHAVIORAL HEALTH ...', '000048', then up to two period limits (Cd D, W, M, Y or L); the report's
print date may close the sheet.

Records (DL-MAX, DL-EXCL, DL-PERIOD, DL-VER), for codes in the spine:
  units_limit per day, scope member_provider: the maximum (blocked when DL-EXCL applies: anesthesia time units, an
  all-nines placeholder, or a 'per 1 day' limit that differs from the maximum)
  units_limit per day/week/month/year/lifetime for each Limit with Frequency Value 1 (blocked: DL-PERIOD undecided)
"""
from __future__ import annotations

import re
from datetime import date, datetime

from ..core import codes as C
from .base import (Context, Spec, TableOutput, date_in_rows, find_header, in_spine, load_rows, row_quote,
                   table_record, text)

NAME = "daily_limits"
HEADER = {"description": ("proceduredescription",), "max": ("proceduremaximumoccurrence",), "limit1": ("limit1",),
          "value1": ("frequency1value",), "cd1": ("frequency1cd",), "limit2": ("limit2",),
          "value2": ("frequency2value",), "cd2": ("frequency2cd",)}
READINGS = ("DL-MAX", "DL-EXCL", "DL-PERIOD", "DL-VER")
ROW = re.compile(r"^(\S+)\s+-\s*(.*)$")
PERIOD = {"D": "day", "W": "week", "M": "month", "Y": "year", "L": "lifetime"}


def detect(sample: dict) -> bool:
    return any(find_header(rows, HEADER) for rows in sample.get("sheets", {}).values())


def _sheet(path: str):
    for title, rows in load_rows(path).items():
        h = find_header(rows, HEADER)
        if h:
            return title, rows, h
    raise ValueError("daily_limits: no sheet carries 'Procedure Description | Procedure Maximum Occurrence | ...'")


def version(path: str, http_last_modified: str | None = None):
    title, rows, (hi, _) = _sheet(path)
    v = date_in_rows(rows, hi, r"\bas\s+of")
    if v is None:
        raise ValueError(f"daily_limits: no 'As of m/d/yy' above the header of sheet {title!r}")
    return v


def _whole(v) -> int | None:
    t = text(v)
    return int(t) if t.isdigit() else None


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    title, rows, (hi, cols) = _sheet(path)
    excl = ctx.readings["DL-EXCL"]
    record_only = re.compile(excl.bind("record_only_codes", r"^0[01][0-9]{3}$"))
    placeholder = re.compile(excl.bind("placeholder_max", r"^9{3,}$"))
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    n, blocked = 0, {"anesthesia_time_units": 0, "placeholder_maximum": 0, "two_daily_limits": 0}
    for i in range(hi + 1, len(rows)):
        row, r = rows[i] or (), i + 1

        def cell(f, row=row):
            c = cols[f]
            return row[c] if c < len(row) else None

        first = cell("description")
        if isinstance(first, (datetime, date)) or not text(first):
            continue                                              # the report's print date, or a blank row
        m = ROW.match(text(first))
        code = C.norm_procedure(m.group(1)) if m else None
        mx_raw = text(cell("max"))
        mx = _whole(mx_raw)
        if not code or not mx:
            out.warnings.append(f"row {r}: {text(first)[:60]!r} / maximum {mx_raw!r} not read")
            continue
        n += 1
        limits = []
        for k in ("1", "2"):
            lim, val, cd = _whole(cell("limit" + k)), _whole(cell("value" + k)), text(cell("cd" + k)).upper()
            if lim is not None or val is not None or cd:
                limits.append({"limit": lim, "value": val, "cd": cd})
        locator = f"sheet '{title}' row {r}"
        out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": code,
                         "locator": locator, "data": {"code": code, "description": m.group(2).strip(),
                                                      "max_raw": mx_raw, "daily_max": mx, "limits": limits}})
        if not in_spine(code, ctx.spine):
            continue
        quote = row_quote(first, mx_raw, *[x for lm in limits for x in (lm["limit"], lm["value"], lm["cd"])])
        why = None
        if record_only.match(code):
            why = ("anesthesia_time_units", "an anesthesia code is billed in 15-minute time units; its maximum "
                                            "cannot count them (DL-EXCL)")
        elif placeholder.match(mx_raw.lstrip("0") or "0"):
            why = ("placeholder_maximum", f"maximum {mx_raw} is an all-nines placeholder, not a limit (DL-EXCL)")
        else:
            day = [lm for lm in limits if lm["cd"] == "D" and lm["value"] == 1 and lm["limit"] not in (None, mx)]
            if day:
                why = ("two_daily_limits", f"the file states two daily limits ({mx} and {day[0]['limit']} per 1 day; "
                                           f"DL-EXCL)")
        flags = [{"code": why[0], "text": why[1], "blocks": True}] if why else []
        if why:
            blocked[why[0]] += 1
        out.records.append(table_record(
            ctx, NAME, kind="units_limit", subject={"codes": [code]},
            params={"max": mx, "per": "day", "scope": "member_provider", "unit_basis": "unit"},
            locator=locator, quote=quote, row_key=code, readings=("DL-MAX", "DL-EXCL", "DL-VER"), flags=flags))
        for k, lm in enumerate(limits, start=1):
            per = PERIOD.get(lm["cd"])
            if not per or lm["value"] != 1 or not lm["limit"] or (per == "day" and lm["limit"] == mx):
                continue
            out.records.append(table_record(
                ctx, NAME, kind="units_limit", subject={"codes": [code]},
                params={"max": lm["limit"], "per": per, "scope": "unstated", "unit_basis": "unstated"},
                locator=f"{locator} (Limit {k})", quote=quote, row_key=f"{code}|limit{k}",
                readings=("DL-PERIOD", "DL-VER"),
                flags=[{"code": "period_semantics", "text": "whether the limit counts units or services is not "
                                                            "stated (DL-PERIOD)", "blocks": True}]))
    out.stats = {"codes": n, "records": len(out.records), "blocked": blocked}
    return out


SPEC = Spec(NAME, "xlsx", version, extract, detect, READINGS,
            description="HCPCS/CPT Procedures Daily Limits Guidelines")
