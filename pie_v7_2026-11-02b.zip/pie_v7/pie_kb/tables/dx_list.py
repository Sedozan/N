"""The AHCCCS Behavioral Health Diagnosis List (one PDF per federal fiscal year) as value set A6.

A ruled two-column grid: 'DIAGNOSIS CODE | LONG DESCRIPTION' (FY2027) or 'ICD 10 - 2025 | DESCRIPTION' (FY2026), the
period in the title rows ('EFFECTIVE 10/01/2026 TO 09/30/2027'). A long description wraps around its code, so codes
and descriptions are read cell by cell from the grid, not line by line. Codes after the row 'Z55-Z65 Social
Determinants of Health Code Set' (and, from FY2027, 'Z71 - Z91 FACTORS INFLUENCING HEALTH STATUS CODES') form
a subset named by its code range (A6:Z55-Z65, A6:Z71-Z91). Reading DX-SET.
"""
from __future__ import annotations

import re

from ..core import codes as C
from ..core import dates as D
from ..sources import versions
from ..sources.versions import VersionInfo
from .base import Context, Spec, TableOutput
from .pdfgrid import grids

NAME = "dx_list"
READINGS = ("DX-SET",)
PERIOD = re.compile(r"EFFECTIVE\s+(\d{1,2}/\d{1,2}/\d{2,4})\s+TO\s+(\d{1,2}/\d{1,2}/\d{2,4})", re.I)
LINE_CODE = re.compile(r"(?m)^\s*([A-TV-Z]\d[0-9A-Z]{1,5})\b")
SUBSET = re.compile(r"\b([A-Z]\d{2})\s*-\s*([A-Z]\d{2})\b")


def version(path: str, http_last_modified: str | None = None) -> VersionInfo:
    head = versions.pdf_head_text(path, pages=1)
    m = PERIOD.search(re.sub(r"\s+", " ", head))
    if m:
        a, b = D.mdy(m.group(1)), D.mdy(m.group(2))
        if a and b:
            return VersionInfo(a.isoformat(), a.isoformat(), "stated", m.group(0), b.isoformat())
    return versions.from_pdf_text("dx_list_fy", head)


def extract(path: str, ctx: Context) -> TableOutput:
    import pymupdf

    from ..parse import pdf as P
    out = TableOutput()
    v = ctx.version or version(path)
    start, end = v.date, v.period_end
    svid = ctx.source_version_id
    subset, subset_title, seen, by_subset = "", "", {}, {}
    header_codes: set = set()
    ranges: list = []                                  # (first, last, subset, title) of every subset row

    def add(code: str, desc: str, page: int, locator: str, how: str = "grid") -> None:
        nonlocal subset, subset_title
        if how != "grid":                              # a row read outside the grid: its subset by code range
            hit = [(n, t) for lo, hi, n, t in ranges if lo <= code[:3] <= hi]
            subset, subset_title = hit[0] if hit else ("", "")
        seen[code] = page
        by_subset[subset or "BH"] = by_subset.get(subset or "BH", 0) + 1
        out.value_sets.append({"value_set_id": "A6" + (f":{subset}" if subset else ""), "source_version_id": svid,
                               "code": code, "code_system": "ICD10CM", "description": desc,
                               "attributes": {"page": page, "subset": subset or "BH", "subset_title": subset_title,
                                              "locator": locator, "read_from": how},
                               "effective_start": start, "effective_end": end})

    for g in grids(path):
        for i, row in enumerate(g.rows):
            cells = [c for c in row if c is not None]
            if not cells:
                continue
            first = cells[0].text
            code = first.replace(".", "").replace(" ", "").upper()
            if C.is_icd10(code) and len(cells) >= 2:
                if code in seen:
                    out.warnings.append(f"{code} listed twice (pages {seen[code]} and {g.page})")
                else:
                    add(code, cells[1].text, g.page, f"p.{g.page} row {i + 1}")
                continue
            m = SUBSET.search(" ".join(c.text for c in cells))
            if m:                                # 'Z55-Z65 Social Determinants of Health Code Set'
                subset, subset_title = f"{m.group(1)}-{m.group(2)}", " ".join(c.text for c in cells).strip()
                header_codes |= {m.group(1), m.group(2)}
                ranges.append((m.group(1), m.group(2), subset, subset_title))
    with pymupdf.open(path) as doc:
        listed = set(LINE_CODE.findall("\n".join(p.get_text() for p in doc)))
    missed = listed - set(seen) - header_codes
    if missed:                                   # a row the grid finder left out (no ruling at a page top)
        for ln in P.read(path).kept():
            tok = ln.text.split(" ", 1)
            if tok[0] in missed and tok[0] not in seen and len(tok) == 2:
                add(tok[0], tok[1], ln.page, f"p.{ln.page} line at y {ln.y0:.0f}", "line")
                out.warnings.append(f"{tok[0]} read from its text line on p.{ln.page} (outside the ruled grid); its "
                                    f"description may be cut where it wraps")
    still = sorted(listed - set(seen) - header_codes)
    if still:
        out.warnings.append(f"{len(still)} code(s) in the text not read: {still[:10]}")
    if not seen:
        out.warnings.append("no grid rows read (scanned or unruled PDF?)")
    out.stats = {"codes": len(seen), "by_subset": by_subset, "codes_in_text": len(listed - header_codes),
                 "period": [start, end]}
    return out


SPEC = Spec(NAME, "pdf", version, extract, None, READINGS, description="AHCCCS Behavioral Health Diagnosis List")
