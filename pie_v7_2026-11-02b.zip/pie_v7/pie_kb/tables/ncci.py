"""CMS Medicaid NCCI edit files (quarterly zips): procedure-to-procedure (PTP) and medically unlikely (MUE) edits.

Layout (CMS's published format and v6.3 knowledge; no file received in this workspace yet): each zip holds a text and
an Excel copy, a large PTP file split over several workbooks; free text (title, AMA notice) surrounds a header row
'Column 1 | Column 2 | (prior to 1996) | Effective Date | Deletion Date | Modifier ... | PTP Edit Rationale' or
'HCPCS/CPT Code | ... MUE Values | MUE Rationale'. Dates are yyyymmdd; '*' or a blank deletion date means none. The
edition (practitioner, outpatient hospital, DME) and the quarter come from the file names.

Records, for codes in the spine (NCCI-PTP, NCCI-MUE, NCCI-VER):
  pair_prohibited  per Column 2 code, modifier indicator and edit window: the Column 1 codes as partners (one record
                   holds every partner of the group, so a code with 2,000 Column 1 partners is a few records, not
                   2,000); scope member_provider_day; indicator 9 builds nothing
  units_limit      per code: the MUE value per claim line, scope member_provider
Only the edits whose Column 2 code (PTP) or code (MUE) is in the spine are kept as rows; the zip stays in the archive.
"""
from __future__ import annotations

import csv
import io
import os
import re
import zipfile
from datetime import date

from ..core import codes as C
from ..sources.versions import VersionInfo
from .base import Context, Spec, TableOutput, as_date, find_header, in_spine, table_record, text

PTP_HEADER = {"col1": ("column1*", "col1*", "comprehensive*"), "col2": ("column2*", "col2*", "component*"),
              "eff": ("effective*",), "del": ("deletion*",), "mod": ("modifier*",)}
MUE_HEADER = {"code": ("hcpcscptcode*", "hcpcs*", "cptcode*"), "value": ("*muevalue*",)}
QUARTER_START = {1: (1, 1), 2: (4, 1), 3: (7, 1), 4: (10, 1)}
_Q = [re.compile(r"(20\d{2})\s*[-_ ]?\s*q\s*([1-4])", re.I), re.compile(r"q\s*([1-4])\s*[-_ ]?\s*(20\d{2})", re.I)]
_EFF = re.compile(r"effective\s*(\d{2})(\d{2})(\d{4})", re.I)
EDITIONS = (("dme", ("durablemedical", "dme")), ("outpatient", ("outpatient",)), ("practitioner", ("practitioner",)))
FORM = {"practitioner": "CMS-1500", "dme": "CMS-1500", "outpatient": "UB-04"}


def _kind_of(names: list) -> set:
    low = " ".join(names).lower()
    return {k for k in ("ptp", "mue") if k in low}


def detect_ptp(sample: dict) -> bool:
    return sample.get("kind") == "zip" and _kind_of([sample.get("name", "")] + sample.get("names", [])) == {"ptp"}


def detect_mue(sample: dict) -> bool:
    return sample.get("kind") == "zip" and _kind_of([sample.get("name", "")] + sample.get("names", [])) == {"mue"}


def edition(names: list) -> str | None:
    low = re.sub(r"[^a-z]", "", " ".join(names).lower())
    found = [e for e, keys in EDITIONS if any(k in low for k in keys)]
    return found[0] if len(found) == 1 else None


def quarter(names: list) -> tuple[int, int] | None:
    found = set()
    for n in names:
        b = os.path.basename(n)
        for rx in _Q:
            for m in rx.finditer(b):
                a, b2 = m.groups()
                y, q = (int(a), int(b2)) if len(a) == 4 else (int(b2), int(a))
                found.add((y, q))
        for m in _EFF.finditer(b):
            mo, d, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            q = (mo - 1) // 3 + 1
            if (mo, d) == QUARTER_START[q]:
                found.add((y, q))
    return found.pop() if len(found) == 1 else None


def version(path: str, http_last_modified: str | None = None) -> VersionInfo:
    with zipfile.ZipFile(path) as z:
        names = [os.path.basename(path)] + z.namelist()
    yq = quarter(names)
    if yq is None:
        raise ValueError(f"ncci: no single quarter named in {names[:4]}")
    y, q = yq
    d = date(y, *QUARTER_START[q])
    return VersionInfo(d.isoformat(), f"{y}q{q}", "stated", f"quarter {y}Q{q} named in the file names")


def _tables(path: str, header: dict) -> list:
    """(member name, rows) for every member of the zip that holds the header; text members first (faster), Excel
    only when no text member has it."""
    out = []
    with zipfile.ZipFile(path) as z:
        members = [n for n in z.namelist() if not n.endswith("/")]
        texts = [n for n in members if n.lower().endswith((".txt", ".csv"))]
        books = [n for n in members if n.lower().endswith((".xlsx", ".xlsm"))]
        for n in texts:
            raw = z.read(n).decode("utf-8-sig", errors="replace")
            sample = "\n".join(raw.splitlines()[:80])
            delim = max(("\t", "|", ","), key=lambda d: sample.count(d))
            rows = [tuple(r) for r in csv.reader(io.StringIO(raw), delimiter=delim)]
            if find_header(rows, header):
                out.append((n, rows))
        if not out:
            import openpyxl
            for n in books:
                wb = openpyxl.load_workbook(io.BytesIO(z.read(n)), read_only=True, data_only=True)
                try:
                    for ws in wb.worksheets:
                        rows = [tuple(r) for r in ws.iter_rows(values_only=True)]
                        if find_header(rows, header):
                            out.append((f"{n}!{ws.title}", rows))
                finally:
                    wb.close()
    return out


def _context(path: str, ctx: Context) -> tuple[str, list]:
    with zipfile.ZipFile(path) as z:
        names = [ctx.doc.title, os.path.basename(path)] + z.namelist()
    ed = edition(names[1:]) or "practitioner"
    return ed, [{"type": "claim_form", "form": FORM[ed]}]


def extract_ptp(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    tabs = _tables(path, PTP_HEADER)
    if not tabs:
        raise ValueError("ncci_ptp: no member of the zip holds 'Column 1 | Column 2 | ... | Modifier'")
    ed, cond = _context(path, ctx)
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    groups: dict = {}
    n_all = n_kept = n_bad = 0
    for member, rows in tabs:
        hi, cols = find_header(rows, PTP_HEADER)
        for i in range(hi + 1, len(rows)):
            row = rows[i]

            def cell(f, row=row):
                c = cols[f]
                return row[c] if c < len(row) else None

            c1, c2 = C.norm_procedure(text(cell("col1"))), C.norm_procedure(text(cell("col2")))
            if not c1 or not c2:
                if text(cell("col1")) or text(cell("col2")):
                    n_bad += 1
                continue
            n_all += 1
            if not in_spine(c2, ctx.spine):
                continue
            n_kept += 1
            mi = text(cell("mod"))[:1]
            eff = as_date(_yyyymmdd(cell("eff")))
            dele = as_date(_yyyymmdd(cell("del")))
            locator = f"{member} row {i + 1}"
            out.rows.append({"source_version_id": svid, "source_id": sid, "spec": "ncci_ptp",
                             "row_key": f"{c2}|{c1}|{eff}", "locator": locator,
                             "data": {"column1": c1, "column2": c2, "effective": eff, "deletion": dele,
                                      "modifier_indicator": mi, "edition": ed}})
            if mi in ("0", "1"):
                groups.setdefault((c2, mi, eff, dele), []).append((c1, locator))
            elif mi != "9":
                out.warnings.append(f"{locator}: modifier indicator {mi!r} is not 0, 1 or 9; no record")
    for (c2, mi, eff, dele), partners in sorted(groups.items()):
        p = sorted({c for c, _ in partners})
        out.records.append(table_record(
            ctx, "ncci_ptp", kind="pair_prohibited", subject={"codes": [c2]},
            params={"partners": p, "scope": "member_provider_day",
                    "modifier_bypass": "none" if mi == "0" else "allowed", "both_ways": False},
            conditions=cond, locator=partners[0][1] + (f" and {len(partners) - 1} more" if len(partners) > 1 else ""),
            quote=f"NCCI PTP {ed}: Column 2 {c2} with Column 1 {', '.join(p[:12])}"
                  f"{f' (+{len(p) - 12} more)' if len(p) > 12 else ''}; modifier indicator {mi}; effective {eff}"
                  f"{f'; deleted {dele}' if dele else ''}",
            row_key=f"{c2}|{mi}|{eff}|{dele}", readings=("NCCI-PTP", "NCCI-VER"),
            effective_start=eff, effective_end=_day_before(dele), window_basis="row"))
    if n_bad:
        out.warnings.append(f"{n_bad} rows with a code that is not a procedure code were not read")
    out.stats = {"edition": ed, "members": [m for m, _ in tabs], "edits": n_all, "edits_kept": n_kept,
                 "records": len(out.records)}
    return out


def extract_mue(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    tabs = _tables(path, MUE_HEADER)
    if not tabs:
        raise ValueError("ncci_mue: no member of the zip holds 'HCPCS/CPT Code | ... MUE Values'")
    ed, cond = _context(path, ctx)
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    n_all = 0
    for member, rows in tabs:
        hi, cols = find_header(rows, MUE_HEADER)
        mai_col = next((c for c, v in enumerate(rows[hi]) if re.sub(r"[^a-z]", "", text(v).lower()) in
                        ("mueadjudicationindicator", "mai", "adjudicationindicator")), None)
        for i in range(hi + 1, len(rows)):
            row = rows[i]
            code = C.norm_procedure(text(row[cols["code"]])) if cols["code"] < len(row) else None
            val = text(row[cols["value"]]) if cols["value"] < len(row) else ""
            if not code or not val.isdigit():
                continue
            n_all += 1
            if not in_spine(code, ctx.spine):
                continue
            locator = f"{member} row {i + 1}"
            mai = text(row[mai_col]) if mai_col is not None and mai_col < len(row) else ""
            out.rows.append({"source_version_id": svid, "source_id": sid, "spec": "ncci_mue", "row_key": code,
                             "locator": locator, "data": {"code": code, "mue": int(val), "mai": mai, "edition": ed}})
            if int(val) <= 0:
                continue
            out.records.append(table_record(
                ctx, "ncci_mue", kind="units_limit", subject={"codes": [code]},
                params={"max": int(val), "per": "line", "scope": "member_provider", "unit_basis": "unit"},
                conditions=cond, locator=locator, quote=f"NCCI MUE {ed}: {code} | {val}" + (f" | MAI {mai}" if mai
                                                                                           else ""),
                row_key=code, readings=("NCCI-MUE", "NCCI-VER")))
    out.stats = {"edition": ed, "members": [m for m, _ in tabs], "codes": n_all, "records": len(out.records)}
    return out


def _yyyymmdd(v):
    t = text(v)
    if re.fullmatch(r"\d{8}", t):
        if t.startswith("9999"):
            return None
        return f"{t[4:6]}/{t[6:8]}/{t[:4]}"
    return None if t in ("", "*") else v


def _day_before(iso: str | None) -> str | None:
    if not iso:
        return None
    from ..core.dates import day_before, to_date
    d = to_date(iso)
    return day_before(d).isoformat() if d else None


SPEC_PTP = Spec("ncci_ptp", "zip", version, extract_ptp, detect_ptp, ("NCCI-PTP", "NCCI-VER"),
                description="CMS Medicaid NCCI procedure-to-procedure edits")
SPEC_MUE = Spec("ncci_mue", "zip", version, extract_mue, detect_mue, ("NCCI-MUE", "NCCI-VER"),
                description="CMS Medicaid NCCI medically unlikely edits")
