"""What every table spec shares: the spec interface, its output, workbook helpers and the table record builder.

A table spec reads one family of AHCCCS or CMS table files (B2, PA guidelines, telehealth code set, ...). It
  recognises its layout (detect), dates the file from its own words (version),
  keeps every row (kb_table_rows), builds records for the code spine under the signed readings of its cells
  (kb_records, origin "table"), fills value sets (kb_value_sets) and hands any narrative text in the file to the
  narrative extractor as sections (kb_sections).
A new table is one module with one Spec; nothing else in the package lists table layouts.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Callable

from ..core import dates as D
from ..core.record import Record, finalize
from ..core.text import clean
from ..sources.versions import VersionInfo

HEADER_SCAN_ROWS = 60


@dataclass
class Context:
    doc: object                       # SourceDoc
    source_version_id: str
    readings: dict                    # reading_id -> Reading (every spec's)
    spine: set | None = None          # procedure codes records are made for; None: every code
    applicability: dict = field(default_factory=dict)
    version: VersionInfo | None = None


@dataclass
class TableOutput:
    rows: list = field(default_factory=list)          # kb_table_rows
    records: list = field(default_factory=list)       # Record objects
    value_sets: list = field(default_factory=list)    # kb_value_sets
    sections: list = field(default_factory=list)      # kb_sections rows for text inside the file
    warnings: list = field(default_factory=list)
    stats: dict = field(default_factory=dict)


@dataclass(frozen=True)
class Spec:
    name: str                                   # the registry's parser name
    file_kind: str                              # xlsx | zip | pdf
    version: Callable                           # (path, http_last_modified) -> VersionInfo
    extract: Callable                           # (path, Context) -> TableOutput
    detect: Callable | None = None              # (path) -> bool; PDFs are recognised by their title instead
    readings: tuple = ()                        # reading ids the spec's records rest on
    defines_spine: bool = False                 # B2: its codes are the code spine
    description: str = ""


# ------------------------------------------------------------------ cells and headers
def text(v) -> str:
    """Cell text, cleaned; numbers without a trailing .0; None -> ''."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    if isinstance(v, (datetime, date)):
        return v.strftime("%m/%d/%Y")
    return clean(str(v))


def hnorm(v) -> str:
    """A header cell normalised: lower-case letters and digits only."""
    return re.sub(r"[^a-z0-9]", "", text(v).lower())


def _name_match(n: str, a: str) -> bool:
    if a.startswith("*") and a.endswith("*"):
        return a.strip("*") in n
    if a.endswith("*"):
        return n.startswith(a[:-1])
    return n == a


def find_header(rows: list, want: dict, scan: int = HEADER_SCAN_ROWS):
    """(row index, {field: column index}) of the first row that holds every wanted header, or None.

    want: {field: (accepted normalised names...)}; a name ending in '*' matches as a prefix ('modif*' takes
    'Modifer Aggregated', AHCCCS's spelling, and 'Modifier'); '*name*' matches anywhere in the header."""
    for i, row in enumerate(rows[:scan]):
        cells = [hnorm(v) for v in (row or ())]
        found = {}
        for fld, names in want.items():
            for c, n in enumerate(cells):
                if not n or c in found.values():
                    continue
                if any(_name_match(n, a) for a in names):
                    found[fld] = c
                    break
        if len(found) == len(want):
            return i, found
    return None


def extra_columns(row: tuple, known: dict) -> list:
    """Header cells the spec does not read (a column AHCCCS adds is reported, never dropped in silence)."""
    return [text(v) for c, v in enumerate(row or ()) if text(v) and c not in known.values()]


def date_in_rows(rows: list, upto: int, pattern: str, basis: str = "stated") -> VersionInfo | None:
    """The version date written above a table ('As of 10/1/26', 'Updated: 9/14/2026', 'EFFECTIVE DATE: 06/01/2026'):
    the first match in the rows above `upto`. Two different dates there are refused."""
    rx = re.compile(pattern + r"\s*:?\s*(\d{1,2}/\d{1,2}/(?:\d{4}|\d{2}))(?![\d/])", re.I)
    hits = []
    for row in rows[:max(upto, 0)]:
        for v in row or ():
            t = text(v)
            m = rx.search(t) if t else None
            if m:
                hits.append((D.mdy(m.group(1)), t))
    if not hits:
        return None
    if len({d for d, _ in hits}) > 1:
        raise ValueError(f"two different version dates above the table: {sorted({t for _, t in hits})}")
    d, ev = hits[0]
    return VersionInfo(d.isoformat(), d.isoformat(), basis, ev[:300])


def as_date(v) -> str | None:
    """A cell holding a date (a datetime, or text m/d/yyyy or yyyy-mm-dd) as ISO; the AHCCCS open end 12/31/2299 and
    blanks -> None."""
    if v is None or text(v) == "":
        return None
    if isinstance(v, datetime):
        d = v.date()
    elif isinstance(v, date):
        d = v
    else:
        d = D.to_date(text(v))
    if d is None:
        return None
    return None if d >= D.OPEN_END else d.isoformat()


def split_list(v, sep: str = ",") -> list:
    """'06, 08, 19, ' -> ['06', '08', '19'] (separators , ; or whitespace when sep is None)."""
    t = text(v)
    parts = re.split(r"[,;\s]+", t) if sep is None else re.split(r"\s*[,;]\s*", t)
    return [p.strip() for p in parts if p.strip()]


def load_rows(path: str) -> dict:
    """{sheet title: [row tuples]} of a workbook, values only (read-only mode)."""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        return {ws.title: [tuple(r) for r in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
    finally:
        wb.close()


def workbook_modified(path: str) -> VersionInfo | None:
    """The workbook's own last-saved date (docProps/core.xml), for files that state no date in their cells."""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    try:
        p = wb.properties
        m = p.modified or p.created
        if not m:
            return None
        who = f" by {p.lastModifiedBy}" if p.lastModifiedBy else ""
        return VersionInfo(m.date().isoformat(), m.date().isoformat(), "file_metadata",
                           f"workbook last saved {m.isoformat(timespec='minutes')}{who} (the cells state no date)")
    finally:
        wb.close()


# ------------------------------------------------------------------ records
def table_record(ctx: Context, spec: str, *, kind: str, subject: dict, params: dict, locator: str, quote: str,
                 row_key: str, readings: tuple | list, conditions: list | None = None, exceptions: list | None = None,
                 effective_start: str | None = None, effective_end: str | None = None,
                 window_basis: str = "version", flags: list | None = None, statement: str = "") -> Record:
    """A record read from a table row under signed readings. Its window is the version's unless the row states its
    own dates (window_basis 'row'); the build closes version windows when the next version arrives."""
    d = ctx.doc
    rec = Record(kind=kind, subject=subject, params=params,
                 citation={"source_id": d.source_id, "document_key": d.document_key,
                           "source_version_id": ctx.source_version_id, "locator": locator, "quote": quote,
                           "row_key": row_key, "title": d.title},
                 conditions=list(conditions or []), exceptions=list(exceptions or []),
                 applicability=dict(ctx.applicability), statement=statement, effective_start=effective_start,
                 effective_end=effective_end, window_basis=window_basis, origin="table",
                 authority_level=d.authority_level, jurisdiction=d.jurisdiction, binding=d.binding,
                 flags=list(flags or []), confidence=1.0,
                 extraction={"spec": spec, "readings": sorted(readings)}, status="proposed")
    return finalize(rec)


def row_quote(*cells) -> str:
    """A table row as it reads: its cells joined by ' | ' (the quote a table record cites)."""
    return " | ".join(text(c) for c in cells if text(c))


def in_spine(code: str, spine: set | None) -> bool:
    return spine is None or code in spine
