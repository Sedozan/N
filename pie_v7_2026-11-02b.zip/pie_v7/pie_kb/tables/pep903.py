"""PEP-903 Provider Enrollment Screening Glossary: the AHCCCS provider types and their enrollment screening rules.

Sheets 'PT Code Order' and 'PT Alphabetical Order' (the same rows, sorted two ways) with the header 'Provider Type
Code | Provider Type Name | Enrollment Type | NPI Required? | Enrollment Fee Required? | Site Visit Required? | Risk
Level | Fingerprint-based Criminal Background Check | EFT Required | Regulatory Agency and Certifications'; a type's
further agencies sit on the rows below it with the code cell empty. Sheet 'Acronyms'.

Output: value set PROVIDER_TYPES (code system PROVIDER_TYPE) with the screening columns as attributes, value set
ACRONYMS, and the rows. No records: the file names things, it sets no claim rule (PEP-PT).
The cells state no date: the version is the workbook's own last-saved date (PEP-VER).
"""
from __future__ import annotations

from ..core import codes as C
from .base import Context, Spec, TableOutput, find_header, load_rows, text, workbook_modified

NAME = "pep903"
HEADER = {"code": ("providertypecode",), "name": ("providertypename",), "enrollment_type": ("enrollmenttype",),
          "npi_required": ("nationalprovideridentifier*", "npirequired*"), "fee_required": ("enrollmentfee*",),
          "site_visit": ("sitevisit*",), "risk_level": ("risklevel",), "fingerprinting": ("fingerprint*",),
          "eft_required": ("electronicfundstransfer*", "eft*"), "agencies": ("regulatoryagency*",)}
CORE = {k: HEADER[k] for k in ("code", "name", "risk_level")}
READINGS = ("PEP-PT", "PEP-VER")


def detect(sample: dict) -> bool:
    return any(find_header(rows, CORE) for rows in sample.get("sheets", {}).values())


def version(path: str, http_last_modified: str | None = None):
    v = workbook_modified(path)
    if v is None:
        raise ValueError("pep903: the workbook states no date and has no last-saved date")
    return v


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    sheets = load_rows(path)
    order = sorted(sheets, key=lambda t: (t != "PT Code Order", t))
    sheet = next((t for t in order if find_header(sheets[t], CORE)), None)
    if sheet is None:
        raise ValueError("pep903: no sheet carries 'Provider Type Code | Provider Type Name | ... | Risk Level'")
    rows = sheets[sheet]
    hi, cols = find_header(rows, HEADER) or find_header(rows, CORE)
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    types, cur, notes = [], None, []
    for i in range(hi + 1, len(rows)):
        row, r = rows[i], i + 1

        def cell(f, row=row):
            c = cols.get(f)
            return text(row[c]) if c is not None and c < len(row) else ""

        code_raw = cell("code")
        if code_raw:
            code = C.norm_two(code_raw)
            if not code:
                notes.append((r, code_raw))                      # '* The site visit for an H2O provider ...'
                cur = None
                continue
            agency = " ".join(text(v) for c, v in enumerate(row) if c >= cols.get("agencies", 99) and text(v))
            cur = {"code": code, "name": cell("name"), "enrollment_type": cell("enrollment_type"),
                   "npi_required": cell("npi_required"), "fee_required": cell("fee_required"),
                   "site_visit": cell("site_visit"), "risk_level": cell("risk_level"),
                   "fingerprinting": cell("fingerprinting"), "eft_required": cell("eft_required"),
                   "agencies": [agency] if agency else [], "rows": [r]}
            types.append(cur)
        elif cur is not None and any(text(v) for v in row):
            more = " ".join(text(v) for c, v in enumerate(row) if c >= cols.get("agencies", 99) and text(v))
            if more:
                cur["agencies"].append(more)
                cur["rows"].append(r)
    by_code: dict = {}
    for t in types:                                           # 39 and A5 are listed once per enrollment type
        by_code.setdefault(t["code"], []).append(t)
        out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME,
                         "row_key": f"{t['code']}|{t['enrollment_type']}",
                         "locator": f"sheet '{sheet}' rows {t['rows'][0]}-{t['rows'][-1]}", "data": t})
    for code, ts in by_code.items():
        names = sorted({t["name"] for t in ts})
        if len(names) > 1:
            out.warnings.append(f"provider type {code} has two names: {names}")
        variants = [{k: v for k, v in t.items() if k not in ("code", "name", "rows")} for t in ts]
        attrs = variants[0] if len(variants) == 1 else {"variants": variants}
        out.value_sets.append({"value_set_id": "PROVIDER_TYPES", "source_version_id": svid, "code": code,
                               "code_system": "PROVIDER_TYPE", "description": ts[0]["name"],
                               "attributes": {**attrs, "locator": f"sheet '{sheet}' row {ts[0]['rows'][0]}"},
                               "effective_start": None, "effective_end": None})
    for r, t in notes:
        out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": f"note@{r}",
                         "locator": f"sheet '{sheet}' row {r}", "data": {"note": t}})
    acr = sheets.get("Acronyms") or []
    for i, row in enumerate(acr[1:], start=2):
        a, e = (text(row[0]) if row else ""), (text(row[1]) if row and len(row) > 1 else "")
        if a and e:
            out.value_sets.append({"value_set_id": "ACRONYMS", "source_version_id": svid, "code": a,
                                   "code_system": "ACRONYM", "description": e,
                                   "attributes": {"locator": f"sheet 'Acronyms' row {i}"},
                                   "effective_start": None, "effective_end": None})
    out.stats = {"provider_types": len(by_code), "enrollment_rows": len(types), "notes": len(notes), "acronyms": sum(1 for v in out.value_sets if v["code_system"] ==
                                                                "ACRONYM"),
                 "risk_levels": {lvl: sum(1 for t in types if t["risk_level"] == lvl)
                                 for lvl in sorted({t["risk_level"] for t in types})}}
    return out


SPEC = Spec(NAME, "xlsx", version, extract, detect, READINGS,
            description="PEP-903 Provider Enrollment Screening Glossary (provider types)")
