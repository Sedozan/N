"""Table specs: one module per family of table files, registered here by the registry's parser name.

Intake asks this package which spec recognises a workbook or a zip (by its layout, never its name) and how a table
file is dated; the tables stage (run.py) asks each spec for its rows, records, value sets and sections.
"""
from __future__ import annotations

import os
import zipfile

from . import b2, daily_limits, dx_list, exhibit_300_2a, ncci, pa_guidelines, pep903, same_day, telehealth
from .base import HEADER_SCAN_ROWS, Spec

SPECS: dict[str, Spec] = {s.name: s for s in [
    b2.SPEC, pa_guidelines.SPEC, telehealth.SPEC, pep903.SPEC, same_day.SPEC, daily_limits.SPEC, dx_list.SPEC,
    exhibit_300_2a.SPEC, ncci.SPEC_PTP, ncci.SPEC_MUE]}


def file_kind_of(parser: str) -> str | None:
    """The file kind a registry parser reads: a spec's own kind, 'pdf' for the narrative parsers, None for none."""
    if parser in SPECS:
        return SPECS[parser].file_kind
    return None if parser in ("", "none") else "pdf"


def _xlsx_sample(path: str) -> dict:
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        sheets = {}
        for ws in wb.worksheets:
            sheets[ws.title] = [tuple(r) for r in ws.iter_rows(min_row=1, max_row=HEADER_SCAN_ROWS, values_only=True)]
        return {"kind": "xlsx", "path": path, "sheets": sheets}
    finally:
        wb.close()


def detect_xlsx(path: str) -> list[str]:
    """The specs whose layout this workbook carries (normally exactly one)."""
    sample = _xlsx_sample(path)
    return [n for n, s in SPECS.items() if s.file_kind == "xlsx" and s.detect and s.detect(sample)]


def detect_zip(path: str) -> list[str]:
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
    sample = {"kind": "zip", "path": path, "name": os.path.basename(path), "names": names}
    return [n for n, s in SPECS.items() if s.file_kind == "zip" and s.detect and s.detect(sample)]


def version_of_file(path: str, parser: str, http_last_modified: str | None = None):
    return SPECS[parser].version(path, http_last_modified)


__all__ = ["SPECS", "Spec", "detect_xlsx", "detect_zip", "version_of_file", "file_kind_of"]
