"""FFS Prior Authorization Guidelines: every covered code with its current prior authorization status.

Layout: title rows, 'As of m/d/yy', then the header 'Procedure Description | Prior Authorization Description | AHCCCS
Coverage Cd | Begin Date (PA) | End Date (PA)'. A row reads 'H0004  - BEHAVIORAL HEALTH COUNSELING ...',
"4 - PA NOT REQ'D FOR ACUTE OR LTC", '01', 2001-01-01, 2299-12-31. Numbered notes close the sheet.

Records (reading PA-CODES), for codes in the spine: prior_auth_rule with the row's own window (window_basis 'row').
The table is kept whole (14,760 codes in the 10/10/26 file).
"""
from __future__ import annotations

import re

from ..core import codes as C
from .base import (Context, Spec, TableOutput, as_date, date_in_rows, extra_columns, find_header, in_spine,
                   load_rows, row_quote, table_record, text)

NAME = "pa_guidelines"
HEADER = {"procedure": ("proceduredescription",), "pa": ("priorauthorizationdescription",),
          "coverage": ("ahcccscoveragecd*",), "begin": ("begindatepa",), "end": ("enddatepa",)}
READINGS = ("PA-CODES", "PA-VER")
CODE_DESC = re.compile(r"^(\S+)\s+-\s*(.*)$")
PA_CODE = re.compile(r"^\s*([1-4])\s*-\s*(.+)$")
# PA-CODES: requirement and the recipients it applies to (prior_auth_rule's 'programs' parameter)
MEANING = {"1": ("required", "acute"), "2": ("required", "ltc"), "3": ("required", "all"), "4": ("not_required", "all")}


def detect(sample: dict) -> bool:
    return any(find_header(rows, HEADER) for rows in sample.get("sheets", {}).values())


def _sheet(path: str):
    for title, rows in load_rows(path).items():
        h = find_header(rows, HEADER)
        if h:
            return title, rows, h
    raise ValueError("pa_guidelines: no sheet carries the header 'Procedure Description | Prior Authorization "
                     "Description | ... | Begin Date (PA) | End Date (PA)'")


def version(path: str, http_last_modified: str | None = None):
    title, rows, (hi, _) = _sheet(path)
    v = date_in_rows(rows, hi, r"\bas\s+of")
    if v is None:
        raise ValueError(f"pa_guidelines: no 'As of m/d/yy' line above the header in sheet {title!r}")
    return v


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    title, rows, (hi, cols) = _sheet(path)
    extra = extra_columns(rows[hi], cols)
    if extra:
        out.warnings.append(f"columns not read: {extra}")
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    notes, n_codes, by_pa, unknown, local = [], 0, {}, 0, []
    for i in range(hi + 1, len(rows)):
        row, r = rows[i], i + 1

        def cell(f, row=row):
            c = cols[f]
            return row[c] if c < len(row) else None

        first = text(cell("procedure"))
        if not first:
            continue
        m = CODE_DESC.match(first)
        raw = m.group(1).upper() if m and re.fullmatch(r"[A-Z0-9]{5}", m.group(1).upper()) else None
        if not raw:
            notes.append({"row": r, "text": first})                # 'Notes:', '[1] ...', '[2] ...'
            continue
        code = C.norm_procedure(raw)                               # None for AHCCCS local codes (W3031, LL321)
        n_codes += 1
        if not code:
            local.append(raw)
        pa_text, cov = text(cell("pa")), text(cell("coverage"))
        pm = PA_CODE.match(pa_text)
        pa = pm.group(1) if pm else ""
        begin, end = as_date(cell("begin")), as_date(cell("end"))
        locator = f"sheet '{title}' row {r}"
        out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": code or raw,
                         "locator": locator,
                         "data": {"code": code or raw, "standard_code": bool(code), "description": m.group(2).strip(),
                                  "pa_code": pa, "pa_text": pa_text, "coverage_code": cov, "begin": begin, "end": end,
                                  "sheet": title, "row": r}})
        by_pa[pa or "?"] = by_pa.get(pa or "?", 0) + 1
        if not pa:
            unknown += 1
            out.warnings.append(f"{locator}: prior authorization value {pa_text!r} is not 1 to 4; no record")
            continue
        if not code or not in_spine(code, ctx.spine):
            continue
        requirement, programs = MEANING[pa]
        out.records.append(table_record(
            ctx, NAME, kind="prior_auth_rule", subject={"codes": [code]},
            params={"requirement": requirement, "authorization": "prior", "programs": programs},
            locator=locator, quote=row_quote(first, pa_text, cov, cell("begin"), cell("end")), row_key=code,
            readings=READINGS, effective_start=begin, effective_end=end, window_basis="row"))
    for n in notes:
        out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": f"note@{n['row']}",
                         "locator": f"sheet '{title}' row {n['row']}", "data": {"note": n["text"]}})
    if ctx.spine is not None and not ctx.spine:
        out.warnings.append("the code spine is empty (no B2 version loaded yet): rows kept, no records")
    out.stats = {"codes": n_codes, "local_codes": local, "by_pa_code": by_pa, "unread_pa_values": unknown,
                 "notes": len(notes), "records": len(out.records)}
    return out


SPEC = Spec(NAME, "xlsx", version, extract, detect, READINGS, description="FFS Prior Authorization Guidelines")
