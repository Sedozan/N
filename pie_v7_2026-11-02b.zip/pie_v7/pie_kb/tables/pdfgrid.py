"""Tables inside PDFs: PyMuPDF finds the grid (ruled cells); the text of each cell is rebuilt with the reader's own
line builder, because the grid extractor drops the word spaces that some AHCCCS PDFs set as separate spans
("BehavioralHealth Counselingand Therapy")."""
from __future__ import annotations

from dataclasses import dataclass, field

from ..parse import pdf as P


@dataclass
class Cell:
    text: str
    sups: list = field(default_factory=list)     # superscript markers taken out of the text (i, ii, *, 1 ...)
    bbox: tuple = ()


@dataclass
class Grid:
    page: int                                    # 1-based
    bbox: tuple
    rows: list                                   # [[Cell | None, ...], ...] (None: the cell is part of a merge)


def _cell(spans: list, spaces: list, bbox, page_no: int) -> Cell:
    x0, y0, x1, y1 = bbox
    inside = [s for s in spans if x0 - 1 <= (s["x0"] + s["x1"]) / 2 <= x1 + 1 and y0 - 1 <= s["cy"] <= y1 + 1]
    lines = sorted((P._line(r, page_no, 0, spaces) for r in P._rows(inside)), key=lambda ln: ln.y0)
    sups = [s for ln in lines for s in ln.sups]
    return Cell(" ".join(ln.text for ln in lines if ln.text).strip(), sups, tuple(bbox))


def grids(path: str, pages: list | None = None) -> list[Grid]:
    """Every ruled table of the PDF (or of the given 1-based pages), cell by cell."""
    import pymupdf
    out = []
    with pymupdf.open(path) as doc:
        for i in range(doc.page_count):
            if pages and i + 1 not in pages:
                continue
            page = doc[i]
            spaces: list = []
            spans = P._spans(page, spaces)
            for t in page.find_tables().tables:
                rows = [[_cell(spans, spaces, c, i + 1) if c else None for c in r.cells] for r in t.rows]
                out.append(Grid(i + 1, tuple(t.bbox), rows))
    return out


def text_below(path: str, page_no: int, y: float) -> list:
    """The reader's lines on a page below y (the notes under a grid): [(text, size, bold, y0)]."""
    import pymupdf
    with pymupdf.open(path) as doc:
        page = doc[page_no - 1]
        spaces: list = []
        spans = [s for s in P._spans(page, spaces) if s["y0"] >= y]
        lines = sorted((P._line(r, page_no, 0, spaces) for r in P._rows(spans)), key=lambda ln: ln.y0)
        return [(ln.text if not ln.lead_sup else f"{ln.lead_sup} {ln.text}", ln.size, ln.bold, ln.y0)
                for ln in lines if ln.text]
