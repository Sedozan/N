"""AHCCCS Telehealth Code Set: the codes that may be delivered by telehealth, their modifiers and places of service.

Two sheets: 'Guidelines' (prose: which modifiers mean what, POS 02 and 10 not used) and the code sheet ('2026 Final':
'EFFECTIVE DATE:  06/01/2026', then 'CPT / HCPCS CODE | DESCRIPTION | GT | GQ | FQ | Places of Service (POS) | PLACE OF
SERVICE (POS) CODE**'). Numeric codes are stored as numbers. Footnote markers sit in the modifier cells ('GT*',
'GT ***') and the footnotes follow the last code.

Records (TH-MOD, TH-POS, TH-VER), for codes in the spine: telehealth_rule allowed, with the marked modifiers and the
places of service of the column TH-POS binds. The guidelines and the footnotes go to the narrative extractor as
sections.
"""
from __future__ import annotations

import re

from ..core import codes as C
from ..parse.sections import text_section
from .base import (Context, Spec, TableOutput, date_in_rows, extra_columns, find_header, in_spine, load_rows,
                   row_quote, split_list, table_record, text)

NAME = "telehealth"
HEADER = {"code": ("cpthcpcscode",), "description": ("description",), "GT": ("gt",), "GQ": ("gq",), "FQ": ("fq",)}
READINGS = ("TH-MOD", "TH-POS", "TH-VER")
MOD_CELL = re.compile(r"^\s*(GT|GQ|FQ)\s*(\**)\s*$", re.I)


def detect(sample: dict) -> bool:
    return any(find_header(rows, HEADER) for rows in sample.get("sheets", {}).values())


def _code_sheet(sheets: dict):
    hits = [(t, rows, find_header(rows, HEADER)) for t, rows in sheets.items()]
    hits = [h for h in hits if h[2]]
    if not hits:
        raise ValueError("telehealth: no sheet carries 'CPT / HCPCS CODE | DESCRIPTION | GT | GQ | FQ'")
    if len(hits) > 1:
        dated = sorted(((date_in_rows(rows, h[0], r"effective\s+date"), t, rows, h) for t, rows, h in hits),
                       key=lambda x: (x[0].date if x[0] else ""))
        _, t, rows, h = dated[-1]
        return t, rows, h, [x[1] for x in dated[:-1]]
    t, rows, h = hits[0]
    return t, rows, h, []


def version(path: str, http_last_modified: str | None = None):
    title, rows, (hi, _), _ = _code_sheet(load_rows(path))
    v = date_in_rows(rows, hi, r"effective\s+date")
    if v is None:
        raise ValueError(f"telehealth: no 'EFFECTIVE DATE: mm/dd/yyyy' above the header of sheet {title!r}")
    return v


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    sheets = load_rows(path)
    title, rows, (hi, cols), older = _code_sheet(sheets)
    if older:
        out.warnings.append(f"code sheets {older} are older than {title!r} and are not read")
    want = ctx.readings["TH-POS"].bind("pos_column", "placeofservicepos*")
    head = [re.sub(r"[^a-z0-9]", "", text(v).lower()) for v in rows[hi]]
    used = next((c for c, h in enumerate(head) if h and (h == want or (want.endswith("*") and h.startswith(want[:-1])))),
                None)
    other = next((c for c, h in enumerate(head) if h.startswith("placesofservice")), None)
    if used is None:
        raise ValueError(f"telehealth: no column matching {want!r} (reading TH-POS) in sheet {title!r}")
    known = {**cols, "pos": used, **({"pos_other": other} if other is not None else {})}
    extra = extra_columns(rows[hi], known)
    if extra:
        out.warnings.append(f"columns not read: {extra}")
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    footnotes, n, disagree = [], 0, 0
    for i in range(hi + 1, len(rows)):
        row, r = rows[i], i + 1

        def cell(c, row=row):
            return row[c] if c is not None and c < len(row) else None

        first = cell(cols["code"])
        code = C.norm_procedure(first) if first is not None and text(first) else None
        if not code:
            if text(first):
                footnotes.append((text(first), f"sheet '{title}' row {r}", 0))
            continue
        n += 1
        mods, marks = [], []
        for m in ("GT", "GQ", "FQ"):
            raw = text(cell(cols[m]))
            mm = MOD_CELL.match(raw) if raw else None
            if mm:
                mods.append(mm.group(1).upper())
                if mm.group(2):
                    marks.append(f"{mm.group(1).upper()}{mm.group(2)}")
            elif raw:
                out.warnings.append(f"sheet '{title}' row {r}: {m} cell {raw!r} not read")
        pos = [p for p in (C.norm_two(x) for x in split_list(cell(used))) if p]
        pos_other = [p for p in (C.norm_two(x) for x in split_list(cell(other), None)) if p] if other is not None else []
        if other is not None and sorted(pos) != sorted(pos_other):
            disagree += 1
        locator = f"sheet '{title}' row {r}"
        out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": code, "locator": locator,
                         "data": {"code": code, "description": text(cell(cols["description"])), "modifiers": mods,
                                  "footnote_marks": marks, "pos": pos, "pos_other_column": pos_other, "sheet": title,
                                  "row": r}})
        if not in_spine(code, ctx.spine):
            continue
        flags = [{"code": "footnote", "text": f"the code set marks {', '.join(marks)}: see the footnotes under the "
                                              f"codes", "blocks": False}] if marks else []
        out.records.append(table_record(
            ctx, NAME, kind="telehealth_rule", subject={"codes": [code]},
            params={"allowed": True, "modifiers": mods, "pos": pos}, locator=locator,
            quote=row_quote(first, cell(cols["description"]), cell(cols["GT"]), cell(cols["GQ"]), cell(cols["FQ"]),
                            cell(used)),
            row_key=code, readings=READINGS, flags=flags))
    applic = dict(ctx.applicability)
    if footnotes:
        out.sections.append(text_section(ctx.doc, svid, [title, "Footnotes"], footnotes, ordinal=1,
                                         applicability=applic))
    for t, srows in sheets.items():
        if t == title or t in older:
            continue
        paras = [(" ".join(text(v) for v in row if text(v)), f"sheet '{t}' row {i + 1}", 0)
                 for i, row in enumerate(srows) if any(text(v) for v in row)]
        if paras:
            out.sections.append(text_section(ctx.doc, svid, [t], paras, ordinal=0, applicability=applic))
    out.stats = {"codes": n, "footnotes": len(footnotes), "pos_columns_disagree": disagree,
                 "records": len(out.records), "sections": len(out.sections)}
    return out


SPEC = Spec(NAME, "xlsx", version, extract, detect, READINGS, description="AHCCCS Telehealth Code Set")
