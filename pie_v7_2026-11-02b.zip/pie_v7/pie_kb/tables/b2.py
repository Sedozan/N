"""B2: the AHCCCS Behavioral Health Services Matrix (monthly workbook).

One row per procedure code and provider type, set two or four spreadsheet rows tall with merged cells; the value sits
in the first row of each merged range, so a record starts at every row whose code cell is filled. The header row moved
between versions (row 6 in August 2025, row 10 in October 2026) and two column names changed ("Category of Service" ->
"Category of Service Aggregated", "Place of Service" -> "Place of Service Aggregated"); AHCCCS spells "Modifer".

Records (readings B2-PT, B2-POS, B2-MOD, B2-COV, B2-VER):
  provider_type_rule  per code: the provider types listed for it; complete for H0xxx/H2xxx (B2-PT binds)
  pos_rule            per code and provider type: the places of service listed
  modifier_rule       per code and provider type: the modifiers listed
B2's codes are the code spine (decision 13): records from every other table are made for these codes.
"""
from __future__ import annotations

import re

from ..core import codes as C
from .base import (Context, Spec, TableOutput, date_in_rows, extra_columns, find_header, load_rows, row_quote,
                   split_list, table_record, text)

NAME = "b2"
HEADER = {"code": ("procedurecode",), "description": ("procedurecodedescription",),
          "provider_type": ("providertype",), "provider_type_description": ("providertypedescription",),
          "coverage": ("ahcccscoveragecode",), "category_of_service": ("categoryofservice*",),
          "places_of_service": ("placeofservice*",), "modifiers": ("modif*",)}
READINGS = ("B2-PT", "B2-POS", "B2-MOD", "B2-COV", "B2-VER")


def detect(sample: dict) -> bool:
    return any(find_header(rows, HEADER) for rows in sample.get("sheets", {}).values())


def _sheets(path: str):
    out = []
    for title, rows in load_rows(path).items():
        h = find_header(rows, HEADER)
        if h:
            out.append((title, rows, h))
    if not out:
        raise ValueError("b2: no sheet carries the B2 header row (Procedure Code, Provider Type, Place of Service, ...)")
    return out


def version(path: str, http_last_modified: str | None = None):
    title, rows, (hi, _) = _sheets(path)[0]
    v = date_in_rows(rows, hi, r"\bas\s+of")
    if v is None:
        raise ValueError(f"b2: no 'As of m/d/yy' line above the header in sheet {title!r}")
    return v


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    pt_reading = ctx.readings["B2-PT"]
    complete_rx = re.compile(pt_reading.bind("complete_codes", r"^H[02][0-9]{3}$"))
    role = pt_reading.bind("role", "billing_or_rendering")
    covered = ctx.readings["B2-COV"].bind("covered", "01")
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    by_code: dict = {}
    seen: dict = {}
    n_mod = n_pos = n_nomod = n_nopos = 0
    sheets = _sheets(path)
    if len(sheets) > 1:
        out.warnings.append(f"{len(sheets)} sheets carry the B2 header; each is read")
    for title, rows, (hi, cols) in sheets:
        extra = extra_columns(rows[hi], cols)
        if extra:
            out.warnings.append(f"sheet {title!r}: columns not read: {extra}")
        for i in range(hi + 1, len(rows)):
            row, r = rows[i], i + 1

            def cell(f, row=row):
                c = cols[f]
                return row[c] if c < len(row) else None

            raw = text(cell("code"))
            if not raw:
                continue                                    # the lower rows of a merged record, or a blank
            code = C.norm_procedure(raw)
            pt = C.norm_two(cell("provider_type"))
            if not code or not pt:
                out.warnings.append(f"sheet {title!r} row {r}: code {raw!r} / provider type "
                                    f"{text(cell('provider_type'))!r} not recognised; row kept, no record")
            pos = [p for p in (C.norm_two(x) for x in split_list(cell("places_of_service"))) if p]
            mods = [m for m in (C.norm_two(x) for x in split_list(cell("modifiers"))) if m]
            cov = text(cell("coverage"))
            data = {"code": code or raw, "description": text(cell("description")), "provider_type": pt or "",
                    "provider_type_description": text(cell("provider_type_description")), "coverage_code": cov,
                    "category_of_service": split_list(cell("category_of_service")), "places_of_service": pos,
                    "modifiers": mods, "sheet": title, "row": r}
            locator = f"sheet '{title}' row {r}"
            key = f"{code or raw}|{pt or ''}"
            out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": key,
                             "locator": locator, "data": data})
            if not code or not pt:
                continue
            if key in seen:
                out.warnings.append(f"{key} appears twice (rows {seen[key]} and {r}); both kept")
            seen[key] = r
            if cov != covered:
                out.warnings.append(f"{locator}: AHCCCS Coverage Code {cov!r} is not read (B2-COV); no record")
                continue
            by_code.setdefault(code, []).append((pt, r, title, data))
            quote = row_quote(raw, data["description"], pt, data["provider_type_description"], cov,
                              cell("category_of_service"), cell("places_of_service"), cell("modifiers"))
            cond = [{"type": "provider_type", "include": [pt], "role": role}]
            if mods:
                out.records.append(table_record(
                    ctx, NAME, kind="modifier_rule", subject={"codes": [code]},
                    params={"mode": "allowed", "modifiers": mods, "complete_list": True}, conditions=cond,
                    locator=locator, quote=quote, row_key=key, readings=("B2-MOD", "B2-COV", "B2-VER")))
                n_mod += 1
            else:
                n_nomod += 1
            if pos:
                out.records.append(table_record(
                    ctx, NAME, kind="pos_rule", subject={"codes": [code]},
                    params={"mode": "allowed", "pos": pos, "complete_list": True}, conditions=cond,
                    locator=locator, quote=quote, row_key=key, readings=("B2-POS", "B2-COV", "B2-VER")))
                n_pos += 1
            else:
                n_nopos += 1
    n_complete = 0
    for code, items in sorted(by_code.items()):
        items.sort(key=lambda t: t[1])
        pts = sorted({pt for pt, *_ in items})
        complete = bool(complete_rx.match(code))
        n_complete += complete
        first, last = items[0], items[-1]
        locator = f"sheet '{first[2]}' rows {first[1]}-{last[1]}"
        quote = row_quote(code, first[3]["description"]) + " | provider types: " + \
            ", ".join(f"{pt} {d['provider_type_description']}".strip() for pt, _, _, d in items)
        out.records.append(table_record(
            ctx, NAME, kind="provider_type_rule", subject={"codes": [code]},
            params={"mode": "allowed", "provider_types": pts, "role": role, "complete_list": complete},
            locator=locator, quote=quote, row_key=code, readings=("B2-PT", "B2-COV", "B2-VER")))
    out.stats = {"rows": len(out.rows), "codes": len(by_code), "pairs": len(seen), "complete_list_codes": n_complete,
                 "modifier_records": n_mod, "pairs_without_modifiers": n_nomod, "pos_records": n_pos,
                 "pairs_without_pos": n_nopos, "records": len(out.records)}
    return out


SPEC = Spec(NAME, "xlsx", version, extract, detect, READINGS, defines_spine=True,
            description="AHCCCS Behavioral Health Services Matrix (B2)")
