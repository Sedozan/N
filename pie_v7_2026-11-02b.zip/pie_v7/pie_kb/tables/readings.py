"""Table readings: what each cell of an AHCCCS or CMS table means, written once and signed by a person.

A table record carries the ids of the readings it rests on; it is approved when they are signed, and a rejected reading
withdraws its records (kb/build.py). A reading's `binds` hold the settings the spec reads from it (which codes have a
complete provider type list, which column holds the telehealth places of service), so a setting cannot change
without the reading changing, and a changed reading must be signed again.
"""
from __future__ import annotations

import csv
import os
from dataclasses import dataclass

from .. import config
from ..core.hashing import sha256_text

STATUSES = ("proposed", "signed", "rejected")
COLUMNS = ("spec", "reading_id", "reading", "evidence", "status", "reviewer", "reviewed_at", "binds")


@dataclass(frozen=True)
class Reading:
    spec: str
    reading_id: str
    reading: str
    evidence: str
    status: str
    reviewer: str
    reviewed_at: str
    binds: str

    def bind(self, key: str, default: str | None = None) -> str | None:
        return parse_binds(self.binds).get(key, default)

    def row(self) -> dict:
        return {c: getattr(self, c) for c in COLUMNS}


def parse_binds(s: str) -> dict:
    out = {}
    for part in (s or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def path(reference_dir: str | None = None) -> str:
    return os.path.join(reference_dir or config.REFERENCE_DIR, "table_readings.csv")


def load(reference_dir: str | None = None) -> dict:
    with open(path(reference_dir), newline="", encoding="utf-8") as f:
        return {r["reading_id"].strip(): Reading(**{c: (r.get(c) or "").strip() for c in COLUMNS})
                for r in csv.DictReader(f)}


def fingerprint(readings: dict) -> str:
    """A hash of what the readings say (text and binds, not who signed them): a changed reading makes table
    versions due again; a signature does not."""
    return sha256_text("\n".join(f"{r.reading_id}|{r.spec}|{r.reading}|{r.binds}"
                                 for r in sorted(readings.values(), key=lambda r: r.reading_id)))[:12]


def validate(readings: dict, specs: dict) -> list[str]:
    p = []
    for rid, r in readings.items():
        if r.spec not in specs:
            p.append(f"reading {rid}: unknown spec {r.spec!r}")
        if r.status not in STATUSES:
            p.append(f"reading {rid}: status {r.status!r} is not one of {STATUSES}")
        if r.status == "signed" and not (r.reviewer and r.reviewed_at):
            p.append(f"reading {rid}: signed without a reviewer and a date")
        if not r.reading:
            p.append(f"reading {rid}: no text")
    for name, spec in specs.items():
        for rid in spec.readings:
            if rid not in readings:
                p.append(f"spec {name}: reading {rid} is not in table_readings.csv")
    return p
