"""The AHCCCS Same Day Disallow Table: which behavioral health codes may not be billed together on one day.

Layout (v6.3 knowledge; no file received yet): a legend cell ('D = Disallowed ... A = Allowable ... A* = Allowable on
same day for the member, cannot be provided/billed by the same provider ...') and 'Updated: m/d/yyyy' above the grid;
numbered notes in column A (note 2: exceptions approved on medical necessity); then a row of column codes from column
D, a row of their descriptions and a row of their units; then one row per code (code, description, unit in A to C)
with D, A* or A in every cell.

Records (SD-D, SD-ASTAR, SD-A, SD-ROW, SD-NOTE2, SD-VER), for row codes in the spine: pair_prohibited with the row
code as subject (its line is the finding) and the column code as partner; scope member_day (D) or member_provider_day
(A*); note 2 as an exception; both_ways when the table marks the pair in both directions; no rule on the diagonal.
"""
from __future__ import annotations

import re

from ..core import codes as C
from ..core.text import clean
from .base import Context, Spec, TableOutput, date_in_rows, in_spine, load_rows, table_record, text

NAME = "same_day"
READINGS = ("SD-D", "SD-ASTAR", "SD-A", "SD-ROW", "SD-NOTE2", "SD-VER")
NOTE2 = "Exceptions to limitations on service frequency or duration may be approved based on medical necessity."
LEGEND_WORDS = ("d=disallowed", "a=allowable", "a*=allowableonsamedayforthemember,cannotbeprovided/billedbythesame"
                "provider")
INDICATORS = ("D", "A*", "A")


def _norm(v) -> str:
    return re.sub(r"[^a-z0-9*=,/]", "", text(v).lower())


def _legend(rows: list):
    for i, row in enumerate(rows[:60]):
        for c, v in enumerate(row or ()):
            n = _norm(v)
            if "d=disallowed" in n and "a*=" in n:
                return i, c, text(v)
    return None


def detect(sample: dict) -> bool:
    return any(_legend(rows) for rows in sample.get("sheets", {}).values())


def _sheet(path: str):
    for title, rows in load_rows(path).items():
        lg = _legend(rows)
        if lg:
            return title, rows, lg
    raise ValueError("same_day: no sheet carries the legend 'D = Disallowed / A = Allowable / A* = ...'")


def version(path: str, http_last_modified: str | None = None):
    title, rows, (li, _, _) = _sheet(path)
    v = date_in_rows(rows, li + 12, r"\bupdated")
    if v is None:
        raise ValueError(f"same_day: no 'Updated: m/d/yyyy' near the legend of sheet {title!r}")
    return v


def extract(path: str, ctx: Context) -> TableOutput:
    out = TableOutput()
    title, rows, (li, _, legend) = _sheet(path)
    missing = [w for w in LEGEND_WORDS if w not in _norm(legend)]
    if missing:
        raise ValueError(f"same_day: the legend no longer reads as the signed readings rest on (missing {missing}): "
                         f"{legend!r}")
    hi = cols = None
    for i in range(li + 1, min(li + 15, len(rows))):
        found = [(c, C.norm_procedure(text(v))) for c, v in enumerate(rows[i] or ()) if c >= 3 and text(v)]
        codes = [(c, k) for c, k in found if k]
        if len(codes) >= 2:
            hi, cols = i, codes
            break
    if hi is None:
        raise ValueError("same_day: no row of column codes below the legend")
    notes_text = " ".join(text(rows[i][0]) for i in range(li + 1, hi + 3) if rows[i] and text(rows[i][0]))
    parts = re.split(r"(?:^|(?<=\s))(\d{1,2})\.\s+", notes_text)
    notes = {int(parts[k]): parts[k + 1].strip() for k in range(1, len(parts) - 1, 2)}
    if 2 not in notes or not clean(notes[2]).lower().startswith(NOTE2.lower()):
        raise ValueError(f"same_day: note 2 no longer opens with {NOTE2!r}; reading SD-NOTE2 rests on it")
    col_desc = {c: text(rows[hi + 1][c]) if c < len(rows[hi + 1]) else "" for c, _ in cols}
    grid: dict = {}
    svid, sid = ctx.source_version_id, ctx.doc.source_id
    for i in range(hi + 3, len(rows)):
        row, r = rows[i] or (), i + 1
        code = C.norm_procedure(text(row[0])) if row and text(row[0]) else None
        if not code:
            continue
        for c, col in cols:
            ind = text(row[c]).upper() if c < len(row) else ""
            if ind not in INDICATORS:
                out.warnings.append(f"row {r} ({code} x {col}): {ind!r} is not D, A or A*; not read")
                continue
            grid[(code, col)] = (ind, r, c, text(row[1]) if len(row) > 1 else "")
            out.rows.append({"source_version_id": svid, "source_id": sid, "spec": NAME, "row_key": f"{code}|{col}",
                             "locator": f"sheet '{title}' row {r} column {c + 1}",
                             "data": {"row_code": code, "col_code": col, "indicator": ind,
                                      "row_description": text(row[1]) if len(row) > 1 else "",
                                      "col_description": col_desc.get(c, "")}})
    counts = {k: 0 for k in INDICATORS}
    for (code, col), (ind, r, c, desc) in sorted(grid.items()):
        counts[ind] += 1
        if ind == "A" or code == col or not in_spine(code, ctx.spine):
            continue
        back = grid.get((col, code), ("",))[0] in ("D", "A*")
        scope = "member_day" if ind == "D" else "member_provider_day"
        out.records.append(table_record(
            ctx, NAME, kind="pair_prohibited", subject={"codes": [code]},
            params={"partners": [col], "scope": scope, "modifier_bypass": "none", "both_ways": back},
            exceptions=[{"text": notes[2], "type": "other"}],
            locator=f"sheet '{title}' row {r} column {c + 1}", quote=f"{code} {desc} | {col} | {ind}",
            row_key=f"{code}|{col}", readings=("SD-D" if ind == "D" else "SD-ASTAR", "SD-ROW", "SD-NOTE2", "SD-VER")))
    out.stats = {"row_codes": len({k[0] for k in grid}), "column_codes": len(cols), "cells": len(grid),
                 "indicators": counts, "records": len(out.records), "notes": notes}
    return out


SPEC = Spec(NAME, "xlsx", version, extract, detect, READINGS, description="AHCCCS Same Day Disallow Table")
