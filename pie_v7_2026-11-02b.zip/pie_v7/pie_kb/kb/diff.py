"""What a revision changed: records of consecutive versions of one document, matched by meaning.

A record_key in both versions is unchanged (counted, not listed). Of the rest, a record that keeps its place (the same
section or table row), kind and subject but says something else is "changed"; the others are "added" or "removed".
Approvals follow the same matching (kb/status.py): an unchanged record in an unchanged section keeps its decision.
"""
from __future__ import annotations

from collections import defaultdict

from ..core.hashing import canonical


def _slot(r) -> tuple:
    c = r.citation or {}
    return c.get("section_key") or c.get("row_key") or c.get("locator") or "", r.kind, canonical(r.subject)


def diffs(by_version: dict, version_order: dict, build_id: str) -> tuple[list, dict]:
    """(kb_record_diffs rows, counts). by_version: {source_version_id: [Record]}; version_order: {(source_id,
    document_key): [source_version_id oldest first]}."""
    rows, counts = [], defaultdict(int)
    for (sid, dk), svids in version_order.items():
        for old, new in zip(svids, svids[1:]):
            a = {r.record_key: r for r in by_version.get(old, [])}
            b = {r.record_key: r for r in by_version.get(new, [])}
            counts["unchanged"] += len(a.keys() & b.keys())
            came: dict = defaultdict(list)
            for k in sorted(b.keys() - a.keys()):
                came[_slot(b[k])].append(b[k])

            def emit(change, ra, rb, detail):
                counts[change] += 1
                rows.append({"build_id": build_id, "source_id": sid, "document_key": dk, "from_version": old,
                             "to_version": new, "change": change, "record_key": (rb or ra).record_key,
                             "record_id_from": ra.record_id if ra else "", "record_id_to": rb.record_id if rb else "",
                             "section_key": ((rb or ra).citation or {}).get("section_key") or "", "detail": detail})
            for k in sorted(a.keys() - b.keys()):
                ra = a[k]
                twins = came.get(_slot(ra))
                if twins:
                    rb = twins.pop(0)
                    emit("changed", ra, rb, f"{ra.statement} -> {rb.statement}"[:1000])
                else:
                    emit("removed", ra, None, ra.statement[:1000])
            for rest in came.values():
                for rb in rest:
                    emit("added", None, rb, rb.statement[:1000])
    return rows, dict(counts)
