"""Exception overlays: an exception one source states against rules another source holds (EPSDT for members under 21
against AHCCCS service limits; emergency services without prior authorization against the PA guidelines).

An exception record (kind "exception") overlays the records that share a code with it, are of a kind it targets
(params.target_kinds; any kind checked on claims when it names none), overlap it in time and in applicability, and
are neither rejected nor superseded. An overlaid executable record becomes conditional: a person confirms, finding by
finding, whether the exception applies. Overlays never delete or change the record they touch.
"""
from __future__ import annotations

from collections import defaultdict

from ..core.kinds import KINDS
from .conflicts import _applies_together, _overlap


def find(views: dict) -> dict:
    """{record_id: [(exception record_id, reason)]}. views as in kb/conflicts.find."""
    by_code: dict = defaultdict(list)
    for rid, v in views.items():
        if v["status"] in ("rejected", "superseded"):
            continue
        for c in v["codes"]:
            by_code[c].append(rid)
    out: dict = defaultdict(list)
    for xid, xv in views.items():
        x = xv["record"]
        if x.kind != "exception" or xv["status"] in ("rejected", "superseded"):
            continue
        targets = set((x.params or {}).get("target_kinds") or [])
        for c in xv["codes"]:
            for rid in by_code.get(c, []):
                if rid == xid:
                    continue
                r = views[rid]["record"]
                if r.kind == "exception" or not getattr(KINDS.get(r.kind), "checkable", False):
                    continue
                if targets and r.kind not in targets:
                    continue
                if _overlap(xv["window"], views[rid]["window"]) is None or not _applies_together(x, r):
                    continue
                effect = (x.params or {}).get("effect") or "changes"
                reason = (f"an exception in {x.citation.get('source_id')} p.{x.citation.get('page_start') or '?'} "
                          f"{effect} it ({xid}): a person confirms per finding whether it applies")
                if (xid, reason) not in out[rid]:
                    out[rid].append((xid, reason))
    return dict(out)
