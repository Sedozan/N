"""Resolving a record that names a service instead of codes ("Respite services are limited to 600 hours per year").

  signed     a reviewer mapped the category to a value set (review decision "category: map"); "none" says it names no
             code set, and the record stays unresolved
  section    the record sits under a service whose code list the guide gives (the CBHSG lists "Unskilled Respite Care >
             HCPCS Codes"), and the category shares a word with that service's name: the service of its own section
  unresolved anything else; the build offers the closest service code sets as suggestions for the review workbook
Only the subject of a kind checked on claims is resolved; a partner or parent category stays unresolved (the record's
class says so), and pointers, definitions and duties need no codes.
"""
from __future__ import annotations

import re
from collections import defaultdict

from ..core.kinds import KINDS
from ..core.text import match_form
from ..review import decisions as DC

STOP = {"service", "services", "the", "and", "of", "for", "a", "an", "in", "to", "or", "by", "with", "on", "codes",
        "code", "behavioral", "health", "bh", "billing", "limitations", "covered", "including"}


def words(s: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]+", match_form(s)) if w not in STOP and len(w) > 2}


def service_sets(value_sets: list) -> dict:
    """{value_set_id: {"service": path, "source_id", "codes": {svid: set}}} for the SVC sets the patterns made."""
    out: dict = {}
    for v in value_sets:
        vid = v.get("value_set_id") or ""
        if not vid.startswith("SVC:"):
            continue
        _, source_id, service = vid.split(":", 2)
        e = out.setdefault(vid, {"service": service, "source_id": source_id, "codes": defaultdict(set)})
        e["codes"][v["source_version_id"]].add(v["code"])
    return out


def _codes_for(entry: dict, svid: str) -> list:
    """The set's codes in the record's own version, else in its latest version."""
    if svid in entry["codes"]:
        return sorted(entry["codes"][svid])
    last = max(entry["codes"])
    return sorted(entry["codes"][last])


def resolve(records: list, value_sets: list, log: DC.Log) -> dict:
    """{record_id: (codes, basis)} for records that name a category and no codes; basis says how (or why not)."""
    sets = service_sets(value_sets)
    out = {}
    for r in records:
        cat = (r.subject or {}).get("category")
        if not cat or (r.subject or {}).get("codes") or not getattr(KINDS.get(r.kind), "checkable", False):
            continue                               # a pointer or a definition needs no codes
        src = r.citation.get("source_id")
        d, _ = log.current("category", DC.category_key(src, cat), DC.category_sha(src, cat))
        if d and d["decision"] == "map":
            vid = (d.get("correction") or {}).get("value_set_id")
            if vid in sets:
                out[r.record_id] = (_codes_for(sets[vid], r.citation.get("source_version_id")),
                                    f"signed: {vid} (mapped by {d['reviewer']})")
                continue
            out[r.record_id] = ([], f"signed map to {vid!r}, which is not a service code set")
            continue
        if d and d["decision"] == "none":
            out[r.record_id] = ([], f"names no code set (decided by {d['reviewer']})")
            continue
        path = r.citation.get("section_path") or ""
        own = [vid for vid, e in sets.items() if e["source_id"] == src
               and (path == e["service"] or path.startswith(e["service"] + " > ")) and words(cat) & words(e["service"])]
        if own:
            vid = max(own, key=lambda v: len(sets[v]["service"]))          # the closest enclosing service
            out[r.record_id] = (_codes_for(sets[vid], r.citation.get("source_version_id")),
                                f"section: {vid} (the service of its own section)")
            continue
        out[r.record_id] = ([], "unresolved: no code set maps this category yet")
    return out


def suggestions(category: str, value_sets: list, n: int = 3) -> list:
    """The service code sets whose names share the most words with the category: [(value_set_id, score, size)]."""
    want = words(category)
    if not want:
        return []
    scored = []
    for vid, e in service_sets(value_sets).items():
        have = words(e["service"])
        score = len(want & have) / len(want | have) if have else 0
        if score:
            size = len(e["codes"][max(e["codes"])])
            scored.append((vid, round(score, 2), size))
    return sorted(scored, key=lambda t: (-t[1], t[0]))[:n]
