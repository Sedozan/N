"""The code spine (decision 13): the procedure codes the behavioral health knowledge base makes records for.

Every code in any loaded B2 version, plus every procedure code an extractable section of a BH narrative source (a
manual, policy, guide or notice; not the text inside a table file) names. Tables
are kept whole; their records are made only for spine codes, so the PA guidelines' 14,760 codes or the NCCI edit files
do not flood the knowledge base with codes no BH source concerns.
"""
from __future__ import annotations

from ..core import codes as C
from ..core.hashing import sha256_text

EXTRACTABLE = ("body", "definitions", "purpose")


def spine(store, reg=None) -> tuple[set, dict]:
    """(codes, counts by origin). With the registry, only sections of narrative sources count: the sections a table
    file carries (telehealth footnotes, exhibit notes) do not widen the spine, so reading tables never changes the
    spine they were read with."""
    narrative = None
    if reg is not None:
        narrative = {(d.source_id, d.document_key) for d in reg.docs if d.method == "narrative"}
    b2 = {(r.get("data") or {}).get("code") for r in store.read("table_rows") if r.get("spec") == "b2"}
    b2 = {c for c in b2 if c and C.norm_procedure(c)}
    named = set()
    for s in store.read("sections"):
        if narrative is not None and (s.get("source_id"), s.get("document_key")) not in narrative:
            continue
        if s.get("role") in EXTRACTABLE:
            named |= {c for c in ((s.get("codes") or {}).get("procedure") or []) if C.norm_procedure(c)}
    codes = b2 | named
    return codes, {"b2": len(b2), "named_in_sources_only": len(named - b2), "total": len(codes)}


def fingerprint(codes: set) -> str:
    return sha256_text(",".join(sorted(codes)))[:10]
