"""A record's effective review status at build time.

  table records      approved when every reading they rest on is signed; rejected when one of them is rejected
  other records      the latest decision on the record's current content. With none, the decision on the same meaning
                     (record_key) in the document's previous version carries forward when the record's section reads
                     the same and no term it uses was redefined; when the section changed, it goes back for review.
                     Otherwise the extraction status (proposed, or needs_review when grounding flagged something).
  fixed records      a fix supersedes the original; the corrected record (origin sme) waits for a second reviewer.
                     A supersession carries forward like an approval, and the corrected record's window runs on
                     through the later versions whose section reads the same (kb/build.py)
An approval never moves a record outside its own window: the window comes from the version (kb/build.py), so an
approved record of an old version keeps judging the dates its version was in force.
"""
from __future__ import annotations

import re
from collections import defaultdict

from ..core.text import match_form
from ..review import decisions as DC

DECIDED = {"approve": "approved", "reject": "rejected", "fix": "superseded", "defer": "needs_review"}


def _doc(r) -> tuple:
    return r.citation.get("source_id"), r.citation.get("document_key")


def definitions(records: list) -> dict:
    """{source_version_id: {term: definition}} in match form, from definition records."""
    out: dict = defaultdict(dict)
    for r in records:
        if r.kind == "definition" and r.subject.get("term"):
            out[r.citation.get("source_version_id")][match_form(r.subject["term"])] = \
                match_form(str(r.params.get("definition") or ""))
    return out


def _uses(quote: str, term: str) -> bool:
    return bool(term) and re.search(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])", match_form(quote)) is not None


def resolve(records: list, version_order: dict, sections: dict, log: DC.Log, readings: dict) -> dict:
    """{record_id: {"status", "basis", "review", "flags"}} for every record.

    version_order: {(source_id, document_key): [source_version_id oldest first]}; sections: {section_id: row}."""
    reading_state = {rid: DC.reading_status(r, log) for rid, r in readings.items()}
    defs = definitions(records)
    by_version: dict = defaultdict(list)
    for r in records:
        by_version[r.citation.get("source_version_id")].append(r)
    out: dict = {}
    for doc, svids in version_order.items():
        prior: dict = {}                         # record_key -> (record, state) in the latest earlier version
        prev_svid = None
        for svid in svids:
            redefined = set()
            if prev_svid:
                old, new = defs.get(prev_svid, {}), defs.get(svid, {})
                redefined = {t for t in old.keys() & new.keys() if old[t] != new[t]}
            here = {}
            for r in by_version.get(svid, []):
                st = _one(r, reading_state, log, prior, sections, redefined)
                out[r.record_id] = st
                here[r.record_key] = (r, st)
            prior = {**prior, **here} if here else prior
            prev_svid = svid
    for r in records:                              # versions missing from the ledger: extraction status only
        out.setdefault(r.record_id, {"status": r.status, "basis": "version not in the ledger", "review": {},
                                     "flags": [{"code": "no_version", "text": "its version is not in the ledger"}]})
    return out


def _one(r, reading_state: dict, log: DC.Log, prior: dict, sections: dict, redefined: set) -> dict:
    flags: list = []
    if r.origin == "table":
        used = list((r.extraction or {}).get("readings") or [])
        states = {rid: reading_state.get(rid, ("proposed", "reading not in table_readings.csv")) for rid in used}
        rejected = [rid for rid, (s, _) in states.items() if s == "rejected"]
        pending = [rid for rid, (s, _) in states.items() if s != "signed"]
        if rejected:
            return {"status": "rejected", "basis": f"reading {', '.join(rejected)} rejected", "review": {},
                    "flags": flags}
        if pending:
            return {"status": "proposed", "basis": f"readings not signed: {', '.join(pending)}", "review": {},
                    "flags": flags}
        return {"status": "approved", "basis": "readings signed: " + ", ".join(used), "review": {
            "readings": {rid: b for rid, (_, b) in states.items()}}, "flags": flags}
    d, stale = log.current("record", r.record_id, r.content_sha)
    if stale and not d:
        flags.append({"code": "stale_decision", "text": f"{len(stale)} earlier decision(s) were made on other "
                                                        f"content; the record changed since"})
    if d:
        if d["decision"] == "approve" and r.origin == "sme" and DC.same_person(d["reviewer"],
                                                                                (r.review or {}).get("author")):
            return {"status": "needs_review", "basis": "approved by its own author: needs a second reviewer",
                    "review": _review(d), "flags": flags}
        return {"status": DECIDED[d["decision"]], "basis": f"{d['decision']} by {d['reviewer']} on "
                                                           f"{d['decided_at'][:10]}", "review": _review(d),
                "flags": flags}
    old = prior.get(r.record_key)
    if old and old[1]["status"] in ("approved", "rejected", "superseded"):
        o, ost = old
        same = _section_hash(sections, o) is not None and _section_hash(sections, o) == _section_hash(sections, r)
        terms = sorted(t for t in redefined if _uses(r.citation.get("quote") or "", t))
        if same and not terms:
            flags.append({"code": "carried_forward", "text": f"{ost['status']} in {o.citation['source_version_id']} "
                                                             f"({ost['basis']}); its section reads the same"})
            return {"status": ost["status"], "basis": f"carried forward from {o.record_id}",
                    "review": {**ost["review"], "carried_from": o.record_id}, "flags": flags}
        why = f"the term(s) {', '.join(terms)} were redefined" if terms else "its section changed"
        flags.append({"code": "back_to_review", "text": f"{ost['status']} in {o.citation['source_version_id']}; "
                                                        f"{why}"})
        return {"status": "needs_review", "basis": f"was {ost['status']} in {o.citation['source_version_id']}; {why}",
                "review": {"previous": o.record_id}, "flags": flags}
    base = r.status if r.status in ("proposed", "needs_review") else "proposed"
    if r.origin == "sme" and (r.review or {}).get("author"):
        return {"status": "needs_review", "basis": f"authored by {r.review['author']}: needs a second reviewer",
                "review": dict(r.review), "flags": flags}
    return {"status": base, "basis": "not reviewed", "review": {}, "flags": flags}


def _section_hash(sections: dict, r) -> str | None:
    s = sections.get(r.citation.get("section_id"))
    return s.get("text_hash") if s else None


def _review(d: dict) -> dict:
    return {"decision_id": d["decision_id"], "decision": d["decision"], "reviewer": d["reviewer"],
            "decided_at": d["decided_at"], "note": d.get("note") or ""}
