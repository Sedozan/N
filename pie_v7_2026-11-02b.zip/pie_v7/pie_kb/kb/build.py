"""The knowledge base build: every record with its effective status, window, codes, class and conflicts, as of a date.

  window          a version runs from its own date to the day before the next version of its document
                  (sources/ledger.windows); a record's window is its version's, narrowed by dates its text or table
                  row states. A corrected record (origin sme) runs on through later versions whose section reads the
                  same, as its correction still applies there.
  status          decisions bound to content, signed readings, carry-forward (kb/status.py)
  codes           a record that names a service gets the service's code set (kb/resolve.py)
  class           executable, conditional, signal, knowledge or unresolved, for the claim type (core/checkability.py)
  conflicts       kb/conflicts.py; an open conflict holds both records back
  overlays        kb/overlays.py; an exception another record states makes an executable record conditional
  executable_now  executable, approved, in force on the build date, and not held back by a conflict
Writes kb_records_current (the projection detection reads), kb_records_history, kb_conflicts, kb_record_diffs,
kb_code_index and kb_build_log. It reads the records and decisions and changes neither.
"""
from __future__ import annotations

import dataclasses
import glob
import os
from collections import Counter, defaultdict
from datetime import date, datetime, timezone

from .. import config
from ..core.checkability import execution_class
from ..core.hashing import files_hash
from ..core.record import Record
from ..review import decisions as DC
from ..sources import ledger
from ..sources.intake import new_run_id
from ..tables import readings as RD
from . import conflicts as CF
from . import diff as DF
from . import overlays as OV
from . import resolve as RS
from . import status as ST


def package_sha() -> str:
    files = sorted(glob.glob(os.path.join(config.PACKAGE_DIR, "**", "*.py"), recursive=True) +
                   glob.glob(os.path.join(config.REFERENCE_DIR, "*.csv")))
    return files_hash(*files, n=12)


def version_order(wins: dict) -> dict:
    """{(source_id, document_key): [source_version_id oldest first]}; undated versions last."""
    out: dict = defaultdict(list)
    for w in sorted(wins.values(), key=lambda w: (w["effective_start"] or "9999-12-31", w.get("first_seen_at") or "",
                                                  w["source_version_id"])):
        out[(w["source_id"], w["document_key"])].append(w["source_version_id"])
    return dict(out)


def _window(r: Record, wins: dict, order: dict, section_hash: dict) -> tuple:
    """(start, end, basis) of a record."""
    svid = r.citation.get("source_version_id")
    w = wins[svid]
    vs, ve, basis = w["effective_start"], w["effective_end"], f"version ({w['window_basis']})"
    if r.origin == "sme" and r.citation.get("section_key"):
        later = order.get((r.citation.get("source_id"), r.citation.get("document_key")), [])
        mine = section_hash.get((svid, r.citation["section_key"]))
        for nxt in later[later.index(svid) + 1:] if svid in later else []:
            if mine is None or section_hash.get((nxt, r.citation["section_key"])) != mine:
                break
            ve = wins[nxt]["effective_end"]
            basis = f"version ({w['window_basis']}) carried through {nxt}: its section reads the same"
    rs, re_ = r.effective_start, r.effective_end
    start = max([x for x in (vs, rs) if x]) if (vs or rs) else None
    end = min([x for x in (ve, re_) if x]) if (ve or re_) else None
    if r.window_basis not in ("version", "", None):
        basis += f" + {r.window_basis}"
    if start and end and start > end:
        basis += "; empty: its stated dates fall outside its version"
    return start, end, basis


def build(store, reg, today: date | None = None, claim_type: str | None = None, log=print) -> dict:
    today = today or date.today()
    day = today.isoformat()
    ct = claim_type or config.CLAIM_TYPE
    build_id = new_run_id("build")
    warnings: list = []
    monthly = {d.source_id for d in reg.docs if d.cadence == "monthly"}
    wins = {w["source_version_id"]: w for w in ledger.windows(store.read("source_versions"), today, monthly)}
    order = version_order(wins)
    records = [Record.from_row(r) for r in store.read("records")]
    live = [r for r in records if r.citation.get("source_version_id") in wins]
    if len(live) < len(records):
        warnings.append(f"{len(records) - len(live)} record(s) belong to versions that are not active; left out")
    sections = {s["section_id"]: s for s in store.read("sections")}
    section_hash = {(s["source_version_id"], s["section_key"]): s.get("text_hash") for s in sections.values()}
    rlog = DC.Log(store.read("review_log"))
    readings = RD.load()
    value_sets = store.read("value_sets")

    status = ST.resolve(live, order, sections, rlog, readings)
    resolved = RS.resolve(live, value_sets, rlog)
    windows = {r.record_id: _window(r, wins, order, section_hash) for r in live}
    docs = {}
    for r in live:
        try:
            docs[r.record_id] = reg.get(r.citation.get("source_id"), r.citation.get("document_key") or "main")
        except KeyError:
            warnings.append(f"{r.record_id}: source {r.citation.get('source_id')} is not in the registry")
    views = {r.record_id: {"record": r, "status": status[r.record_id]["status"], "window": windows[r.record_id][:2],
                           "codes": list(r.subject.get("codes") or []) or resolved.get(r.record_id, ([], ""))[0]}
             for r in live}
    statements = [(p, DC.precedence_status(p, rlog)[0]) for p in reg.precedence]
    conflict_rows = CF.find(views, docs, statements, rlog, build_id)
    held = CF.effects(conflict_rows)
    overlays = OV.find(views)
    in_conflicts: dict = defaultdict(list)
    for c in conflict_rows:
        in_conflicts[c["record_a"]].append(c["conflict_id"])
        in_conflicts[c["record_b"]].append(c["conflict_id"])

    current, history, index = [], [], []
    for r in live:
        st = status[r.record_id]
        start, end, wbasis = windows[r.record_id]
        codes, rbasis = resolved.get(r.record_id, (None, ""))
        judged = dataclasses.replace(r, subject={**r.subject, "codes": codes}) if codes else r
        cls, why = execution_class(judged, ct)
        ov = overlays.get(r.record_id, [])
        if ov:
            why = list(why) + [reason for _, reason in ov]
            cls = "conditional" if cls == "executable" else cls
        in_force = bool(start) and start <= day and (end is None or end >= day)
        reasons = list(why) + ([held[r.record_id]] if r.record_id in held else [])
        now = cls == "executable" and st["status"] == "approved" and in_force and r.record_id not in held
        row = {"build_id": build_id, "record_id": r.record_id, "record_key": r.record_key,
               "content_sha": r.content_sha, "kind": r.kind, "subject": r.subject, "params": r.params,
               "conditions": r.conditions, "exceptions": r.exceptions, "applicability": r.applicability,
               "statement": r.statement, "citation": r.citation, "source_id": r.citation.get("source_id"),
               "document_key": r.citation.get("document_key"),
               "source_version_id": r.citation.get("source_version_id"), "authority_level": r.authority_level,
               "origin": r.origin, "status": st["status"], "status_basis": st["basis"], "review": st["review"],
               "effective_start": start, "effective_end": end, "window_basis": wbasis, "in_force_today": in_force,
               "resolved_codes": codes or [], "resolution": rbasis, "execution_class": cls,
               "execution_reasons": reasons, "executable_now": now, "conflicts": in_conflicts.get(r.record_id, []),
               "overlays": [x for x, _ in ov],
               "flags": list(r.flags or []) + st["flags"]}
        current.append(row)
        history.append({k: row[k] for k in ("build_id", "record_id", "record_key", "content_sha", "kind", "status",
                                             "execution_class", "statement", "citation", "effective_start",
                                             "effective_end", "review")} | {"executable_now": now})
        p = r.params or {}
        for role, cs in (("subject", r.subject.get("codes") or []), ("subject_resolved", codes or []),
                         ("partner", p.get("partners") or []), ("parent", p.get("parent_codes") or [])):
            for c in cs:
                index.append({"build_id": build_id, "code": c, "record_id": r.record_id, "kind": r.kind, "role": role,
                              "source_id": r.citation.get("source_id"), "effective_start": start,
                              "effective_end": end, "status": st["status"], "execution_class": cls})
    by_version: dict = defaultdict(list)
    for r in live:
        by_version[r.citation.get("source_version_id")].append(r)
    diff_rows, diff_counts = DF.diffs(by_version, order, build_id)

    counts = {"records": len(current), "status": dict(Counter(c["status"] for c in current)),
              "class": dict(Counter(c["execution_class"] for c in current)),
              "executable_now": sum(1 for c in current if c["executable_now"]),
              "in_force_today": sum(1 for c in current if c["in_force_today"]),
              "conflicts": dict(Counter(c["status"].split(":")[0] for c in conflict_rows)),
              "overlaid": sum(1 for c in current if c["overlays"]),
              "diffs": diff_counts, "codes_indexed": len({i["code"] for i in index}),
              "categories": dict(Counter(c["resolution"].split(":")[0] for c in current if c["resolution"]))}
    sources = sorted({(w["source_id"], w["document_key"], w["source_version_id"], w["effective_start"] or "",
                       w["effective_end"] or "") for w in wins.values()})
    store.write("records_current", current)
    store.write("records_history", history, mode="append")
    store.write("conflicts", conflict_rows, mode="append")
    store.write("record_diffs", diff_rows, mode="append")
    store.write("code_index", index)
    built_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
    store.write("build_log", [{"build_id": build_id, "built_at": built_at, "pie_version": config.PIE_VERSION,
                               "package_sha": package_sha(), "counts": counts,
                               "sources": [list(s) for s in sources], "warnings": warnings}], mode="append")
    log(f"build {build_id} as of {day}: {counts['records']:,} records; status {counts['status']}; class "
        f"{counts['class']}; executable now {counts['executable_now']:,}; conflicts {counts['conflicts']}")
    for w in warnings[:10]:
        log(f"  warning: {w}")
    return {"build_id": build_id, "as_of": day, **counts, "warnings": warnings}
