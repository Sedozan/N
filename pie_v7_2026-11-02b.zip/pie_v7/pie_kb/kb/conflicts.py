"""Conflicts: two records about the same code and the same thing that cannot both hold on a date of service.

Two records are compared only when they share a code, have the same kind, overlap in time and in applicability
(delivery systems, programs), mean different things (different record_key), are neither rejected nor superseded, and
carry the same conditions or conditions one inside the other's (a B2 row for one provider type meets a guide rule for
every provider type on that provider type). Limits with different conditions are not compared: the narrower one is a
specific rule.

  different_limit  two caps on the same count with different numbers (units, services, dollars, ages)
  contradiction    one requires or allows what the other forbids (prior authorization required and not required, a
                   modifier required and not allowed, telehealth allowed and not, a place of service allowed and not,
                   two claim forms)
  different_list   two lists stated as complete that differ (provider types, places of service, modifiers)

Each conflict gets a suggested prevailing record (decision 7): (a) a precedence statement a source makes about the
matter; (b) the higher authority; (c) the more specific record; (d) the later one. A suggestion is never applied:
records in an open conflict are not executable until a person signs a resolution (review decision a, b or both).
"""
from __future__ import annotations

from collections import defaultdict
from itertools import combinations

from ..core.hashing import canonical, short_hash
from ..review import decisions as DC

MATTERS = {"claim_values": {"provider_type_rule", "modifier_rule", "pos_rule", "claim_form_required",
                            "telehealth_rule", "diagnosis_required"}}
COMPARED = ("units_limit", "frequency_limit", "dollar_limit", "age_limit", "prior_auth_rule", "telehealth_rule",
            "claim_form_required", "provider_type_rule", "modifier_rule", "pos_rule")
LIST_FIELD = {"provider_type_rule": "provider_types", "modifier_rule": "modifiers", "pos_rule": "pos"}
LIMIT_KINDS = ("units_limit", "frequency_limit", "dollar_limit", "age_limit")


def _compatible(a, b) -> bool:
    """Equal, or one of them not stated."""
    return a == b or a in (None, "", "unstated") or b in (None, "", "unstated")


def relation(a, b) -> tuple | None:
    """(relationship, detail) when records a and b (same kind) cannot both hold, else None."""
    pa, pb, k = a.params or {}, b.params or {}, a.kind
    if k in ("units_limit", "frequency_limit"):
        if pa.get("per") != pb.get("per") or bool(pa.get("combined")) != bool(pb.get("combined")):
            return None
        if not _compatible(pa.get("scope"), pb.get("scope")) or \
                (k == "units_limit" and not _compatible(pa.get("unit_basis"), pb.get("unit_basis"))):
            return None
        if pa.get("max") != pb.get("max"):
            return "different_limit", f"{pa.get('max')} vs {pb.get('max')} per {pa.get('per')}"
    elif k == "dollar_limit":
        if pa.get("per") == pb.get("per") and pa.get("max_amount") != pb.get("max_amount"):
            return "different_limit", f"${pa.get('max_amount')} vs ${pb.get('max_amount')} per {pa.get('per')}"
    elif k == "age_limit":
        if (pa.get("min_age"), pa.get("below_age")) != (pb.get("min_age"), pb.get("below_age")):
            return "different_limit", (f"ages {pa.get('min_age')} to under {pa.get('below_age')} vs "
                                       f"{pb.get('min_age')} to under {pb.get('below_age')}")
    elif k == "prior_auth_rule":
        if pa.get("requirement") != pb.get("requirement") and \
                _compatible(pa.get("authorization"), pb.get("authorization")):
            return "contradiction", "prior authorization required by one, not required by the other"
    elif k == "telehealth_rule":
        if bool(pa.get("allowed")) != bool(pb.get("allowed")):
            return "contradiction", "telehealth allowed by one, not allowed by the other"
    elif k == "claim_form_required":
        if pa.get("form") != pb.get("form"):
            return "contradiction", f"claim form {pa.get('form')} vs {pb.get('form')}"
    elif k in LIST_FIELD:
        f = LIST_FIELD[k]
        A, B = set(pa.get(f) or []), set(pb.get(f) or [])
        ma, mb = pa.get("mode"), pb.get("mode")
        if k == "provider_type_rule" and not _compatible(pa.get("role"), pb.get("role")):
            return None
        if ma == mb == "allowed" and pa.get("complete_list") and pb.get("complete_list") and A != B:
            return "different_list", f"complete lists differ: only in one {sorted(A ^ B)[:12]}"
        for yes, no in (("allowed", "not_allowed"), ("required", "not_allowed")):
            if {ma, mb} == {yes, no}:
                allowed, banned = (A, B) if ma == yes else (B, A)
                if allowed & banned:
                    return "contradiction", f"{sorted(allowed & banned)[:12]} {yes} by one, not allowed by the other"
    return None


def _overlap(a: tuple, b: tuple) -> tuple | None:
    """Two (start, end) windows as their overlap, or None. A missing start (an undated version) is taken as always,
    a missing end as open, so an undated record is compared rather than missed."""
    starts = [x for x in (a[0], b[0]) if x]
    ends = [x for x in (a[1], b[1]) if x]
    s, e = (max(starts) if starts else None), (min(ends) if ends else None)
    if s and e and s > e:
        return None
    return s, e


def _applies_together(a, b) -> bool:
    aa, ab = a.applicability or {}, b.applicability or {}
    da, db = set(aa.get("delivery_systems") or []), set(ab.get("delivery_systems") or [])
    if da and db and not da & db:
        return False
    ia, ib = set(aa.get("programs_include") or []), set(ab.get("programs_include") or [])
    if ia and ib and not ia & ib:
        return False
    if (ia and ia <= set(ab.get("programs_exclude") or [])) or (ib and ib <= set(aa.get("programs_exclude") or [])):
        return False
    return True


def _matches(entry: str, doc) -> bool:
    return entry in (doc.source_id, doc.doc_id) or entry.lower() == (doc.family or "").lower()


def _specificity(r) -> tuple:
    ds = (r.applicability or {}).get("delivery_systems") or []
    return len(r.conditions or []), 1 if (r.subject or {}).get("codes") else 0, -(len(ds) or 9)


def suggest(a, b, docs: dict, statements: list) -> tuple[str, str, str]:
    """(prevailing record_id or '', basis, precedence_id) for records a and b."""
    da, db = docs.get(a.record_id), docs.get(b.record_id)
    for p, state in statements:
        if state == "rejected" or (p.matter in MATTERS and a.kind not in MATTERS[p.matter]):
            continue
        for win, lose in ((a, b), (b, a)):
            dw, dl = docs.get(win.record_id), docs.get(lose.record_id)
            if dw and dl and any(_matches(e, dw) for e in p.prevails) and any(_matches(e, dl) for e in p.over):
                signed = "" if state == "signed" else "; the statement is not signed yet"
                return win.record_id, (f"precedence statement {p.precedence_id} ({p.stated_in} p.{p.page}): "
                                       f"{p.notes or p.matter}{signed}"), p.precedence_id
    la, lb = a.authority_level or 9, b.authority_level or 9
    if la != lb:
        (win, dw, lw), (_, dl, ll) = sorted([(a, da, la), (b, db, lb)], key=lambda t: t[2])
        names = (f"{dw.title} ", f"{dl.title} ") if dw and dl else ("", "")
        return win.record_id, f"higher authority: {names[0]}(level {lw}) over {names[1]}(level {ll})", ""
    sa, sb = _specificity(a), _specificity(b)
    if sa != sb:
        win = a if sa > sb else b
        return win.record_id, "more specific (more conditions, named codes, or narrower applicability)", ""
    if (a.effective_start or "") != (b.effective_start or ""):
        win = a if (a.effective_start or "") > (b.effective_start or "") else b
        return win.record_id, "later effective date", ""
    return "", "no canon decides: a person must", ""


def find(views: dict, docs: dict, statements: list, log: DC.Log, build_id: str) -> list:
    """Conflict rows. views: {record_id: {"record", "status", "window": (start, end), "codes": [...]}}."""
    groups: dict = defaultdict(list)
    for rid, v in views.items():
        r = v["record"]
        if r.kind in COMPARED and v["status"] not in ("rejected", "superseded"):
            for c in v["codes"]:
                groups[(c, r.kind)].append(rid)
    pairs: dict = {}
    for (code, _), rids in groups.items():
        if len(rids) < 2:
            continue
        for x, y in combinations(sorted(set(rids)), 2):
            if (x, y) in pairs:
                pairs[(x, y)]["codes"].add(code)
                continue
            a, b = views[x]["record"], views[y]["record"]
            if a.record_key == b.record_key:
                continue
            ca, cb = {canonical(c) for c in a.conditions or []}, {canonical(c) for c in b.conditions or []}
            narrower = ""
            if ca != cb:
                # one record's conditions inside the other's: they meet on the narrower domain (a B2 row for one
                # provider type and a guide rule for every provider). A narrower limit is a specific rule, not a
                # conflict; disjoint conditions never meet.
                if not (ca <= cb or cb <= ca) or a.kind in LIMIT_KINDS:
                    continue
                narrower = " (where the narrower record's conditions hold)"
            w = _overlap(views[x]["window"], views[y]["window"])
            if w is None or not _applies_together(a, b):
                continue
            rel = relation(a, b)
            if rel:
                pairs[(x, y)] = {"rel": (rel[0], rel[1] + narrower), "window": w, "codes": {code}}
    rows = []
    for (x, y), p in sorted(pairs.items()):
        a, b = views[x]["record"], views[y]["record"]
        cid = "C-" + short_hash(x, y)
        prevailing, basis, pid = suggest(a, b, docs, statements)
        d, _ = log.current("conflict", cid, DC.conflict_sha(a.content_sha, b.content_sha))
        status = "open"
        if d and d["decision"] in ("a", "b", "both"):
            status = f"resolved:{d['decision']}"
        rows.append({"conflict_id": cid, "build_id": build_id, "record_a": x, "record_b": y,
                     "relationship": p["rel"][0], "codes": sorted(p["codes"]), "window_start": p["window"][0],
                     "window_end": p["window"][1], "suggested_prevailing": prevailing, "basis": basis,
                     "precedence_id": pid, "detail": p["rel"][1], "status": status})
    return rows


def effects(rows: list) -> dict:
    """{record_id: reason it is held back} from the conflicts: open holds both records; a resolution holds the
    record that does not prevail."""
    out: dict = {}
    for c in rows:
        st = c["status"]
        if st == "open":
            for rid in (c["record_a"], c["record_b"]):
                out.setdefault(rid, f"in open conflict {c['conflict_id']} ({c['relationship']}); waits for a signed "
                                    f"resolution")
        elif st in ("resolved:a", "resolved:b"):
            lose = c["record_b"] if st == "resolved:a" else c["record_a"]
            out.setdefault(lose, f"does not prevail in conflict {c['conflict_id']} (signed)")
    return out
