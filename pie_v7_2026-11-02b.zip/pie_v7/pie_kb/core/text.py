"""Text clean-up shared by parsing, grounding and hashing.

Policy PDFs carry typographic variants (curly quotes, en and em dashes, no-break spaces, bullet glyphs). Every
comparison in PIE goes through `clean` so a quote matches its source whatever glyph the PDF used.
"""
from __future__ import annotations

import re
import unicodedata

_DASHES = "‐‑‒–—―−﹘﹣－"
_SQUOTES = "‘’‚‛′ʼ"
_DQUOTES = "“”„‟″"
_SPACES = "              　"
_ZERO_WIDTH = "​‌‍⁠﻿­"
BULLETS = "•●▪■◦‣⁃∙○➢"

_TABLE = str.maketrans({**{c: "-" for c in _DASHES}, **{c: "'" for c in _SQUOTES}, **{c: '"' for c in _DQUOTES},
                        **{c: " " for c in _SPACES}, **{c: None for c in _ZERO_WIDTH}})
_WS = re.compile(r"\s+")


def clean(s: str | None) -> str:
    """Normalise glyphs (dashes, quotes, spaces) and collapse whitespace; None -> ''."""
    if s is None:
        return ""
    s = unicodedata.normalize("NFKC", str(s)).translate(_TABLE)
    return _WS.sub(" ", s).strip()


def clean_keep_lines(s: str | None) -> str:
    """Like clean, but keeps line breaks (collapses spaces within each line)."""
    if s is None:
        return ""
    s = unicodedata.normalize("NFKC", str(s)).translate(_TABLE)
    return "\n".join(_WS.sub(" ", line).strip() for line in s.splitlines()).strip()


def match_form(s: str | None) -> str:
    """The form two texts are compared in: clean, lower case, bullets dropped, spaces around punctuation unified."""
    s = clean(s).lower()
    s = re.sub(f"[{re.escape(BULLETS)}]", " ", s)
    s = re.sub(r"\s*([,;:()/])\s*", r"\1 ", s)
    return _WS.sub(" ", s).strip()


def is_bullet(token: str) -> bool:
    return bool(token) and all(ch in BULLETS for ch in token.strip())


def sentences(text: str) -> list[tuple[int, int]]:
    """(start, end) character spans of the sentences of `text`.

    A sentence ends at '.', '?' or '!' followed by a space and an upper-case letter, a digit or an opening bracket,
    or at a blank line. Abbreviations common in AHCCCS text (e.g., i.e., A.A.C., U.S., No., Ch.) do not end one.
    """
    spans, start = [], 0
    abbrev = re.compile(r"(?:\b(?:e\.g|i\.e|etc|vs|No|Ch|Sec|Supp|St|Dr|Mr|Ms|Inc|Jr|al)\.|\b[A-Z]\.(?:[A-Z]\.)+|"
                        r"\b[A-Z]\.)$")
    for m in re.finditer(r"[.?!](?=\s+[A-Z0-9(\[\"'])|\n\s*\n", text):
        end = m.end()
        head = text[start:end]
        if m.group(0) == "." and abbrev.search(head.rstrip()):
            continue
        if head.strip():
            spans.append((start, end))
        start = end
    if text[start:].strip():
        spans.append((start, len(text)))
    return spans
