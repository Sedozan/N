"""Whether a record can be checked on a claim, per claim type: the execution class.

  executable   every field the check needs is on the claim and verified; nothing in the record needs a person
  conditional  checkable, but a field is not verified yet, a stated exception must be confirmed per finding, or a
               parameter the check needs is unstated (scope, role, modifier bypass)
  signal       a threshold for review (documentation above N units), never a violation
  knowledge    the record cannot be checked on a claim (a definition, a duty, a credential, an incomplete list)
  unresolved   the record names a category no code list resolves, or it cannot be read as stated

A flag that blocks (a dict with "blocks": true) makes the record unresolved whatever its kind: a table cell the
signed reading says not to compile (an all-nines placeholder maximum, anesthesia time units), a period whose meaning is
undecided.

The class is computed from content. Whether a record is executable now also needs an approval and no open conflict;
kb/build.py adds those. A field marked "unverified" becomes "available" once SB measures it on the claims table, and
every record that needed it moves up by itself.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .kinds import KINDS

CLASSES = ("executable", "conditional", "signal", "knowledge", "unresolved")
AVAILABLE, UNVERIFIED, UNAVAILABLE = "available", "unverified", "unavailable"

# the claim field each condition type reads
CONDITION_FIELDS = {"age": ("dob", "dos"), "program": ("program",), "delivery_system": ("program",),
                    "place_of_service": ("pos",), "modifier": ("modifiers",), "diagnosis": ("diagnosis",),
                    "provider_type": ("billing_type", "rendering_type"), "claim_form": ("form_type",),
                    "setting": ("setting",), "member_attribute": ("member_attribute",),
                    "service_context": ("service_context",), "other": ("other_context",)}


@dataclass(frozen=True)
class ClaimType:
    name: str
    forms: tuple                                  # AHCCCS FORM_TYP values
    fields: dict = field(default_factory=dict)    # logical field -> available | unverified | unavailable
    notes: str = ""

    def status(self, f: str) -> str:
        return self.fields.get(f, UNAVAILABLE)


_COMMON = {"dos": AVAILABLE, "member": AVAILABLE, "dob": AVAILABLE, "billing_provider": AVAILABLE,
           "rendering_provider": AVAILABLE, "billing_type": AVAILABLE, "rendering_type": AVAILABLE,
           "paid_amount": AVAILABLE, "form_type": AVAILABLE, "units": AVAILABLE,
           # columns that exist in all_data_C_A but whose fill rate and meaning are not measured yet
           "diagnosis": UNVERIFIED, "pos": UNVERIFIED, "pa_number": UNVERIFIED, "service_end_date": UNVERIFIED,
           "program": UNVERIFIED}

CLAIM_TYPES: dict[str, ClaimType] = {c.name: c for c in [
    ClaimType("professional", ("A",), {**_COMMON, "proc_code": AVAILABLE, "modifiers": AVAILABLE},
              "CMS-1500 lines (FORM_TYP A): PROC_CD, PROC_MOD_1..4, QUANTITY_PAID, SProv_Type, BProv_Type"),
    ClaimType("institutional", ("I", "O", "L"), {**_COMMON, "proc_code": UNVERIFIED, "modifiers": UNVERIFIED,
                                                 "revenue_code": UNAVAILABLE, "bill_type": UNAVAILABLE},
              "UB-04 lines: form O carried no PROC_CD on any line in the 2026-10-18 profile; only Revenue_Cd_Desc"),
    ClaimType("pharmacy", ("C",), {**_COMMON, "ndc": UNVERIFIED, "proc_code": UNVERIFIED},
              "NCPDP lines; NDC_CD exists, fill rate not measured"),
    ClaimType("dental", ("D",), {**_COMMON, "proc_code": AVAILABLE, "tooth": UNAVAILABLE}, "ADA lines (CDT codes)"),
]}


def required_fields(rec) -> tuple[set, set]:
    """(fields the base check reads, fields the record's conditions read)."""
    k = KINDS.get(rec.kind)
    base = set(k.fields if k else ())
    p = rec.params or {}
    if rec.kind == "pair_prohibited" and p.get("scope") == "member_provider_day":
        base |= {"rendering_provider"}
    if rec.kind in ("units_limit", "frequency_limit") and p.get("scope") == "member_provider":
        base |= {"rendering_provider"}
    if rec.kind == "provider_type_rule":
        role = p.get("role")
        base -= {"billing_type", "rendering_type"}
        base |= {"rendering_type"} if role == "rendering" else {"billing_type"} if role == "billing" else \
            {"billing_type", "rendering_type"}
    if rec.kind == "documentation_required" and not p.get("threshold_units"):
        base = {"medical_record"}
    cond = set()
    for c in rec.conditions or []:
        cond |= set(CONDITION_FIELDS.get(c.get("type"), ("other_context",)))
    return base, cond


def execution_class(rec, claim_type: str = "professional") -> tuple[str, list[str]]:
    """(class, reasons). Reasons say what holds the record back, in words a reviewer can act on."""
    ct = CLAIM_TYPES[claim_type]
    k = KINDS.get(rec.kind)
    if k is None:
        return "unresolved", [f"unknown kind {rec.kind}"]
    blocking = [f for f in (rec.flags or []) if isinstance(f, dict) and f.get("blocks")]
    if blocking:
        return "unresolved", [f.get("text") or f.get("code") or "flagged" for f in blocking]
    if rec.kind == "documentation_required":
        if (rec.params or {}).get("threshold_units"):
            return "signal", ["a documentation threshold ranks providers for review; it caps nothing"]
        return "knowledge", ["documentation is in the medical record, not on the claim"]
    if not k.checkable:
        return "knowledge", [f"a {rec.kind.replace('_', ' ')} is not checked on a claim"]
    reasons = []
    codes = (rec.subject or {}).get("codes") or []
    if not codes:
        return "unresolved", [f"names a category ({(rec.subject or {}).get('category')!r}) that no code list "
                              f"resolves yet"]
    p = rec.params or {}
    if rec.kind == "pair_prohibited" and not p.get("partners"):
        return "unresolved", [f"partner category {p.get('partner_category')!r} is not resolved to codes"]
    if rec.kind == "included_in" and not p.get("parent_codes"):
        return "unresolved", [f"parent category {p.get('parent_category')!r} is not resolved to codes"]
    if rec.kind in ("provider_type_rule", "modifier_rule", "pos_rule") and p.get("mode") == "allowed" \
            and not p.get("complete_list"):
        return "knowledge", ["an allowed list not stated as complete cannot show a violation"]
    base, cond = required_fields(rec)
    missing_base = sorted(f for f in base if ct.status(f) == UNAVAILABLE)
    if missing_base:
        return "knowledge", [f"needs {', '.join(missing_base)}, not on {claim_type} claims"]
    unverified = sorted(f for f in base | cond if ct.status(f) == UNVERIFIED)
    missing_cond = sorted(f for f in cond if ct.status(f) == UNAVAILABLE)
    if missing_cond:
        reasons.append(f"condition needs {', '.join(missing_cond)}, not on the claim (a person confirms per finding)")
    if unverified:
        reasons.append(f"uses {', '.join(unverified)}: on the claims table, fill rate not measured yet")
    if rec.exceptions:
        reasons.append("states an exception a person confirms per finding")
    for name in ("scope", "role", "modifier_bypass"):
        if p.get(name) == "unstated":
            reasons.append(f"{name.replace('_', ' ')} is not stated in the source")
    return ("conditional", reasons) if reasons else ("executable", [])
