"""Date parsing for the date forms AHCCCS documents use, and date windows."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

MONTHS = {m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november",
     "december"], start=1)}
MONTHS.update({k[:3]: v for k, v in list(MONTHS.items())})
MONTHS["sept"] = 9

MDY_RE = re.compile(r"(?<![\d/])(\d{1,2})/(\d{1,2})/(\d{4}|\d{2})(?![\d/])")
MONTH_DAY_YEAR_RE = re.compile(r"\b(" + "|".join(sorted(MONTHS, key=len, reverse=True)) +
                               r")\.?\s+(\d{1,2}),?\s+(\d{4})\b", re.I)
MONTH_YEAR_RE = re.compile(r"\b(" + "|".join(sorted(MONTHS, key=len, reverse=True)) + r")\.?\s+(\d{4})\b", re.I)
ISO_RE = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
OPEN_END = date(2299, 12, 31)          # AHCCCS writes an open end as 12/31/2299


def _year(y: str) -> int:
    n = int(y)
    return n if n >= 100 else 2000 + n if n < 70 else 1900 + n


def mdy(s: str) -> date | None:
    """'10/1/26' or '10/01/2026' -> date; None when the text holds no such date (or an impossible one)."""
    m = MDY_RE.search(s or "")
    if not m:
        return None
    try:
        return date(_year(m.group(3)), int(m.group(1)), int(m.group(2)))
    except ValueError:
        return None


def all_mdy(s: str) -> list[date]:
    out = []
    for m in MDY_RE.finditer(s or ""):
        try:
            out.append(date(_year(m.group(3)), int(m.group(1)), int(m.group(2))))
        except ValueError:
            continue
    return out


def any_date(s: str) -> date | None:
    """The first date in the text in any of the forms: 10/1/2026, October 1, 2026, Oct. 1, 2026, 2026-10-01."""
    found = []
    for rx, conv in ((MDY_RE, lambda m: date(_year(m.group(3)), int(m.group(1)), int(m.group(2)))),
                     (MONTH_DAY_YEAR_RE, lambda m: date(int(m.group(3)), MONTHS[m.group(1).lower()], int(m.group(2)))),
                     (ISO_RE, lambda m: date(int(m.group(1)), int(m.group(2)), int(m.group(3))))):
        for m in rx.finditer(s or ""):
            try:
                found.append((m.start(), conv(m)))
            except (ValueError, KeyError):
                continue
    return min(found)[1] if found else None


def month_year(s: str) -> date | None:
    """'May 2023' -> 2023-05-01."""
    m = MONTH_YEAR_RE.search(s or "")
    if not m:
        return None
    return date(int(m.group(2)), MONTHS[m.group(1).lower()], 1)


def to_date(v) -> date | None:
    """A cell or field value (date, datetime, ISO text, m/d/y text) -> date."""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    if not s:
        return None
    m = ISO_RE.match(s)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    return mdy(s) or any_date(s)


def iso(d: date | None) -> str | None:
    return d.isoformat() if d else None


def day_before(d: date) -> date:
    return d - timedelta(days=1)


def fiscal_year_window(fy: int) -> tuple[date, date]:
    """The federal / AHCCCS contract year FY<fy>: October 1 of fy-1 to September 30 of fy."""
    return date(fy - 1, 10, 1), date(fy, 9, 30)


def months_between(a: date, b: date) -> list[date]:
    """First days of the months strictly after a's month and strictly before b's month."""
    out, y, m = [], a.year, a.month
    while True:
        m += 1
        if m > 12:
            y, m = y + 1, 1
        first = date(y, m, 1)
        if (first.year, first.month) >= (b.year, b.month):
            return out
        out.append(first)


def overlaps(a_start: str | None, a_end: str | None, b_start: str | None, b_end: str | None) -> bool:
    """Two ISO windows overlap; None = open on that side."""
    lo = max(a_start or "0000-01-01", b_start or "0000-01-01")
    hi = min(a_end or "9999-12-31", b_end or "9999-12-31")
    return lo <= hi
