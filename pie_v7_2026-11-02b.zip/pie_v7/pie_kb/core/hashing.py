"""Hashes and content-derived ids. Every id in PIE is derived from content, so the same input always gets the same id."""
from __future__ import annotations

import hashlib
import json
from typing import Any

from .text import clean


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical(obj: Any) -> str:
    """One JSON form per value: sorted keys, no spaces, sets and tuples as sorted lists, floats like 4.0 as 4."""
    return json.dumps(_canon(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _canon(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): _canon(v) for k, v in obj.items() if v is not None and v != [] and v != {} and v != ""}
    if isinstance(obj, (set, frozenset)):
        return sorted((_canon(v) for v in obj), key=lambda v: json.dumps(v, sort_keys=True, default=str))
    if isinstance(obj, (list, tuple)):
        return [_canon(v) for v in obj]
    if isinstance(obj, float) and obj.is_integer():
        return int(obj)
    if isinstance(obj, str):
        return clean(obj)
    return obj


def short_hash(*parts: Any, n: int = 16) -> str:
    """First n hex characters of the sha256 of the canonical form of parts."""
    return sha256_text(canonical(list(parts)))[:n]


def text_hash(text: str) -> str:
    """Hash of a text after glyph and whitespace normalisation (a re-typeset PDF with the same words hashes the same)."""
    return sha256_text(clean(text))[:16]


def files_hash(*paths: str, n: int = 10) -> str:
    """First n hex characters of the sha256 of some files' contents, in the order given (a stage's code version)."""
    h = hashlib.sha256()
    for p in paths:
        with open(p, "rb") as f:
            h.update(f.read())
        h.update(b"\x00")
    return h.hexdigest()[:n]


def code_version(*parts: str, n: int = 10) -> str:
    """Hash of the package files a stage's output depends on. Each part is a path relative to pie_kb/: a folder means
    its .py files, a file is itself (a reference CSV included). A change to any of them gives the stage a new
    configuration id, so the versions it already processed become due again."""
    import glob
    import os
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    files = []
    for part in parts:
        p = os.path.join(root, part)
        files += sorted(glob.glob(os.path.join(p, "*.py"))) if os.path.isdir(p) else [p]
    return files_hash(*files, n=n)
