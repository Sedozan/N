"""Code systems: recognise, clean and validate the codes policy text and tables carry.

Procedure codes (HCPCS Level II, CPT categories I to III, PLA and MAAA), dental CDT, ICD-10-CM diagnoses, revenue
codes, NDCs, modifiers, places of service, AHCCCS provider types and bill types. Adding a code system means adding one
entry to SYSTEMS; nothing else in the package lists code shapes.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, Iterable

# HCPCS Level II sections (CMS): A B C E G H J K L M P Q R S T U V. D is dental (CDT); F, I, N, O, W, X, Y, Z are not
# HCPCS Level II letters, so "F1020" in a policy is an ICD-10 code, not a procedure.
HCPCS_LETTERS = "ABCEGHJKLMPQRSTUV"


@dataclass(frozen=True)
class CodeSystem:
    name: str
    pattern: re.Pattern
    normalize: Callable[[str], str]
    kind: str            # procedure | diagnosis | revenue | drug | modifier | place_of_service | provider_type | bill_type
    description: str

    def valid(self, code: str) -> bool:
        return bool(self.pattern.fullmatch(self.normalize(code)))


def _upper(s: str) -> str:
    return str(s).strip().upper()


def _pad_procedure(s) -> str:
    """A procedure code as text. Spreadsheets store numeric CPT codes as numbers: 100 -> '00100', 88321.0 -> '88321'."""
    if isinstance(s, float) and s.is_integer():
        s = int(s)
    t = str(s).strip().upper()
    if t.endswith(".0") and t[:-2].isdigit():
        t = t[:-2]
    if t.isdigit() and len(t) < 5:
        t = t.zfill(5)
    return t


def _icd(s: str) -> str:
    return str(s).strip().upper().replace(".", "")


def _two(s) -> str:
    """Modifier, place of service or provider type: 2 characters; numbers are zero-padded (8 -> '08', 3.0 -> '03')."""
    if isinstance(s, float) and s.is_integer():
        s = int(s)
    t = str(s).strip().upper()
    if t.endswith(".0") and t[:-2].isdigit():
        t = t[:-2]
    return t.zfill(2) if t.isdigit() and len(t) == 1 else t


def _ndc(s: str) -> str:
    t = str(s).strip()
    if re.fullmatch(r"\d{4}-\d{4}-\d{2}", t):
        a, b, c = t.split("-")
        return "0" + a + b + c
    if re.fullmatch(r"\d{5}-\d{3}-\d{2}", t):
        a, b, c = t.split("-")
        return a + "0" + b + c
    if re.fullmatch(r"\d{5}-\d{4}-\d", t):
        a, b, c = t.split("-")
        return a + b + "0" + c
    return re.sub(r"\D", "", t)


SYSTEMS: dict[str, CodeSystem] = {s.name: s for s in [
    CodeSystem("HCPCS", re.compile(rf"[{HCPCS_LETTERS}]\d{{4}}"), _upper, "procedure", "HCPCS Level II"),
    CodeSystem("CPT", re.compile(r"\d{5}"), _pad_procedure, "procedure", "CPT category I"),
    CodeSystem("CPT_II", re.compile(r"\d{4}F"), _upper, "procedure", "CPT category II"),
    CodeSystem("CPT_III", re.compile(r"\d{4}T"), _upper, "procedure", "CPT category III"),
    CodeSystem("CPT_PLA", re.compile(r"\d{4}U"), _upper, "procedure", "CPT proprietary laboratory analyses"),
    CodeSystem("CPT_MAAA", re.compile(r"\d{4}M"), _upper, "procedure", "CPT multianalyte assays"),
    CodeSystem("CDT", re.compile(r"D\d{4}"), _upper, "procedure", "ADA dental (CDT)"),
    CodeSystem("ICD10CM", re.compile(r"[A-TV-Z]\d[0-9A-Z][0-9A-Z]{0,4}"), _icd, "diagnosis", "ICD-10-CM, without dot"),
    CodeSystem("REVENUE", re.compile(r"0\d{3}"), _upper, "revenue", "UB-04 revenue code"),
    CodeSystem("NDC", re.compile(r"\d{11}"), _ndc, "drug", "National Drug Code, 11 digits"),
    CodeSystem("MODIFIER", re.compile(r"[0-9A-Z]{2}"), _two, "modifier", "procedure modifier"),
    CodeSystem("POS", re.compile(r"\d{2}"), _two, "place_of_service", "CMS place of service"),
    CodeSystem("PROVIDER_TYPE", re.compile(r"[0-9A-Z]{2}"), _two, "provider_type", "AHCCCS provider type"),
    CodeSystem("BILL_TYPE", re.compile(r"0?\d{3}"), _upper, "bill_type", "UB-04 type of bill"),
]}

PROCEDURE_SYSTEMS = ("HCPCS", "CPT", "CPT_II", "CPT_III", "CPT_PLA", "CPT_MAAA", "CDT")


def procedure_system(code) -> str | None:
    """The procedure code system a token belongs to, or None. '100' (a spreadsheet number) reads as CPT 00100."""
    t = _pad_procedure(code)
    for name in PROCEDURE_SYSTEMS:
        if SYSTEMS[name].pattern.fullmatch(t):
            return name
    return None


def norm_procedure(code) -> str | None:
    """Cleaned procedure code, or None when the token is not one."""
    t = _pad_procedure(code)
    return t if procedure_system(t) else None


def norm_two(code) -> str | None:
    t = _two(code)
    return t if re.fullmatch(r"[0-9A-Z]{2}", t) else None


def is_icd10(code: str) -> bool:
    return bool(SYSTEMS["ICD10CM"].pattern.fullmatch(_icd(code)))


# ------------------------------------------------------------------ finding codes in text
# A procedure code in running text: HCPCS (letter + 4 digits), CPT (5 digits, or 4 digits + F/T/U/M), CDT (D + 4).
# Codes joined by a slash ("H0031/H0032", "90832/90834") are both found; a date ("10/12345", "12345/12/2024") is not.
PROC_IN_TEXT = re.compile(rf"(?<![A-Za-z0-9.-])(?<!(?<![A-Za-z0-9])\d/)(?<!(?<![A-Za-z0-9])\d\d/)"
                          rf"((?:[{HCPCS_LETTERS}D]\d{{4}})|(?:\d{{4}}[0-9FTUM]))(?![A-Za-z0-9])(?!/\d{{1,2}}(?![0-9]))")
# ICD-10-CM in running text: dotted (F10.239) or undotted when it cannot be a HCPCS code (F1020, Z6331).
ICD_IN_TEXT = re.compile(r"(?<![A-Za-z0-9])([A-TV-Z]\d[0-9A-Z](?:\.[0-9A-Z]{1,4}|[0-9A-Z]{0,4}))(?![A-Za-z0-9])")
RANGE_IN_TEXT = re.compile(
    rf"(?<![A-Za-z0-9])((?:[{HCPCS_LETTERS}D]\d{{4}})|(?:\d{{4}}[0-9FTUM]))\s*(?:-|to|through|thru)\s*"
    rf"((?:[{HCPCS_LETTERS}D]\d{{4}})|(?:\d{{4}}[0-9FTUM]))(?![A-Za-z0-9])", re.I)
# Context that makes a 5-digit number something other than a CPT code
_NOT_CPT_BEFORE = re.compile(r"(?:\bAZ|Arizona|Phoenix|Tucson|Box|Suite|Ste\.?|zip|fax|phone|ext\.?|#)\s*$", re.I)


def procedure_codes_in(text: str) -> list[tuple[str, int, int]]:
    """(code, start, end) for every procedure-code-shaped token in text, in order. ZIP codes after 'AZ' or a city are
    skipped; years and page numbers are not 5 characters long."""
    out = []
    for m in PROC_IN_TEXT.finditer(text or ""):
        code = m.group(1).upper()
        if code.isdigit() and _NOT_CPT_BEFORE.search(text[max(0, m.start() - 12):m.start()]):
            continue
        out.append((code, m.start(1), m.end(1)))
    return out


def diagnosis_codes_in(text: str) -> list[tuple[str, int, int]]:
    """ICD-10-CM codes in text. Undotted 5-character tokens that look like HCPCS (H0004) are not diagnoses."""
    out = []
    for m in ICD_IN_TEXT.finditer(text or ""):
        tok = m.group(1).upper()
        if "." not in tok and len(tok) == 5 and tok[0] in HCPCS_LETTERS and tok[1:].isdigit():
            continue
        out.append((tok.replace(".", ""), m.start(1), m.end(1)))
    return out


def ranges_in(text: str) -> list[tuple[str, str, int, int]]:
    return [(m.group(1).upper(), m.group(2).upper(), m.start(), m.end()) for m in RANGE_IN_TEXT.finditer(text or "")]


def expand_range(lo: str, hi: str, universe: Iterable[str]) -> list[str]:
    """Codes of `universe` from lo to hi inclusive, same leading letter (or both numeric) and same length.

    A range cannot be expanded without a list of codes that exist (H0001-H0005 is not every number in between), so
    the caller passes the codes known to the knowledge base; the endpoints are always included."""
    lo, hi = lo.upper(), hi.upper()
    if len(lo) != len(hi) or (lo[0].isalpha() != hi[0].isalpha()) or (lo[0].isalpha() and lo[0] != hi[0]):
        return [lo, hi] if lo != hi else [lo]
    out = {lo, hi}
    for c in universe:
        c = str(c).upper()
        if len(c) == len(lo) and (c[0] == lo[0] if lo[0].isalpha() else c[0].isdigit()) and lo <= c <= hi:
            out.add(c)
    return sorted(out)


MODIFIER_NEAR = re.compile(r"(?:\bmodifiers?\s+((?:[0-9A-Z]{2}(?:\s*(?:,|and|or|/)\s*)?)+)|"
                           r"\b([0-9A-Z]{2})\s+modifiers?\b|-([A-Z0-9]{2})\b)")


def modifiers_in(text: str) -> list[str]:
    """Two-character modifiers named next to the word 'modifier' ('the HQ modifier', 'modifiers GT, GQ or FQ')."""
    out = []
    for m in MODIFIER_NEAR.finditer(text or ""):
        chunk = m.group(1) or m.group(2) or ""
        for tok in re.findall(r"\b[0-9A-Z]{2}\b", chunk):
            if tok not in ("OR", "AN", "TO", "OF", "IN", "ON", "BY", "IS") and tok not in out:
                out.append(tok)
    return out


def provider_types_in(text: str) -> list[str]:
    """AHCCCS provider type codes named as such: 'provider type 77', 'PT 01', 'provider types B5 and B6'."""
    out = []
    for m in re.finditer(r"\b(?:provider\s+types?|PTs?)\s*(?:\(\s*)?((?:[0-9A-Z]{2}\b(?:\s*(?:,|and|or|/)\s*)?)+)",
                         text or "", re.I):
        for tok in re.findall(r"\b[0-9A-Z]{2}\b", m.group(1).upper()):
            if tok not in ("OR", "AN", "TO", "OF", "IN", "ON", "BY", "IS") and tok not in out:
                out.append(tok)
    return out
