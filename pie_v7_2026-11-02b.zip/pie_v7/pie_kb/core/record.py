"""The knowledge base record: one thing a source says, typed, cited and dated.

Identity:
  record_key  what the record says (kind, subject, parameters, conditions, exceptions, applicability) within its
              source and document. Equal across two versions of a document when the meaning did not change, which is
              how approvals carry forward (kb/diff.py).
  record_id   one statement in one source version at one place (record_key + version + locator + quote).
  content_sha the exact content a reviewer approved; an approval binds to it.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from . import codes as C
from .hashing import canonical, sha256_text, short_hash
from .kinds import KINDS, normalize_params, render_statement, validate_conditions, validate_params
from .text import clean, match_form

ORIGINS = ("table", "pattern", "model", "pattern+model", "sme")
STATUSES = ("proposed", "needs_review", "approved", "rejected", "superseded", "retired")
WINDOW_BASES = ("version", "stated", "row", "version+stated", "version+row", "unknown")


@dataclass
class Record:
    kind: str
    subject: dict                                  # {"codes": [...], "category": str, "term": str}
    params: dict
    citation: dict                                 # source_id, document_key, source_version_id, section_id,
                                                   # section_path, page_start, page_end, locator, quote
    conditions: list = field(default_factory=list)
    exceptions: list = field(default_factory=list)  # [{"text": verbatim clause, "type": optional condition type}]
    applicability: dict = field(default_factory=dict)  # delivery_systems, programs_include, programs_exclude
    statement: str = ""
    effective_start: str | None = None
    effective_end: str | None = None
    window_basis: str = "version"
    origin: str = "model"
    authority_level: int | None = None
    jurisdiction: str = "state"
    binding: str = ""
    flags: list = field(default_factory=list)      # grounding and check findings for the reviewer
    confidence: float | None = None
    extraction: dict = field(default_factory=dict)  # run_id, config_id, backend, proposal index
    status: str = "proposed"
    review: dict = field(default_factory=dict)     # reviewer, decided_at, decision, note, decision_id
    record_key: str = ""
    record_id: str = ""
    content_sha: str = ""

    # ------------------------------------------------------------ normalisation and identity
    def normalize(self) -> "Record":
        self.kind = str(self.kind).strip()
        subj = dict(self.subject or {})
        codes = []
        for c in subj.get("codes") or []:
            n = C.norm_procedure(c)
            codes.append(n if n else str(c).strip().upper())
        subj["codes"] = sorted(set(codes))
        for k in ("category", "term"):
            if subj.get(k):
                subj[k] = clean(subj[k])
        self.subject = {k: v for k, v in subj.items() if v not in (None, "", [])}
        if self.kind in KINDS:
            self.params = normalize_params(self.kind, self.params or {})
        self.conditions = [_norm_condition(c) for c in (self.conditions or [])]
        self.exceptions = [{**e, "text": clean(e.get("text"))} for e in (self.exceptions or []) if clean(e.get("text"))]
        if not self.statement:
            self.statement = render_statement(self.kind, self.subject, self.params, self.conditions) \
                if self.kind in KINDS else ""
        self.statement = clean(self.statement)
        q = self.citation.get("quote")
        if q is not None:
            self.citation["quote"] = clean(q)
        return self

    def meaning(self) -> dict:
        """The fields that define what the record says (no place, no version, no wording)."""
        return {"source_id": self.citation.get("source_id"), "document_key": self.citation.get("document_key"),
                "kind": self.kind, "subject": self.subject, "params": self.params, "conditions": self.conditions,
                "exceptions": sorted(match_form(e["text"]) for e in self.exceptions),
                "applicability": self.applicability}

    def assign_ids(self) -> "Record":
        self.record_key = "K-" + short_hash(self.meaning())
        quote = match_form(self.citation.get("quote") or "")
        self.record_id = "R-" + short_hash(self.record_key, self.citation.get("source_version_id"),
                                           self.citation.get("locator"), quote)
        self.content_sha = sha256_text(canonical({"meaning": self.meaning(), "statement": self.statement,
                                                  "start": self.effective_start, "end": self.effective_end,
                                                  "quote": quote}))[:24]
        return self

    # ------------------------------------------------------------ validation
    def problems(self) -> list[str]:
        p = []
        if self.kind not in KINDS:
            return [f"unknown kind {self.kind!r}"]
        k = KINDS[self.kind]
        p += validate_params(self.kind, self.params)
        p += validate_conditions(self.conditions)
        codes = self.subject.get("codes") or []
        if k.subject == "codes" and not codes:
            p.append(f"{self.kind} needs subject codes")
        if k.subject == "codes_or_category" and not codes and not self.subject.get("category"):
            p.append(f"{self.kind} needs subject codes or a category")
        if k.subject == "term" and not self.subject.get("term"):
            p.append(f"{self.kind} needs a subject term")
        bad = [c for c in codes if not C.norm_procedure(c)]
        if bad:
            p.append(f"subject codes not recognised as procedure codes: {bad[:5]}")
        if self.origin not in ORIGINS:
            p.append(f"unknown origin {self.origin!r}")
        if self.status not in STATUSES:
            p.append(f"unknown status {self.status!r}")
        if not self.citation.get("source_id") or not self.citation.get("source_version_id"):
            p.append("citation needs source_id and source_version_id")
        if self.origin != "table" and not (self.citation.get("quote") or "").strip():
            p.append("a record read from text needs the quote it was read from")
        if self.origin == "table" and not self.citation.get("locator"):
            p.append("a table record needs its sheet and cell (locator)")
        if self.effective_start and self.effective_end and self.effective_start > self.effective_end:
            p.append(f"window starts {self.effective_start} after it ends {self.effective_end}")
        return p

    def to_row(self) -> dict:
        return asdict(self)

    @classmethod
    def from_row(cls, row: dict) -> "Record":
        known = {k: v for k, v in row.items() if k in cls.__dataclass_fields__}
        return cls(**known)


def _norm_condition(c: dict) -> dict:
    c = {k: v for k, v in dict(c).items() if v not in (None, "", [])}
    for k in ("include", "exclude", "present", "absent", "codes"):
        if isinstance(c.get(k), list):
            if c.get("type") in ("place_of_service", "modifier", "provider_type"):
                c[k] = sorted({C.norm_two(v) or str(v).strip().upper() for v in c[k]})
            else:
                c[k] = sorted({clean(str(v)) for v in c[k]})
    if "text" in c:
        c["text"] = clean(c["text"])
    return c


def store_row(rec: Record, claim_type: str = "professional") -> dict:
    """The kb_records row: the record, its source columns and its execution class for a claim type."""
    from .checkability import execution_class
    cls, why = execution_class(rec, claim_type)
    return {**rec.to_row(), "source_id": rec.citation.get("source_id"),
            "source_version_id": rec.citation.get("source_version_id"), "execution_class": cls,
            "execution_reasons": why}


def finalize(rec: Record) -> Record:
    """Normalise and assign ids; the one call every producer of records makes last."""
    return rec.normalize().assign_ids()


def record_from_json(d: dict[str, Any]) -> Record:
    return Record.from_row(d)
