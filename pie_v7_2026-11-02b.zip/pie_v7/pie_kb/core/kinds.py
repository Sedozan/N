"""The record kinds: what a knowledge base record can say, and the parameters each kind takes.

A kind is not a SQL shape. Every obligation a source states is kept as a record, whatever its kind; whether it can be
checked on a claim is decided separately (checkability.py) from the fields the record needs and the claim type.

Each kind lists its parameters with a type and whether it is required. `validate_params` is the one validator used by
the table extractors, the model output parser, the review ingest and the tests.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from . import codes as C

PERIODS = ("line", "day", "week", "month", "year", "benefit_year", "lifetime", "stay", "episode", "session")
SCOPES = ("member", "member_provider", "unstated")
PAIR_SCOPES = ("member_day", "member_provider_day", "unstated")
UNIT_BASES = ("unit", "minutes_15", "minutes_30", "hour", "day", "session", "visit", "mile", "unstated")
FORMS = ("CMS-1500", "UB-04", "ADA", "NCPDP")


@dataclass(frozen=True)
class Param:
    type: str                      # int | number | bool | str | enum | list_codes | list_pt | list_mod | list_pos | list_str
    required: bool = False
    choices: tuple = ()
    default: Any = None


@dataclass(frozen=True)
class Kind:
    name: str
    summary: str                   # one line, used in the prompt and the review workbook
    subject: str                   # codes | codes_or_category | term | any
    params: dict = field(default_factory=dict)
    checkable: bool = True         # False: the kind is knowledge by nature (a definition, a pointer, a duty)
    fields: tuple = ()             # claim fields the base check reads (checkability.py adds the conditions' fields)


KINDS: dict[str, Kind] = {k.name: k for k in [
    Kind("not_covered", "The service or code is not covered (not payable).", "codes_or_category",
         {}, True, ("proc_code", "dos")),
    Kind("prior_auth_rule", "Prior or continued authorization is required, or explicitly not required.",
         "codes_or_category",
         {"requirement": Param("enum", True, ("required", "not_required")),
          "authorization": Param("enum", False, ("prior", "continued", "prior_and_continued"), "prior"),
          "programs": Param("enum", False, ("all", "acute", "ltc"), "all")},
         True, ("proc_code", "dos", "pa_number")),
    Kind("pair_prohibited", "The subject code may not be billed with the partner codes (the subject line is the "
         "finding).", "codes_or_category",
         {"partners": Param("list_codes"), "partner_category": Param("str"),
          "scope": Param("enum", False, PAIR_SCOPES, "unstated"),
          "modifier_bypass": Param("enum", False, ("none", "allowed", "unstated"), "unstated"),
          "both_ways": Param("bool", False, (), False)},
         True, ("proc_code", "dos", "member")),
    Kind("included_in", "The subject service is included in another service or per diem and is not billed "
         "separately.", "codes_or_category",
         {"parent_codes": Param("list_codes"), "parent_category": Param("str"),
          "scope": Param("enum", False, ("same_day", "same_stay", "unstated"), "unstated")},
         True, ("proc_code", "dos", "member")),
    Kind("units_limit", "At most `max` units of the subject code(s) per period.", "codes_or_category",
         {"max": Param("int", True), "per": Param("enum", True, PERIODS),
          "scope": Param("enum", False, SCOPES, "unstated"), "combined": Param("bool", False, (), False),
          "unit_basis": Param("enum", False, UNIT_BASES, "unstated")},
         True, ("proc_code", "units", "dos", "member")),
    Kind("frequency_limit", "At most `max` services (dates of service) per period.", "codes_or_category",
         {"max": Param("int", True), "per": Param("enum", True, PERIODS), "scope": Param("enum", False, SCOPES,
                                                                                          "unstated")},
         True, ("proc_code", "dos", "member")),
    Kind("dollar_limit", "At most `max_amount` dollars per period.", "codes_or_category",
         {"max_amount": Param("number", True), "per": Param("enum", True, PERIODS)},
         True, ("proc_code", "paid_amount", "dos", "member")),
    Kind("provider_type_rule", "Only (allowed) or never (not_allowed) these AHCCCS provider types bill or render the "
         "code.", "codes_or_category",
         {"mode": Param("enum", True, ("allowed", "not_allowed")), "provider_types": Param("list_pt", True),
          "role": Param("enum", False, ("billing", "rendering", "billing_or_rendering", "unstated"), "unstated"),
          "complete_list": Param("bool", False, (), False)},
         True, ("proc_code", "billing_type", "rendering_type")),
    Kind("provider_qualification", "Who may deliver the service: licence, credential, supervision, training.",
         "codes_or_category", {"requirement": Param("str", True)}, False, ("rendering_credential",)),
    Kind("modifier_rule", "A modifier is required, allowed (a list) or not allowed with the code.", "codes_or_category",
         {"mode": Param("enum", True, ("required", "allowed", "not_allowed")), "modifiers": Param("list_mod", True),
          "match": Param("enum", False, ("any", "all"), "any"), "complete_list": Param("bool", False, (), False)},
         True, ("proc_code", "modifiers")),
    Kind("pos_rule", "The places of service the code is allowed or not allowed in.", "codes_or_category",
         {"mode": Param("enum", True, ("allowed", "not_allowed")), "pos": Param("list_pos", True),
          "complete_list": Param("bool", False, (), False)},
         True, ("proc_code", "pos")),
    Kind("telehealth_rule", "The code may (or may not) be delivered by telehealth, with these modifiers and "
         "originating-site places of service.", "codes_or_category",
         {"allowed": Param("bool", True), "modifiers": Param("list_mod"), "pos": Param("list_pos")},
         True, ("proc_code", "modifiers", "pos")),
    Kind("claim_form_required", "The service must be billed on this claim form.", "codes_or_category",
         {"form": Param("enum", True, FORMS)}, True, ("proc_code", "form_type")),
    Kind("diagnosis_required", "The service needs a diagnosis from a list (value set) or named codes.",
         "codes_or_category",
         {"value_set": Param("str"), "diagnoses": Param("list_str"),
          "position": Param("enum", False, ("any", "principal"), "any")},
         True, ("proc_code", "diagnosis")),
    Kind("age_limit", "The service is limited to members of an age range on the date of service.", "codes_or_category",
         {"min_age": Param("int"), "below_age": Param("int")}, True, ("proc_code", "dob", "dos")),
    Kind("documentation_required", "Documentation must exist or be submitted (with the claim, in the record).",
         "codes_or_category",
         {"requirement": Param("str", True), "threshold_units": Param("int"),
          "per": Param("enum", False, PERIODS), "submit_with_claim": Param("bool", False, (), False)},
         True, ("proc_code", "units", "dos", "member")),
    Kind("coverage_scope", "What a covered service is, includes or covers (a covered-service statement).", "any",
         {"description": Param("str")}, False),
    Kind("definition", "The meaning of a term as the source defines it.", "term",
         {"definition": Param("str", True)}, False),
    Kind("exception", "An exception that changes other rules (waives, narrows or extends them).", "any",
         {"effect": Param("enum", True, ("waives", "narrows", "extends")), "applies_to": Param("str", True),
          "target_kinds": Param("list_str")}, False),
    Kind("cross_reference", "The source points to another source for the requirement.", "any",
         {"target": Param("str", True), "target_source_id": Param("str")}, False),
    Kind("obligation", "Any other duty, prohibition or permission a source states.", "any",
         {"duty": Param("str", True)}, False),
]}

# typed conditions a record can carry; the value checker and the claim fields each needs
CONDITION_TYPES = {
    "age": ("min_age", "below_age"),
    "program": ("include", "exclude"),
    "delivery_system": ("include",),
    "place_of_service": ("include", "exclude"),
    "modifier": ("present", "absent"),
    "diagnosis": ("value_set", "codes"),
    "provider_type": ("include", "exclude", "role"),
    "claim_form": ("form",),
    "setting": ("text",),
    "member_attribute": ("text",),
    "service_context": ("text",),
    "other": ("text",),
}


def _check(name: str, spec: Param, v: Any) -> str | None:
    t = spec.type
    if t == "int":
        if isinstance(v, bool) or not isinstance(v, (int, float)) or (isinstance(v, float) and not v.is_integer()):
            return f"{name} must be a whole number (got {v!r})"
        if int(v) <= 0:
            return f"{name} must be positive (got {v!r})"
    elif t == "number":
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v <= 0:
            return f"{name} must be a positive number (got {v!r})"
    elif t == "bool":
        if not isinstance(v, bool):
            return f"{name} must be true or false (got {v!r})"
    elif t == "str":
        if not isinstance(v, str) or not v.strip():
            return f"{name} must be text (got {v!r})"
    elif t == "enum":
        if v not in spec.choices:
            return f"{name} must be one of {list(spec.choices)} (got {v!r})"
    elif t.startswith("list_"):
        if not isinstance(v, list) or not v:
            return f"{name} must be a non-empty list (got {v!r})"
        if t == "list_codes":
            bad = [c for c in v if not C.norm_procedure(c)]
        elif t in ("list_pt", "list_mod"):
            bad = [c for c in v if not C.norm_two(c)]
        elif t == "list_pos":
            bad = [c for c in v if not (C.norm_two(c) or "").isdigit()]
        else:
            bad = [c for c in v if not isinstance(c, str) or not c.strip()]
        if bad:
            return f"{name} holds invalid entries {bad[:5]}"
    return None


def normalize_params(kind: str, params: dict) -> dict:
    """Defaults filled, codes and two-character values cleaned, unknown keys dropped. Call validate_params after."""
    k = KINDS[kind]
    out = {}
    for name, spec in k.params.items():
        v = params.get(name, None) if params else None
        if v in (None, "", []):
            if spec.default is not None:
                out[name] = spec.default
            continue
        if spec.type == "list_codes" and isinstance(v, list):
            v = sorted({C.norm_procedure(c) or str(c).strip().upper() for c in v})
        elif spec.type in ("list_pt", "list_mod", "list_pos") and isinstance(v, list):
            v = sorted({C.norm_two(c) or str(c).strip().upper() for c in v})
        elif spec.type == "int" and isinstance(v, str) and v.strip().isdigit():
            v = int(v.strip())
        elif spec.type == "int" and isinstance(v, float) and v.is_integer():
            v = int(v)
        elif spec.type == "bool" and isinstance(v, str) and v.strip().lower() in ("true", "false"):
            v = v.strip().lower() == "true"
        out[name] = v
    return out


def validate_params(kind: str, params: dict) -> list[str]:
    """Problems with the parameters of a record of this kind ([] = valid)."""
    if kind not in KINDS:
        return [f"unknown kind {kind!r}"]
    k = KINDS[kind]
    problems = []
    for name, spec in k.params.items():
        v = (params or {}).get(name)
        if v in (None, "", []):
            if spec.required:
                problems.append(f"{kind} needs {name}")
            continue
        why = _check(name, spec, v)
        if why:
            problems.append(why)
    extra = set(params or {}) - set(k.params)
    if extra:
        problems.append(f"{kind} does not take {sorted(extra)}")
    if kind == "pair_prohibited" and not (params or {}).get("partners") and not (params or {}).get("partner_category"):
        problems.append("pair_prohibited needs partners or partner_category")
    if kind == "included_in" and not (params or {}).get("parent_codes") and not (params or {}).get("parent_category"):
        problems.append("included_in needs parent_codes or parent_category")
    if kind == "age_limit":
        lo, hi = (params or {}).get("min_age"), (params or {}).get("below_age")
        if lo is None and hi is None:
            problems.append("age_limit needs min_age or below_age")
        elif lo is not None and hi is not None and lo >= hi:
            problems.append(f"age_limit min_age {lo} must be below below_age {hi}")
    if kind == "diagnosis_required" and not (params or {}).get("value_set") and not (params or {}).get("diagnoses"):
        problems.append("diagnosis_required needs value_set or diagnoses")
    return problems


def validate_conditions(conditions: list) -> list[str]:
    problems = []
    for i, c in enumerate(conditions or []):
        if not isinstance(c, dict) or c.get("type") not in CONDITION_TYPES:
            problems.append(f"condition {i}: type must be one of {sorted(CONDITION_TYPES)} (got {c!r})")
            continue
        allowed = set(CONDITION_TYPES[c["type"]]) | {"type"}
        extra = set(c) - allowed
        if extra:
            problems.append(f"condition {i} ({c['type']}): unknown keys {sorted(extra)}")
        if not any(c.get(k) not in (None, "", []) for k in CONDITION_TYPES[c["type"]]):
            problems.append(f"condition {i} ({c['type']}): no value")
        if c["type"] == "age":
            for k in ("min_age", "below_age"):
                if c.get(k) is not None and not (isinstance(c[k], int) and 0 <= c[k] <= 125):
                    problems.append(f"condition {i} (age): {k} must be a whole number 0 to 125")
    return problems


def render_statement(kind: str, subject: dict, params: dict, conditions: list | None = None) -> str:
    """A plain-English sentence for a record (table records have no sentence of their own)."""
    codes = ", ".join(subject.get("codes") or []) or subject.get("category") or subject.get("term") or "the service"
    p = params or {}
    if kind == "not_covered":
        s = f"{codes} is not covered"
    elif kind == "prior_auth_rule":
        prog = {"all": "", "acute": " for acute care members", "ltc": " for ALTCS (long-term care) members"}.get(
            p.get("programs", "all"), "")
        s = (f"{codes} requires prior authorization{prog}" if p.get("requirement") == "required"
             else f"{codes} does not require prior authorization{prog}")
    elif kind == "pair_prohibited":
        partners = ", ".join(p.get("partners") or []) or p.get("partner_category") or "the partner services"
        where = {"member_day": " for the same member on the same day",
                 "member_provider_day": " by the same provider for the same member on the same day"}.get(
            p.get("scope"), " on the same day")
        s = f"{codes} may not be billed with {partners}{where}"
    elif kind == "included_in":
        parent = ", ".join(p.get("parent_codes") or []) or p.get("parent_category") or "the parent service"
        s = f"{codes} is included in {parent} and is not billed separately"
    elif kind == "units_limit":
        s = f"At most {p.get('max')} unit(s) of {codes} per {str(p.get('per', '')).replace('_', ' ')}"
        if p.get("combined"):
            s += " (combined across the codes)"
    elif kind == "frequency_limit":
        s = f"{codes} at most {p.get('max')} time(s) per {str(p.get('per', '')).replace('_', ' ')}"
    elif kind == "dollar_limit":
        s = f"{codes} limited to ${p.get('max_amount')} per {str(p.get('per', '')).replace('_', ' ')}"
    elif kind == "provider_type_rule":
        pts = ", ".join(p.get("provider_types") or [])
        s = (f"{codes} may be billed only by provider types {pts}" if p.get("mode") == "allowed"
             else f"{codes} may not be billed by provider types {pts}")
        if p.get("mode") == "allowed" and not p.get("complete_list"):
            s += " (list not stated as complete)"
    elif kind == "modifier_rule":
        mods = ", ".join(p.get("modifiers") or [])
        s = {"required": f"{codes} requires modifier {mods}", "allowed": f"{codes} allows modifiers {mods}",
             "not_allowed": f"{codes} may not carry modifier {mods}"}.get(p.get("mode"), f"{codes}: modifiers {mods}")
    elif kind == "pos_rule":
        pos = ", ".join(p.get("pos") or [])
        s = (f"{codes} is allowed in places of service {pos}" if p.get("mode") == "allowed"
             else f"{codes} is not allowed in places of service {pos}")
    elif kind == "telehealth_rule":
        if p.get("allowed"):
            s = f"{codes} may be delivered by telehealth"
            if p.get("modifiers"):
                s += f" with modifier {' or '.join(p['modifiers'])}"
            if p.get("pos"):
                s += f", originating site places of service {', '.join(p['pos'])}"
        else:
            s = f"{codes} may not be delivered by telehealth"
    elif kind == "claim_form_required":
        s = f"{codes} is billed on the {p.get('form')} form"
    elif kind == "diagnosis_required":
        s = f"{codes} requires a diagnosis from {p.get('value_set') or ', '.join(p.get('diagnoses') or [])}"
    elif kind == "age_limit":
        lo, hi = p.get("min_age"), p.get("below_age")
        rng = (f"aged {lo} through {hi - 1}" if lo is not None and hi is not None else
               f"aged {lo} and older" if lo is not None else f"under age {hi}")
        s = f"{codes} is limited to members {rng}"
    elif kind == "documentation_required":
        s = f"{codes}: {p.get('requirement')}"
    elif kind == "definition":
        s = f"{subject.get('term')}: {p.get('definition')}"
    elif kind == "cross_reference":
        s = f"{codes}: see {p.get('target')}"
    elif kind == "exception":
        s = f"Exception ({p.get('effect')}): {p.get('applies_to')}"
    elif kind == "obligation":
        s = p.get("duty") or codes
    else:
        s = p.get("description") or p.get("requirement") or codes
    cond = condition_text(conditions)
    return s.rstrip(".") + (f" {cond}" if cond else "") + "."


ROLE_WORDS = {"billing": "billing provider type", "rendering": "rendering provider type",
              "billing_or_rendering": "billing provider type (a group's rendering provider type)"}


def condition_text(conditions: list | None) -> str:
    """The conditions of a record in words ('when the billing provider type ... is 77; for members under age 21')."""
    parts = []
    for c in conditions or []:
        t = c.get("type")
        if t == "age":
            lo, hi = c.get("min_age"), c.get("below_age")
            parts.append(f"for members aged {lo} through {hi - 1}" if lo is not None and hi is not None else
                         f"for members aged {lo} and older" if lo is not None else f"for members under age {hi}")
        elif t in ("program", "delivery_system"):
            if c.get("include"):
                parts.append(f"for {', '.join(c['include'])}")
            if c.get("exclude"):
                parts.append(f"except {', '.join(c['exclude'])}")
        elif t == "place_of_service":
            if c.get("include"):
                parts.append(f"in places of service {', '.join(c['include'])}")
            if c.get("exclude"):
                parts.append(f"outside places of service {', '.join(c['exclude'])}")
        elif t == "modifier":
            if c.get("present"):
                parts.append(f"with modifier {' or '.join(c['present'])}")
            if c.get("absent"):
                parts.append(f"without modifier {', '.join(c['absent'])}")
        elif t == "diagnosis":
            parts.append(f"with a diagnosis from {c.get('value_set') or ', '.join(c.get('codes') or [])}")
        elif t == "provider_type":
            who = ROLE_WORDS.get(c.get("role"), "provider type")
            if c.get("include"):
                parts.append(f"when the {who} is {', '.join(c['include'])}")
            if c.get("exclude"):
                parts.append(f"unless the {who} is {', '.join(c['exclude'])}")
        elif t == "claim_form":
            parts.append(f"on {c.get('form')} claims")
        elif c.get("text"):
            parts.append(f"({c['text']})")
    return "; ".join(parts)
