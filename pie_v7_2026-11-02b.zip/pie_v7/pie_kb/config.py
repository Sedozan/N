"""Every name, path and switch PIE v7 uses, in one place.

Environment variables override the defaults: PIE_<NAME> (for example PIE_SCHEMA=policy_kb_dev).
Nothing else in the package hard-codes a table name, a folder or a claims column.
"""
from __future__ import annotations

import os

from . import __version__

PIE_VERSION = __version__


def _env(name: str, default: str) -> str:
    return os.environ.get(f"PIE_{name}", default)


# ---------------------------------------------------------------- folders
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PACKAGE_DIR)                      # holds pie_kb/, notebooks/, tests/
REFERENCE_DIR = os.path.join(PACKAGE_DIR, "reference")      # the registry and the readings people sign
DATA_DIR = _env("DATA_DIR", os.path.join(ROOT_DIR, "data"))
INBOX_DIR = os.path.join(DATA_DIR, "inbox")                 # drop files here (any name, any subfolder)
ARCHIVE_DIR = os.path.join(DATA_DIR, "archive")             # one immutable copy per file version
QUARANTINE_DIR = os.path.join(DATA_DIR, "quarantine")       # files no registry row recognises
STAGE_DIR = os.path.join(DATA_DIR, "stage")                 # what the GPU notebook reads (no Delta there)
RUNS_DIR = os.path.join(DATA_DIR, "runs")                   # one folder per extraction run
REVIEW_DIR = os.path.join(DATA_DIR, "review")               # review workbooks out and back
REVIEW_OUT_DIR = os.path.join(REVIEW_DIR, "out")            # exports (notebook 07)
REVIEW_IN_DIR = os.path.join(REVIEW_DIR, "in")              # filled workbooks (read by v01)

# ---------------------------------------------------------------- tables
CATALOG = _env("CATALOG", "main")
SCHEMA = _env("SCHEMA", "policy_kb")
TABLE_PREFIX = "kb_"
# "delta" on Databricks; "parquet" writes local files under LOCAL_STORE_DIR (tests, local runs)
STORE = _env("STORE", "delta")
# the Spark table format: "delta" on Databricks; the local Spark end-to-end test sets "parquet" (no Delta jars there)
TABLE_FORMAT = _env("TABLE_FORMAT", "delta")
LOCAL_STORE_DIR = _env("LOCAL_STORE_DIR", os.path.join(DATA_DIR, "local_tables"))


def table(name: str) -> str:
    """Full name of a knowledge base table, e.g. table('records') -> main.policy_kb.kb_records."""
    return f"{CATALOG}.{SCHEMA}.{TABLE_PREFIX}{name}"


# ---------------------------------------------------------------- scope
DOMAIN = "BH"
DELIVERY_SYSTEMS_IN_SCOPE = ("FFS",)          # SB 2026-11-01: FFS first; managed care sources are deferred
CLAIM_TYPE = "professional"                   # the claim-type adapter used for execution classes

# ---------------------------------------------------------------- claims (read only, later releases)
CLAIMS_TABLE = _env("CLAIMS_TABLE", "main.prod_input.all_data_C_A")

# ---------------------------------------------------------------- fetching
FETCH_TIMEOUT_SECONDS = 90
FETCH_USER_AGENT = f"Mozilla/5.0 (compatible; PIE/{PIE_VERSION}; policy research)"
MAX_FILE_BYTES = 150 * 1024 * 1024

# ---------------------------------------------------------------- narrative extraction
HF_MODEL = _env("HF_MODEL", "openai/gpt-oss-120b")
# The token file SB's summarization notebook already uses; empty = already logged in.
HF_TOKEN_PATH = _env("HF_TOKEN_PATH",
                     "/Workspace/Users/sedo.senou@azahcccs.gov/Projects/all_projects_predictions/data/hf_token.txt")
REASONING = _env("REASONING", "medium")       # v6.3 A/B on chapter 19: medium found more rules than low
TOKEN_BUDGET = {"low": 3000, "medium": 5000, "high": 8000}
RETRY_FACTOR = 1.8                            # one retry at this multiple when the answer runs out of budget
LAST_RESORT_FACTOR = 3.0                      # a piece that cannot be split gets one call at this multiple
MAX_SPLIT_DEPTH = 4                           # a section is split in halves at most this many times
LIST_TOKEN_MIN_CODES = 4                      # a run of at least this many codes becomes a list token [L1]
CACHE_FLUSH_EVERY = 20                        # model calls between cache writes in the GPU notebook
EXTRACT_MAX_CHARS = int(_env("EXTRACT_MAX_CHARS", "6000"))   # a longer section goes to the model in pieces
EXTRACT_BATCH = int(_env("EXTRACT_BATCH", "1"))              # pieces per generate() call or parallel requests
SERVING_ENDPOINT = _env("SERVING_ENDPOINT", "databricks-gpt-oss-120b")   # the ServingBackend's endpoint
MAX_CONSECUTIVE_FAILURES = 5                  # a run stops after this many model calls in a row fail (GPU trouble)
MIN_MODEL_WORDS = 8                           # a section with fewer words is not sent to the model
# v6.3 on chapter 19 (Serverless GPU, transformers, one piece at a time): 2 h for 46 sections at low, 4 h 47 min at
# medium; used only for the plan's estimate, replaced by the measured rate once a run has made calls
EST_SECONDS_PER_PIECE = {"low": 156, "medium": 374, "high": 600}
