"""Hashes and content-derived ids. Every id in PIE is derived from content, so the same input always gets the same id."""
from __future__ import annotations

import hashlib
import json
from typing import Any

from .text import clean


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical(obj: Any) -> str:
    """One JSON form per value: sorted keys, no spaces, sets and tuples as sorted lists, floats like 4.0 as 4."""
    return json.dumps(_canon(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _canon(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): _canon(v) for k, v in obj.items() if v is not None and v != [] and v != {} and v != ""}
    if isinstance(obj, (set, frozenset)):
        return sorted((_canon(v) for v in obj), key=lambda v: json.dumps(v, sort_keys=True, default=str))
    if isinstance(obj, (list, tuple)):
        return [_canon(v) for v in obj]
    if isinstance(obj, float) and obj.is_integer():
        return int(obj)
    if isinstance(obj, str):
        return clean(obj)
    return obj


def short_hash(*parts: Any, n: int = 16) -> str:
    """First n hex characters of the sha256 of the canonical form of parts."""
    return sha256_text(canonical(list(parts)))[:n]


def text_hash(text: str) -> str:
    """Hash of a text after glyph and whitespace normalisation (a re-typeset PDF with the same words hashes the same)."""
    return sha256_text(clean(text))[:16]
