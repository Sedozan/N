"""Reading and writing the knowledge base tables, with every column declared once.

Two back ends with one interface:
  SparkStore    Delta tables main.policy_kb.kb_<name> (Databricks)
  LocalStore    Parquet files under LOCAL_STORE_DIR (tests and local runs)

Dicts and lists are stored as JSON text (columns typed "json"), so the same row round-trips through either store.
`replace_where` deletes the rows of some keys and appends their new rows: re-running a stage on a version replaces
that version's rows and leaves every other version untouched.
"""
from __future__ import annotations

import json
import os
from typing import Iterable

from .. import config

S, L, F, B, J = "string", "long", "double", "boolean", "json"

SCHEMAS: dict[str, list[tuple[str, str]]] = {
    "source_registry": [("source_id", S), ("document_key", S), ("doc_id", S), ("title", S), ("family", S),
                        ("method", S), ("parser", S), ("authority_level", L), ("binding", S), ("jurisdiction", S),
                        ("delivery_systems", J), ("priority", S), ("status", S), ("cadence", S),
                        ("version_rule", S), ("url", S), ("listing_url", S), ("notes", S), ("synced_at", S)],
    "source_versions": [("source_version_id", S), ("source_id", S), ("document_key", S), ("version_date", S),
                        ("version_label", S), ("version_basis", S), ("version_evidence", S), ("period_end", S),
                        ("sha256", S), ("bytes", L), ("file_kind", S), ("archive_path", S), ("original_name", S),
                        ("origin", S), ("origin_url", S), ("http_last_modified", S), ("first_seen_at", S),
                        ("status", S), ("duplicate_of", S), ("notes", S)],
    "processing_ledger": [("source_version_id", S), ("stage", S), ("config_id", S), ("run_id", S), ("status", S),
                          ("started_at", S), ("finished_at", S), ("counts", S), ("message", S)],
    "sections": [("section_id", S), ("section_key", S), ("source_version_id", S), ("source_id", S),
                 ("document_key", S), ("path", J), ("path_text", S), ("heading", S), ("level", L),
                 ("page_start", L), ("page_end", L), ("text", S), ("text_hash", S), ("n_chars", L),
                 ("blocks", J), ("codes", J), ("signal", L), ("role", S), ("applicability", J), ("defined_terms", J),
                 ("stated_dates", J), ("ordinal", L)],
    "table_rows": [("source_version_id", S), ("source_id", S), ("spec", S), ("row_key", S), ("locator", S),
                   ("data", J)],
    "value_sets": [("value_set_id", S), ("source_version_id", S), ("code", S), ("code_system", S),
                   ("description", S), ("attributes", J), ("effective_start", S), ("effective_end", S)],
    "readings": [("spec", S), ("reading_id", S), ("reading", S), ("evidence", S), ("status", S), ("reviewer", S),
                 ("reviewed_at", S), ("binds", S)],
    "records": [("record_id", S), ("record_key", S), ("content_sha", S), ("kind", S), ("subject", J),
                ("params", J), ("conditions", J), ("exceptions", J), ("applicability", J), ("statement", S),
                ("citation", J), ("source_id", S), ("source_version_id", S), ("effective_start", S),
                ("effective_end", S), ("window_basis", S), ("origin", S), ("authority_level", L),
                ("jurisdiction", S), ("binding", S), ("flags", J), ("confidence", F), ("extraction", J),
                ("status", S), ("review", J), ("execution_class", S), ("execution_reasons", J)],
    "proposals": [("run_id", S), ("source_version_id", S), ("section_id", S), ("proposal_index", L),
                  ("origin", S), ("kept", B), ("drop_reason", S), ("record_id", S), ("raw", J), ("grounding", J)],
    "extraction_outcomes": [("run_id", S), ("source_version_id", S), ("section_id", S), ("outcome", S),
                            ("detail", S), ("n_proposals", L), ("n_records", L), ("seconds", F)],
    "review_log": [("decision_id", S), ("record_id", S), ("decision", S), ("reviewer", S), ("decided_at", S),
                   ("note", S), ("correction", J), ("content_sha_reviewed", S), ("source_version_id", S),
                   ("applied", S), ("workbook", S)],
    "conflicts": [("conflict_id", S), ("build_id", S), ("record_a", S), ("record_b", S), ("relationship", S),
                  ("codes", J), ("window_start", S), ("window_end", S), ("suggested_prevailing", S),
                  ("basis", S), ("precedence_id", S), ("detail", S), ("status", S)],
    "record_diffs": [("build_id", S), ("source_id", S), ("document_key", S), ("from_version", S),
                     ("to_version", S), ("change", S), ("record_key", S), ("record_id_from", S),
                     ("record_id_to", S), ("section_key", S), ("detail", S)],
    "code_index": [("build_id", S), ("code", S), ("record_id", S), ("kind", S), ("role", S), ("source_id", S),
                   ("effective_start", S), ("effective_end", S), ("status", S), ("execution_class", S)],
    "records_history": [("build_id", S), ("record_id", S), ("record_key", S), ("content_sha", S), ("kind", S),
                        ("status", S), ("execution_class", S), ("executable_now", B), ("statement", S),
                        ("citation", J), ("effective_start", S), ("effective_end", S), ("review", J)],
    "build_log": [("build_id", S), ("built_at", S), ("pie_version", S), ("package_sha", S), ("counts", J),
                  ("sources", J), ("warnings", J)],
}


def _encode(rows: Iterable[dict], schema: list[tuple[str, str]]) -> list[dict]:
    out = []
    for r in rows:
        row = {}
        for col, typ in schema:
            v = r.get(col)
            if typ == J:
                row[col] = None if v is None else (v if isinstance(v, str) else json.dumps(v, sort_keys=True,
                                                                                          default=str))
            elif typ == L:
                row[col] = None if v in (None, "") else int(v)
            elif typ == F:
                row[col] = None if v in (None, "") else float(v)
            elif typ == B:
                row[col] = None if v is None else bool(v)
            else:
                row[col] = None if v is None else str(v)
        out.append(row)
    return out


def decode(rows: list[dict], name: str) -> list[dict]:
    """JSON columns back to Python values."""
    jcols = [c for c, t in SCHEMAS[name] if t == J]
    out = []
    for r in rows:
        r = dict(r)
        for c in jcols:
            v = r.get(c)
            if isinstance(v, str) and v:
                try:
                    r[c] = json.loads(v)
                except ValueError:
                    pass
        out.append(r)
    return out


class LocalStore:
    """Parquet files under a folder; the same interface as SparkStore."""

    def __init__(self, folder: str | None = None):
        self.folder = folder or config.LOCAL_STORE_DIR
        os.makedirs(self.folder, exist_ok=True)

    def _path(self, name: str) -> str:
        return os.path.join(self.folder, f"{config.TABLE_PREFIX}{name}.parquet")

    def exists(self, name: str) -> bool:
        return os.path.exists(self._path(name))

    def read(self, name: str) -> list[dict]:
        import pandas as pd
        if not self.exists(name):
            return []
        df = pd.read_parquet(self._path(name))
        df = df.astype(object).where(df.notna(), None)
        return decode(df.to_dict("records"), name)

    def _write_all(self, name: str, rows: list[dict]) -> None:
        import pandas as pd
        import pyarrow as pa
        schema = SCHEMAS[name]
        pa_types = {S: pa.string(), J: pa.string(), L: pa.int64(), F: pa.float64(), B: pa.bool_()}
        enc = _encode(rows, schema)
        table = pa.Table.from_pylist(enc, schema=pa.schema([(c, pa_types[t]) for c, t in schema]))
        import pyarrow.parquet as pq
        pq.write_table(table, self._path(name))
        _ = pd  # pandas is the reader's dependency

    def write(self, name: str, rows: list[dict], mode: str = "overwrite") -> None:
        if mode == "append":
            rows = self._raw(name) + list(rows)
            self._write_all(name, rows)
            return
        self._write_all(name, list(rows))

    def _raw(self, name: str) -> list[dict]:
        """Rows as stored (JSON still text), for appends."""
        import pandas as pd
        if not self.exists(name):
            return []
        df = pd.read_parquet(self._path(name))
        return df.astype(object).where(df.notna(), None).to_dict("records")

    def replace_where(self, name: str, column: str, values: Iterable, rows: list[dict],
                      where: dict | None = None) -> None:
        """Delete the rows whose `column` is in `values` (and, with `where`, whose other columns equal its values),
        then append `rows`."""
        values, where = set(values), where or {}
        keep = [r for r in self._raw(name)
                if not (r.get(column) in values and all(r.get(k) == v for k, v in where.items()))]
        self._write_all(name, keep + _encode(rows, SCHEMAS[name]))


class SparkStore:
    """Delta tables through the active Spark session (Databricks)."""

    def __init__(self, spark):
        self.spark = spark

    @staticmethod
    def _spark_schema(name: str):
        from pyspark.sql import types as T
        m = {S: T.StringType(), J: T.StringType(), L: T.LongType(), F: T.DoubleType(), B: T.BooleanType()}
        return T.StructType([T.StructField(c, m[t], True) for c, t in SCHEMAS[name]])

    def exists(self, name: str) -> bool:
        return self.spark.catalog.tableExists(config.table(name))

    def read(self, name: str) -> list[dict]:
        if not self.exists(name):
            return []
        cols = [c for c, _ in SCHEMAS[name]]
        df = self.spark.table(config.table(name))
        rows = [r.asDict() for r in df.select(*[c for c in cols if c in df.columns]).collect()]
        return decode(rows, name)

    def _df(self, name: str, rows: list[dict]):
        return self.spark.createDataFrame(_encode(rows, SCHEMAS[name]), schema=self._spark_schema(name))

    def write(self, name: str, rows: list[dict], mode: str = "overwrite") -> None:
        df = self._df(name, list(rows))
        w = df.write.format(config.TABLE_FORMAT).mode(mode)
        if config.TABLE_FORMAT == "delta" and mode == "overwrite":
            w = w.option("overwriteSchema", "true")
        w.saveAsTable(config.table(name))

    def replace_where(self, name: str, column: str, values: Iterable, rows: list[dict],
                      where: dict | None = None) -> None:
        values, where = sorted({str(v) for v in values}), where or {}
        if config.TABLE_FORMAT != "delta":
            # no row deletes outside Delta (local Spark tests): read, filter, rewrite the whole table
            keep = [r for r in self.read(name) if not (str(r.get(column)) in set(values)
                                                        and all(r.get(k) == v for k, v in where.items()))]
            self.write(name, keep + list(rows), mode="overwrite")
            return
        if self.exists(name) and values:
            from pyspark.sql import functions as fn
            from delta.tables import DeltaTable
            cond = fn.col(column).isin(values)
            for k, v in where.items():
                cond = cond & (fn.col(k) == fn.lit(v))
            DeltaTable.forName(self.spark, config.table(name)).delete(cond)
        if rows:
            self.write(name, rows, mode="append")
        elif not self.exists(name):
            self.write(name, [], mode="overwrite")


def open_store(spark=None):
    """SparkStore on Databricks (config.STORE == 'delta'), LocalStore otherwise."""
    if config.STORE == "parquet" or spark is None:
        return LocalStore()
    return SparkStore(spark)
