# Databricks notebook source
# MAGIC %md
# MAGIC # d02 · Detection: approved rules run over paid claim lines (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Every approved record of the latest build (07) judges the claim lines whose service date falls in its window, so
# MAGIC each line is judged by the edition in force on its date. Run 07 first; set the dates below; run all.
# MAGIC
# MAGIC **How to read a finding.**
# MAGIC - **violation**: the record is executable on that date (its edition is held, nothing in it needs a person).
# MAGIC - **lead**: a person confirms first. The reasons say what: an exception (Same Day note 2: an approved medical
# MAGIC   necessity exception), a parameter the source leaves open, a presumed date (the edition in force then is not
# MAGIC   held), a "may", a rule for FFS lines when FFS_WHERE is not set, or a telehealth line whose only issue is
# MAGIC   place of service 02 or 10 (check_type telehealth_pos_code: AHCCCS uses them only when another payer is
# MAGIC   primary, so it is a coding question, not proof of a site the code set forbids).
# MAGIC - **check_type** says what was checked: the kind, or for telehealth the modifier, the site or the POS 02/10 code.
# MAGIC - Dollars are the amounts paid on the flagged lines, each line counted once in the totals. They are not an
# MAGIC   overpayment estimate: a pair finding puts one line at issue, a limit finding a group of lines.
# MAGIC
# MAGIC **What does not run** (section 1): a record with a condition the claim cannot show (setting, member attribute,
# MAGIC service context), a limit in hours (it needs the code's billing unit), a period other than a day or a line, a
# MAGIC category no code set resolves, a record in an open conflict. Nothing is guessed.
# MAGIC
# MAGIC Lines: one row per claim line (ClaimID, LN_NO; rows of a line, such as an original and its reversal, are summed),
# MAGIC professional form A, net units and net paid above zero. The claims write -1 in an empty modifier slot. A line that
# MAGIC covers several days (END_DATE after the begin date) is spread evenly over its days for the limits per day, and
# MAGIC pairs compare the days lines cover. Without END_DATE every line is one day (14 nights of lodging on one line
# MAGIC would then read as one day: set it).
# MAGIC
# MAGIC Every run is logged in kb_detect_runs (settings, counts, the full SQL text and the code version), and the
# MAGIC investigator tables flagged_lines (one row per flagged line, with priority) and line_issues (every issue on a
# MAGIC line, with the policy words) are rebuilt for Power BI from the latest run.
# MAGIC
# MAGIC Prior authorization: a units or frequency finding on a line that carries a PA number (EVENT_PA_NO) is a lead
# MAGIC (the units above the limit may be authorized). A missing number proves nothing: AHCCCS finds a PA by member,
# MAGIC provider, dates, code and units without it (Claims Clues, May 2023), and the field is filled on 8% of lines.

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import uuid
from datetime import datetime, timezone

import pandas as pd

from pie_kb import bi as BI
from pie_kb import detect as DT
from pie_kb.io.store import open_store

CLAIMS = "main.prod_input.all_data_C_A"
SINCE = "2026-04-01"            # service dates from (ISO): start with recent claims (the state's focus), then
                                # widen once the run time is known; the knowledge base holds editions from 10/1/2024
UNTIL = None                    # service dates to (ISO); None: the last date in the claims
FORMS = ("A",)                  # FORM_TYP: A = professional (CMS-1500)
WHERE = "CLM_TYP = 'F'"         # extra filter on the claims table: CLM_TYP F = FFS claims, M = managed care
                                # encounters, Q = Medicare-only (crossover); meanings inferred, to confirm with the
                                # data owner. Encounters: WHERE = "CLM_TYP = 'M'" and FFS_WHERE = "false"
FFS_WHERE = "true"              # which lines are FFS: "true" when WHERE keeps FFS claims only; None: rules written for
                                # FFS only (Chapter 19) run on every line, as leads
END_DATE = "Svc_End_Dt"         # service end date column; None (or a column the table lacks): every line is one day
PA_NUMBER = "EVENT_PA_NO"       # prior authorization number column; None (or a column the table lacks): not read
WRITE = True                    # append the findings to kb_findings and the run to kb_detect_runs
PUBLISH_BI = True               # rebuild the investigator tables flagged_lines and line_issues (07: policy_rules)
TOP = 25

store = open_store(spark)  # noqa: F821
current = store.read("records_current")
build_id = current[0]["build_id"] if current else None
open_conflicts = {x for c in store.read("conflicts") if c.get("build_id") == build_id
                  and not str(c.get("status") or "").startswith("resolved") for x in (c["record_a"], c["record_b"])}
rules, skipped = DT.prepare(current, open_conflicts=open_conflicts, ffs_known=FFS_WHERE is not None)
run_id = f"detect-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:4]}"
claim_cols = set(spark.table(CLAIMS).columns)  # noqa: F821
end_col = END_DATE if END_DATE and END_DATE in claim_cols else None
pa_col = PA_NUMBER if PA_NUMBER and PA_NUMBER in claim_cols else None
notes = "; ".join(x for x in (
    "" if end_col or not END_DATE else f"{END_DATE} is not a column of {CLAIMS}: every line read as one day",
    "" if pa_col or not PA_NUMBER else f"{PA_NUMBER} is not a column of {CLAIMS}: no PA number read") if x)
print(f"PIE {config.PIE_VERSION} | {run_id} | build {build_id} | detection code {DT.code_sha()} | "
      f"{len({r['part_of'] for r in rules}):,} records run ({len(rules):,} record-code rows); "
      f"{len({s['part_of'] for s in skipped}):,} approved records do not run")
if notes:
    print("NOTE:", notes)

# COMMAND ----------

# MAGIC %md ## 1 · Which approved records run, and why the others do not

# COMMAND ----------

display(pd.DataFrame(DT.coverage(rules, skipped)))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 2 · Claim lines read

# COMMAND ----------

lines_sql = DT.lines_sql(CLAIMS, where=WHERE, forms=FORMS, since=SINCE, until=UNTIL, ffs_where=FFS_WHERE,
                         columns={"dos_end": end_col, "pa": pa_col})
spark.sql(lines_sql).createOrReplaceTempView("pie_lines")  # noqa: F821
line_stats = spark.sql("""SELECT count(*) AS lines_read, count(DISTINCT member) AS members, min(dos) AS first_dos,
                                 max(dos) AS last_dos, count_if(days > 1) AS multi_day_lines,
                                 count_if(pa IS NOT NULL) AS lines_with_pa_number,
                                 round(sum(paid), 2) AS paid, count_if(is_ffs) AS ffs_lines
                          FROM pie_lines""").collect()[0].asDict()  # noqa: F821
display(pd.DataFrame([line_stats]))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 3 · Run

# COMMAND ----------

findings = (DT.run(spark, rules).selectExpr(f"'{run_id}' AS run_id", f"'{build_id}' AS build_id", "*")  # noqa: F821
            .cache())
findings.createOrReplaceTempView("pie_findings")
found = spark.sql("""
    SELECT (SELECT count(*) FROM pie_findings) AS findings, count(*) AS lines_flagged,
           count_if(tier = 'violation') AS violation_lines, count_if(tier = 'lead') AS lead_lines,
           round(sum(paid), 2) AS paid_on_flagged_lines
    FROM (SELECT line_id, first(paid) AS paid, max(tier) AS tier FROM pie_findings GROUP BY line_id)""").collect()[0].asDict()  # noqa: F821
print(f"{found['findings']:,} findings on {found['lines_flagged']:,} lines")
if WRITE:
    if found["findings"]:
        findings.write.mode("append").option("mergeSchema", "true").saveAsTable(config.table("findings"))
        print("appended to", config.table("findings"))
    settings = {"claims_table": CLAIMS, "where_sql": WHERE, "ffs_where": FFS_WHERE, "forms": FORMS, "since": SINCE,
                "until": UNTIL, "end_date_column": end_col}
    store.replace_where("detect_runs", "run_id", [run_id],
                        [DT.run_row(run_id, build_id, settings, rules, skipped, line_stats, found, lines_sql, True,
                                    notes)])
    print("run logged in", config.table("detect_runs"), "(settings, counts, SQL text, code version)")
    if PUBLISH_BI:
        try:
            out = BI.publish_findings(spark)  # noqa: F821
            print("investigator tables:", out["counts"], *out["warnings"], sep="\n  ")
        except Exception as e:  # noqa: BLE001  (the findings and the run log are saved already)
            print("investigator tables NOT rebuilt:", str(e).splitlines()[0][:300],
                  "\n  (CREATE SCHEMA refused? set PIE_BI_SCHEMA in _settings to a schema you can write)")

# COMMAND ----------

# MAGIC %md ## 4 · Summary by source, kind and tier (a line flagged by two rules of one row is counted once)

# COMMAND ----------

display(spark.sql("""
    SELECT source_id, check_type, tier, sum(findings) AS findings, count(*) AS lines,
           count(DISTINCT member) AS members, count(DISTINCT bprov) AS billing_providers,
           round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT split(version, '@')[0] AS source_id, check_type, tier, line_id, first(member) AS member,
                 first(bprov) AS bprov, first(paid) AS paid, count(*) AS findings
          FROM pie_findings GROUP BY 1, 2, 3, 4)
    GROUP BY 1, 2, 3 ORDER BY paid_on_lines DESC"""))  # noqa: F821
display(spark.sql("""
    SELECT tier, count(*) AS lines, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT line_id, first(paid) AS paid, max(tier) AS tier FROM pie_findings GROUP BY line_id)
    GROUP BY tier"""))  # noqa: F821
display(spark.sql("""
    SELECT count(*) AS lines_flagged, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT line_id, first(paid) AS paid FROM pie_findings GROUP BY line_id)"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 5 · The rules that flag the most dollars

# COMMAND ----------

display(spark.sql(f"""
    SELECT part_of AS record, kind, tier, first(statement) AS statement, first(source) AS source,
           first(locator) AS locator, count(DISTINCT line_id) AS lines, count(DISTINCT bprov) AS billing_providers,
           round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT DISTINCT part_of, kind, tier, statement, source, locator, line_id, bprov, paid FROM pie_findings)
    GROUP BY part_of, kind, tier ORDER BY paid_on_lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 6 · Billing providers with the most flagged dollars (each line once)

# COMMAND ----------

display(spark.sql(f"""
    SELECT bprov, count(DISTINCT line_id) AS lines, count(DISTINCT member) AS members,
           count(DISTINCT CASE WHEN tier = 'violation' THEN line_id END) AS violation_lines,
           count(DISTINCT part_of) AS rules, round(sum(paid), 2) AS paid_on_lines
    FROM (SELECT DISTINCT bprov, line_id, member, tier, part_of, paid FROM pie_findings)
    GROUP BY bprov ORDER BY paid_on_lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 7 · Findings with their evidence and the policy words (violations first)

# COMMAND ----------

display(spark.sql(f"""
    SELECT tier, check_type, code, dos, dos_end, member, bprov, sprov, units, paid, evidence, statement, source,
           version, locator, quote, reasons, line_id, record_id
    FROM pie_findings ORDER BY tier DESC, paid DESC LIMIT 500"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 8 · The full SQL of this run (also in kb_detect_runs)

# COMMAND ----------

print(lines_sql, *DT.sql_text().values(), sep="\n\n-- ----\n")
