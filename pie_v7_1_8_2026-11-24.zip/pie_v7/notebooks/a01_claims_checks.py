# Databricks notebook source
# MAGIC %md
# MAGIC # a01 · Claims checks the open readings wait on (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Read only: it writes nothing. Run it after 03 (it needs kb_table_rows) and read the last cell.
# MAGIC
# MAGIC 1. **Formats.** Do the claim values look like B2's values (provider type "02" vs "2", POS "11" vs "11.0")? If the
# MAGIC    match rate in cell 2 is low, fix the normalisation before trusting anything below.
# MAGIC 2. **Fill rates.** What the build assumes about each claim field is in pie_kb/reference/claim_fields.csv (from
# MAGIC    the runs of 2026-11-08 and 11-09, service dates 4/1 to 9/25/2026: POS and diagnosis usable; EVENT_PA_NO too
# MAGIC    sparse to show a missing authorization, measured on FFS and managed care lines together). The build applies
# MAGIC    them to every date from 10/1/2024, so this cell shows them by delivery system (DELIVERY) and quarter from
# MAGIC    CLAIMS_FROM: update that file if a quarter differs, and from the FFS lines for EVENT_PA_NO.
# MAGIC 3. **B2-MOD, B2-POS, B2-PT.** How often do paid lines on B2 codes carry a modifier, a place of service or a
# MAGIC    provider type B2 does not list for the code? This is what AHCCCS's own claim edits let through, the evidence
# MAGIC    for whether B2's lists can be read as complete (a line outside them is a violation) or only as a reference.
# MAGIC
# MAGIC Each claim line is checked against the B2 version in force on its service date (a version runs from its own
# MAGIC date to the day before the next one held), from the first B2 version on; section 1b shows the results by
# MAGIC version.
# MAGIC The claims table writes -1 in empty modifier slots: a modifier counts only when it is two letters or digits,
# MAGIC and -1 or zeros count as empty in EVENT_PA_NO and the diagnosis columns.

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

CLAIMS = "main.prod_input.all_data_C_A"
SINCE = None                    # service dates from here on (ISO); None: the first B2 version's date
CLAIMS_FROM = "2024-10-01"      # fill rates: the whole claim window, by quarter
DELIVERY = "CLM_TYP"            # the column that marks FFS versus managed care lines: F = FFS claims, M = managed care
                                # encounters, Q = Medicare-only (crossover); inferred 11/23/2026, to confirm with the
                                # data owner (FORM_TYP_DESC is the claim form, not the delivery system)
FORMS = ("A",)                  # FORM_TYP: A = professional (CMS-1500)
WHERE = "1 = 1"                 # extra filter on the claims table, e.g. "PMT_AMT > 0"
TOP = 25


def t(name: str) -> str:
    return config.table(name)


def pt(col: str) -> str:        # provider type: B2 writes two characters ("02", "C2")
    return (f"CASE WHEN trim(CAST({col} AS STRING)) RLIKE '^[0-9]$' THEN lpad(trim(CAST({col} AS STRING)), 2, '0') "
            f"ELSE upper(trim(CAST({col} AS STRING))) END")


def pos(col: str) -> str:       # place of service: two digits, no decimal tail
    return f"lpad(regexp_replace(trim(CAST({col} AS STRING)), '\\\\.0+$', ''), 2, '0')"


def mod(col: str) -> str:       # a modifier is two letters or digits; the claims write -1 for an empty slot
    v = f"upper(trim(CAST({col} AS STRING)))"
    return f"CASE WHEN {v} RLIKE '^[A-Z0-9]{{2}}$' THEN {v} END"


def blank(col: str) -> str:     # the value, or NULL when empty, -1 or all zeros
    v = f"trim(CAST({col} AS STRING))"
    return f"CASE WHEN {v} IS NULL OR {v} IN ('', '-1') OR {v} RLIKE '^0+$' THEN NULL ELSE {v} END"


def newest(spec: str) -> str:
    row = spark.sql(f"""SELECT r.source_version_id FROM (SELECT DISTINCT source_version_id FROM {t('table_rows')}
                        WHERE spec = '{spec}') r JOIN {t('source_versions')} v USING (source_version_id)
                        ORDER BY v.version_date DESC LIMIT 1""").collect()  # noqa: F821
    if not row:
        raise ValueError(f"no {spec} rows in {t('table_rows')}: run 03 first")
    return row[0][0]


PA_VERSION = newest("pa_guidelines")
newest("b2")                    # fails early when no B2 version has been read
forms = ", ".join(f"'{f}'" for f in FORMS)
spark.sql(f"""
    CREATE OR REPLACE TEMP VIEW b2_versions AS
    SELECT source_version_id, v_start, date_sub(lead(v_start) OVER (ORDER BY v_start), 1) AS v_end
    FROM (SELECT DISTINCT r.source_version_id, to_date(v.version_date) AS v_start
          FROM {t('table_rows')} r JOIN {t('source_versions')} v USING (source_version_id)
          WHERE r.spec = 'b2' AND v.status = 'active')""")  # noqa: F821
display(spark.sql("SELECT * FROM b2_versions ORDER BY v_start"))  # noqa: F821
SINCE = SINCE or spark.sql("SELECT min(v_start) FROM b2_versions").collect()[0][0].isoformat()  # noqa: F821
spark.sql(f"""
    CREATE OR REPLACE TEMP VIEW b2_rows AS
    SELECT source_version_id, d.code, d.provider_type, d.modifiers, d.places_of_service FROM (
      SELECT source_version_id, from_json(data, 'struct<code:string, provider_type:string, modifiers:array<string>,
                                                          places_of_service:array<string>>') AS d
      FROM {t('table_rows')} WHERE spec = 'b2')""")  # noqa: F821
spark.sql("""
    CREATE OR REPLACE TEMP VIEW b2_code AS
    SELECT source_version_id, code, array_distinct(flatten(collect_list(modifiers))) AS mods,
           array_distinct(flatten(collect_list(places_of_service))) AS poss, collect_set(provider_type) AS types,
           collect_list(struct(provider_type, modifiers, places_of_service)) AS by_type
    FROM b2_rows GROUP BY source_version_id, code""")  # noqa: F821
spark.sql(f"""
    CREATE OR REPLACE TEMP VIEW lines AS
    SELECT upper(trim(CAST(PROC_CD AS STRING))) AS code, {pt('SProv_Type')} AS rtype, {pt('BProv_Type')} AS btype,
           {pos('POS_CODE')} AS pos,
           filter(array({mod('PROC_MOD_1')}, {mod('PROC_MOD_2')}, {mod('PROC_MOD_3')}, {mod('PROC_MOD_4')}),
                  x -> x IS NOT NULL) AS mods,
           {blank('EVENT_PA_NO')} AS pa_no, CAST(PMT_AMT AS DOUBLE) AS paid,
           CAST(BProv_ID AS STRING) AS bprov, to_date(Svc_Begin_Dt) AS dos,
           coalesce(CAST({DELIVERY} AS STRING), '(blank)') AS delivery
    FROM {CLAIMS}
    WHERE CAST(FORM_TYP AS STRING) IN ({forms}) AND to_date(Svc_Begin_Dt) >= DATE'{SINCE}' AND ({WHERE})""")  # noqa: F821
spark.sql("""
    CREATE OR REPLACE TEMP VIEW b2_lines AS
    SELECT l.*, v.source_version_id AS b2_version, b.mods AS b2_mods, b.poss AS b2_poss, b.types AS b2_types,
           filter(b.by_type, r -> r.provider_type IN (l.rtype, l.btype)) AS matched
    FROM lines l
    JOIN b2_versions v ON l.dos >= v.v_start AND (v.v_end IS NULL OR l.dos <= v.v_end)
    JOIN b2_code b ON b.source_version_id = v.source_version_id AND b.code = l.code""")  # noqa: F821
n_lines = spark.sql("SELECT count(*) FROM lines").collect()[0][0]  # noqa: F821
print(f"B2 by service date | PA {PA_VERSION} | {n_lines:,} claim lines since {SINCE} on forms {FORMS}")
if n_lines == 0:
    print("No lines: check SINCE, FORMS, WHERE and whether Svc_Begin_Dt reads as a date (to_date)")

# COMMAND ----------

# MAGIC %md ## 0 · Lines by form and delivery system (DELIVERY) from CLAIMS_FROM, all forms
# MAGIC
# MAGIC The values of DELIVERY that mean FFS and managed care: the fill rates and the PA check below are split by them.

# COMMAND ----------

display(spark.sql(f"""
    SELECT CAST(FORM_TYP AS STRING) AS form, coalesce(CAST({DELIVERY} AS STRING), '(blank)') AS delivery,
           count(*) AS lines,
           min(to_date(Svc_Begin_Dt)) AS first_service_date, max(to_date(Svc_Begin_Dt)) AS last_service_date
    FROM {CLAIMS} WHERE to_date(Svc_Begin_Dt) >= DATE'{CLAIMS_FROM}'
    GROUP BY 1, 2 ORDER BY lines DESC"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 1 · Formats: do claim values look like B2's?

# COMMAND ----------

display(spark.sql("""
    SELECT count(*) AS lines_on_b2_codes,
           round(avg(CASE WHEN array_contains(b2_types, rtype) OR array_contains(b2_types, btype) THEN 1 ELSE 0 END), 4)
             AS share_type_listed,
           round(avg(CASE WHEN pos IS NULL THEN NULL WHEN array_contains(b2_poss, pos) THEN 1 ELSE 0 END), 4)
             AS share_pos_listed,
           round(avg(CASE WHEN size(mods) = 0 THEN NULL WHEN size(array_except(mods, b2_mods)) = 0 THEN 1 ELSE 0 END), 4)
             AS share_mods_listed
    FROM b2_lines"""))  # noqa: F821
for col in ("rtype", "btype", "pos"):
    display(spark.sql(f"SELECT {col}, count(*) AS lines FROM b2_lines GROUP BY {col} ORDER BY lines DESC LIMIT 15"))  # noqa: F821
display(spark.sql("SELECT m, count(*) AS lines FROM b2_lines LATERAL VIEW explode(mods) e AS m GROUP BY m "
                  "ORDER BY lines DESC LIMIT 15"))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 1b · By B2 version: the shares off the list for the lines each version judged
# MAGIC
# MAGIC A version that covers many months (no capture held between it and the next) judges lines AHCCCS may have
# MAGIC checked against a later list: read a rise late in its window as that, not as billing behaviour. POS 02 and 10 are
# MAGIC listed for BH codes in the 2025 B2 versions and not in October 2026; the telehealth code set (effective
# MAGIC 1/1/2026) says AHCCCS does not use them except when another primary payer requires them.

# COMMAND ----------

display(spark.sql("""
    SELECT b2_version, min(dos) AS first_service_date, max(dos) AS last_service_date, count(*) AS lines,
           round(avg(CASE WHEN size(mods) = 0 THEN NULL WHEN size(array_except(mods, b2_mods)) = 0 THEN 0 ELSE 1 END),
                 4) AS share_mods_off,
           round(avg(CASE WHEN pos IS NULL OR pos = '00' THEN NULL WHEN array_contains(b2_poss, pos) THEN 0 ELSE 1 END),
                 4) AS share_pos_off,
           round(avg(CASE WHEN code RLIKE '^H[02][0-9]{3}$' THEN CASE WHEN size(matched) = 0 THEN 1 ELSE 0 END END),
                 4) AS share_h_codes_neither_type_listed,
           round(avg(CASE WHEN pos IN ('02', '10') THEN 1 ELSE 0 END), 4) AS share_pos_02_10
    FROM b2_lines GROUP BY b2_version ORDER BY first_service_date"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 2 · Fill rates by delivery system and quarter from CLAIMS_FROM (the build assumes them for every date),
# MAGIC and whether EVENT_PA_NO follows the PA file on each delivery system (the PA file is FFS only)

# COMMAND ----------

diag = [c for c in spark.table(CLAIMS).columns if any(k in c.upper() for k in ("DIAG", "ICD", "DX_"))]  # noqa: F821
print("diagnosis-like columns:", diag or "none found")
extra = "".join(f", round(avg(CASE WHEN {blank(c)} IS NULL THEN 0 ELSE 1 END), 4) AS fill_{c}"
                for c in diag if not c.upper().endswith(("_DESC", "_KEY")))
display(spark.sql(f"""
    SELECT coalesce(delivery, 'all') AS delivery, coalesce(qtr, 'all') AS quarter, count(*) AS lines,
           round(avg(CASE WHEN {pos('POS_CODE')} IS NULL OR {pos('POS_CODE')} IN ('00', '') THEN 0 ELSE 1 END), 4)
             AS fill_pos,
           round(avg(CASE WHEN {mod('PROC_MOD_1')} IS NULL THEN 0 ELSE 1 END), 4) AS fill_modifier_1,
           round(avg(CASE WHEN {blank('EVENT_PA_NO')} IS NULL THEN 0 ELSE 1 END), 4) AS fill_pa_no{extra}
    FROM (SELECT *, concat(year(to_date(Svc_Begin_Dt)), '-Q', quarter(to_date(Svc_Begin_Dt))) AS qtr,
                 coalesce(CAST({DELIVERY} AS STRING), '(blank)') AS delivery FROM {CLAIMS}
          WHERE CAST(FORM_TYP AS STRING) IN ({forms}) AND to_date(Svc_Begin_Dt) >= DATE'{CLAIMS_FROM}' AND ({WHERE}))
    GROUP BY GROUPING SETS ((delivery, qtr), (delivery), ()) ORDER BY delivery, quarter"""))  # noqa: F821
spark.sql(f"""
    CREATE OR REPLACE TEMP VIEW pa_code AS
    SELECT d.code, max(d.pa_code) AS pa_code FROM (
      SELECT from_json(data, 'struct<code:string, pa_code:string>') AS d FROM {t('table_rows')}
      WHERE spec = 'pa_guidelines' AND source_version_id = '{PA_VERSION}') GROUP BY d.code""")  # noqa: F821
display(spark.sql("""
    SELECT l.delivery, coalesce(p.pa_code, 'not in PA file') AS pa_file_says, count(*) AS lines,
           round(avg(CASE WHEN l.pa_no IS NULL OR l.pa_no RLIKE '^0+$' THEN 0 ELSE 1 END), 4) AS share_with_pa_no
    FROM lines l LEFT JOIN pa_code p ON p.code = l.code GROUP BY 1, 2 ORDER BY 1, 2"""))  # noqa: F821
first_dx = next((c for c in diag if c.upper() in ("DIAG_CD_1", "DIAG_CD1", "PRIN_DIAG_CD")), None)
if first_dx:                    # real ICD-10-CM codes, or a placeholder?
    display(spark.sql(f"""
        SELECT round(avg(CASE WHEN v RLIKE '^[A-Z][0-9][0-9A-Z]' THEN 1 ELSE 0 END), 4) AS share_icd10_shaped,
               round(avg(CASE WHEN v RLIKE '^F' THEN 1 ELSE 0 END), 4) AS share_f_codes,
               count(DISTINCT v) AS distinct_codes
        FROM (SELECT upper(replace({blank(first_dx)}, '.', '')) AS v FROM {CLAIMS}
              WHERE CAST(FORM_TYP AS STRING) IN ({forms}) AND to_date(Svc_Begin_Dt) >= DATE'{SINCE}' AND ({WHERE}))
        WHERE v IS NOT NULL"""))  # noqa: F821
    display(spark.sql(f"""SELECT {first_dx} AS value, count(*) AS lines FROM {CLAIMS}
        WHERE CAST(FORM_TYP AS STRING) IN ({forms}) AND to_date(Svc_Begin_Dt) >= DATE'{SINCE}' AND ({WHERE})
        GROUP BY 1 ORDER BY lines DESC LIMIT 15"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 3 · B2-MOD: modifiers B2 does not list for the code

# COMMAND ----------

spark.sql("""
    CREATE OR REPLACE TEMP VIEW mod_check AS
    SELECT *, array_except(mods, b2_mods) AS off_any_type,
           array_except(mods, array_distinct(flatten(transform(matched, r -> r.modifiers)))) AS off_own_type
    FROM b2_lines WHERE size(mods) > 0""")  # noqa: F821
display(spark.sql("""
    SELECT count(*) AS lines_with_modifier,
           sum(CASE WHEN size(off_any_type) > 0 THEN 1 ELSE 0 END) AS lines_off_list_any_type,
           round(avg(CASE WHEN size(off_any_type) > 0 THEN 1 ELSE 0 END), 4) AS share_off_any_type,
           round(avg(CASE WHEN size(matched) > 0 AND size(off_own_type) > 0 THEN 1 ELSE 0 END), 4) AS share_off_own_type,
           round(sum(CASE WHEN size(off_any_type) > 0 THEN paid ELSE 0 END), 2) AS paid_off_any_type,
           count(DISTINCT CASE WHEN size(off_any_type) > 0 THEN bprov END) AS billing_providers_off
    FROM mod_check"""))  # noqa: F821
display(spark.sql(f"""
    SELECT code, m AS modifier_not_in_b2, count(*) AS lines, count(DISTINCT bprov) AS billing_providers,
           round(sum(paid), 2) AS paid
    FROM mod_check LATERAL VIEW explode(off_any_type) e AS m GROUP BY code, m ORDER BY lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 4 · B2-POS: places of service B2 does not list for the code

# COMMAND ----------

display(spark.sql("""
    SELECT count(*) AS lines_with_pos,
           sum(CASE WHEN NOT array_contains(b2_poss, pos) THEN 1 ELSE 0 END) AS lines_off_list,
           round(avg(CASE WHEN NOT array_contains(b2_poss, pos) THEN 1 ELSE 0 END), 4) AS share_off_any_type,
           round(avg(CASE WHEN size(matched) > 0 AND NOT exists(matched, r -> array_contains(r.places_of_service, pos))
                          THEN 1 ELSE 0 END), 4) AS share_off_own_type,
           round(sum(CASE WHEN NOT array_contains(b2_poss, pos) THEN paid ELSE 0 END), 2) AS paid_off_list,
           count(DISTINCT CASE WHEN NOT array_contains(b2_poss, pos) THEN bprov END) AS billing_providers_off
    FROM b2_lines WHERE pos IS NOT NULL AND pos <> '00'"""))  # noqa: F821
display(spark.sql(f"""
    SELECT code, pos AS pos_not_in_b2, count(*) AS lines, count(DISTINCT bprov) AS billing_providers,
           round(sum(paid), 2) AS paid
    FROM b2_lines WHERE pos IS NOT NULL AND pos <> '00' AND NOT array_contains(b2_poss, pos)
    GROUP BY code, pos ORDER BY lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md ## 5 · B2-PT: H0xxx and H2xxx lines whose provider types B2 does not list for the code

# COMMAND ----------

display(spark.sql("""
    SELECT count(*) AS h_code_lines,
           round(avg(CASE WHEN NOT array_contains(b2_types, rtype) THEN 1 ELSE 0 END), 4) AS share_rendering_unlisted,
           round(avg(CASE WHEN NOT array_contains(b2_types, btype) THEN 1 ELSE 0 END), 4) AS share_billing_unlisted,
           round(avg(CASE WHEN size(matched) = 0 THEN 1 ELSE 0 END), 4) AS share_neither_listed,
           round(sum(CASE WHEN size(matched) = 0 THEN paid ELSE 0 END), 2) AS paid_neither_listed
    FROM b2_lines WHERE code RLIKE '^H[02][0-9]{3}$'"""))  # noqa: F821
display(spark.sql(f"""
    SELECT code, rtype, btype, count(*) AS lines, count(DISTINCT bprov) AS billing_providers, round(sum(paid), 2) AS paid
    FROM b2_lines WHERE code RLIKE '^H[02][0-9]{{3}}$' AND size(matched) = 0
    GROUP BY code, rtype, btype ORDER BY lines DESC LIMIT {TOP}"""))  # noqa: F821

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading the results
# MAGIC
# MAGIC First check section 1: if the share of lines whose provider type, POS or modifiers B2 lists is low across the
# MAGIC board, the formats differ and the numbers below overstate what is off the list.
# MAGIC
# MAGIC For each of B2-MOD, B2-POS and B2-PT, the share of lines off the list (any provider type) says what AHCCCS's own
# MAGIC claim edits allow; section 1b shows whether it holds across versions. The cut-offs are a judgment call, not a
# MAGIC standard:
# MAGIC
# MAGIC | share off the list | what it suggests | reading |
# MAGIC |---|---|---|
# MAGIC | under about 0.5% | AHCCCS edits enforce the list; what gets through is rare | sign as complete: few findings, each worth a look |
# MAGIC | about 0.5% to 2% | partly enforced, or enforced for some codes only | look at the top pairs before deciding |
# MAGIC | over about 2%, across many providers | AHCCCS pays outside the list | reject as complete; keep the list as a review signal |
# MAGIC
# MAGIC A line off the list that AHCCCS paid passed every claim edit. Calling it a violation needs a source that says the
# MAGIC list is complete, which is what the reading claims and what FFS chapter 19 (B2 "is intended to be a reference
# MAGIC document") argues against. Send the five summary rows back and the readings can be settled.
