# Databricks notebook source
# MAGIC %md
# MAGIC # 07 · Build the knowledge base and export the review workbook (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC The build gives every record, as of the build date: its window (from its version, narrowed by dates the text
# MAGIC states), its review status (decisions bound to its content; approvals carried forward only where the section
# MAGIC reads the same), its codes (a service named without codes resolved to the service's code set), its execution
# MAGIC class, its conflicts (with a suggested prevailing record, never applied unsigned) and the exceptions that overlay
# MAGIC it. A record is executable now only when it is executable, approved, in force and in no open conflict.
# MAGIC
# MAGIC Writes kb_records_current (what detection reads), kb_records_history, kb_conflicts, kb_record_diffs,
# MAGIC kb_code_index and kb_build_log, then a review workbook in review/out, then policy_rules for investigators
# MAGIC (schema config.BI_SCHEMA, default policy_kb_bi; d02 adds flagged_lines and line_issues) and kb_rule_records.
# MAGIC
# MAGIC Next: download the workbook, fill Decision and Reviewer on the rows you decide, put it in review/in, and run
# MAGIC v01.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

# MAGIC %run ./_settings

# COMMAND ----------

import pandas as pd

from pie_kb.io.store import open_store

AS_OF = None                        # None: today; or a datetime.date to see the knowledge base as of that day
SOURCES = None                      # None: every source in the workbook; or a set such as {"A7", "A8"}
PUBLISH_BI = True                   # rebuild the investigator tables (approved rules only, editions merged)

store = open_store(spark)  # noqa: F821
res = stages.build(store, reg, today=AS_OF)
print({k: v for k, v in res.items() if k != "warnings"})

# COMMAND ----------

wb = stages.review_out(store, reg, sources=SOURCES)
print(wb)

# COMMAND ----------

# MAGIC %md ## Investigator table: policy_rules (Power BI)
# MAGIC What applies to a code: one row per code per approved rule over one continuous period (editions that state the
# MAGIC same rule with touching dates become one row: H0004's 434 d01 rows became 33). Only approved rules; the review
# MAGIC states, editions and presumed stretches stay in the knowledge base.

# COMMAND ----------

if PUBLISH_BI:
    from pie_kb import bi as BI
    try:
        out = BI.publish_rules(spark, store)  # noqa: F821
    except Exception as e:  # noqa: BLE001  (the build and the workbook are saved already)
        raise RuntimeError("investigator tables NOT rebuilt (CREATE SCHEMA refused? set PIE_BI_SCHEMA in _settings to "
                           "a schema you can write): " + str(e).splitlines()[0][:300]) from e
    print(config.CATALOG + "." + config.BI_SCHEMA, out["counts"], *out["warnings"], sep="\n  ")
    display(spark.sql(f"""SELECT code, service, how_code_is_involved, rule_type, rule, level, in_force_from,
                                 in_force_to, source, where_in_source
                          FROM {config.bi_table('policy_rules')} WHERE code = 'H0004'
                          ORDER BY level, rule_type, in_force_from"""))  # noqa: F821

# COMMAND ----------

cur = pd.DataFrame(store.read("records_current"))
if len(cur):
    # a record's presumed dates are a row of their own (part_of names the record): count records once, presumed rows
    cur["presumed_row"] = cur["presumed_from"].notna()
    cur["record"] = cur["record_id"] == cur["part_of"]
    display(cur.groupby(["source_id", "origin", "status", "execution_class"])  # noqa: F821
            .agg(records=("record", "sum"), presumed_rows=("presumed_row", "sum")).reset_index())
