"""The investigator tables for Power BI: what a person needs to review a flagged claim line, and nothing else.

An investigator starts from a provider or a lead, sees what was flagged and how much, opens a line, and needs the
claim facts beside the exact policy words to decide: request records, refer, or dismiss. Schema config.BI_SCHEMA
(default policy_kb_bi) holds three tables:

  flagged_lines   one row per flagged claim line of the latest detection run: priority, level, the main issue in a
                  sentence, the claim facts (providers and their types, member, dates, code and service, modifiers,
                  place of service, PA number, units, paid) and the main policy. Paid sums correctly: each line once.
  line_issues     one row per issue on a line (line x rule), for drill-through: what was found, the rule, why it is
                  a lead, the source, where in it, the policy words and the link.
  policy_rules    one row per code per approved rule: what applies to a code, with its dates and policy words
                  (documentation rules included: they are what a records review checks).

The machinery stays in the knowledge base schema for the PIE team: run history and SQL (kb_detect_runs), presumed
stretches, pending and rejected rules, editions, approvals (kb_records_current, kb_review_log), and the link from a
rule to its records (kb_rule_records). A finding on presumed dates is already a lead, and its reason says so.

Every column has a comment (Publish to Power BI copies them into descriptions); dates are DATE, amounts DOUBLE, no
column holds JSON or a list; keys are declared on Delta (informational). 07 rebuilds policy_rules, d02 the two
finding tables; nothing is edited by hand. Tables of the 7.1.7 layout are dropped.
"""
from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from datetime import date, timedelta

from . import config

LEVELS = {
    "Violation": "the rule can be checked in full on a claim line: a line that breaks it is a finding to act on",
    "Lead": "a person checks first: the rule has an exception or a condition the claim cannot show, the dates are "
            "presumed (no edition in hand), the text says may, a prior authorization number is on the line, or the "
            "place of service is a coding question",
    "Reference only": "the rule cannot be shown on a claim (documentation, qualification, authorization, or a service "
                      "named without codes): use it when reviewing records",
}
LEVEL_COMMENT = "; ".join(f"{k}: {v}" for k, v in LEVELS.items())
PRIORITY_COMMENT = ("High: at least one violation on the line; Medium: leads only; Low: only the telehealth place of "
                    "service 02 or 10 coding question")
TIER_OF_CLASS = {"executable": "Violation", "conditional": "Lead"}
WHY_OF_CLASS = {
    "executable": "Checkable in full on the claim",
    "conditional": "Has an exception or condition a person must check",
    "unresolved": "Names a service, not codes: not checkable until mapped to codes",
    "knowledge": "Cannot be shown on a claim (documentation, qualification or authorization)",
    "signal": "A review signal, not a rule",
}
KIND_NAMES = {
    "not_covered": "Not covered", "prior_auth_rule": "Prior authorization",
    "pair_prohibited": "Not billable on the same day with", "included_in": "Included in another service",
    "units_limit": "Unit limit", "frequency_limit": "Frequency limit", "dollar_limit": "Dollar limit",
    "provider_type_rule": "Provider type rule", "provider_qualification": "Provider qualification",
    "modifier_rule": "Modifier rule", "pos_rule": "Place of service rule", "telehealth_rule": "Telehealth delivery",
    "claim_form_required": "Claim form required", "diagnosis_required": "Diagnosis required",
    "age_limit": "Age limit", "documentation_required": "Documentation required", "coverage_scope": "Coverage scope",
    "definition": "Definition", "exception": "Exception", "cross_reference": "Cross reference",
    "obligation": "Provider obligation",
}
ROLE_NAMES = {"subject": "Main code", "subject_resolved": "Through a service category", "partner": "Partner code",
              "parent": "Parent code (the service it is included in)"}
# what a finding's check is called, in the order the main issue of a line is chosen (most serious first)
ISSUES = [
    ("not_covered", "Service not covered"),
    ("pair_prohibited", "Billed with a service not allowed the same day"),
    ("included_in", "Billed separately but included in another service"),
    ("units_limit", "Over the unit limit"),
    ("frequency_limit", "Over the service limit"),
    ("age_limit", "Outside the age limit"),
    ("provider_type_rule", "Provider type not allowed"),
    ("telehealth_site", "Telehealth from a site not allowed"),
    ("telehealth_modifier", "Telehealth modifier not allowed"),
    ("pos_rule", "Place of service not allowed"),
    ("modifier_rule", "Modifier not allowed or missing"),
    ("telehealth_pos_code", "Telehealth place of service 02 or 10 (coding question)"),
]
CODING_ONLY = ("telehealth_pos_code",)
# tables of the 7.1.7 layout: dropped from the investigator schema (referencing tables first)
LEGACY = ["findings", "rule_codes", "rules_by_code", "rule_presumed", "rule_records", "pending_rules", "rules", "runs",
          "tiers", "sources"]

_T, _D, _I, _F = "string", "date", "int", "double"
SPEC = {
    "flagged_lines": {
        "comment": "One row per claim line flagged in the latest detection run (each line once, so paid sums "
                   "correctly); line_issues holds every issue on the line",
        "columns": [
            ("line_id", _T, "Claim and line number: the key to line_issues"),
            ("priority", _T, "Review order. " + PRIORITY_COMMENT),
            ("level", _T, "The most serious level among the line's issues. " + LEVEL_COMMENT),
            ("main_issue", _T, "The most serious issue on the line, in plain words"),
            ("main_finding", _T, "The rule broken and what was found on the claim, in one sentence"),
            ("issue_count", _I, "How many issues the line has (line_issues lists them)"),
            ("all_issues", _T, "Every kind of issue on the line"),
            ("billing_provider", _T, "Billing provider id"),
            ("billing_provider_type", _T, "Billing provider type, code and name"),
            ("servicing_provider", _T, "Servicing provider id"),
            ("servicing_provider_type", _T, "Servicing provider type, code and name"),
            ("member", _T, "Member id (restrict to the people who need it)"),
            ("claim_id", _T, "Claim"), ("line_no", _T, "Line of the claim"),
            ("service_date", _D, "First date of service"),
            ("service_end_date", _D, "Last date of service (the same as the first for a one-day line)"),
            ("code", _T, "Procedure code"), ("service", _T, "What the code is (AHCCCS description)"),
            ("modifiers", _T, "Modifiers on the line"), ("place_of_service", _T, "Place of service on the line"),
            ("pa_number", _T, "Prior authorization number on the line, if any (blank proves nothing: AHCCCS finds "
                              "a PA without it)"),
            ("units", _F, "Units paid (net of adjustments)"),
            ("paid", _F, "Amount paid on the line (net); not an overpayment"),
            ("main_policy", _T, "Source and place in it of the main issue's rule"),
            ("detected_on", _D, "Date of the detection run"),
            ("run_id", _T, "The detection run (kb_detect_runs holds its settings and SQL)"),
        ],
        "pk": ["line_id"], "fks": []},
    "line_issues": {
        "comment": "One row per issue on a flagged line (line x rule): the evidence beside the policy words",
        "columns": [
            ("issue_key", _T, "Key of the issue"),
            ("line_id", _T, "The flagged line (flagged_lines.line_id)"),
            ("issue", _T, "The issue, in plain words"),
            ("level", _T, LEVEL_COMMENT),
            ("why_lead", _T, "Why a person checks first (blank for a violation)"),
            ("found_on_claim", _T, "What on the claim breaks the rule"),
            ("rule", _T, "The rule in one sentence"),
            ("source", _T, "Policy source"),
            ("where_in_source", _T, "Page and heading of a manual, or sheet and row of an AHCCCS table"),
            ("policy_words", _T, "The exact words the rule rests on"),
            ("source_link", _T, "Where AHCCCS publishes the source"),
            ("rule_key", _T, "The rule (policy_rules.rule_key); blank if it is no longer approved"),
        ],
        "pk": ["issue_key"], "fks": [("line_id", "flagged_lines", "line_id")]},
    "policy_rules": {
        "comment": "What applies to a code: one row per code per approved rule over one continuous period (editions "
                   "that state the same rule, with touching dates, merged)",
        "columns": [
            ("code", _T, "Procedure code"),
            ("service", _T, "What the code is (AHCCCS description)"),
            ("how_code_is_involved", _T, "Main code, Partner code (the rule is written about another code), Parent "
                                         "code (the service it is included in), or Through a service category"),
            ("rule_type", _T, "Plain name of the kind of rule"),
            ("rule", _T, "The rule in one sentence (latest edition)"),
            ("level", _T, "What the rule can do on claim lines. " + LEVEL_COMMENT),
            ("why_level", _T, "Why the rule has its level"),
            ("in_force_from", _D, "First date the rule applies"),
            ("in_force_to", _D, "Last date the rule applies; blank means still in force"),
            ("source", _T, "Full title of the policy source"),
            ("where_in_source", _T, "Page and heading of a manual, or sheet and row of an AHCCCS table (latest edition)"),
            ("policy_words", _T, "The exact words the rule rests on (latest edition)"),
            ("source_link", _T, "Where AHCCCS publishes the source"),
            ("rule_key", _T, "Key of the rule period (line_issues.rule_key; kb_rule_records lists its records)"),
        ],
        "pk": ["rule_key", "code", "how_code_is_involved"], "fks": []},
}
ORDER = ["policy_rules", "flagged_lines", "line_issues"]


# ---------------------------------------------------------------- plain Python: rule periods
def _j(v, default):
    if v is None or v == "":
        return default
    if isinstance(v, str):
        try:
            return json.loads(v)
        except ValueError:
            return default
    return v


def _d(s) -> date | None:
    if not s:
        return None
    return s if isinstance(s, date) else date.fromisoformat(str(s)[:10])


def _touch(prev_end: date | None, start: date | None) -> bool:
    return prev_end is None or start is None or start <= prev_end + timedelta(days=1)


def _codes(r: dict) -> list[tuple[str, str]]:
    """(code, role) for a record row, as the build's code index names them."""
    subj, p = _j(r.get("subject"), {}), _j(r.get("params"), {})
    out = []
    for role, cs in (("subject", subj.get("codes") or []), ("subject_resolved", _j(r.get("resolved_codes"), []) or []),
                     ("partner", p.get("partners") or []), ("parent", p.get("parent_codes") or [])):
        out += [(str(c).upper(), role) for c in cs if c]
    return out


def _where(cit: dict) -> str | None:
    if cit.get("locator"):
        return cit["locator"]
    parts = [f"p.{cit['page_start']}" if cit.get("page_start") else "", cit.get("section_path") or ""]
    return " ".join(x for x in parts if x) or None


def periods(current: list[dict], status: str = "approved") -> list[list[dict]]:
    """Rows of kb_records_current with this status, grouped into continuous periods of one rule: same meaning key,
    source and document; dates that touch; the same level on the rows that are not presumed. A presumed row joins the
    period it touches; a period of presumed rows only takes their level."""
    groups: dict = defaultdict(list)
    for r in current:
        if r.get("status") == status:
            key = (r.get("record_key") or r.get("part_of") or r["record_id"], r.get("source_id"),
                   r.get("document_key") or "main")
            groups[key].append(r)
    out = []
    for key in sorted(groups, key=lambda k: tuple(str(x) for x in k)):
        rows = sorted(groups[key], key=lambda r: (str(r.get("effective_start") or ""), r["record_id"]))
        cur, label, end = None, None, None
        for r in rows:
            start, r_end = _d(r.get("effective_start")), _d(r.get("effective_end"))
            mine = None if r.get("presumed_from") else TIER_OF_CLASS.get(r.get("execution_class"), "Reference only")
            if cur is not None and _touch(end, start) and (mine is None or label is None or mine == label):
                cur.append(r)
                label = label or mine
                end = None if (end is None or r_end is None) else max(end, r_end)
            else:
                if cur:
                    out.append(cur)
                cur, label, end = [r], mine, r_end
        if cur:
            out.append(cur)
    return out


def rules(current: list[dict], registry: list[dict] | None = None) -> dict:
    """{"policy_rules": code x rule rows (without service, which Spark adds), "rule_records": rule x record rows}."""
    titles = {(r["source_id"], r.get("document_key") or "main"): r.get("title") for r in registry or []}
    urls = {(r["source_id"], r.get("document_key") or "main"): r.get("url") for r in registry or []}
    out = {"policy_rules": [], "rule_records": []}
    for rows in periods(current):
        held = [r for r in rows if not r.get("presumed_from")]
        latest = (held or rows)[-1]
        cls = latest.get("execution_class")
        level = TIER_OF_CLASS.get(cls, "Reference only")
        start = _d(rows[0].get("effective_start"))
        ends = [_d(r.get("effective_end")) for r in rows]
        end = None if any(e is None for e in ends) else max(ends)
        why = WHY_OF_CLASS.get(cls, cls or "")
        if held and level == "Violation" and len(held) < len(rows):
            why += "; a lead on dates with no edition in hand (presumed)"
        cit = _j(latest.get("citation"), {})
        sid, dk = latest.get("source_id"), latest.get("document_key") or "main"
        key = "|".join(str(x) for x in (latest.get("record_key") or latest.get("part_of"), sid, dk, start))
        rk = "RK-" + hashlib.sha256(key.encode()).hexdigest()[:16]
        base = {"rule_type": KIND_NAMES.get(latest.get("kind"), latest.get("kind")), "rule": latest.get("statement"),
                "level": level, "why_level": why, "in_force_from": start, "in_force_to": end,
                "source": cit.get("title") or titles.get((sid, dk)) or sid, "where_in_source": _where(cit),
                "policy_words": cit.get("quote"), "source_link": urls.get((sid, dk)), "rule_key": rk}
        for code, role in sorted({c for r in rows for c in _codes(r)}):
            out["policy_rules"].append({"code": code, "how_code_is_involved": ROLE_NAMES.get(role, role), **base})
        recs: dict = {}
        for r in rows:
            recs.setdefault(r.get("part_of") or r["record_id"], []).append(
                (_d(r.get("effective_start")), _d(r.get("effective_end"))))
        for rid, spans in sorted(recs.items()):
            starts = [x for x, _ in spans if x]
            out["rule_records"].append({"rule_key": rk, "record_id": rid,
                                        "effective_start": min(starts).isoformat() if starts else None,
                                        "effective_end": None if any(e is None for _, e in spans)
                                        else max(e for _, e in spans).isoformat()})
    return out


# ---------------------------------------------------------------- Spark: tables, comments, keys
def _q(s: str) -> str:
    return (s or "").replace("\\", "\\\\").replace("'", "\\'")


def spec_sha(name: str) -> str:
    return hashlib.sha256(json.dumps(SPEC[name], sort_keys=True).encode()).hexdigest()[:12]


def _ddl(name: str, delta: bool) -> str:
    sp = SPEC[name]
    cols = ",\n  ".join(f"`{c}` {t.upper()}{' NOT NULL' if delta and c in sp['pk'] else ''} COMMENT '{_q(m)}'"
                        for c, t, m in sp["columns"])
    fmt = "DELTA" if delta else config.TABLE_FORMAT.upper()
    return (f"CREATE TABLE {config.bi_table(name)} (\n  {cols})\nUSING {fmt}\nCOMMENT '{_q(sp['comment'])}'\n"
            f"TBLPROPERTIES ('pie.bi_spec' = '{spec_sha(name)}')")


def _current_spec(spark, name: str) -> str | None:
    full = config.bi_table(name)
    if not spark.catalog.tableExists(full):
        return None
    try:
        rows = spark.sql(f"SHOW TBLPROPERTIES {full} ('pie.bi_spec')").collect()
        return str(rows[0]["value"]) if rows else ""
    except Exception:                                   # noqa: BLE001
        return ""


def ensure(spark, names: list[str]) -> list[str]:
    """Make the schema and the tables (dropping the 7.1.7 layout); a table whose layout changed is dropped and made
    again. Returns warnings (a key the workspace refused); a schema it cannot create raises with what to do."""
    warnings = []
    delta = config.TABLE_FORMAT == "delta"
    try:
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {config.CATALOG}.{config.BI_SCHEMA}")
    except Exception as e:                              # noqa: BLE001
        if not spark.catalog.databaseExists(f"{config.CATALOG}.{config.BI_SCHEMA}"):
            raise RuntimeError(f"schema {config.CATALOG}.{config.BI_SCHEMA} cannot be created "
                               f"({str(e).splitlines()[0][:160]}): ask for CREATE SCHEMA, or set BI_SCHEMA in "
                               f"_settings to a schema you can write") from e
    for n in LEGACY:
        if n not in SPEC and spark.catalog.tableExists(config.bi_table(n)):
            spark.sql(f"DROP TABLE IF EXISTS {config.bi_table(n)}")
            warnings.append(f"dropped {config.bi_table(n)} (7.1.7 layout)")
    stale = [n for n in names if _current_spec(spark, n) != spec_sha(n)]
    if not stale:
        return warnings
    if delta:                                          # a key into a table about to be dropped goes first
        for n in ORDER:
            for col, ref, _ in SPEC[n]["fks"]:
                if (ref in stale or n in stale) and spark.catalog.tableExists(config.bi_table(n)):
                    try:
                        spark.sql(f"ALTER TABLE {config.bi_table(n)} DROP CONSTRAINT IF EXISTS {n}_{col}_fk")
                    except Exception:                  # noqa: BLE001
                        pass
    for n in [x for x in reversed(ORDER) if x in stale]:
        spark.sql(f"DROP TABLE IF EXISTS {config.bi_table(n)}")
    for n in [x for x in ORDER if x in stale]:
        spark.sql(_ddl(n, delta))
    if delta:
        for n in [x for x in ORDER if x in stale]:
            try:
                spark.sql(f"ALTER TABLE {config.bi_table(n)} ADD CONSTRAINT {n}_pk PRIMARY KEY "
                          f"({', '.join(SPEC[n]['pk'])})")
            except Exception as e:                      # noqa: BLE001
                warnings.append(f"{n}: primary key not declared ({str(e).splitlines()[0][:120]})")
        for n in ORDER:
            for col, ref, rcol in SPEC[n]["fks"]:
                if (n in stale or ref in stale) and spark.catalog.tableExists(config.bi_table(n)) \
                        and spark.catalog.tableExists(config.bi_table(ref)):
                    try:
                        spark.sql(f"ALTER TABLE {config.bi_table(n)} ADD CONSTRAINT {n}_{col}_fk FOREIGN KEY ({col}) "
                                  f"REFERENCES {config.bi_table(ref)} ({rcol})")
                    except Exception as e:              # noqa: BLE001
                        warnings.append(f"{n}.{col}: foreign key not declared ({str(e).splitlines()[0][:120]})")
    return warnings


def write_df(spark, name: str, df) -> int:
    """Replace a table's rows (INSERT OVERWRITE keeps its comments and keys)."""
    cols = [c for c, _, _ in SPEC[name]["columns"]]
    view = f"pie_bi_{name}"
    df.select(*cols).createOrReplaceTempView(view)
    spark.sql(f"INSERT OVERWRITE TABLE {config.bi_table(name)} SELECT {', '.join(f'`{c}`' for c in cols)} FROM {view}")
    return spark.table(config.bi_table(name)).count()


def _lookups(spark) -> None:
    """Temp views pie_bi_service (code -> description: B2, then daily limits, then PA guidelines, newest edition
    first), pie_bi_ptype (provider type -> 'code name', PEP-903) and pie_bi_source (source id -> title, link)."""
    rows_t, reg_t = config.table("table_rows"), config.table("source_registry")
    if spark.catalog.tableExists(rows_t):
        spark.sql(f"""
            CREATE OR REPLACE TEMP VIEW pie_bi_service AS
            SELECT code, description AS service FROM (
              SELECT upper(get_json_object(data, '$.code')) AS code, get_json_object(data, '$.description') AS
                     description,
                     row_number() OVER (PARTITION BY upper(get_json_object(data, '$.code'))
                                        ORDER BY CASE source_id WHEN 'A1' THEN 1 WHEN 'A3' THEN 2 ELSE 3 END,
                                                 source_version_id DESC) AS n
              FROM {rows_t}
              WHERE source_id IN ('A1', 'A3', 'A5') AND get_json_object(data, '$.description') IS NOT NULL)
            WHERE n = 1""")
        spark.sql(f"""
            CREATE OR REPLACE TEMP VIEW pie_bi_ptype AS
            SELECT code, concat(code, ' ', name) AS ptype FROM (
              SELECT get_json_object(data, '$.code') AS code, get_json_object(data, '$.name') AS name,
                     row_number() OVER (PARTITION BY get_json_object(data, '$.code')
                                        ORDER BY source_version_id DESC, row_key) AS n
              FROM {rows_t} WHERE source_id = 'A25')
            WHERE n = 1""")
    else:
        spark.sql("CREATE OR REPLACE TEMP VIEW pie_bi_service AS SELECT CAST(NULL AS STRING) AS code, "
                  "CAST(NULL AS STRING) AS service WHERE false")
        spark.sql("CREATE OR REPLACE TEMP VIEW pie_bi_ptype AS SELECT CAST(NULL AS STRING) AS code, "
                  "CAST(NULL AS STRING) AS ptype WHERE false")
    if spark.catalog.tableExists(reg_t):
        spark.sql(f"""CREATE OR REPLACE TEMP VIEW pie_bi_source AS
                      SELECT source_id, first(title) AS title, first(url) AS url FROM {reg_t}
                      WHERE coalesce(document_key, 'main') = 'main' GROUP BY source_id""")
    else:
        spark.sql("CREATE OR REPLACE TEMP VIEW pie_bi_source AS SELECT CAST(NULL AS STRING) AS source_id, "
                  "CAST(NULL AS STRING) AS title, CAST(NULL AS STRING) AS url WHERE false")


def publish_rules(spark, store) -> dict:
    """Rebuild policy_rules (and kb_rule_records, the link from a rule to its records) from the latest build; 07
    calls it after the build. Returns {"counts", "warnings"}."""
    from pyspark.sql import types as T
    built = rules(store.read("records_current"), store.read("source_registry"))
    store.write("rule_records", built["rule_records"])
    warnings = ensure(spark, ["policy_rules"])
    _lookups(spark)
    cols = [c for c, _, _ in SPEC["policy_rules"]["columns"] if c != "service"]
    typ = {c: t for c, t, _ in SPEC["policy_rules"]["columns"]}
    schema = T.StructType([T.StructField(c, T.DateType() if typ[c] == _D else T.StringType(), True) for c in cols])
    spark.createDataFrame([tuple(r.get(c) for c in cols) for r in built["policy_rules"]], schema) \
        .createOrReplaceTempView("pie_bi_rules_in")
    df = spark.sql("SELECT r.*, s.service FROM pie_bi_rules_in r LEFT JOIN pie_bi_service s ON s.code = r.code")
    return {"counts": {"policy_rules": write_df(spark, "policy_rules", df),
                       "kb_rule_records": len(built["rule_records"])}, "warnings": warnings}


def _issue_case(col: str) -> str:
    return "CASE " + col + " " + " ".join(f"WHEN '{k}' THEN '{_q(v)}'" for k, v in ISSUES) + f" ELSE {col} END"


def _rank_case(col: str) -> str:
    return "CASE " + col + " " + " ".join(f"WHEN '{k}' THEN {i}" for i, (k, _) in enumerate(ISSUES)) + " ELSE 99 END"


def publish_findings(spark, run_id: str | None = None) -> dict:
    """Rebuild flagged_lines and line_issues from the latest detection run in kb_findings (or run_id); d02 calls it
    after a run. Returns {"counts", "warnings", "run_id"}."""
    find_t, map_t = config.table("findings"), config.table("rule_records")
    warnings = ensure(spark, ["flagged_lines", "line_issues"])
    if not spark.catalog.tableExists(find_t):
        return {"counts": {}, "warnings": warnings + ["no findings saved yet (kb_findings)"], "run_id": None}
    run_id = run_id or spark.sql(f"SELECT max(run_id) FROM {find_t}").collect()[0][0]
    if not spark.catalog.tableExists(map_t):
        warnings.append("kb_rule_records not built yet (07 builds it): line_issues have no rule_key")
        spark.sql("CREATE OR REPLACE TEMP VIEW pie_bi_map AS SELECT CAST(NULL AS STRING) AS record_id, "
                  "CAST(NULL AS STRING) AS rule_key WHERE false")
    else:
        spark.sql(f"CREATE OR REPLACE TEMP VIEW pie_bi_map AS SELECT record_id, min(rule_key) AS rule_key "
                  f"FROM {map_t} GROUP BY record_id")
    _lookups(spark)
    cols = set(spark.table(find_t).columns)
    opt = lambda c, default="CAST(NULL AS STRING)": f"f.{c}" if c in cols else default  # noqa: E731
    check = f"coalesce({opt('check_type')}, f.kind)"
    rid = f"'{_q(run_id)}'"
    spark.sql(f"""
        CREATE OR REPLACE TEMP VIEW pie_bi_issues AS
        SELECT substr(sha2(concat_ws('|', f.run_id, f.record_id, f.line_id, {check}), 256), 1, 24) AS issue_key,
               f.run_id, f.line_id, {check} AS check_type, {_issue_case(check)} AS issue,
               {_rank_case(check)} AS issue_rank,
               CASE f.tier WHEN 'violation' THEN 'Violation' ELSE 'Lead' END AS level,
               CASE WHEN f.tier <> 'violation' THEN nullif(f.reasons, '') END AS why_lead,
               f.evidence AS found_on_claim, f.statement AS rule, f.source,
               f.locator AS where_in_source, f.quote AS policy_words, src.url AS source_link, m.rule_key,
               CAST(f.claim_id AS STRING) AS claim_id, CAST(f.ln_no AS STRING) AS line_no,
               CAST(f.member AS STRING) AS member, CAST(f.bprov AS STRING) AS bprov,
               CAST(f.sprov AS STRING) AS sprov, f.code, to_date(f.dos) AS service_date,
               to_date(coalesce({opt('dos_end', 'NULL')}, f.dos)) AS service_end_date, {opt('mods')} AS mods,
               {opt('pos')} AS pos, {opt('btype')} AS btype, {opt('rtype')} AS rtype, {opt('pa')} AS pa,
               CAST(f.units AS DOUBLE) AS units, CAST(f.paid AS DOUBLE) AS paid
        FROM {find_t} f
        LEFT JOIN pie_bi_map m ON m.record_id = f.part_of
        LEFT JOIN pie_bi_source src ON src.source_id = split(f.version, '@')[0]
        WHERE f.run_id = {rid}""")
    issues = write_df(spark, "line_issues", spark.table("pie_bi_issues"))
    lines = spark.sql(f"""
        WITH ranked AS (
          SELECT i.*, row_number() OVER (PARTITION BY line_id
                                         ORDER BY CASE level WHEN 'Violation' THEN 0 ELSE 1 END, issue_rank, rule)
                        AS n,
                 count(*) OVER (PARTITION BY line_id) AS issue_count,
                 max(CASE WHEN level = 'Violation' THEN 1 ELSE 0 END) OVER (PARTITION BY line_id) AS any_violation,
                 min(CASE WHEN check_type IN ({", ".join(f"'{c}'" for c in CODING_ONLY)}) THEN 1 ELSE 0 END)
                   OVER (PARTITION BY line_id) AS coding_only,
                 array_join(array_sort(collect_set(issue) OVER (PARTITION BY line_id)), '; ') AS all_issues
          FROM pie_bi_issues i)
        SELECT r.line_id,
               CASE WHEN any_violation = 1 THEN 'High' WHEN coding_only = 1 THEN 'Low' ELSE 'Medium' END AS priority,
               CASE WHEN any_violation = 1 THEN 'Violation' ELSE 'Lead' END AS level,
               issue AS main_issue, concat(coalesce(rule, ''), ' Found: ', coalesce(found_on_claim, '')) AS main_finding,
               CAST(issue_count AS INT) AS issue_count, all_issues,
               bprov AS billing_provider, bt.ptype AS billing_provider_type, sprov AS servicing_provider,
               st.ptype AS servicing_provider_type, member, claim_id, line_no, service_date, service_end_date, r.code,
               sv.service, mods AS modifiers, pos AS place_of_service, pa AS pa_number, units, paid,
               concat_ws(', ', source, where_in_source) AS main_policy,
               to_date(substr(run_id, 8, 8), 'yyyyMMdd') AS detected_on, run_id
        FROM ranked r
        LEFT JOIN pie_bi_ptype bt ON bt.code = r.btype
        LEFT JOIN pie_bi_ptype st ON st.code = r.rtype
        LEFT JOIN pie_bi_service sv ON sv.code = r.code
        WHERE n = 1""")
    return {"counts": {"flagged_lines": write_df(spark, "flagged_lines", lines), "line_issues": issues},
            "warnings": warnings, "run_id": run_id}
