"""Detection: approved knowledge base rules run over paid claim lines, by service date.

A rule judges a line only on the dates its row in kb_records_current covers (effective_start to effective_end), so
each claim is judged by the edition in force on its date of service. Only approved records run, and only those whose
whole content can be checked on the claim:

  violation   the record is executable on that date (class executable, edition held, no exception to confirm)
  lead        the record is conditional (an exception a person confirms, a parameter the source leaves open, a field
              not yet measured) or the date falls in a presumed part of its window

A record with a condition the claim cannot show (a setting, a member attribute, the service context) does not run:
it is listed in the coverage table with the reason, never guessed. Neither does a kind or period detection does not
check yet. Nothing here decides a payment: a finding is evidence for a person, with the rule's words and citation.

A line that covers several days (service end date after its begin date) is spread evenly over its days for the
limits per day, and counts as one service on each of them; pairs and included-in rules compare the days a line
covers, not only its first day. With no end date column (columns["dos_end"] = None), every line is one day.

The rules are prepared in Python (prepare); the claims never leave Spark (run). Notebook d02 calls both, logs the
SQL text of the run (sql_text) and the code version (code_sha) with its findings.
"""
from __future__ import annotations

import hashlib
import json
import os
from collections import Counter

TELEHEALTH_MODIFIERS = ("GT", "GQ", "FQ")       # the code set's telehealth columns (TH-MOD)
CHECKED_CONDITIONS = ("modifier", "place_of_service", "age", "provider_type", "claim_form")
PERIODS = {"units_limit": ("day", "line"), "frequency_limit": ("day",)}
UNIT_BASES = ("unit", "unstated", None, "")      # an hour or session limit needs the code's billing unit (not here)
MAX_SPAN_DAYS = 366                              # only a span's first days are judged (its units still spread
                                                 # over all its days)
# the telehealth code set's Guidelines sheet (A4, effective 1/1/2026): AHCCCS does not use POS 02 or 10 except when
# another primary payer requires them (TPL); such a line is a coding question, not proof of a site the rule forbids
TELEHEALTH_CODING_POS = ("02", "10")
TELEHEALTH_CODING_REASON = ("place of service 02 or 10: AHCCCS does not use them except when another primary payer "
                            "requires them (TPL), so this is a coding question, not proof that the site was not allowed")
# a prior authorization number on a line (EVENT_PA_NO; -1, blank or zeros are none) can authorize units above a limit:
# such a finding is a lead. A missing number proves nothing: AHCCCS matches a PA by member, provider, dates, code and
# units without it (Claims Clues, May 2023, p.2), and the field is filled on 8% of lines.
PA_REASON_SQL = ("concat('a prior authorization number is on the line (', {pa}, '): the units above the limit may "
                 "be authorized; check the authorization')")

# claims table columns (main.prod_input.all_data_C_A); the notebook can override any of them
COLUMNS = {"claim": "ClaimID", "line": "LN_NO", "member": "MEMBER_KEY", "billing": "BProv_ID",
           "servicing": "SProv_ID", "billing_type": "BProv_Type", "servicing_type": "SProv_Type",
           "code": "PROC_CD", "mods": ("PROC_MOD_1", "PROC_MOD_2", "PROC_MOD_3", "PROC_MOD_4"), "pos": "POS_CODE",
           "dos": "Svc_Begin_Dt", "dos_end": "Svc_End_Dt", "units": "QUANTITY_PAID", "paid": "PMT_AMT",
           "dob": "date_of_birth", "form": "FORM_TYP", "pa": "EVENT_PA_NO"}

RULE_FIELDS = [  # name, Spark type
    ("rid", "string"), ("part_of", "string"), ("kind", "string"), ("code", "string"), ("start", "string"),
    ("end", "string"), ("tier", "string"), ("reasons", "string"), ("statement", "string"), ("source", "string"),
    ("version", "string"), ("locator", "string"), ("quote", "string"), ("group_key", "string"), ("maxv", "double"),
    ("per", "string"), ("by_provider", "boolean"), ("partners", "array<string>"), ("bypass", "array<string>"),
    ("min_age", "int"), ("below_age", "int"), ("mode", "string"), ("match", "string"), ("mods", "array<string>"),
    ("pos", "array<string>"), ("ptypes", "array<string>"), ("role", "string"), ("parents", "array<string>"),
    ("c_mod_present", "array<string>"), ("c_mod_absent", "array<string>"), ("c_pos_in", "array<string>"),
    ("c_pos_out", "array<string>"), ("c_age_min", "int"), ("c_age_below", "int"), ("c_pt_in", "array<string>"),
    ("c_pt_out", "array<string>"), ("c_pt_role", "string"), ("c_form", "array<string>"), ("ffs_only", "boolean")]


def _j(v, default):
    if v is None or v == "":
        return default
    return json.loads(v) if isinstance(v, str) else v


def _pt(v) -> str:
    s = str(v).strip().upper()
    return s.zfill(2) if s.isdigit() and len(s) == 1 else s


def _conditions(conds: list) -> tuple[dict | None, str]:
    """Flat condition columns, or (None, why) when one cannot be checked on a claim."""
    out = {"c_mod_present": [], "c_mod_absent": [], "c_pos_in": [], "c_pos_out": [], "c_age_min": None,
           "c_age_below": None, "c_pt_in": [], "c_pt_out": [], "c_pt_role": None, "c_form": []}
    seen = Counter(c.get("type") for c in conds)
    for c in conds:
        t = c.get("type")
        if t not in CHECKED_CONDITIONS:
            return None, f"condition needs {t.replace('_', ' ') if t else 'an unknown field'}, not on the claim"
        if seen[t] > 1:
            return None, f"two {t.replace('_', ' ')} conditions"
        if t == "modifier":
            out["c_mod_present"] = [m.upper() for m in c.get("present") or []]
            out["c_mod_absent"] = [m.upper() for m in c.get("absent") or []]
        elif t == "place_of_service":
            out["c_pos_in"] = [str(p).zfill(2) for p in c.get("include") or []]
            out["c_pos_out"] = [str(p).zfill(2) for p in c.get("exclude") or []]
        elif t == "age":
            out["c_age_min"], out["c_age_below"] = c.get("min_age"), c.get("below_age")
        elif t == "provider_type":
            vals = [_pt(x) for x in (c.get("include") or []) + (c.get("exclude") or [])]
            if any(not (len(x) == 2 and x.isalnum()) for x in vals):
                return None, "provider types given as words, not AHCCCS type codes"
            out["c_pt_in"] = [_pt(x) for x in c.get("include") or []]
            out["c_pt_out"] = [_pt(x) for x in c.get("exclude") or []]
            out["c_pt_role"] = c.get("role") or "billing_or_rendering"
        elif t == "claim_form":
            f = c.get("form")
            out["c_form"] = [str(x).upper() for x in (f if isinstance(f, list) else [f]) if x]
    return out, ""


def _kind_params(kind: str, p: dict) -> tuple[dict | None, str]:
    """The kind's check columns, or (None, why) when detection does not check it yet."""
    base = {"maxv": None, "per": None, "by_provider": False, "partners": [], "bypass": [], "min_age": None,
            "below_age": None, "mode": None, "match": None, "mods": [], "pos": [], "ptypes": [], "role": None,
            "parents": []}
    scope = p.get("scope") or "unstated"
    if kind in ("units_limit", "frequency_limit"):
        if p.get("per") not in PERIODS[kind]:
            return None, f"{kind.replace('_', ' ')} per {p.get('per')} is not checked yet"
        if kind == "units_limit" and p.get("unit_basis") not in UNIT_BASES:
            return None, f"a limit in {p.get('unit_basis')}s needs the code's billing unit to compare with units"
        if p.get("max") is None:
            return None, "no maximum"
        # an unstated scope is read per provider: the narrower count, so fewer and surer findings
        return {**base, "maxv": float(p["max"]), "per": p["per"], "by_provider": scope != "member"}, ""
    if kind == "pair_prohibited":
        if not p.get("partners"):
            return None, "partner category not resolved to codes"
        by = p.get("modifier_bypass")
        return {**base, "partners": [x.upper() for x in p["partners"]], "by_provider": scope != "member_day",
                "bypass": [m.upper() for m in by] if isinstance(by, list) else []}, ""
    if kind == "age_limit":
        return {**base, "min_age": p.get("min_age"), "below_age": p.get("below_age")}, ""
    if kind == "modifier_rule":
        mode = p.get("mode")
        if mode == "allowed" and not p.get("complete_list"):
            return None, "an allowed list not stated as complete cannot show a violation"
        if mode not in ("required", "allowed", "not_allowed"):
            return None, f"modifier mode {mode} is not checked"
        return {**base, "mode": mode, "match": p.get("match") or "any",
                "mods": [m.upper() for m in p.get("modifiers") or []]}, ""
    if kind == "pos_rule":
        mode = p.get("mode")
        if mode == "allowed" and not p.get("complete_list"):
            return None, "an allowed list not stated as complete cannot show a violation"
        if mode not in ("allowed", "not_allowed"):
            return None, f"place of service mode {mode} is not checked"
        return {**base, "mode": mode, "pos": [str(x).zfill(2) for x in p.get("pos") or []]}, ""
    if kind == "provider_type_rule":
        mode = p.get("mode")
        if mode == "allowed" and not p.get("complete_list"):
            return None, "an allowed list not stated as complete cannot show a violation"
        if mode not in ("allowed", "not_allowed"):
            return None, f"provider type mode {mode} is not checked"
        return {**base, "mode": mode, "ptypes": [_pt(x) for x in p.get("provider_types") or []],
                "role": p.get("role") or "billing_or_rendering"}, ""
    if kind == "telehealth_rule":
        if not p.get("allowed"):
            return None, "a telehealth prohibition is not checked yet"
        return {**base, "mods": [m.upper() for m in p.get("modifiers") or []],
                "pos": [str(x).zfill(2) for x in p.get("pos") or []]}, ""
    if kind == "included_in":
        if not p.get("parent_codes"):
            return None, "parent category not resolved to codes"
        if scope not in ("same_day",):
            return None, f"included in, scope {scope}, is not checked yet"
        return {**base, "parents": [x.upper() for x in p["parent_codes"]], "by_provider": True}, ""
    if kind == "not_covered":
        return base, ""
    return None, f"{kind.replace('_', ' ')} is not checked on claims"


def prepare(current: list[dict], open_conflicts: set | None = None, ffs_known: bool = False) -> tuple[list, list]:
    """(rule rows, not run). current: kb_records_current rows; a row is one record over one window (a presumed part
    is a row of its own). open_conflicts: record ids in an open conflict (they do not run). ffs_known: whether the
    notebook can tell FFS lines (a record for FFS only then runs on them; else its findings are leads)."""
    rows, skipped = [], []
    open_conflicts = open_conflicts or set()
    for r in current:
        if r.get("status") != "approved" or r.get("execution_class") not in ("executable", "conditional"):
            continue
        rid, kind = r["record_id"], r["kind"]

        def skip(why):
            skipped.append({"rid": rid, "part_of": r.get("part_of") or rid, "kind": kind, "source_id": r.get("source_id"),
                            "statement": r.get("statement"), "why": why})
        if (r.get("part_of") or rid) in open_conflicts or rid in open_conflicts:
            skip("in an open conflict")
            continue
        subject, params = _j(r.get("subject"), {}), _j(r.get("params"), {})
        codes = [c.upper() for c in (subject.get("codes") or _j(r.get("resolved_codes"), []) or [])]
        if not codes:
            skip("names a category no code set resolves")
            continue
        conds, why = _conditions(_j(r.get("conditions"), []))
        if conds is None:
            skip(why)
            continue
        kp, why = _kind_params(kind, params)
        if kp is None:
            skip(why)
            continue
        reasons = list(_j(r.get("execution_reasons"), []))
        tier = "violation" if r.get("execution_class") == "executable" else "lead"
        if r.get("presumed_from"):
            tier = "lead"
            reasons.append(f"presumed from {r['presumed_from']}: the edition in force on these dates is not held")
        flags = [f for f in _j(r.get("flags"), []) if isinstance(f, dict)]
        if any(f.get("code") == "discretionary" for f in flags):
            tier = "lead"
            reasons.append("the text says may: a finding is discretionary")
        systems = (_j(r.get("applicability"), {}) or {}).get("delivery_systems") or []
        ffs_only = bool(systems) and set(systems) == {"FFS"}
        if ffs_only and not ffs_known:
            tier = "lead"
            reasons.append("applies to FFS lines; the run cannot tell FFS lines apart")
        cit = _j(r.get("citation"), {})
        base = {"rid": rid, "part_of": r.get("part_of") or rid, "kind": kind, "start": r.get("effective_start"),
                "end": r.get("effective_end"), "tier": tier, "reasons": "; ".join(reasons),
                "statement": r.get("statement"), "source": cit.get("title") or r.get("source_id"),
                "version": r.get("source_version_id"),
                "locator": cit.get("locator") or " ".join(x for x in (f"p.{cit['page_start']}" if cit.get("page_start")
                                                                         else "", cit.get("section_path") or "") if x)
                or None,
                "quote": cit.get("quote"), "ffs_only": ffs_only and ffs_known, **conds, **kp}
        combined = bool(params.get("combined")) and kind == "units_limit"
        for c in codes:
            rows.append({**base, "code": c, "group_key": rid if combined else f"{rid}|{c}"})
    return rows, skipped


def lines_sql(table: str, where: str = "1 = 1", forms=("A",), since=None, until=None, ffs_where=None,
              columns: dict | None = None) -> str:
    """One row per claim line: rows of a line (an original and its adjustments) summed, payable lines only.
    days: the days the line covers (dos to dos_end; 1 when the end date is missing, before dos or not read)."""
    c = {**COLUMNS, **(columns or {})}
    s = lambda col: f"trim(CAST({col} AS STRING))"  # noqa: E731

    def mod(col):
        v = f"upper({s(col)})"
        return f"CASE WHEN {v} RLIKE '^[A-Z0-9]{{2}}$' THEN {v} END"

    def ptype(col):
        v = s(col)
        return (f"CASE WHEN {v} IS NULL OR upper({v}) IN ('', 'NONE', 'NAN', 'NULL', '-1') THEN NULL "
                f"WHEN {v} RLIKE '^[0-9]$' THEN lpad({v}, 2, '0') ELSE upper({v}) END")
    forms_sql = ", ".join(f"'{f}'" for f in forms)
    dates = (f" AND to_date({c['dos']}) >= DATE'{since}'" if since else "") + \
            (f" AND to_date({c['dos']}) <= DATE'{until}'" if until else "")
    mods = ", ".join(mod(m) for m in c["mods"])
    end = f"max(to_date({c['dos_end']}))" if c.get("dos_end") else "CAST(NULL AS DATE)"
    pa_v = s(c["pa"]) if c.get("pa") else None
    pa = (f"max(CASE WHEN {pa_v} IS NULL OR {pa_v} IN ('', '-1') OR {pa_v} RLIKE '^0+$' THEN NULL ELSE {pa_v} END)"
          if pa_v else "CAST(NULL AS STRING)")
    days = "CASE WHEN dos_end IS NULL OR dos_end <= dos THEN 1 ELSE datediff(dos_end, dos) + 1 END"
    return f"""
    SELECT claim_id, ln_no, line_id, member, bprov, sprov, btype, rtype, code, mods, pos, form, dos,
           date_add(dos, days - 1) AS dos_end, days, units, paid, pa, is_ffs, age
    FROM (
    SELECT claim_id, ln_no, concat_ws('-', claim_id, ln_no) AS line_id, member, bprov, sprov, btype, rtype, code,
           mods, pos, form, dos, dos_end, {days} AS days, units, paid, pa, is_ffs,
           CAST(floor(months_between(dos, dob) / 12) AS INT) AS age
    FROM (
      SELECT {s(c['claim'])} AS claim_id, {s(c['line'])} AS ln_no, max({s(c['member'])}) AS member,
             max({s(c['billing'])}) AS bprov, max({s(c['servicing'])}) AS sprov,
             max({ptype(c['billing_type'])}) AS btype, max({ptype(c['servicing_type'])}) AS rtype,
             max(upper({s(c['code'])})) AS code,
             max(filter(array({mods}), x -> x IS NOT NULL)) AS mods,
             max(lpad(regexp_replace({s(c['pos'])}, '\\\\.0+$', ''), 2, '0')) AS pos,
             max(upper({s(c['form'])})) AS form, max(to_date({c['dos']})) AS dos, {end} AS dos_end,
             max(to_date({c['dob']})) AS dob,
             sum(CAST({c['units']} AS DOUBLE)) AS units, sum(CAST({c['paid']} AS DOUBLE)) AS paid, {pa} AS pa,
             max({'(' + ffs_where + ')' if ffs_where else 'CAST(NULL AS BOOLEAN)'}) AS is_ffs
      FROM {table}
      WHERE upper({s(c['form'])}) IN ({forms_sql}){dates} AND ({where})
      GROUP BY {s(c['claim'])}, {s(c['line'])})
    WHERE units > 0 AND paid > 0 AND dos IS NOT NULL AND code IS NOT NULL)"""


COND_SQL = """
    (size(r.c_mod_present) = 0 OR arrays_overlap(l.mods, r.c_mod_present))
    AND (size(r.c_mod_absent) = 0 OR NOT arrays_overlap(l.mods, r.c_mod_absent))
    AND (size(r.c_pos_in) = 0 OR coalesce(array_contains(r.c_pos_in, l.pos), false))
    AND (size(r.c_pos_out) = 0 OR (l.pos IS NOT NULL AND NOT array_contains(r.c_pos_out, l.pos)))
    AND (r.c_age_min IS NULL OR coalesce(l.age >= r.c_age_min, false))
    AND (r.c_age_below IS NULL OR coalesce(l.age < r.c_age_below, false))
    AND (size(r.c_form) = 0 OR coalesce(array_contains(r.c_form, l.form), false))
    AND (size(r.c_pt_in) = 0 OR CASE r.c_pt_role
           WHEN 'billing' THEN coalesce(array_contains(r.c_pt_in, l.btype), false)
           WHEN 'rendering' THEN coalesce(array_contains(r.c_pt_in, l.rtype), false)
           ELSE coalesce(array_contains(r.c_pt_in, l.btype), false) OR coalesce(array_contains(r.c_pt_in, l.rtype), false) END)
    AND (size(r.c_pt_out) = 0 OR CASE r.c_pt_role
           WHEN 'billing' THEN l.btype IS NOT NULL AND NOT array_contains(r.c_pt_out, l.btype)
           WHEN 'rendering' THEN l.rtype IS NOT NULL AND NOT array_contains(r.c_pt_out, l.rtype)
           ELSE NOT coalesce(array_contains(r.c_pt_out, l.btype), false)
                AND NOT coalesce(array_contains(r.c_pt_out, l.rtype), false) END)
    AND (NOT r.ffs_only OR coalesce(l.is_ffs, false))"""

# the type a provider type rule reads: a group (01) bills for its rendering provider (as reading B2-PT)
BILLING_TYPE = "CASE WHEN l.btype = '01' THEN l.rtype ELSE l.btype END"

_TELE = "array(" + ", ".join(f"'{m}'" for m in TELEHEALTH_MODIFIERS) + ")"
_TELE_MOD_BAD = f"size(array_except(array_intersect(l.mods, {_TELE}), r.mods)) > 0"
_TELE_POS_BAD = "(l.pos IS NOT NULL AND NOT array_contains(r.pos, l.pos))"
_TELE_CODING = (f"(NOT ({_TELE_MOD_BAD}) AND {_TELE_POS_BAD} AND l.pos IN ("
                + ", ".join(f"'{p}'" for p in TELEHEALTH_CODING_POS) + "))")

# kind: the predicate that flags a line, its evidence, and (optional) the check, tier and reasons when they differ from
# the kind, the record's tier and the record's reasons
SINGLE_LINE = {
    "age_limit": {"pred": "l.age IS NOT NULL AND ((r.min_age IS NOT NULL AND l.age < r.min_age) OR "
                          "(r.below_age IS NOT NULL AND l.age >= r.below_age))",
                  "evidence": "concat('member age ', l.age, ' on the date of service')"},
    "modifier_rule": {"pred": """CASE r.mode
                          WHEN 'required' THEN CASE r.match WHEN 'all' THEN size(array_except(r.mods, l.mods)) > 0
                                                ELSE NOT arrays_overlap(l.mods, r.mods) END
                          WHEN 'allowed' THEN size(array_except(l.mods, r.mods)) > 0
                          ELSE arrays_overlap(l.mods, r.mods) END""",
                      "evidence": "concat('modifiers on the line: ', coalesce(nullif(array_join(l.mods, ' '), ''), 'none'))"},
    "pos_rule": {"pred": "l.pos IS NOT NULL AND CASE r.mode WHEN 'allowed' THEN NOT array_contains(r.pos, l.pos) "
                         "ELSE array_contains(r.pos, l.pos) END",
                 "evidence": "concat('place of service ', l.pos)"},
    "provider_type_rule": {"pred": f"""CASE r.role
                               WHEN 'billing' THEN {BILLING_TYPE} IS NOT NULL AND (array_contains(r.ptypes, {BILLING_TYPE}) = (r.mode = 'not_allowed'))
                               WHEN 'rendering' THEN l.rtype IS NOT NULL AND (array_contains(r.ptypes, l.rtype) = (r.mode = 'not_allowed'))
                               ELSE CASE r.mode WHEN 'allowed' THEN coalesce(l.btype, l.rtype) IS NOT NULL
                                         AND NOT coalesce(array_contains(r.ptypes, l.btype), false)
                                         AND NOT coalesce(array_contains(r.ptypes, l.rtype), false)
                                    ELSE coalesce(array_contains(r.ptypes, l.btype), false)
                                         OR coalesce(array_contains(r.ptypes, l.rtype), false) END END""",
                           "evidence": "concat('billing type ', coalesce(l.btype, 'blank'), ', servicing type ', coalesce(l.rtype, 'blank'))"},
    # a telehealth line (GT, GQ or FQ) with a modifier the code set does not list, or a place of service it does not
    # list; POS 02 or 10 alone is a coding question (TELEHEALTH_CODING_REASON), always a lead
    "telehealth_rule": {"pred": f"arrays_overlap(l.mods, {_TELE}) AND (({_TELE_MOD_BAD}) OR {_TELE_POS_BAD})",
                        "evidence": "concat('telehealth line: modifiers ', array_join(l.mods, ' '), ', place of service ', "
                                    "coalesce(l.pos, 'blank'))",
                        "check": f"CASE WHEN {_TELE_MOD_BAD} THEN 'telehealth_modifier' WHEN {_TELE_CODING} "
                                 "THEN 'telehealth_pos_code' ELSE 'telehealth_site' END",
                        "tier": f"CASE WHEN {_TELE_CODING} THEN 'lead' ELSE r.tier END",
                        "reasons": f"CASE WHEN {_TELE_CODING} THEN concat_ws('; ', nullif(r.reasons, ''), "
                                   f"'{TELEHEALTH_CODING_REASON}') ELSE r.reasons END"},
    "not_covered": {"pred": "true", "evidence": "'the code is billed'"},
    "units_limit": {"pred": "r.per = 'line' AND l.units > r.maxv",
                    "evidence": "concat(l.units, ' units on the line, most ', r.maxv)",
                    "tier": "CASE WHEN l.pa IS NOT NULL THEN 'lead' ELSE r.tier END",
                    "reasons": "CASE WHEN l.pa IS NOT NULL THEN concat_ws('; ', nullif(r.reasons, ''), "
                               + PA_REASON_SQL.format(pa="l.pa") + ") ELSE r.reasons END"},
}

FINDING_COLS = """r.rid AS record_id, r.part_of, r.kind, {check} AS check_type, {tier} AS tier, l.line_id, l.claim_id,
                  l.ln_no, l.member, l.bprov, l.sprov, l.code, l.dos, l.dos_end, l.days, l.units, l.paid,
                  l.pos, array_join(l.mods, ' ') AS mods, l.btype, l.rtype, l.pa,
                  {evidence} AS evidence, r.statement, r.source, r.version, r.locator, r.quote, {reasons} AS reasons"""
# the columns of a finding from a row of pie_applies (a) or pie_day_applies; tier and reasons may be overridden
_A_COLS = """a.rid AS record_id, a.part_of, a.kind, a.kind AS check_type, {tier} AS tier, a.line_id, a.claim_id,
             a.ln_no, a.member, a.bprov, a.sprov, a.code, a.dos, a.dos_end, a.days, a.units, a.paid, a.l_pos AS pos,
             a.mods_text AS mods, a.btype, a.rtype, a.pa"""
_A_TAIL = "a.statement, a.source, a.version, a.locator, a.quote, {reasons} AS reasons"
_A_GROUP = """a.rid, a.part_of, a.kind, a.tier, a.line_id, a.claim_id, a.ln_no, a.member, a.bprov, a.sprov, a.code,
              a.dos, a.dos_end, a.days, a.units, a.paid, a.l_pos, a.mods_text, a.btype, a.rtype, a.pa, a.statement,
              a.source, a.version, a.locator, a.quote, a.reasons"""
_PA_TIER = "CASE WHEN a.pa IS NOT NULL THEN 'lead' ELSE a.tier END"
_PA_REASONS = ("CASE WHEN a.pa IS NOT NULL THEN concat_ws('; ', nullif(a.reasons, ''), "
               + PA_REASON_SQL.format(pa="a.pa") + ") ELSE a.reasons END")
_A = _A_COLS.format(tier="a.tier")
_A_END = _A_TAIL.format(reasons="a.reasons")
_WINDOW = "l.dos >= to_date(r.start) AND l.dos <= coalesce(to_date(r.end), DATE'9999-12-31')"
# the days of a partner line overlap the days of the finding's line
_OVERLAP = "p.dos <= a.dos_end AND a.dos <= p.dos_end"
_PARTNER = ("concat(p.code, ' (line ', p.line_id, CASE WHEN p.days > 1 OR a.days > 1 "
            "THEN concat(', ', p.dos, ' to ', p.dos_end) ELSE '' END, ')')")


def sql_text(lines_view: str = "pie_lines") -> dict:
    """The SQL detection runs, as text: the view of rules joined to lines (pie_applies), the view of the days of the
    lines a limit per day judges (pie_day_applies), and the findings query. pie_rules is prepare()'s rows."""
    applies = f"""
        CREATE OR REPLACE TEMP VIEW pie_applies AS
        SELECT r.*, l.line_id, l.claim_id, l.ln_no, l.member, l.bprov, l.sprov, l.btype, l.rtype, l.mods AS l_mods,
               array_join(l.mods, ' ') AS mods_text, l.pos AS l_pos, l.pa, l.dos, l.dos_end, l.days, l.units, l.paid,
               CASE WHEN r.by_provider THEN concat_ws('|', coalesce(l.bprov, ''), coalesce(l.sprov, '')) END AS who
        FROM pie_rules r JOIN {lines_view} l ON l.code = r.code AND {_WINDOW}
        WHERE {COND_SQL}"""
    # limits per day: every day a line covers, inside the rule's window, with the line's units spread evenly
    day_applies = f"""
        CREATE OR REPLACE TEMP VIEW pie_day_applies AS
        SELECT j.*, j.units / j.days AS day_units
        FROM (SELECT r.*, l.line_id, l.claim_id, l.ln_no, l.member, l.bprov, l.sprov, l.btype, l.rtype,
                     array_join(l.mods, ' ') AS mods_text, l.pos AS l_pos, l.pa, l.dos, l.dos_end, l.days,
                     l.units, l.paid,
                     CASE WHEN r.by_provider THEN concat_ws('|', coalesce(l.bprov, ''), coalesce(l.sprov, '')) END AS who,
                     explode(sequence(l.dos, least(l.dos_end, date_add(l.dos, {MAX_SPAN_DAYS - 1})))) AS day
              FROM pie_rules r JOIN {lines_view} l
                ON l.code = r.code AND l.dos <= coalesce(to_date(r.end), DATE'9999-12-31')
                   AND l.dos_end >= to_date(r.start)
              WHERE r.kind IN ('units_limit', 'frequency_limit') AND r.per = 'day' AND {COND_SQL}) j
        WHERE j.day >= to_date(j.start) AND j.day <= coalesce(to_date(j.end), DATE'9999-12-31')"""
    parts = []
    for kind, spec in SINGLE_LINE.items():
        cols = FINDING_COLS.format(evidence=spec["evidence"], check=spec.get("check", "r.kind"),
                                   tier=spec.get("tier", "r.tier"), reasons=spec.get("reasons", "r.reasons"))
        parts.append(f"""SELECT {cols}
            FROM pie_rules r JOIN {lines_view} l ON l.code = r.code AND {_WINDOW}
            WHERE r.kind = '{kind}' AND {COND_SQL} AND ({spec['pred']})""")
    # a line is flagged once per rule, with its worst day (the earliest of equal days); the total is rounded so evenly
    # spread units add up exactly
    parts.append(f"""
        SELECT {_A_COLS.format(tier=_PA_TIER)},
               max_by(concat(round(g.total, 2), CASE a.kind WHEN 'units_limit' THEN ' units' ELSE ' services' END, ' on ', a.day,
                             CASE WHEN a.by_provider THEN ' from this provider' ELSE ' from all providers' END,
                             ', most ', a.maxv, '; lines ', g.lines,
                             CASE WHEN a.days > 1 THEN concat('; this line covers ', a.days, ' days (', a.units,
                                  ' units, read as ', round(a.units / a.days, 2), ' a day)') ELSE '' END),
                      named_struct('total', g.total, 'earlier', -datediff(a.day, DATE'1970-01-01')))
                 AS evidence,
               {_A_TAIL.format(reasons=_PA_REASONS)}
        FROM pie_day_applies a JOIN (
          SELECT group_key, member, day, who,
                 CASE WHEN kind = 'units_limit' THEN round(sum(day_units), 6) ELSE count(DISTINCT line_id) END AS total,
                 max(maxv) AS maxv, array_join(sort_array(collect_set(line_id)), ' ') AS lines
          FROM pie_day_applies
          GROUP BY group_key, member, day, who, kind
          HAVING total > max(maxv)) g
          ON g.group_key = a.group_key AND g.member = a.member AND g.day = a.day
             AND (g.who IS NULL AND a.who IS NULL OR g.who = a.who)
        GROUP BY {_A_GROUP}""")
    # pairs: the subject's line is the finding, the partner's line its evidence; days that overlap count as the same day
    parts.append(f"""
        SELECT {_A},
               concat('billed with ', array_join(sort_array(collect_set({_PARTNER})), ', '),
                      CASE WHEN first(a.by_provider) THEN ' by the same provider' ELSE '' END) AS evidence,
               {_A_END}
        FROM pie_applies a JOIN {lines_view} p
          ON p.member = a.member AND {_OVERLAP} AND p.line_id <> a.line_id
             AND array_contains(a.partners, p.code)
             AND (NOT a.by_provider OR (p.bprov = a.bprov AND p.sprov = a.sprov))
             AND NOT arrays_overlap(a.l_mods, a.bypass) AND NOT arrays_overlap(p.mods, a.bypass)
        WHERE a.kind = 'pair_prohibited'
        GROUP BY {_A_GROUP}""")
    # included in: the bundled line is the finding when its parent is billed on its days by the same billing provider
    parts.append(f"""
        SELECT {_A},
               concat('included in ', array_join(sort_array(collect_set({_PARTNER})), ', '),
                      ' billed the same day by the same billing provider') AS evidence,
               {_A_END}
        FROM pie_applies a JOIN {lines_view} p
          ON p.member = a.member AND {_OVERLAP} AND p.line_id <> a.line_id AND array_contains(a.parents, p.code)
             AND p.bprov = a.bprov
        WHERE a.kind = 'included_in'
        GROUP BY {_A_GROUP}""")
    return {"applies": applies, "day_applies": day_applies, "findings": "\nUNION ALL\n".join(parts)}


def code_sha() -> str:
    """The first 12 hex digits of this module's sha256: which detection code produced a run."""
    with open(os.path.abspath(__file__), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()[:12]


def run(spark, rules: list[dict], lines_view: str = "pie_lines"):
    """Findings as a Spark DataFrame (one row per flagged line per rule). rules: prepare()'s rule rows."""
    from pyspark.sql.types import StructType, StructField
    from pyspark.sql.types import _parse_datatype_string
    schema = StructType([StructField(n, _parse_datatype_string(t), True) for n, t in RULE_FIELDS])
    norm = [{n: (r.get(n) if r.get(n) is not None or not t.startswith("array") else []) for n, t in RULE_FIELDS}
            for r in rules]
    spark.createDataFrame(norm, schema).createOrReplaceTempView("pie_rules")
    sql = sql_text(lines_view)
    spark.sql(sql["applies"])
    spark.sql(sql["day_applies"])
    return spark.sql(sql["findings"])


def run_row(run_id: str, build_id, settings: dict, rules: list[dict], skipped: list[dict], lines: dict,
            found: dict, lines_sql_text: str, written: bool, notes: str = "") -> dict:
    """The kb_detect_runs row of a run. settings: claims_table, where_sql, ffs_where, forms, since, until,
    end_date_column; lines: lines_read, members, first_dos, last_dos, multi_day_lines, lines_with_pa_number;
    found: findings,
    lines_flagged, violation_lines, lead_lines, paid_on_flagged_lines."""
    from datetime import datetime, timezone
    from . import __version__
    sql = sql_text()
    forms = settings.get("forms")
    return {"run_id": run_id, "build_id": build_id, "run_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "pie_version": __version__, "detect_sha": code_sha(),
            **{k: (None if settings.get(k) is None else str(settings[k]))
               for k in ("claims_table", "where_sql", "ffs_where", "since", "until", "end_date_column")},
            "forms": ",".join(forms) if isinstance(forms, (list, tuple)) else forms,
            "records_run": len({r["part_of"] for r in rules}), "rule_rows": len(rules),
            "records_not_run": len({s["part_of"] for s in skipped}),
            **{k: lines.get(k) for k in ("lines_read", "members", "multi_day_lines", "lines_with_pa_number")},
            **{k: (None if lines.get(k) is None else str(lines[k])) for k in ("first_dos", "last_dos")},
            **{k: found.get(k) for k in ("findings", "lines_flagged", "violation_lines", "lead_lines",
                                         "paid_on_flagged_lines")},
            "lines_sql": lines_sql_text, "applies_sql": sql["applies"], "day_applies_sql": sql["day_applies"],
            "findings_sql": sql["findings"], "written": written, "notes": notes}


def coverage(rules: list[dict], skipped: list[dict]) -> list[dict]:
    """Records that ran and records that did not, by kind and reason (one row per record, not per code)."""
    ran = {}
    for r in rules:
        ran.setdefault((r["kind"], r["tier"]), set()).add(r["part_of"])
    out = [{"kind": k, "status": f"runs ({t})", "why": "", "records": len(v)} for (k, t), v in sorted(ran.items())]
    miss = Counter((s["kind"], s["why"]) for s in {s["part_of"]: s for s in skipped}.values())
    out += [{"kind": k, "status": "does not run", "why": w, "records": n} for (k, w), n in sorted(miss.items())]
    return out
