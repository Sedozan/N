"""The investigator tables (pie_kb/bi.py): rule periods merged from editions; policy_rules by code; flagged_lines
(one row per line, priority, the main issue, the claim facts) and line_issues on local Spark."""
import json
from datetime import date

import pytest

from pie_kb import bi as B
from pie_kb import config


def row(rid, key, start, end, cls="executable", status="approved", presumed=False, src="AX", part_of=None,
        kind="units_limit", params=None, subject=None, statement=None, locator=None, resolved=None):
    return {"build_id": "build-20261123T165718Z-464d", "record_id": rid, "part_of": part_of or rid.split("~")[0],
            "record_key": key, "kind": kind, "subject": json.dumps(subject or {"codes": ["H0004"]}),
            "params": json.dumps(params if params is not None else {"max": 32, "per": "day", "unit_basis": "unit"}),
            "statement": statement or f"{key} statement.", "source_id": src, "document_key": "main",
            "source_version_id": f"{src}@{start}#abcd1234", "status": status, "status_basis": "approve by ss",
            "review": json.dumps({"reviewer": "ss", "decided_at": "2026-11-23T10:00:00"}),
            "effective_start": start, "effective_end": end, "presumed_from": start if presumed else None,
            "execution_class": cls, "execution_reasons": json.dumps([]), "resolved_codes": json.dumps(resolved or []),
            "citation": json.dumps({"title": "Test source", "locator": locator or f"row of {start}", "quote": "words"})}


CURRENT = [
    # one limit held in three editions, presumed between the second and the third and after the third
    row("R-a1", "K1", "2024-06-10", "2024-09-09"),
    row("R-a2", "K1", "2024-09-10", "2025-03-08"),
    row("R-a2~2025-03-09", "K1", "2025-03-09", "2026-09-13", cls="conditional", presumed=True, part_of="R-a2"),
    row("R-a3", "K1", "2026-09-14", "2026-12-13", locator="sheet 'September 2026' row 12494"),
    row("R-a3~2026-12-14", "K1", "2026-12-14", None, cls="conditional", presumed=True, part_of="R-a3"),
    # a gap (an edition in between rejected): two periods; the later wording wins in the later one
    row("R-b1", "K2", "2025-01-01", "2025-04-14", kind="modifier_rule", params={"mode": "required", "modifiers": ["HQ"]}),
    row("R-b2", "K2", "2025-04-15", "2025-09-30", kind="modifier_rule", status="rejected", params={}),
    row("R-b3", "K2", "2025-10-01", None, kind="modifier_rule", params={"mode": "required", "modifiers": ["HQ"]},
        statement="H0004 requires modifier HQ (when two or more members)."),
    # a change of level (an exception appears): two periods; the partner code is listed
    row("R-c1", "K3", "2025-01-21", "2025-06-30", kind="pair_prohibited", params={"partners": ["H0014"]}),
    row("R-c2", "K3", "2025-07-01", None, cls="conditional", kind="pair_prohibited", params={"partners": ["H0014"]}),
    # presumed rows only; a documentation rule through a service category; never shown: waiting, proposed
    row("R-d1~2023-02-11", "K4", "2023-02-11", None, cls="conditional", presumed=True, part_of="R-d1", src="A9",
        kind="not_covered", params={}),
    row("R-g1", "K7", "2026-10-01", None, cls="knowledge", kind="documentation_required", params={},
        subject={"category": "counseling services"}, resolved=["H0004", "90832"]),
    row("R-h1", "K8", "2026-10-22", None, status="needs_review", kind="not_covered", params={}),
    row("R-i1", "K9", "2026-11-01", None, status="proposed", kind="pos_rule", params={"mode": "allowed", "pos": ["11"]}),
]
REGISTRY = [{"source_id": "AX", "document_key": "main", "title": "Test source", "url": "https://example.org/x"},
            {"source_id": "A4", "document_key": "main", "title": "AHCCCS Telehealth Code Set",
             "url": "https://example.org/th"}]


@pytest.fixture(scope="module")
def built():
    return B.rules(CURRENT, REGISTRY)


def rule(built, kind, **match):
    got = [r for r in built["policy_rules"] if r["rule_type"] == B.KIND_NAMES[kind]
           and all(r[k] == v for k, v in match.items())]
    return got


def test_editions_of_one_rule_become_one_row_per_code(built):
    r = rule(built, "units_limit")
    assert len(r) == 1
    r = r[0]
    assert (r["code"], r["how_code_is_involved"]) == ("H0004", "Main code")
    assert (r["in_force_from"], r["in_force_to"]) == (date(2024, 6, 10), None)
    assert r["level"] == "Violation" and "presumed" in r["why_level"]
    assert r["where_in_source"] == "sheet 'September 2026' row 12494" and r["source_link"] == "https://example.org/x"
    recs = sorted((x["record_id"], x["effective_start"], x["effective_end"]) for x in built["rule_records"]
                  if x["rule_key"] == r["rule_key"])
    assert recs == [("R-a1", "2024-06-10", "2024-09-09"), ("R-a2", "2024-09-10", "2026-09-13"),
                    ("R-a3", "2026-09-14", None)]


def test_a_gap_or_a_change_of_level_starts_another_row(built):
    mods = sorted((x["in_force_from"], x["in_force_to"], x["rule"]) for x in rule(built, "modifier_rule"))
    assert [m[:2] for m in mods] == [(date(2025, 1, 1), date(2025, 4, 14)), (date(2025, 10, 1), None)]
    assert mods[1][2].endswith("(when two or more members).")
    pairs = sorted((x["code"], x["in_force_from"], x["level"], x["how_code_is_involved"])
                   for x in rule(built, "pair_prohibited"))
    assert pairs == [("H0004", date(2025, 1, 21), "Violation", "Main code"),
                     ("H0004", date(2025, 7, 1), "Lead", "Main code"),
                     ("H0014", date(2025, 1, 21), "Violation", "Partner code"),
                     ("H0014", date(2025, 7, 1), "Lead", "Partner code")]


def test_levels_and_what_never_shows(built):
    assert rule(built, "not_covered")[0]["level"] == "Lead"                      # presumed rows only
    docs = rule(built, "documentation_required")
    assert {(d["code"], d["how_code_is_involved"], d["level"]) for d in docs} == \
        {("H0004", "Through a service category", "Reference only"), ("90832", "Through a service category",
                                                                     "Reference only")}
    assert not rule(built, "pos_rule") and len(rule(built, "not_covered")) == 1   # proposed and waiting stay out
    keys = [(r["rule_key"], r["code"], r["how_code_is_involved"]) for r in built["policy_rules"]]
    assert len(keys) == len(set(keys))
    assert {r["rule_key"] for r in B.rules(list(reversed(CURRENT)), REGISTRY)["policy_rules"]} == \
        {r["rule_key"] for r in built["policy_rules"]}


def test_every_layout_is_small_commented_and_keyed():
    assert set(B.SPEC) == {"flagged_lines", "line_issues", "policy_rules"}
    assert sum(len(sp["columns"]) for sp in B.SPEC.values()) <= 55
    for name, sp in B.SPEC.items():
        cols = [c for c, _, _ in sp["columns"]]
        assert len(cols) == len(set(cols)) and all(m for _, _, m in sp["columns"]) and sp["comment"], name
        assert set(sp["pk"]) <= set(cols), name
    r = B.rules(CURRENT, REGISTRY)["policy_rules"][0]
    assert set(r) | {"service"} == {c for c, _, _ in B.SPEC["policy_rules"]["columns"]}
    assert not any(isinstance(v, (dict, list)) for v in r.values())


# ---------------------------------------------------------------- local Spark
pytest.importorskip("pyspark")


@pytest.fixture(scope="module")
def monkeypatch_module():
    mp = pytest.MonkeyPatch()
    yield mp
    mp.undo()


@pytest.fixture(scope="module")
def spark():
    from pyspark.sql import SparkSession
    return (SparkSession.builder.master("local[2]").appName("pie-bi-test").config("spark.sql.ansi.enabled", "true")
            .config("spark.ui.enabled", "false").config("spark.sql.shuffle.partitions", "2").getOrCreate())


FCOLS = ("run_id string, build_id string, record_id string, part_of string, kind string, check_type string, "
         "tier string, line_id string, claim_id string, ln_no string, member string, bprov string, sprov string, "
         "code string, dos date, dos_end date, days int, units double, paid double, pos string, mods string, "
         "btype string, rtype string, pa string, evidence string, statement string, source string, version string, "
         "locator string, quote string, reasons string")
NEW, OLD = "detect-20261124T010000Z-aaaa", "detect-20261101T000000Z-bbbb"


def f(run, rid, part, kind, check, tier, line, code="H0004", paid=100.0, pa=None, pos="11", btype="77", reasons=""):
    return (run, "b", rid, part, kind, check, tier, line, line.split("-")[0], "1", "M1", "P1", "S1", code,
            date(2026, 10, 1), date(2026, 10, 1), 1, 5.0, paid, pos, "GT", btype, btype, pa, f"found {check}",
            f"rule {check}.", "Test source", "AX@2026-09-14#abcd1234", "row 9", "words", reasons)


FINDINGS = [
    # a line with a violation and a lead: one row, High, the violation is its main issue
    f(NEW, "R-a3", "R-a3", "units_limit", "units_limit", "violation", "C1-1"),
    f(NEW, "R-c2", "R-c2", "pair_prohibited", "pair_prohibited", "lead", "C1-1", reasons="exception"),
    # leads only: Medium; a PA number on the line
    f(NEW, "R-a3~2026-12-14", "R-a3", "units_limit", "units_limit", "lead", "C2-1", pa="PA9", reasons="PA on line"),
    # only the POS 02/10 coding question: Low
    f(NEW, "R-e1", "R-e1", "telehealth_rule", "telehealth_pos_code", "lead", "C3-1", pos="10", reasons="TPL"),
    # two violations: the more serious kind is the main issue
    f(NEW, "R-b3", "R-b3", "modifier_rule", "modifier_rule", "violation", "C5-1"),
    f(NEW, "R-d1~2023-02-11", "R-d1", "not_covered", "not_covered", "violation", "C5-1"),
    # a rule no longer approved; an older run that must not show
    f(NEW, "R-gone", "R-gone", "not_covered", None, "violation", "C4-1", code="T1016"),
    f(OLD, "R-a3", "R-a3", "units_limit", "units_limit", "violation", "C9-1"),
]


@pytest.fixture(scope="module")
def published(spark, tmp_path_factory, monkeypatch_module):
    from pie_kb.io.store import SparkStore
    root = tmp_path_factory.mktemp("bi")
    for attr, v in (("CATALOG", "spark_catalog"), ("SCHEMA", "pie_bi_kb"), ("BI_SCHEMA", "pie_bi_out"),
                    ("TABLE_FORMAT", "parquet")):
        monkeypatch_module.setattr(config, attr, v)
    for sch in ("pie_bi_kb", "pie_bi_out"):
        spark.sql(f"DROP SCHEMA IF EXISTS spark_catalog.{sch} CASCADE")
        spark.sql(f"CREATE SCHEMA spark_catalog.{sch} LOCATION '{root / sch}'")
    store = SparkStore(spark)
    store.write("records_current", CURRENT)
    store.write("source_registry", REGISTRY)
    store.write("table_rows", [
        {"source_version_id": "A1@2026-10-01#x", "source_id": "A1", "spec": "b2", "row_key": "H0004|77",
         "locator": "r", "data": json.dumps({"code": "H0004", "description": "BEHAVIORAL HEALTH COUNSELING"})},
        {"source_version_id": "A3@2026-09-14#x", "source_id": "A3", "spec": "daily_limits", "row_key": "H0004",
         "locator": "r", "data": json.dumps({"code": "H0004", "description": "older wording"})},
        {"source_version_id": "A25@2026-10-20#x", "source_id": "A25", "spec": "pep903", "row_key": "77|GROUP",
         "locator": "r", "data": json.dumps({"code": "77", "name": "BH OUTPATIENT CLINIC"})}])
    # a table of the 7.1.7 layout, dropped on publish
    spark.sql(f"CREATE TABLE {config.bi_table('rules_by_code')} (x STRING) USING parquet")
    rules_out = B.publish_rules(spark, store)
    again = B.publish_rules(spark, store)
    spark.createDataFrame(FINDINGS, FCOLS).write.format("parquet").mode("overwrite") \
        .saveAsTable(config.table("findings"))
    fin = B.publish_findings(spark)
    return rules_out, again, fin


def test_policy_rules_are_published_with_the_service_and_replace(spark, published):
    rules_out, again, _ = published
    n = len(B.rules(CURRENT, REGISTRY)["policy_rules"])
    assert rules_out["counts"]["policy_rules"] == again["counts"]["policy_rules"] == n
    assert any("rules_by_code" in w for w in rules_out["warnings"])
    assert not spark.catalog.tableExists(config.bi_table("rules_by_code"))
    got = spark.table(config.bi_table("policy_rules")).where("code = 'H0004'").select("service").distinct().collect()
    assert [r[0] for r in got] == ["BEHAVIORAL HEALTH COUNSELING"]                 # B2 before daily limits
    assert dict(spark.table(config.bi_table("policy_rules")).dtypes)["in_force_from"] == "date"
    assert spark.table(config.table("rule_records")).count() == len(B.rules(CURRENT, REGISTRY)["rule_records"])


def test_flagged_lines_one_row_per_line_with_priority(spark, published):
    _, _, fin = published
    assert fin["run_id"] == NEW and fin["counts"] == {"flagged_lines": 5, "line_issues": 7}
    lines = {r["line_id"]: r.asDict() for r in spark.table(config.bi_table("flagged_lines")).collect()}
    assert set(lines) == {"C1-1", "C2-1", "C3-1", "C4-1", "C5-1"}                  # the older run is not shown
    assert lines["C5-1"]["main_issue"] == "Service not covered"
    c1, c2, c3 = lines["C1-1"], lines["C2-1"], lines["C3-1"]
    assert (c1["priority"], c1["level"], c1["issue_count"], c1["main_issue"]) == \
        ("High", "Violation", 2, "Over the unit limit")
    assert c1["all_issues"] == "Billed with a service not allowed the same day; Over the unit limit"
    assert c1["main_finding"] == "rule units_limit. Found: found units_limit"
    assert (c1["billing_provider_type"], c1["service"], c1["paid"]) == \
        ("77 BH OUTPATIENT CLINIC", "BEHAVIORAL HEALTH COUNSELING", 100.0)
    assert (c2["priority"], c2["pa_number"]) == ("Medium", "PA9")
    assert (c3["priority"], c3["place_of_service"], c3["modifiers"]) == ("Low", "10", "GT")
    assert c1["detected_on"] == date(2026, 11, 24) and c1["main_policy"] == "Test source, row 9"
    assert sum(r["paid"] for r in lines.values()) == 500.0                         # each line once


def test_line_issues_carry_the_evidence_and_the_policy(spark, published):
    issues = [r.asDict() for r in spark.table(config.bi_table("line_issues")).collect()]
    by = {(r["line_id"], r["issue"]): r for r in issues}
    v = by[("C1-1", "Over the unit limit")]
    assert v["level"] == "Violation" and v["why_lead"] is None and v["source_link"] == "https://example.org/x"
    rk = {x["record_id"]: x["rule_key"] for x in B.rules(CURRENT, REGISTRY)["rule_records"]}
    assert v["rule_key"] == rk["R-a3"]
    assert by[("C2-1", "Over the unit limit")]["why_lead"] == "PA on line"
    assert by[("C4-1", "Service not covered")]["rule_key"] is None                 # no longer approved
    assert len({r["issue_key"] for r in issues}) == len(issues)
